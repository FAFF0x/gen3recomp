local build = (... and ...) or "."
local mainPath = build .. "/main.lua"

local stack = { layers = {} }
function stack.push(id, mod, opts) stack.layers[#stack.layers+1] = {id=id,mod=mod,opts=opts} end
function stack.pop(id) if stack.layers[#stack.layers] and stack.layers[#stack.layers].id == id then table.remove(stack.layers) end end
function stack.top() return stack.layers[#stack.layers] end

local pokemon = {
  _evolutions = { [1] = { { target = 2 } } },
  _learnsets = { [1]={{1,10},{5,20}}, [2]={{10,30}} },
  install=function() end,
  speciesOf=function(mon) return mon.species end,
  evolutions=function(sp) return pokemon._evolutions[sp] or {} end,
  learnset=function(sp) return pokemon._learnsets[sp] or {} end,
  moveIdAt=function(mon,i) return mon.moves[i] end,
  moveName=function(id) return "MOVE"..tostring(id) end,
  battleMove=function(id) return { pp=20,power=40,accuracy=100,type=0,category="physical",priority=0,target="FOE",effect=0 } end,
  moveMaxPp=function() return 20 end,
  isHmMove=function(id) return id==99 end,
  displayName=function(mon) return mon.nickname or "MON" end,
  replaceMove=function(mon,slot,id) local old=mon.moves[slot]; if old==99 then return nil,"hm" end; mon.moves[slot]=id; mon.pp[slot]=20; mon.maxPp[slot]=20; return old end,
  teachMove=function(mon,id) for i=1,4 do if not mon.moves[i] then mon.moves[i]=id; mon.pp[i]=20; mon.maxPp[i]=20; return true,i end end return false end,
  swapMoves=function(mon,a,b) mon.moves[a],mon.moves[b]=mon.moves[b],mon.moves[a]; mon.pp[a],mon.pp[b]=mon.pp[b],mon.pp[a]; return true end,
}
local party = { open=false,mode="list",cursor=1,ACTIONS={},actionCursor=1,_battle=false }
function party.close() party.open=false; stack.pop("party") end
function party.show(p,ov,opts) party.open=true; party._party=p; party._session=opts.session; party.mode="list"; stack.push("party",party,{}) end
function party.handleInput(input)
  if party.mode=="list" and input:wasPressed("a") then party.mode="action"; party.ACTIONS={"SUMMARY","SWITCH","ITEM","CANCEL"}; party.actionCursor=1 end
end

package.preload["src.ui.game3.stack"] = function() return stack end
package.preload["src.ui.game3.party_menu"] = function() return party end
package.preload["src.core.game3.pokemon"] = function() return pokemon end
package.preload["src.core.game3.battle.moves"] = function() return { numForName=function() end, get=pokemon.battleMove, displayName=pokemon.moveName } end
package.preload["src.core.game3.battle.types"] = function() return { name=function() return "NORMAL" end, isPhysical=function() return true end } end
package.preload["src.core.game3.summary_data"] = function() return { moveDescription=function() return "desc" end } end
package.preload["src.ui.game3.frlg_font"] = function() return { draw=function() end } end
package.preload["src.core.game3.runtime"] = function() return { getSession=function() return nil end } end

local hooks = {}
local events = {}
local mod = {
  generation=3,
  hooks={wrap=function(_,name,fn,priority) hooks[name]=fn end},
  events={on=function(_,name,fn) events[name]=fn end},
  exports={},
  log={warn=function() end},
}

local chunk = assert(loadfile(mainPath))
chunk()(mod)
assert(mod.exports.generation==3 and mod.exports.fireRedOnly==true)
assert(type(mod.exports.replaceMove)=="function" and type(mod.exports.swapMoves)=="function")
assert(type(hooks["render.hud"])=="function")

local mon={species=2,level=10,nickname="TEST",moves={10,20,30,40},pp={10,11,12,13},maxPp={20,20,20,20}}
local session={party={mon}}
party.open=true; party._party=session.party; party._session=session; party.mode="list"; party.cursor=1; stack.push("party",party,{})
local pressed={a=true}
local input={wasPressed=function(_,k) return pressed[k] or false end}
party.handleInput(input)
assert(party.mode=="action")
local found
for i,a in ipairs(party.ACTIONS) do if a=="MOVES" then found=i end end
assert(found,"MOVES action not injected")
party.actionCursor=found
party.handleInput(input)
assert(stack.top() and stack.top().id=="moves_manager_gen3","manager not opened")

local ok,old,slot=mod.exports.replaceMove(mon,1,30)
assert(ok==false and old=="duplicate")
local ok2=mod.exports.swapMoves(mon,1,2)
assert(ok2 and mon.moves[1]==20 and mon.moves[2]==10)
print("moves-manager-gen3-contract-ok")
