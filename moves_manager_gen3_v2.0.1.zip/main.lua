-- Moves Manager - Gen 3 / FireRed
-- Native FireRed port of moves_manager_gen2.
-- Uses game3 Pokemon APIs for HM protection, PP-safe move replacement and
-- PP/PP-Up-safe reordering.  A custom game3 stack layer owns input; an
-- optional window-space presenter keeps the screen compatible with Modern UI.

local MOD_ID = "moves_manager_gen3"
local VERSION = "2.0.1"
local SCREEN_ID = "moves_manager_gen3"
local MEMORY_FIELD = "movesManagerGen3Memory"

local function clamp(v, lo, hi)
  v = math.floor(tonumber(v) or lo)
  if v < lo then return lo end
  if v > hi then return hi end
  return v
end

local function fit(text, n)
  text = tostring(text or "")
  if #text <= n then return text end
  if n <= 1 then return text:sub(1, n) end
  return text:sub(1, n - 1) .. "."
end

local function humanize(value)
  if value == nil then return "--" end
  local s = tostring(value):gsub("_", " ")
  return s
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local function req(name)
    local ok, value = pcall(require, name)
    if ok then return value end
    if mod.log and mod.log.warn then
      mod.log:warn("%s: unable to load %s: %s", MOD_ID, name, tostring(value))
    end
    return nil
  end

  local Stack = req("src.ui.game3.stack")
  local PartyMenu = req("src.ui.game3.party_menu")
  local Pokemon = req("src.core.game3.pokemon")
  local Moves = req("src.core.game3.battle.moves")
  local Types = req("src.core.game3.battle.types")
  local SummaryData = req("src.core.game3.summary_data")
  local FrlgFont = req("src.ui.game3.frlg_font")
  local Runtime = req("src.core.game3.runtime")

  if not (Stack and PartyMenu and Pokemon and FrlgFont) then return end

  local function resolveMoveId(value)
    local n = tonumber(value)
    if n and n > 0 then return n end
    if type(value) == "string" and Moves and type(Moves.numForName) == "function" then
      local ok, out = pcall(Moves.numForName, value)
      out = ok and tonumber(out) or nil
      if out and out > 0 then return out end
    end
    return nil
  end

  local function moveDef(id)
    id = resolveMoveId(id)
    if not id then return nil end
    if type(Pokemon.battleMove) == "function" then
      local ok, d = pcall(Pokemon.battleMove, id)
      if ok and d then return d end
    end
    if Moves and type(Moves.get) == "function" then
      local ok, d = pcall(Moves.get, id)
      if ok then return d end
    end
    return nil
  end

  local function moveName(id)
    id = resolveMoveId(id)
    if not id then return "-------" end
    if type(Pokemon.moveName) == "function" then
      local ok, n = pcall(Pokemon.moveName, id)
      if ok and n and n ~= "" then return tostring(n) end
    end
    if Moves and type(Moves.displayName) == "function" then
      local ok, n = pcall(Moves.displayName, id)
      if ok and n and n ~= "" then return tostring(n) end
    end
    return "MOVE " .. tostring(id)
  end

  local function typeName(def)
    if not def then return "--" end
    local t = def.type or def.kind
    if Types and type(Types.name) == "function" then
      local ok, n = pcall(Types.name, t)
      if ok and n then return tostring(n) end
    end
    return humanize(t)
  end

  local function categoryName(def)
    if not def then return "--" end
    local c = def.category
    if type(c) == "string" and c ~= "" then return c:upper() end
    if (tonumber(def.power) or 0) <= 0 then return "STATUS" end
    if Types and type(Types.isPhysical) == "function" then
      local ok, physical = pcall(Types.isPhysical, def.type or def.kind)
      if ok then return physical and "PHYSICAL" or "SPECIAL" end
    end
    return "--"
  end

  local function moveDescription(id)
    if SummaryData and type(SummaryData.moveDescription) == "function" then
      local ok, text = pcall(SummaryData.moveDescription, id, moveName(id))
      if ok and text and text ~= "" then return tostring(text) end
    end
    return "No move description available."
  end

  local function currentMoveId(mon, slot)
    if not mon then return nil end
    if type(Pokemon.moveIdAt) == "function" then
      local ok, id = pcall(Pokemon.moveIdAt, mon, slot)
      if ok then return resolveMoveId(id) end
    end
    local raw = mon.moves and mon.moves[slot]
    if type(raw) == "table" then raw = raw.id or raw.move or raw.moveId or raw.num or raw[1] end
    return resolveMoveId(raw)
  end

  local function currentPp(mon, slot, id)
    if not mon then return 0 end
    if type(mon.pp) == "table" and tonumber(mon.pp[slot]) then return tonumber(mon.pp[slot]) end
    local raw = mon.moves and mon.moves[slot]
    if type(raw) == "table" and tonumber(raw.pp) then return tonumber(raw.pp) end
    local d = moveDef(id)
    return (d and tonumber(d.pp)) or 0
  end

  local function maxPp(mon, slot, id)
    if mon and type(mon.maxPp) == "table" and tonumber(mon.maxPp[slot]) then
      return tonumber(mon.maxPp[slot])
    end
    local raw = mon and mon.moves and mon.moves[slot]
    if type(raw) == "table" and tonumber(raw.maxPp) then return tonumber(raw.maxPp) end
    if type(Pokemon.moveMaxPp) == "function" then
      local ok, v = pcall(Pokemon.moveMaxPp, id)
      if ok and tonumber(v) then return tonumber(v) end
    end
    local d = moveDef(id)
    return (d and tonumber(d.pp)) or 0
  end

  local function memoryFor(mon)
    if type(mon) ~= "table" then return { order = {}, known = {} } end
    local memory = mon[MEMORY_FIELD]
    if type(memory) ~= "table" then
      memory = { order = {}, known = {} }
      mon[MEMORY_FIELD] = memory
    end
    if type(memory.order) ~= "table" then memory.order = {} end
    if type(memory.known) ~= "table" then memory.known = {} end
    for _, id in ipairs(memory.order) do memory.known[tostring(id)] = true end
    return memory
  end

  local function remember(mon, value)
    local id = resolveMoveId(value)
    if not id or type(mon) ~= "table" then return end
    local memory = memoryFor(mon)
    local key = tostring(id)
    if memory.known[key] then return end
    memory.known[key] = true
    memory.order[#memory.order + 1] = id
  end

  local reverseEvolutionCache
  local function reverseEvolutionMap()
    if reverseEvolutionCache then return reverseEvolutionCache end
    reverseEvolutionCache = {}
    pcall(function() if Pokemon.install then Pokemon.install(nil) end end)
    local raw = Pokemon._evolutions
    local function accept(source, rows)
      source = tonumber(source)
      if not source or type(rows) ~= "table" then return end
      for _, evo in ipairs(rows) do
        local target = tonumber(evo.target or evo.species or evo.to or evo[3])
        if target and target > 0 then
          local list = reverseEvolutionCache[target]
          if not list then list = {}; reverseEvolutionCache[target] = list end
          local found = false
          for _, v in ipairs(list) do if v == source then found = true break end end
          if not found then list[#list + 1] = source end
        end
      end
    end
    if type(raw) == "table" then
      for source, rows in pairs(raw) do accept(source, rows) end
    elseif type(Pokemon.evolutions) == "function" then
      for source = 1, 512 do
        local ok, rows = pcall(Pokemon.evolutions, source)
        if ok then accept(source, rows) end
      end
    end
    for _, rows in pairs(reverseEvolutionCache) do table.sort(rows) end
    return reverseEvolutionCache
  end

  local function evolutionLine(mon)
    local species = type(Pokemon.speciesOf) == "function" and Pokemon.speciesOf(mon)
      or tonumber(mon and (mon.species or mon.speciesId))
    local out, seen = {}, {}
    local reverse = reverseEvolutionMap()
    local function visit(id)
      id = tonumber(id)
      if not id or seen[id] then return end
      seen[id] = true
      for _, parent in ipairs(reverse[id] or {}) do visit(parent) end
      out[#out + 1] = id
    end
    visit(species)
    return out
  end

  local function seedMemory(mon)
    if type(mon) ~= "table" then return memoryFor(mon) end
    local level = clamp(mon.level or 1, 1, 100)
    for _, species in ipairs(evolutionLine(mon)) do
      if type(Pokemon.learnset) == "function" then
        local ok, rows = pcall(Pokemon.learnset, species)
        if ok and type(rows) == "table" then
          for _, row in ipairs(rows) do
            local lv = tonumber(row.level or row[1]) or 0
            local mv = resolveMoveId(row.move or row[2])
            if mv and lv <= level then remember(mon, mv) end
          end
        end
      end
    end
    for i = 1, 4 do
      local id = currentMoveId(mon, i)
      if id then remember(mon, id) end
    end
    return memoryFor(mon)
  end

  local function knownSlot(mon, id)
    id = resolveMoveId(id)
    if not id then return nil end
    for i = 1, 4 do
      if currentMoveId(mon, i) == id then return i end
    end
    return nil
  end

  local function learnedRows(mon)
    local memory = seedMemory(mon)
    local rows = {}
    for _, raw in ipairs(memory.order) do
      local id = resolveMoveId(raw)
      if id and moveDef(id) and not knownSlot(mon, id) then
        rows[#rows + 1] = { id = id, name = moveName(id) }
      end
    end
    return rows
  end

  local function replaceMove(mon, slot, moveId)
    moveId = resolveMoveId(moveId)
    slot = clamp(slot or 1, 1, 4)
    if not mon or not moveId or not moveDef(moveId) then return false, "unknown_move" end
    local duplicate = knownSlot(mon, moveId)
    if duplicate and duplicate ~= slot then return false, "duplicate" end
    local oldId = currentMoveId(mon, slot)
    if oldId and oldId == moveId then return false, "same_move" end
    if oldId and type(Pokemon.isHmMove) == "function" and Pokemon.isHmMove(oldId) then
      return false, "hm_locked"
    end
    if oldId then remember(mon, oldId) end
    remember(mon, moveId)

    if oldId then
      local old, why = Pokemon.replaceMove(mon, slot, moveId)
      if not old then return false, why or "replace_failed" end
      return true, old, slot
    end

    if type(Pokemon.teachMove) == "function" then
      local ok, actual = Pokemon.teachMove(mon, moveId)
      if ok then return true, nil, actual or slot end
    end
    return false, "no_slot"
  end

  local function swapMoves(mon, a, b)
    if not mon then return false end
    if not currentMoveId(mon, a) or not currentMoveId(mon, b) then return false end
    if type(Pokemon.swapMoves) == "function" then
      local ok, result = pcall(Pokemon.swapMoves, mon, a, b)
      return ok and result == true
    end
    return false
  end

  local Manager = {
    open = false,
    mode = "known",
    slot = 1,
    pool = {},
    poolIndex = 1,
    poolScroll = 0,
    detailPage = 1,
    swapSlot = nil,
    notice = nil,
  }

  local function selectedId()
    return currentMoveId(Manager.mon, Manager.slot)
  end

  local function candidate()
    return Manager.pool[Manager.poolIndex]
  end

  local function monName()
    if not Manager.mon then return "POKéMON" end
    if type(Pokemon.displayName) == "function" then
      local ok, n = pcall(Pokemon.displayName, Manager.mon)
      if ok and n then return tostring(n) end
    end
    return tostring(Manager.mon.nickname or Manager.mon.name or "POKéMON")
  end

  local function syncPool()
    local n = #Manager.pool
    if n <= 0 then
      Manager.poolIndex, Manager.poolScroll = 1, 0
      return
    end
    Manager.poolIndex = clamp(Manager.poolIndex, 1, n)
    if Manager.poolIndex < Manager.poolScroll + 1 then Manager.poolScroll = Manager.poolIndex - 1 end
    if Manager.poolIndex > Manager.poolScroll + 7 then Manager.poolScroll = Manager.poolIndex - 7 end
    Manager.poolScroll = clamp(Manager.poolScroll, 0, math.max(0, n - 7))
  end

  local function openPool()
    local id = selectedId()
    if id and type(Pokemon.isHmMove) == "function" and Pokemon.isHmMove(id) then
      Manager.notice = "HM moves can't be forgotten."
      return
    end
    Manager.pool = learnedRows(Manager.mon)
    Manager.poolIndex = 1
    Manager.poolScroll = 0
    Manager.mode = "pool"
    Manager.notice = nil
  end

  function Manager.show(mon, session, opts)
    opts = opts or {}
    if type(mon) ~= "table" or mon.isEgg then return false end
    seedMemory(mon)
    Manager.open = true
    Manager.mon = mon
    Manager.session = session
    Manager.mode = "known"
    Manager.slot = 1
    for i = 1, 4 do if currentMoveId(mon, i) then Manager.slot = i break end end
    Manager.pool = {}
    Manager.poolIndex = 1
    Manager.poolScroll = 0
    Manager.detailPage = 1
    Manager.swapSlot = nil
    Manager.notice = nil
    Manager.returnToParty = opts.returnToParty == true
    Manager.partyCursor = opts.partyCursor or 1
    Stack.push(SCREEN_ID, Manager, { hideBelow = true })
    return true
  end

  function Manager.close()
    if not Manager.open then return end
    Manager.open = false
    Stack.pop(SCREEN_ID)
    local reopen = Manager.returnToParty
    local session = Manager.session
    local cursor = Manager.partyCursor
    Manager.returnToParty = false
    Manager.session = nil
    Manager.mon = nil
    if reopen and session and PartyMenu and type(PartyMenu.show) == "function" then
      PartyMenu.show(session.party, session.move_overlay or session.moveOverlay, { session = session })
      if PartyMenu.open then PartyMenu.cursor = clamp(cursor, 1, math.max(1, #(session.party or {}))) end
    end
  end

  local function teachCandidate()
    local row = candidate()
    if not row then return end
    local oldId = selectedId()
    local oldName = oldId and moveName(oldId) or nil
    local ok, reason, actualSlot = replaceMove(Manager.mon, Manager.slot, row.id)
    if not ok then
      if reason == "duplicate" then Manager.notice = monName() .. " already knows that move."
      elseif reason == "hm_locked" then Manager.notice = "HM moves can't be forgotten."
      elseif reason == "same_move" then Manager.notice = "That move is already in this slot."
      else Manager.notice = "That move can't be selected." end
      return
    end
    Manager.slot = actualSlot or Manager.slot
    Manager.mode = "known"
    Manager.swapSlot = nil
    Manager.notice = oldName and ("Forgot " .. oldName .. "; learned " .. moveName(row.id) .. ".")
      or ("Learned " .. moveName(row.id) .. ".")
  end

  function Manager.handleInput(input)
    if not Manager.open or not input then return end
    local function pressed(k) return input.wasPressed and input:wasPressed(k) end
    Manager.notice = Manager.notice

    if Manager.mode == "known" then
      if pressed("up") then
        Manager.slot = Manager.slot > 1 and Manager.slot - 1 or 4
        Manager.notice = nil
      elseif pressed("down") then
        Manager.slot = Manager.slot < 4 and Manager.slot + 1 or 1
        Manager.notice = nil
      elseif pressed("select") then
        if Manager.swapSlot then
          if Manager.swapSlot == Manager.slot then
            Manager.swapSlot = nil
          elseif swapMoves(Manager.mon, Manager.swapSlot, Manager.slot) then
            Manager.swapSlot = nil
          end
        elseif selectedId() then
          Manager.swapSlot = Manager.slot
        end
        Manager.notice = nil
      elseif pressed("a") then
        if Manager.swapSlot then
          if Manager.swapSlot == Manager.slot then
            Manager.swapSlot = nil
          elseif swapMoves(Manager.mon, Manager.swapSlot, Manager.slot) then
            Manager.swapSlot = nil
          end
        elseif selectedId() then
          Manager.mode = "current_detail"
          Manager.detailPage = 1
          Manager.notice = nil
        else
          openPool()
        end
      elseif pressed("b") or pressed("start") then
        if Manager.swapSlot then Manager.swapSlot = nil else Manager.close() end
      end
      return
    end

    if Manager.mode == "pool" then
      local n = #Manager.pool
      if n == 0 then
        if pressed("a") or pressed("b") then Manager.mode = selectedId() and "current_detail" or "known" end
        return
      end
      if pressed("up") then Manager.poolIndex = Manager.poolIndex > 1 and Manager.poolIndex - 1 or n
      elseif pressed("down") then Manager.poolIndex = Manager.poolIndex < n and Manager.poolIndex + 1 or 1
      elseif pressed("left") then Manager.poolIndex = math.max(1, Manager.poolIndex - 7)
      elseif pressed("right") then Manager.poolIndex = math.min(n, Manager.poolIndex + 7)
      elseif pressed("a") then Manager.mode = "candidate_detail"; Manager.detailPage = 1
      elseif pressed("b") then Manager.mode = selectedId() and "current_detail" or "known" end
      syncPool()
      return
    end

    local isCandidate = Manager.mode == "candidate_detail"
    if pressed("left") then Manager.detailPage = Manager.detailPage > 1 and Manager.detailPage - 1 or 2
    elseif pressed("right") or pressed("select") then Manager.detailPage = Manager.detailPage < 2 and Manager.detailPage + 1 or 1
    elseif pressed("a") then
      if isCandidate then teachCandidate() else openPool() end
    elseif pressed("b") then
      Manager.mode = isCandidate and "pool" or "known"
      Manager.detailPage = 1
      Manager.notice = nil
    end
  end

  local COLORS = {
    bg = { 16/255, 28/255, 48/255, 1 },
    panel = { 232/255, 240/255, 250/255, 1 },
    panel2 = { 212/255, 226/255, 245/255, 1 },
    ink = { 28/255, 42/255, 63/255, 1 },
    accent = { 40/255, 104/255, 181/255, 1 },
    yellow = { 245/255, 192/255, 50/255, 1 },
    muted = { 96/255, 116/255, 142/255, 1 },
    white = { 1, 1, 1, 1 },
    danger = { 176/255, 54/255, 54/255, 1 },
  }

  local function color(c, a)
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * (a or 1))
  end

  local function box(x, y, w, h, fill, border)
    color(fill or COLORS.panel)
    love.graphics.rectangle("fill", x, y, w, h, 2, 2)
    if border then
      color(border)
      love.graphics.rectangle("line", x + 0.5, y + 0.5, w - 1, h - 1, 2, 2)
    end
  end

  local function text(str, x, y, col, small, maxWidth)
    FrlgFont.draw(tostring(str or ""), x, y, {
      small = small == true,
      maxWidth = maxWidth,
      colors = { fg = col or COLORS.ink, shadow = { 1, 1, 1, 0 } },
    })
  end

  local function drawMoveRow(slot, y, selected)
    local id = currentMoveId(Manager.mon, slot)
    box(8, y, 224, 26, selected and COLORS.panel2 or COLORS.panel, selected and COLORS.yellow or COLORS.accent)
    if Manager.swapSlot == slot then
      color(COLORS.yellow); love.graphics.rectangle("fill", 8, y, 5, 26)
    elseif selected then
      color(COLORS.accent); love.graphics.rectangle("fill", 8, y, 4, 26)
    end
    text(tostring(slot), 15, y + 6, COLORS.muted, true)
    if id then
      local d = moveDef(id)
      text(fit(moveName(id), 17), 32, y + 3, COLORS.ink, false, 105)
      text(typeName(d), 145, y + 3, COLORS.accent, true, 52)
      text(string.format("PP %d/%d", currentPp(Manager.mon, slot, id), maxPp(Manager.mon, slot, id)), 145, y + 14, COLORS.muted, true, 74)
    else
      text("EMPTY SLOT", 32, y + 8, COLORS.muted, false)
    end
  end

  local function detailData(id, slot)
    local d = moveDef(id) or {}
    return {
      name = moveName(id),
      type = typeName(d),
      category = categoryName(d),
      power = (tonumber(d.power) or 0) > 0 and tostring(d.power) or "---",
      accuracy = (tonumber(d.accuracy) or 0) > 0 and tostring(d.accuracy) or "---",
      pp = slot and string.format("%d/%d", currentPp(Manager.mon, slot, id), maxPp(Manager.mon, slot, id))
        or tostring((d and d.pp) or 0),
      priority = tostring(d.priority or 0),
      target = humanize(d.target),
      effect = humanize(d.effect),
      chance = tostring(d.secondaryChance or d.effectChance or 0) .. "%",
      description = moveDescription(id),
    }
  end

  local function drawDetails(id, slot, candidateMode)
    if not id then return end
    local d = detailData(id, slot)
    text(fit(d.name, 24), 10, 8, COLORS.white, false, 145)
    text("PAGE " .. tostring(Manager.detailPage) .. "/2", 181, 9, COLORS.white, true)
    box(8, 24, 224, 106, COLORS.panel, COLORS.accent)
    if Manager.detailPage == 1 then
      local rows = {
        { "TYPE", d.type }, { "CLASS", d.category }, { "POWER", d.power },
        { "ACCURACY", d.accuracy }, { "PP", d.pp }, { "PRIORITY", d.priority },
      }
      for i, row in ipairs(rows) do
        local y = 31 + (i - 1) * 15
        text(row[1], 16, y, COLORS.muted, true)
        text(row[2], 91, y, COLORS.ink, false, 128)
      end
    else
      text("TARGET", 16, 31, COLORS.muted, true); text(fit(d.target, 20), 91, 31, COLORS.ink, false)
      text("EFFECT", 16, 47, COLORS.muted, true); text(fit(d.effect, 20), 91, 47, COLORS.ink, false)
      text("CHANCE", 16, 63, COLORS.muted, true); text(d.chance, 91, 63, COLORS.ink, false)
      text("DESCRIPTION", 16, 82, COLORS.muted, true)
      text(d.description, 16, 96, COLORS.ink, true, 205)
    end
    text(candidateMode and "A TEACH" or "A CHANGE", 10, 137, COLORS.white, true)
    text("←→ PAGE   B BACK", 108, 137, COLORS.white, true)
  end

  function Manager.draw()
    if not Manager.open or not (love and love.graphics) then return end
    love.graphics.push("all")
    love.graphics.origin()
    love.graphics.setScissor()
    color(COLORS.bg); love.graphics.rectangle("fill", 0, 0, 240, 160)
    color(COLORS.accent); love.graphics.rectangle("fill", 0, 0, 240, 20)

    if Manager.mode == "known" then
      text("MOVES MANAGER", 8, 5, COLORS.white, false)
      text(fit(monName(), 14), 144, 6, COLORS.white, true)
      for i = 1, 4 do drawMoveRow(i, 25 + (i - 1) * 28, Manager.slot == i) end
      if Manager.notice then text(fit(Manager.notice, 37), 8, 140, COLORS.yellow, true, 224)
      elseif Manager.swapSlot then text("A/SELECT SWAP   B CANCEL", 8, 140, COLORS.white, true)
      else text("A DETAILS   SELECT SWAP   B BACK", 8, 140, COLORS.white, true) end
    elseif Manager.mode == "pool" then
      text("REMEMBERED MOVES", 8, 5, COLORS.white, false)
      text(string.format("%d/%d", math.min(Manager.poolIndex, #Manager.pool), #Manager.pool), 202, 6, COLORS.white, true)
      box(8, 25, 224, 105, COLORS.panel, COLORS.accent)
      if #Manager.pool == 0 then
        text("No other remembered moves.", 20, 70, COLORS.muted, false)
      else
        for row = 1, 7 do
          local idx = Manager.poolScroll + row
          local entry = Manager.pool[idx]
          if not entry then break end
          local yy = 29 + (row - 1) * 14
          if idx == Manager.poolIndex then
            color(COLORS.panel2); love.graphics.rectangle("fill", 11, yy - 1, 218, 14)
            color(COLORS.accent); love.graphics.rectangle("fill", 11, yy - 1, 4, 14)
          end
          local d = moveDef(entry.id)
          text(fit(entry.name, 20), 19, yy, COLORS.ink, true, 130)
          text(typeName(d), 164, yy, COLORS.accent, true, 60)
        end
      end
      text("A DETAILS   ←→ PAGE   B BACK", 8, 140, COLORS.white, true)
    else
      local cand = Manager.mode == "candidate_detail"
      local id = cand and (candidate() and candidate().id) or selectedId()
      drawDetails(id, cand and nil or Manager.slot, cand)
      if Manager.notice then text(fit(Manager.notice, 36), 10, 122, COLORS.danger, true, 215) end
    end
    love.graphics.pop()
  end

  -- High-resolution window-space presenter.  gen3_modern_ui intentionally only
  -- redraws stock FireRed stack IDs; this presenter owns our custom screen so
  -- the manager remains visually coherent when Modern UI is active.
  local windowFonts = {}
  local function wfont(size)
    size = math.max(10, math.floor(size + 0.5))
    if windowFonts[size] then return windowFonts[size] end
    local ok, f = pcall(love.graphics.newFont, size)
    if ok then windowFonts[size] = f; return f end
    return nil
  end

  local function wtext(value, x, y, size, col, width, align)
    local f = wfont(size)
    if f then love.graphics.setFont(f) end
    color(col or COLORS.ink)
    if width then love.graphics.printf(tostring(value or ""), x, y, width, align or "left")
    else love.graphics.print(tostring(value or ""), x, y) end
  end

  local function modernLayout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
    local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
    local s = math.max(0.75, math.min(w / 720, h / 480))
    return { x=x, y=y, w=w, h=h, s=s, pad=22*s, gap=14*s, header=62*s, footer=48*s }
  end

  local function drawModern(game, viewport)
    if not Manager.open or not viewport or not (love and love.graphics) then return end
    local top = Stack.top and Stack.top() or nil
    if not top or top.id ~= SCREEN_ID then return end
    local L = modernLayout(viewport)
    local ok, err = pcall(function()
      love.graphics.push("all")
      love.graphics.origin()
      love.graphics.setScissor(L.x, L.y, L.w, L.h)
      color(COLORS.bg); love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
      color(COLORS.accent); love.graphics.rectangle("fill", L.x, L.y, L.w, L.header)
      wtext("MOVES MANAGER", L.x + L.pad, L.y + 14*L.s, 27*L.s, COLORS.white)
      wtext(monName(), L.x + L.w*0.58, L.y + 20*L.s, 17*L.s, COLORS.white, L.w*0.36, "right")
      local contentY = L.y + L.header + L.gap
      local contentH = L.h - L.header - L.footer - L.gap*2
      local footerY = L.y + L.h - L.footer
      color({10/255,21/255,37/255,1}); love.graphics.rectangle("fill", L.x, footerY, L.w, L.footer)

      if Manager.mode == "known" then
        local rowH = contentH / 4 - 4*L.s
        for i=1,4 do
          local yy = contentY + (i-1)*(rowH+5*L.s)
          color(Manager.slot==i and COLORS.panel2 or COLORS.panel); love.graphics.rectangle("fill", L.x+L.pad, yy, L.w-L.pad*2, rowH, 8*L.s,8*L.s)
          if Manager.slot==i then color(COLORS.yellow); love.graphics.rectangle("fill", L.x+L.pad, yy, 6*L.s,rowH,8*L.s,0) end
          local id=currentMoveId(Manager.mon,i)
          wtext(tostring(i),L.x+L.pad+16*L.s,yy+rowH*0.32,15*L.s,COLORS.muted)
          if id then
            local d=moveDef(id)
            wtext(moveName(id),L.x+L.pad+52*L.s,yy+10*L.s,21*L.s,COLORS.ink,L.w*0.42)
            wtext(typeName(d).."  "..categoryName(d),L.x+L.w*0.62,yy+10*L.s,14*L.s,COLORS.accent,L.w*0.28,"right")
            wtext(string.format("PP %d / %d",currentPp(Manager.mon,i,id),maxPp(Manager.mon,i,id)),L.x+L.w*0.62,yy+34*L.s,14*L.s,COLORS.muted,L.w*0.28,"right")
          else
            wtext("EMPTY SLOT",L.x+L.pad+52*L.s,yy+rowH*0.34,19*L.s,COLORS.muted)
          end
        end
        wtext(Manager.notice or (Manager.swapSlot and "A / SELECT  SWAP     B  CANCEL" or "A  DETAILS     SELECT  SWAP     B  BACK"),L.x+L.pad,footerY+14*L.s,16*L.s,Manager.notice and COLORS.yellow or COLORS.white,L.w-L.pad*2,"center")
      elseif Manager.mode == "pool" then
        local leftW=L.w*0.57
        color(COLORS.panel); love.graphics.rectangle("fill",L.x+L.pad,contentY,leftW-L.pad-L.gap,contentH,8*L.s,8*L.s)
        local rowH=contentH/7
        for row=1,7 do
          local idx=Manager.poolScroll+row; local e=Manager.pool[idx]; if not e then break end
          local yy=contentY+(row-1)*rowH
          if idx==Manager.poolIndex then color(COLORS.panel2); love.graphics.rectangle("fill",L.x+L.pad+5*L.s,yy+3*L.s,leftW-L.pad-L.gap-10*L.s,rowH-6*L.s,6*L.s,6*L.s) end
          wtext(e.name,L.x+L.pad+18*L.s,yy+rowH*0.27,17*L.s,COLORS.ink,leftW*0.55)
          wtext(typeName(moveDef(e.id)),L.x+leftW-95*L.s,yy+rowH*0.30,13*L.s,COLORS.accent,80*L.s,"right")
        end
        local e=candidate(); local rx=L.x+leftW; local rw=L.w-L.pad-rx+L.x
        color(COLORS.panel); love.graphics.rectangle("fill",rx,contentY,rw,contentH,8*L.s,8*L.s)
        if e then
          local d=detailData(e.id,nil)
          wtext(d.name,rx+18*L.s,contentY+18*L.s,22*L.s,COLORS.ink,rw-36*L.s)
          wtext(d.type.." • "..d.category,rx+18*L.s,contentY+55*L.s,14*L.s,COLORS.accent,rw-36*L.s)
          wtext("POWER  "..d.power,rx+18*L.s,contentY+95*L.s,15*L.s,COLORS.muted)
          wtext("ACC.   "..d.accuracy,rx+18*L.s,contentY+125*L.s,15*L.s,COLORS.muted)
          wtext("PP     "..d.pp,rx+18*L.s,contentY+155*L.s,15*L.s,COLORS.muted)
          wtext(d.description,rx+18*L.s,contentY+205*L.s,14*L.s,COLORS.ink,rw-36*L.s)
        end
        wtext("A  DETAILS     ← →  PAGE     B  BACK",L.x+L.pad,footerY+14*L.s,16*L.s,COLORS.white,L.w-L.pad*2,"center")
      else
        local cand=Manager.mode=="candidate_detail"; local id=cand and (candidate() and candidate().id) or selectedId(); local d=id and detailData(id,cand and nil or Manager.slot)
        color(COLORS.panel); love.graphics.rectangle("fill",L.x+L.pad,contentY,L.w-L.pad*2,contentH,8*L.s,8*L.s)
        if d then
          wtext(d.name,L.x+L.pad+24*L.s,contentY+18*L.s,26*L.s,COLORS.ink,L.w*0.55)
          wtext("PAGE "..Manager.detailPage.." / 2",L.x+L.w*0.72,contentY+24*L.s,14*L.s,COLORS.muted,L.w*0.20,"right")
          if Manager.detailPage==1 then
            local rows={{"TYPE",d.type},{"CLASS",d.category},{"POWER",d.power},{"ACCURACY",d.accuracy},{"PP",d.pp},{"PRIORITY",d.priority}}
            for i,r in ipairs(rows) do local yy=contentY+(62+(i-1)*42)*L.s; wtext(r[1],L.x+L.pad+30*L.s,yy,14*L.s,COLORS.muted); wtext(r[2],L.x+L.pad+180*L.s,yy,18*L.s,COLORS.ink) end
          else
            wtext("TARGET",L.x+L.pad+30*L.s,contentY+76*L.s,14*L.s,COLORS.muted); wtext(d.target,L.x+L.pad+180*L.s,contentY+72*L.s,18*L.s,COLORS.ink)
            wtext("EFFECT",L.x+L.pad+30*L.s,contentY+126*L.s,14*L.s,COLORS.muted); wtext(d.effect,L.x+L.pad+180*L.s,contentY+122*L.s,18*L.s,COLORS.ink)
            wtext("CHANCE",L.x+L.pad+30*L.s,contentY+176*L.s,14*L.s,COLORS.muted); wtext(d.chance,L.x+L.pad+180*L.s,contentY+172*L.s,18*L.s,COLORS.ink)
            wtext(d.description,L.x+L.pad+30*L.s,contentY+230*L.s,15*L.s,COLORS.ink,L.w-L.pad*2-60*L.s)
          end
        end
        wtext((cand and "A  TEACH" or "A  CHANGE").."     ← →  PAGE     B  BACK",L.x+L.pad,footerY+14*L.s,16*L.s,COLORS.white,L.w-L.pad*2,"center")
      end
      love.graphics.setScissor()
      love.graphics.pop()
    end)
    if not ok then
      pcall(love.graphics.setScissor)
      pcall(love.graphics.pop)
      if mod.log and mod.log.warn then mod.log:warn("%s modern presenter failed: %s",MOD_ID,tostring(err)) end
    end
  end

  local function injectMovesAction()
    if not (PartyMenu.open and PartyMenu.mode == "action") then return end
    if PartyMenu._battle then return end
    local mon = PartyMenu._party and PartyMenu._party[PartyMenu.cursor]
    if not mon or mon.isEgg then return end
    local actions = PartyMenu.ACTIONS
    if type(actions) ~= "table" then return end
    for _, act in ipairs(actions) do if act == "MOVES" then return end end
    local at = #actions + 1
    for i, act in ipairs(actions) do
      if act == "CANCEL" then at = i; break end
      if act == "ITEM" then at = i + 1 end
    end
    table.insert(actions, at, "MOVES")
  end

  local function installPartyPatch()
    if PartyMenu._movesManagerGen3Installed then return true end
    local previous = PartyMenu.handleInput
    if type(previous) ~= "function" then return false end
    PartyMenu.handleInput = function(input)
      injectMovesAction()
      if PartyMenu.open and PartyMenu.mode == "action" and input and input.wasPressed
          and input:wasPressed("a") then
        local act = PartyMenu.ACTIONS and PartyMenu.ACTIONS[PartyMenu.actionCursor]
        if act == "MOVES" then
          local mon = PartyMenu._party and PartyMenu._party[PartyMenu.cursor]
          local session = PartyMenu._session
          local cursor = PartyMenu.cursor
          if mon and not mon.isEgg then
            pcall(function() require("src.core.game3.audio").playSe(5) end)
            PartyMenu.close()
            Manager.show(mon, session, { returnToParty = true, partyCursor = cursor })
          end
          return
        end
      end
      local result = previous(input)
      injectMovesAction()
      return result
    end
    PartyMenu._movesManagerGen3Installed = MOD_ID
    return true
  end

  installPartyPatch()

  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result = nextFn(game, viewport)
    drawModern(game, viewport)
    return result
  end, 200)

  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("game.ready", function()
      installPartyPatch()
    end)
    mod.events:on("pokemon.move_learned", function(event)
      if event and event.mon then remember(event.mon, event.moveNum or event.moveId) end
    end)
  end

  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.fireRedOnly = true
  mod.exports.open = function(mon, session)
    session = session or (Runtime and Runtime.getSession and Runtime.getSession())
    return Manager.show(mon, session, { returnToParty = false })
  end
  mod.exports.learnedMoves = function(mon)
    local memory = seedMemory(mon)
    local out = {}
    for _, id in ipairs(memory.order) do out[#out + 1] = id end
    return out
  end
  mod.exports.replaceMove = replaceMove
  mod.exports.swapMoves = swapMoves
  mod.exports.screenId = SCREEN_ID
end
