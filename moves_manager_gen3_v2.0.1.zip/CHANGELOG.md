# Changelog

## 2.0.1 - Gen 3 / FireRed port

- Ported the mod from Gen2 to FireRed's native game3 runtime.
- Changed internal ID to `moves_manager_gen3` and target to `firered` only.
- Replaced direct Gen2 move-table edits with `Pokemon.replaceMove`, `Pokemon.teachMove` and `Pokemon.swapMoves`.
- Added FireRed HM protection.
- Rebuilt remembered-move reconstruction around Gen3 learnsets and evolution data.
- Added native game3 stack UI and a high-resolution Modern UI-compatible presenter.
- Added Party menu **MOVES** integration without declaring conflicts against other mods.
