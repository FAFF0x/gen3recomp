# Changelog

## 1.2.0

- Changed the Start-menu shortcut from a direct generic BOX browser to FireRed's native PC flow.
- Native PC now acts as the mode selector: WITHDRAW, DEPOSIT, MOVE POKéMON, MOVE ITEMS, SEE YA!.
- Integrated Advanced Box into FireRed's native `box_storage_ui.show` path for WITHDRAW / DEPOSIT / MOVE.
- Added explicit WITHDRAW mode: A immediately withdraws the highlighted BOX Pokémon to PARTY.
- Added explicit DEPOSIT mode: A immediately deposits the highlighted PARTY Pokémon into the first free slot of the current BOX.
- MOVE mode is now clearly labelled MOVE / SWAP and retains two-step party/box swaps.
- B returns from Advanced Box to the PC storage menu through the original FireRed `onClose` callback.
- Physical PCs use the same advanced WITHDRAW / DEPOSIT / MOVE screens.
- MOVE ITEMS deliberately remains native FireRed for correct held-item behavior.
- Preserved live Pokémon details and the v1.1.2 HELP/L-R compatibility fix.

## 1.1.2

- Temporarily suspended FireRed HELP while Advanced Box is open so L/R can safely change boxes.
- Restored HELP automatically when the Advanced Box closes.

## 1.1.1

- Added BOX header navigation with LEFT/RIGHT.

## 1.1.0

- Added simultaneous PARTY / BOX / live details layout and direct swap workflow.
