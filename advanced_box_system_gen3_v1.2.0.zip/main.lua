-- Advanced Box System Gen 3 for Pokemon Recomp / FireRed
-- v1.2.0
--
-- FireRed-only PC-first storage workflow with an advanced PARTY <-> BOX browser.
-- FireRed owns the PC menu and storage data; the mod replaces only the Pokémon browser for selected modes.

local VERSION = "1.2.0"
local MOD_ID = "advanced_box_system_gen3"

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local function req(name)
    local ok, value = pcall(require, name)
    if ok then return value end
    if mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("%s: unable to load %s: %s", MOD_ID, name, tostring(value))
    end
    return nil
  end

  local function readModule(rel)
    local source = mod:read(rel)
    if not source then error("[" .. MOD_ID .. "] missing mod file: " .. rel) end
    return assert(load(source, "@" .. MOD_ID .. "/" .. rel))()
  end

  local Runtime = req("src.core.game3.runtime")
  local Storage = req("src.core.game3.storage")
  local PcMenu = req("src.ui.game3.pc_menu")
  local NativeBoxUI = req("src.ui.game3.box_storage_ui")
  if not Storage then return end

  local makeUi = readModule("src/advanced_box_ui.lua")
  local BoxUI = makeUi(mod)

  local function currentSession(game, session)
    if type(session) == "table" then return session end
    if Runtime and type(Runtime.getSession) == "function" then
      local ok, live = pcall(Runtime.getSession)
      if ok and type(live) == "table" then return live end
    end
    if game and type(game.session) == "table" then return game.session end
    return nil
  end

  local function openBox(game, session, mode, onClose)
    local live = currentSession(game, session)
    if not live then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("%s: BOX requested without an active FireRed session", MOD_ID)
      end
      return false
    end
    Storage.ensure(live)
    return BoxUI.show(live, { mode = mode or "move", onClose = onClose })
  end

  local function openPc(game, session)
    local live = currentSession(game, session)
    if not live then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("%s: PC requested without an active FireRed session", MOD_ID)
      end
      return false
    end
    Storage.ensure(live)
    if PcMenu and type(PcMenu.show) == "function" then
      PcMenu.show({ session = live })
      return true
    end
    return openBox(game, live, "move")
  end

  -- Integrate the advanced browser into FireRed's real PC workflow instead of
  -- replacing the PC menu.  The native PC still owns the mode selection.
  -- WITHDRAW / DEPOSIT / MOVE open our clearer browser; MOVE ITEMS remains
  -- native because FireRed already has precise item-transfer semantics.
  if NativeBoxUI and type(NativeBoxUI.show) == "function" then
    -- Keep the pre-mod implementation so a hot reload can replace our wrapper
    -- without stacking wrappers or retaining an old BoxUI closure. If another
    -- mod patched the function first, that patched function becomes our
    -- fallback and remains in the chain.
    if type(NativeBoxUI._advancedBoxSystemGen3BaseShow) ~= "function" then
      NativeBoxUI._advancedBoxSystemGen3BaseShow = NativeBoxUI.show
    end
    local baseShow = NativeBoxUI._advancedBoxSystemGen3BaseShow
    NativeBoxUI.show = function(opts)
      opts = opts or {}
      local subMode = tostring(opts.subMode or "move")
      if subMode == "withdraw" or subMode == "deposit" or subMode == "move" then
        local live = currentSession(nil, opts.session)
        if live then
          Storage.ensure(live)
          return BoxUI.show(live, { mode = subMode, onClose = opts.onClose })
        end
      end
      return baseShow(opts)
    end
    NativeBoxUI._advancedBoxSystemGen3PatchVersion = VERSION
  end

  mod.exports.open = function(game, mode, session)
    if mode == "pc" or mode == nil then return openPc(game, session) end
    return openBox(game, session, mode)
  end
  mod.exports.openRemote = function(game, session)
    return openPc(game, session)
  end
  mod.exports.openBox = function(game, mode, session)
    return openBox(game, session, mode or "move")
  end
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.fireRedOnly = true
  mod.exports.boxCount = Storage.TOTAL_BOXES_COUNT or 14
  mod.exports.boxCapacity = Storage.IN_BOX_COUNT or 30
  mod.exports.nativeStorage = true
  mod.exports.screenId = BoxUI.SCREEN_ID
  mod.exports.isOpen = BoxUI.isOpen

  -- High-resolution presentation. The logical screen itself lives on the
  -- FireRed UI stack, which gives it exclusive input without replacing the
  -- game's storage state or save format.
  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result = nextFn(game, viewport)
    if BoxUI.isOpen() then
      local ok, err = pcall(BoxUI.drawWindow, viewport)
      if not ok and mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("%s: Advanced Box render failed: %s", MOD_ID, tostring(err))
      end
    end
    return result
  end)

  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then return out end

    for _, entry in ipairs(out) do
      if entry and (entry.absAdvancedBoxRemote == true
          or entry.id == "advanced_box_system_gen3_pc") then
        return out
      end
    end

    local row = {
      id = "advanced_box_system_gen3_pc",
      label = "PC",
      desc = { "POKéMON STORAGE", "Deposit / Withdraw / Move" },
      absAdvancedBoxRemote = true,
      absAdvancedBoxGen3 = true,
      onSelect = function(g, session)
        return openPc(g or game, session)
      end,
    }

    if mod.ui and type(mod.ui.insertBefore) == "function" then
      return mod.ui.insertBefore(out, "SAVE", row)
    end

    local insertAt = #out + 1
    for i, entry in ipairs(out) do
      if entry and entry.label == "SAVE" then insertAt = i; break end
    end
    table.insert(out, insertAt, row)
    return out
  end)

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info("%s v%s installed: FireRed PC flow + advanced BOX/PARTY browser", MOD_ID, VERSION)
  end
end
