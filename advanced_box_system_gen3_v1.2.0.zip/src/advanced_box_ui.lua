-- Advanced Box System Gen 3 - custom FireRed storage browser.
-- Window-space presentation + native Game3 storage operations.

return function(mod)
  local Storage = require("src.core.game3.storage")
  local Pokemon = require("src.core.game3.pokemon")
  local ItemsData = require("src.core.game3.items_data")
  local Types = require("src.core.game3.battle.types")
  local SummaryData = require("src.core.game3.summary_data")
  local Stack = require("src.ui.game3.stack")
  local Help = require("src.ui.game3.help_system")

  local UI = {
    open = false,
    session = nil,
    focus = "box", -- box | party | box_header
    boxCursor = 1,
    partyCursor = 1,
    pending = nil, -- { loc, slot, boxId, mon }
    message = nil,
    messageTimer = 0,
    hoverPhase = 0,
    helpOverrideActive = false,
    helpEnabledBefore = nil,
    mode = "move", -- withdraw | deposit | move
    onClose = nil,
  }

  local SCREEN_ID = "advanced_box_system_gen3_browser"
  local fonts = {}

  local THEME = {
    bg = { 0.045, 0.070, 0.115, 0.985 },
    header = { 0.055, 0.115, 0.205, 1 },
    surface = { 0.965, 0.980, 1.000, 1 },
    raised = { 0.900, 0.935, 0.980, 1 },
    selected = { 0.985, 0.790, 0.175, 1 },
    selectedSoft = { 1.000, 0.925, 0.610, 1 },
    accent = { 0.105, 0.400, 0.750, 1 },
    accent2 = { 0.890, 0.185, 0.150, 1 },
    text = { 0.045, 0.075, 0.130, 1 },
    muted = { 0.300, 0.365, 0.455, 1 },
    border = { 0.350, 0.475, 0.625, 1 },
    white = { 1, 1, 1, 1 },
    green = { 0.090, 0.620, 0.390, 1 },
    yellow = { 0.920, 0.650, 0.100, 1 },
    red = { 0.800, 0.180, 0.120, 1 },
    empty = { 0.820, 0.850, 0.890, 1 },
  }

  local TYPE_COLORS = {
    NORMAL={0.61,0.61,0.49,1}, FIGHTING={0.72,0.18,0.15,1}, FLYING={0.53,0.66,0.89,1},
    POISON={0.58,0.25,0.61,1}, GROUND={0.75,0.59,0.28,1}, ROCK={0.63,0.53,0.22,1},
    BUG={0.55,0.66,0.12,1}, GHOST={0.39,0.32,0.58,1}, STEEL={0.56,0.60,0.66,1},
    FIRE={0.91,0.34,0.16,1}, WATER={0.25,0.50,0.86,1}, GRASS={0.32,0.68,0.29,1},
    ELECTRIC={0.92,0.74,0.13,1}, PSYCHIC={0.93,0.33,0.53,1}, ICE={0.44,0.75,0.78,1},
    DRAGON={0.40,0.28,0.78,1}, DARK={0.32,0.27,0.24,1}, UNKNOWN={0.46,0.55,0.54,1},
  }

  local function clamp(v, a, b)
    v = math.floor(tonumber(v) or a)
    if v < a then return a end
    if v > b then return b end
    return v
  end

  local function font(size)
    size = math.max(12, math.floor((tonumber(size) or 12) + 0.5))
    local key = tostring(size)
    if fonts[key] then return fonts[key] end
    local ok, f = pcall(love.graphics.newFont, size)
    if not ok or not f then f = love.graphics.getFont() end
    if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    fonts[key] = f
    return f
  end

  local function setColor(c, alpha)
    alpha = alpha or 1
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * alpha)
  end

  local function roundRect(mode, x, y, w, h, r)
    love.graphics.rectangle(mode, x, y, w, h, r or 7, r or 7)
  end

  local function text(value, x, y, size, color, width, align)
    love.graphics.setFont(font(size))
    setColor(color or THEME.text)
    if width then
      love.graphics.printf(tostring(value or ""), x, y, width, align or "left")
    else
      love.graphics.print(tostring(value or ""), x, y)
    end
  end

  local function fit(s, n)
    s = tostring(s or "")
    if #s <= n then return s end
    if n <= 1 then return s:sub(1, n) end
    return s:sub(1, n - 1) .. "…"
  end

  local function panel(x, y, w, h, selected, soft)
    setColor(selected and (soft and THEME.selectedSoft or THEME.raised) or THEME.surface)
    roundRect("fill", x, y, w, h, 8)
    setColor(selected and THEME.selected or THEME.border, selected and 1 or 0.58)
    love.graphics.setLineWidth(selected and 2 or 1)
    roundRect("line", x, y, w, h, 8)
  end

  local function speciesOf(mon)
    if not mon then return nil end
    local ok, sp = pcall(Pokemon.speciesOf, mon)
    if ok then return sp end
    return tonumber(mon.species or mon.speciesId)
  end

  local function monName(mon)
    if not mon then return "EMPTY" end
    local ok, n = pcall(Pokemon.displayName, mon)
    if ok and n and n ~= "" then return tostring(n) end
    local sp = speciesOf(mon)
    if sp then
      local ok2, sn = pcall(Pokemon.name, sp)
      if ok2 and sn then return tostring(sn) end
    end
    return "POKéMON"
  end

  local function speciesName(mon)
    local sp = speciesOf(mon)
    if not sp then return "----" end
    local ok, n = pcall(Pokemon.name, sp)
    return ok and tostring(n or sp) or tostring(sp)
  end

  local function drawIcon(mon, x, y, size)
    if not mon then return end
    local sp = speciesOf(mon)
    if not sp then return end
    local ok, icon = pcall(Pokemon.icon, sp)
    if not ok or not (icon and icon.image) then return end
    local q = icon.quads and (icon.quads[0] or icon.quads[1])
    local iw = tonumber(icon.w) or 32
    local ih = tonumber(icon.h) or 32
    setColor(THEME.white)
    if q then
      love.graphics.draw(icon.image, q, x, y, 0, size / iw, size / ih)
    else
      local rw, rh = icon.image:getDimensions()
      love.graphics.draw(icon.image, x, y, 0, size / rw, size / rh)
    end
  end

  local function currentStorage()
    if not UI.session then return nil end
    return Storage.ensure(UI.session)
  end

  local function currentBox()
    local storage = currentStorage()
    if not storage then return nil, 1 end
    local id = clamp(storage.currentBox or 1, 1, Storage.TOTAL_BOXES_COUNT or 14)
    return storage.boxes and storage.boxes[id] or nil, id
  end

  local function party()
    if not UI.session then return {} end
    UI.session.party = UI.session.party or {}
    return UI.session.party
  end

  local function boxMon(slot)
    local box = currentBox()
    return box and box.mons and box.mons[slot] or nil
  end

  local function partyMon(slot)
    return party()[slot]
  end

  local function hoveredMon()
    if UI.focus == "party" then return partyMon(UI.partyCursor) end
    -- Keep the currently highlighted box Pokémon visible even while the
    -- BOX header is selected for box-to-box navigation.
    return boxMon(UI.boxCursor)
  end

  local function message(s)
    UI.message = tostring(s or "")
    UI.messageTimer = 2.4
  end

  local function switchBox(delta)
    local storage = currentStorage()
    if not storage then return end
    -- A BOX-origin swap must keep its source box stable. A PARTY-origin move
    -- may browse other boxes freely because only the destination changes.
    if UI.pending and UI.pending.loc == "box" then
      message("Finish or cancel the current swap first")
      return
    end
    local keepHeader = UI.focus == "box_header"
    local n = Storage.TOTAL_BOXES_COUNT or 14
    storage.currentBox = ((clamp(storage.currentBox or 1, 1, n) - 1 + delta) % n) + 1
    UI.boxCursor = clamp(UI.boxCursor, 1, Storage.IN_BOX_COUNT or 30)
    if not UI.pending and not keepHeader then UI.focus = "box" end
  end

  local function modeLabel()
    if UI.mode == "withdraw" then return "WITHDRAW" end
    if UI.mode == "deposit" then return "DEPOSIT" end
    return "MOVE / SWAP"
  end

  local function depositSelectedParty()
    local mon = partyMon(UI.partyCursor)
    if not mon then message("Choose a PARTY Pokémon"); return false end
    local _, boxId = currentBox()
    local ok, a, b = Storage.deposit(UI.session, UI.partyCursor, boxId)
    if ok then
      local p = party()
      UI.partyCursor = clamp(UI.partyCursor, 1, math.min(6, math.max(1, #p)))
      message("Pokémon deposited in BOX " .. tostring(a or boxId))
      return true
    end
    local err = a
    if err == "last_pokemon" then
      message("You can't deposit your last PARTY Pokémon")
    elseif err == "box_full" then
      message("This BOX is full — change BOX")
    else
      message("Can't deposit: " .. tostring(err or "unknown"))
    end
    return false
  end

  local function withdrawSelectedBox()
    local mon = boxMon(UI.boxCursor)
    if not mon then message("Choose a BOX Pokémon"); return false end
    local _, boxId = currentBox()
    local ok, a = Storage.withdraw(UI.session, boxId, UI.boxCursor)
    if ok then
      message("Pokémon withdrawn to PARTY")
      return true
    end
    if a == "party_full" then
      message("PARTY is full — use MOVE / SWAP")
    else
      message("Can't withdraw: " .. tostring(a or "unknown"))
    end
    return false
  end

  local function beginSwap()
    local mon = hoveredMon()
    if not mon then
      message("Empty slot")
      return
    end
    local _, boxId = currentBox()
    if UI.focus == "box" then
      UI.pending = { loc = "box", boxId = boxId, slot = UI.boxCursor, mon = mon }
      UI.focus = "party"
      local p = party()
      UI.partyCursor = clamp(UI.partyCursor, 1, math.min(6, math.max(1, #p + 1)))
      message("Choose a PARTY slot and press A")
    else
      UI.pending = { loc = "party", slot = UI.partyCursor, mon = mon }
      UI.focus = "box"
      message("Choose a BOX slot and press A")
    end
  end

  local function cancelSwap()
    if not UI.pending then return false end
    UI.focus = UI.pending.loc == "box" and "box" or "party"
    UI.pending = nil
    message("Swap cancelled")
    return true
  end

  local function performSwap()
    local p = UI.pending
    if not p then return false end
    local box, boxId = currentBox()
    if not box then message("Storage unavailable"); return false end

    if p.loc == "box" and UI.focus == "party" then
      local target = UI.partyCursor
      local targetMon = partyMon(target)
      local ok, err
      if targetMon then
        ok, err = Storage.moveMon(UI.session, "box", p.slot, "party", target, p.boxId, nil)
      else
        ok, err = Storage.withdraw(UI.session, p.boxId, p.slot)
        if ok then target = #party() end
      end
      if ok then
        UI.pending = nil
        UI.focus = "party"
        UI.partyCursor = clamp(target, 1, 6)
        message(targetMon and "Pokémon swapped" or "Pokémon moved to PARTY")
      else
        message(err == "party_full" and "PARTY is full" or ("Can't move: " .. tostring(err or "unknown")))
      end
      return ok and true or false
    end

    if p.loc == "party" and UI.focus == "box" then
      local targetMon = boxMon(UI.boxCursor)
      local ok, a, b
      if targetMon then
        ok, a = Storage.moveMon(UI.session, "party", p.slot, "box", UI.boxCursor, nil, boxId)
      else
        ok, a, b = Storage.deposit(UI.session, p.slot, boxId, UI.boxCursor)
      end
      if ok then
        UI.pending = nil
        UI.focus = "box"
        message(targetMon and "Pokémon swapped" or "Pokémon stored in BOX")
      else
        local err = a
        if err == "last_pokemon" then
          message("You can't store your last PARTY Pokémon")
        elseif err == "box_full" then
          message("This BOX is full")
        else
          message("Can't move: " .. tostring(err or "unknown"))
        end
      end
      return ok and true or false
    end

    return false
  end

  local function statBlock(mon)
    if not mon then return nil end
    local sp = speciesOf(mon)
    local level = tonumber(mon.level) or 1
    local ivs = mon.ivs or {}
    local evs = mon.evs or {}
    local personality = tonumber(mon.personality) or 0
    local ok, st = pcall(Pokemon.calcStats, sp, level, ivs, evs, personality)
    if not ok or type(st) ~= "table" then st = {} end
    return st
  end

  local function typeName(id)
    local ok, n = pcall(Types.name, id)
    if ok and n then return tostring(n):upper() end
    return "UNKNOWN"
  end

  local function natureName(mon)
    local id = (tonumber(mon and mon.personality) or 0) % 25
    return SummaryData.NATURES[id] or "HARDY"
  end

  local function abilityInfo(mon)
    local sp = speciesOf(mon)
    if not sp then return "-------", "" end
    local aid = Pokemon.abilityId(sp, mon and mon.personality or 0)
    local name = Pokemon.abilityName(aid)
    local desc = SummaryData.abilityDescription and SummaryData.abilityDescription(aid, name) or ""
    return name or "-------", desc or ""
  end

  local function itemName(mon)
    local id = tonumber(mon and (mon.heldItem or mon.item)) or 0
    if id <= 0 then return "NONE" end
    local ok, n = pcall(ItemsData.displayName, id)
    return ok and tostring(n or id) or tostring(id)
  end

  local function statusName(mon)
    local s = mon and (mon.status or mon.statusAilment)
    if s == nil or s == false or s == 0 or s == "" then return "OK" end
    if type(s) == "string" then return tostring(s):upper() end
    s = tonumber(s) or 0
    if s % 8 ~= 0 then return "SLP" end
    if math.floor(s / 128) % 2 == 1 then return "TOX" end
    if math.floor(s / 64) % 2 == 1 then return "PAR" end
    if math.floor(s / 32) % 2 == 1 then return "FRZ" end
    if math.floor(s / 16) % 2 == 1 then return "BRN" end
    if math.floor(s / 8) % 2 == 1 then return "PSN" end
    return tostring(s)
  end

  local function hpRatio(mon, st)
    local maxHp = tonumber(mon and mon.maxHp) or tonumber(st and st.maxHp) or 1
    if maxHp < 1 then maxHp = 1 end
    local hp = tonumber(mon and mon.hp)
    if hp == nil then hp = maxHp end
    hp = math.max(0, math.min(maxHp, hp))
    return hp, maxHp, hp / maxHp
  end

  local function moveInfo(mon, slot)
    if not mon then return nil end
    local id = Pokemon.moveIdAt(mon, slot)
    if not id or id <= 0 then return nil end
    local name = Pokemon.moveName(id) or ("MOVE " .. tostring(id))
    local pp = mon.pp and tonumber(mon.pp[slot])
    local maxPp = mon.maxPp and tonumber(mon.maxPp[slot])
    if not maxPp then
      local ok, mv = pcall(require, "src.core.game3.battle.moves")
      if ok and mv and mv.get then
        local d = mv.get(id)
        maxPp = d and tonumber(d.pp) or nil
      end
    end
    return { id = id, name = tostring(name), pp = pp, maxPp = maxPp }
  end

  local function layout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
    local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
    local s = math.max(0.72, math.min(w / 900, h / 520))
    local pad = math.max(8, 12 * s)
    local gap = math.max(7, 10 * s)
    local headerH = math.max(48, 56 * s)
    local footerH = math.max(30, 35 * s)
    local bodyY = y + headerH
    local bodyH = h - headerH - footerH
    local innerW = w - pad * 2 - gap * 2
    local partyW = math.max(150, innerW * 0.235)
    local detailW = math.max(220, innerW * 0.315)
    local boxW = innerW - partyW - detailW
    if boxW < 220 then
      detailW = math.max(190, detailW - (220 - boxW))
      boxW = innerW - partyW - detailW
    end
    return {
      x=x,y=y,w=w,h=h,s=s,pad=pad,gap=gap,headerH=headerH,footerH=footerH,
      bodyY=bodyY,bodyH=bodyH,
      partyX=x+pad,partyW=partyW,
      boxX=x+pad+partyW+gap,boxW=boxW,
      detailX=x+pad+partyW+gap+boxW+gap,detailW=detailW,
      title=math.max(20,24*s), body=math.max(14,16*s), small=math.max(12,13*s), tiny=12,
    }
  end

  local function drawHpBar(mon, st, x, y, w, h)
    local hp, maxHp, ratio = hpRatio(mon, st)
    setColor({0.78,0.82,0.87,1})
    roundRect("fill", x, y, w, h, h/2)
    local c = ratio <= 0.20 and THEME.red or (ratio <= 0.50 and THEME.yellow or THEME.green)
    setColor(c)
    roundRect("fill", x, y, math.max(1, w*ratio), h, h/2)
    return hp, maxHp
  end

  local function drawPartyPane(L)
    panel(L.partyX, L.bodyY + L.pad*0.25, L.partyW, L.bodyH - L.pad*0.5, UI.focus == "party", true)
    text("PARTY", L.partyX + L.pad, L.bodyY + L.pad*0.65, L.body, UI.focus == "party" and THEME.accent or THEME.text)
    local p = party()
    local topY = L.bodyY + L.pad*2.55
    local availH = L.bodyH - L.pad*3.05
    local rowH = availH / 6
    for i=1,6 do
      local y = topY + (i-1)*rowH
      local mon = p[i]
      local selected = UI.focus == "party" and UI.partyCursor == i
      local pending = UI.pending and UI.pending.loc == "party" and UI.pending.slot == i
      if selected or pending then
        setColor(pending and THEME.selectedSoft or THEME.raised)
        roundRect("fill", L.partyX+L.pad*0.45, y+2, L.partyW-L.pad*0.9, rowH-4, 6)
        setColor(pending and THEME.accent2 or THEME.selected)
        love.graphics.setLineWidth(2)
        roundRect("line", L.partyX+L.pad*0.45, y+2, L.partyW-L.pad*0.9, rowH-4, 6)
      end
      if mon then
        local iconSize = math.min(rowH-8, 38*L.s)
        drawIcon(mon, L.partyX+L.pad*0.6, y+(rowH-iconSize)/2, iconSize)
        local tx = L.partyX+L.pad*0.6+iconSize+5
        text(fit(monName(mon), 11), tx, y+4, L.small, THEME.text, L.partyW-(tx-L.partyX)-L.pad*0.5)
        text("Lv "..tostring(mon.level or 1), tx, y+4+L.small+2, L.tiny, THEME.muted)
        local st = statBlock(mon)
        drawHpBar(mon, st, tx, y+rowH-8, math.max(28,L.partyW-(tx-L.partyX)-L.pad*0.7), 4)
      else
        text(i == (#p+1) and "+ EMPTY SLOT" or "EMPTY", L.partyX+L.pad*0.9, y+rowH*0.33, L.small, THEME.muted)
      end
    end
  end

  local function drawBoxPane(L)
    local box, boxId = currentBox()
    local boxFocused = UI.focus == "box" or UI.focus == "box_header"
    panel(L.boxX, L.bodyY + L.pad*0.25, L.boxW, L.bodyH - L.pad*0.5, boxFocused, true)
    local title = (box and box.name) or ("BOX "..tostring(boxId))
    local count = box and Storage.countBoxMons(currentStorage(), boxId) or 0
    local headerY = L.bodyY + L.pad*0.48
    local headerX = L.boxX + L.pad*0.55
    local headerW = L.boxW - L.pad*1.1
    if UI.focus == "box_header" then
      setColor(THEME.selectedSoft)
      roundRect("fill", headerX, headerY, headerW, math.max(29, 33*L.s), 7)
      setColor(THEME.selected)
      love.graphics.setLineWidth(2)
      roundRect("line", headerX, headerY, headerW, math.max(29, 33*L.s), 7)
      text("◀", headerX+5, headerY+4, L.body, THEME.accent2)
      text("▶", headerX+headerW-24*L.s, headerY+4, L.body, THEME.accent2)
    end
    local titleX = UI.focus == "box_header" and headerX+29*L.s or L.boxX+L.pad
    text(title, titleX, L.bodyY+L.pad*0.65, L.body, boxFocused and THEME.accent or THEME.text)
    local rightText = string.format("BOX %d/%d  •  %d/30", boxId, Storage.TOTAL_BOXES_COUNT or 14, count)
    text(rightText, L.boxX+L.boxW-L.pad-145*L.s, L.bodyY+L.pad*0.78, L.small, THEME.muted, 145*L.s, "right")

    local gx = L.boxX + L.pad*0.6
    local gy = L.bodyY + L.pad*2.55
    local gw = L.boxW - L.pad*1.2
    local gh = L.bodyH - L.pad*3.05
    local cols, rows = 5, 6
    local cg = math.max(3, 5*L.s)
    local cw = (gw - cg*(cols-1))/cols
    local ch = (gh - cg*(rows-1))/rows
    for slot=1,30 do
      local col = (slot-1)%cols
      local row = math.floor((slot-1)/cols)
      local x = gx + col*(cw+cg)
      local y = gy + row*(ch+cg)
      local mon = box and box.mons and box.mons[slot]
      local selected = UI.focus == "box" and UI.boxCursor == slot
      local pending = UI.pending and UI.pending.loc == "box" and UI.pending.boxId == boxId and UI.pending.slot == slot
      setColor(selected and THEME.raised or (mon and THEME.surface or THEME.empty))
      roundRect("fill", x, y, cw, ch, 6)
      setColor(pending and THEME.accent2 or (selected and THEME.selected or THEME.border), (selected or pending) and 1 or 0.45)
      love.graphics.setLineWidth((selected or pending) and 2 or 1)
      roundRect("line", x, y, cw, ch, 6)
      if mon then
        local iconSize = math.min(cw*0.58, ch*0.55, 34*L.s)
        drawIcon(mon, x+(cw-iconSize)/2, y+3, iconSize)
        text(fit(monName(mon), 8), x+3, y+ch-L.small-3, L.tiny, THEME.text, cw-6, "center")
      else
        text(string.format("%02d", slot), x, y+ch*0.38, L.tiny, THEME.muted, cw, "center")
      end
    end
  end

  local function drawTypeChip(name, x, y, w, h, size)
    local c = TYPE_COLORS[name] or TYPE_COLORS.UNKNOWN
    setColor(c)
    roundRect("fill", x, y, w, h, h/2)
    text(name, x, y+(h-size)*0.40, size, THEME.white, w, "center")
  end

  local function drawDetailsPane(L)
    local x = L.detailX
    local y = L.bodyY + L.pad*0.25
    local w = L.detailW
    local h = L.bodyH - L.pad*0.5
    panel(x, y, w, h, false)
    local mon = hoveredMon()
    if not mon then
      text("POKéMON DETAILS", x+L.pad, y+L.pad, L.body, THEME.text)
      text("Move the cursor over a Pokémon\nto see its details instantly.", x+L.pad, y+L.pad*3.0, L.small, THEME.muted, w-L.pad*2)
      return
    end

    local sp = speciesOf(mon)
    local st = statBlock(mon) or {}
    local name = monName(mon)
    local sname = speciesName(mon)
    local lvl = tonumber(mon.level) or 1
    local gender = Pokemon.gender(sp, mon.personality or 0)
    local ability, abilityDesc = abilityInfo(mon)
    local types = Pokemon.types(sp) or {0,0}
    local t1, t2 = typeName(types[1]), typeName(types[2])
    local hp,maxHp = hpRatio(mon, st)
    local shiny = SummaryData.isShiny and SummaryData.isShiny(mon)

    local px = x + L.pad
    local py = y + L.pad*0.72
    text(fit(name, 18), px, py, L.body, THEME.text, w-L.pad*2)
    text(string.format("%s  Lv %d%s%s", sname, lvl, gender=="M" and "  ♂" or (gender=="F" and "  ♀" or ""), shiny and "  ✦" or ""), px, py+L.body+2, L.small, THEME.muted, w-L.pad*2)
    py = py + L.body + L.small + 8

    local chipH = L.small + 8
    local chipW = math.min(82*L.s, (w-L.pad*2-5)/2)
    drawTypeChip(t1, px, py, chipW, chipH, L.tiny)
    if t2 ~= "UNKNOWN" and t2 ~= t1 then drawTypeChip(t2, px+chipW+5, py, chipW, chipH, L.tiny) end
    py = py + chipH + 7

    local barW = w-L.pad*2
    drawHpBar(mon, st, px, py+L.small+3, barW, 7)
    text(string.format("HP %d / %d     STATUS %s", hp, maxHp, statusName(mon)), px, py, L.small, THEME.text)
    py = py + L.small + 16

    local nature = natureName(mon)
    text("Nature", px, py, L.tiny, THEME.muted)
    text(nature, px+52*L.s, py, L.small, THEME.text)
    py = py + L.small + 4
    text("Ability", px, py, L.tiny, THEME.muted)
    text(fit(ability, 18), px+52*L.s, py, L.small, THEME.text, w-L.pad*2-52*L.s)
    py = py + L.small + 4
    text("Item", px, py, L.tiny, THEME.muted)
    text(fit(itemName(mon), 18), px+52*L.s, py, L.small, THEME.text, w-L.pad*2-52*L.s)
    py = py + L.small + 8

    setColor(THEME.border,0.55); love.graphics.line(px,py,w+x-L.pad,py); py=py+6
    text("STATS", px, py, L.small, THEME.accent); py=py+L.small+3
    local stats = {
      {"ATK", st.attack or mon.attack or mon.atk or 0}, {"DEF", st.defense or mon.defense or mon.def or 0},
      {"SpA", st.spAtk or mon.spAtk or mon.spa or 0}, {"SpD", st.spDef or mon.spDef or mon.spd or 0},
      {"SPE", st.speed or mon.speed or mon.spe or 0},
    }
    local sw = (w-L.pad*2)/3
    for i,v in ipairs(stats) do
      local col=(i-1)%3; local row=math.floor((i-1)/3)
      text(v[1], px+col*sw, py+row*(L.small+4), L.tiny, THEME.muted)
      text(tostring(v[2]), px+col*sw+30*L.s, py+row*(L.small+4), L.small, THEME.text)
    end
    py = py + (L.small+4)*2 + 4

    local ivs, evs = mon.ivs or {}, mon.evs or {}
    local function v(tbl,k) return tonumber(tbl[k]) or 0 end
    text("IV", px, py, L.tiny, THEME.muted)
    text(string.format("%d/%d/%d/%d/%d/%d",v(ivs,"hp"),v(ivs,"atk"),v(ivs,"def"),v(ivs,"spa"),v(ivs,"spd"),v(ivs,"spe")), px+25*L.s, py, L.tiny, THEME.text)
    py=py+L.tiny+2
    text("EV", px, py, L.tiny, THEME.muted)
    text(string.format("%d/%d/%d/%d/%d/%d",v(evs,"hp"),v(evs,"atk"),v(evs,"def"),v(evs,"spa"),v(evs,"spd"),v(evs,"spe")), px+25*L.s, py, L.tiny, THEME.text)
    py=py+L.tiny+5

    setColor(THEME.border,0.55); love.graphics.line(px,py,w+x-L.pad,py); py=py+5
    text("MOVES", px, py, L.small, THEME.accent); py=py+L.small+2
    for slot=1,4 do
      local m = moveInfo(mon,slot)
      if m then
        local pp = m.pp ~= nil and tostring(m.pp) or "--"
        local mp = m.maxPp ~= nil and tostring(m.maxPp) or "--"
        text(fit(m.name, 15), px, py, L.small, THEME.text, w-L.pad*2-64*L.s)
        text(pp.."/"..mp, x+w-L.pad-64*L.s, py, L.tiny, THEME.muted, 64*L.s, "right")
      else
        text("----", px, py, L.small, THEME.muted)
      end
      py=py+L.small+2
    end

    local footerY = y+h-L.small-L.pad*0.55
    local extra = string.format("EXP %s   FRIEND %s", tostring(mon.exp or "--"), tostring(mon.friendship or mon.happiness or "--"))
    text(extra, px, footerY, L.tiny, THEME.muted, w-L.pad*2)
  end

  local function drawHeader(L)
    setColor(THEME.bg); love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    setColor(THEME.header); love.graphics.rectangle("fill", L.x, L.y, L.w, L.headerH)
    setColor(THEME.accent2); love.graphics.rectangle("fill", L.x, L.y, L.w, math.max(4,5*L.s))
    text("ADVANCED BOX", L.x+L.pad, L.y+L.pad*0.75, L.title, THEME.white)
    local badgeW = math.max(120, 145*L.s)
    setColor(THEME.selected)
    roundRect("fill", L.x+L.pad+190*L.s, L.y+L.pad*0.68, badgeW, math.max(25, 29*L.s), 7)
    text(modeLabel(), L.x+L.pad+190*L.s, L.y+L.pad*0.86, L.small, THEME.text, badgeW, "center")
    local _, boxId = currentBox()
    text("FireRed PC  •  BOX "..tostring(boxId).." / "..tostring(Storage.TOTAL_BOXES_COUNT or 14), L.x+L.w*0.52, L.y+L.pad*1.05, L.small, {0.80,0.88,0.98,1}, L.w*0.48-L.pad, "right")
  end

  local function drawFooter(L)
    local fy = L.y + L.h - L.footerH
    setColor(THEME.header); love.graphics.rectangle("fill", L.x, fy, L.w, L.footerH)
    setColor(THEME.selected); love.graphics.rectangle("fill", L.x, fy, L.w, math.max(2,3*L.s))
    local hint
    if UI.pending then
      hint = "A: CONFIRM SWAP   B: CANCEL   D-PAD: CHOOSE TARGET"
    elseif UI.mode == "deposit" then
      hint = "A: DEPOSIT PARTY POKéMON   L/R: CHANGE BOX   SELECT: INSPECT PARTY ↔ BOX   B: BACK TO PC"
    elseif UI.mode == "withdraw" then
      hint = "A: WITHDRAW BOX POKéMON   L/R: CHANGE BOX   SELECT: INSPECT BOX ↔ PARTY   B: BACK TO PC"
    else
      hint = "A: MOVE/SWAP   L/R: CHANGE BOX   ↑ HEADER + ←/→: CHANGE BOX   SELECT: PARTY ↔ BOX   B: BACK TO PC"
    end
    text(hint, L.x+L.pad, fy+L.footerH*0.32, L.tiny, {0.88,0.93,1,1}, L.w-L.pad*2)
    if UI.message and UI.message ~= "" then
      local mw = math.min(L.w*0.48, 430*L.s)
      local mx = L.x + L.w - L.pad - mw
      setColor({0.02,0.03,0.05,0.84})
      roundRect("fill", mx, fy-L.footerH*0.95, mw, L.footerH*0.78, 7)
      text(UI.message, mx+8, fy-L.footerH*0.78, L.small, THEME.white, mw-16, "center")
    end
  end

  function UI.drawWindow(viewport)
    if not UI.open or not (love and love.graphics) then return end
    local L = layout(viewport)
    love.graphics.push("all")
    love.graphics.setScissor(L.x, L.y, L.w, L.h)
    drawHeader(L)
    drawPartyPane(L)
    drawBoxPane(L)
    drawDetailsPane(L)
    drawFooter(L)
    love.graphics.setScissor()
    love.graphics.pop()
  end

  -- Native Game3 stack renderer calls draw() on the 240x160 canvas. We leave
  -- it intentionally empty and paint the readable high-resolution UI from
  -- render.hud, after the native frame has been scaled to the window.
  function UI.draw() end

  function UI.update(dt)
    UI.hoverPhase = UI.hoverPhase + (tonumber(dt) or 0)
    if UI.messageTimer > 0 then
      UI.messageTimer = UI.messageTimer - (tonumber(dt) or 0)
      if UI.messageTimer <= 0 then UI.message = nil end
    end
  end

  function UI.handleInput(input)
    if not UI.open or not input then return end
    local p = party()
    -- FireRed checks L/R for the HELP overlay before normal menu input.
    -- While this screen is open Help.enabled is temporarily false, so the
    -- shoulder buttons can safely page boxes here.
    if input:wasPressed("l") then switchBox(-1); return end
    if input:wasPressed("r") then switchBox(1); return end

    if input:wasPressed("select") and not UI.pending then
      if UI.focus == "party" then
        UI.focus = "box"
      else
        UI.focus = "party"
        UI.partyCursor = clamp(UI.partyCursor,1,math.min(6,math.max(1,#p+1)))
      end
      return
    end

    if input:wasPressed("b") then
      if cancelSwap() then return end
      UI.close()
      return
    end

    if UI.focus == "party" then
      local partyLimit = math.min(6, math.max(1, #p + ((#p < 6) and 1 or 0)))
      if input:wasPressed("up") then UI.partyCursor = clamp(UI.partyCursor-1,1,partyLimit); return end
      if input:wasPressed("down") then UI.partyCursor = clamp(UI.partyCursor+1,1,partyLimit); return end
      if input:wasPressed("left") and not UI.pending then UI.focus="box"; return end
      if input:wasPressed("right") and not UI.pending then UI.focus="box"; return end
    elseif UI.focus == "box_header" then
      if input:wasPressed("left") then switchBox(-1); return
      elseif input:wasPressed("right") then switchBox(1); return
      elseif input:wasPressed("down") or input:wasPressed("a") then UI.focus="box"; return
      elseif input:wasPressed("up") then return end
    else
      local cols = 5
      local slot = UI.boxCursor
      if input:wasPressed("left") then
        if (slot-1)%cols == 0 then slot = slot+cols-1 else slot=slot-1 end
        UI.boxCursor=clamp(slot,1,30); return
      elseif input:wasPressed("right") then
        if (slot-1)%cols == cols-1 then slot=slot-(cols-1) else slot=slot+1 end
        UI.boxCursor=clamp(slot,1,30); return
      elseif input:wasPressed("up") then
        -- From the first row, UP selects the BOX header instead of wrapping
        -- to the bottom. LEFT/RIGHT there always changes boxes, so box
        -- navigation works on keyboard, d-pad and controllers without L/R.
        if slot <= cols and not UI.pending then
          UI.focus = "box_header"
        else
          slot=slot-cols; if slot<1 then slot=slot+30 end; UI.boxCursor=slot
        end
        return
      elseif input:wasPressed("down") then
        slot=slot+cols; if slot>30 then slot=slot-30 end; UI.boxCursor=slot; return
      end
    end

    if input:wasPressed("a") then
      if UI.mode == "deposit" then
        if UI.focus == "party" then depositSelectedParty()
        elseif UI.focus == "box_header" then UI.focus = "box"
        else message("DEPOSIT: choose a Pokémon from PARTY") end
      elseif UI.mode == "withdraw" then
        if UI.focus == "box" then withdrawSelectedBox()
        elseif UI.focus == "box_header" then UI.focus = "box"
        else message("WITHDRAW: choose a Pokémon from BOX") end
      else
        if UI.pending then performSwap() else beginSwap() end
      end
      return
    end
  end

  function UI.show(session, opts)
    if type(session) ~= "table" then return false end
    opts = type(opts) == "table" and opts or { mode = opts }
    local mode = tostring(opts.mode or opts.subMode or "move")
    if mode ~= "withdraw" and mode ~= "deposit" and mode ~= "move" then mode = "move" end
    UI.session = session
    UI.mode = mode
    UI.onClose = opts.onClose
    Storage.ensure(session)
    UI.open = true
    UI.focus = mode == "deposit" and "party" or "box"
    UI.pending = nil
    UI.boxCursor = clamp(UI.boxCursor,1,30)
    UI.partyCursor = clamp(UI.partyCursor,1,6)
    if mode == "deposit" then
      UI.message = "Choose a PARTY Pokémon and press A to deposit"
    elseif mode == "withdraw" then
      UI.message = "Choose a BOX Pokémon and press A to withdraw"
    else
      UI.message = "Choose a Pokémon, then choose its destination"
    end
    UI.messageTimer = 3.0
    if Help and not UI.helpOverrideActive then
      UI.helpEnabledBefore = Help.enabled
      UI.helpOverrideActive = true
      if Help.isOpen and Help.isOpen() and Help.close then pcall(Help.close) end
      Help.enabled = false
    end
    Stack.push(SCREEN_ID, UI, { hideBelow = true })
    return true
  end

  function UI.close()
    if not UI.open then return end
    UI.open = false
    UI.pending = nil
    Stack.pop(SCREEN_ID)
    if Help and UI.helpOverrideActive then
      Help.enabled = UI.helpEnabledBefore
      UI.helpEnabledBefore = nil
      UI.helpOverrideActive = false
    end
    local cb = UI.onClose
    UI.onClose = nil
    if type(cb) == "function" then pcall(cb) end
  end

  function UI.isOpen() return UI.open end
  UI.SCREEN_ID = SCREEN_ID
  UI.Storage = Storage
  return UI
end
