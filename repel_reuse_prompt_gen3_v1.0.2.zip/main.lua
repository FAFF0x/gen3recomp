-- Repel Reuse Prompt - Gen 3 / FireRed
-- Ported from the Gen 2 implementation to Pokemon Recomp's native game3 runtime.
--
-- Design goals:
--   * FireRed only (manifest + runtime guard).
--   * Preserve the native Gen 3 Repel counter and StepEvents queue.
--   * Preserve any existing repel_wore_off event behavior by decorating it,
--     rather than replacing the counter or rebuilding step-event logic.
--   * Use ItemUse.useField for re-use so bag consumption / hooks stay native.
--   * Avoid duplicate installation when this implementation is hot-reloaded.

local PATCH_KEY = "__pokemonmod_gen3_repel_reuse_prompt_dispatch_v2"

local Runtime = require("src.core.game3.runtime")
local StepEvents = require("src.core.game3.step_events")
local ItemsData = require("src.core.game3.items_data")
local Bag = require("src.core.game3.bag")
local ItemUse = require("src.core.game3.item_use")
local Choice = require("src.ui.game3.choice")
local Message = require("src.ui.game3.message")

local FALLBACK_ORDER = {
  ItemsData.toNumericId("MAX_REPEL") or 84,
  ItemsData.toNumericId("SUPER_REPEL") or 83,
  ItemsData.toNumericId("REPEL") or 86,
}

local function numericId(id)
  return ItemsData.toNumericId(id) or tonumber(id) or id
end

local function isRepel(id)
  if id == nil then return false end
  local num = numericId(id)
  if ItemsData.REPEL_STEPS[num] ~= nil then return true end
  if ItemsData.REPEL_STEPS[id] ~= nil then return true end
  return ItemsData.fieldUseKind and ItemsData.fieldUseKind(id) == "repel" or false
end

local function currentSession()
  return Runtime and Runtime.getSession and Runtime.getSession() or nil
end

local function currentBag(session)
  return session and (session.bag or session.inventory) or nil
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {}
    rawset(_G, PATCH_KEY, dispatch)
  end

  -- Hot reload / duplicate-copy safety: only one game3 StepEvents wrapper is
  -- installed for this implementation. The active owner/save handle is updated.
  dispatch.mod = mod

  local function rememberRepel(id)
    if not isRepel(id) then return end
    local n = numericId(id)
    mod.save:set("lastRepel", n)
  end

  local function chooseRepel(session)
    local bag = currentBag(session)
    if not bag then return nil end

    local preferred = mod.save:get("lastRepel")
    if preferred ~= nil and isRepel(preferred) and Bag.has(bag, preferred, 1) then
      return numericId(preferred)
    end

    for _, id in ipairs(FALLBACK_ORDER) do
      if Bag.has(bag, id, 1) then return id end
    end
    return nil
  end

  local function closePromptMessage()
    if Message and Message.isOpen and Message.isOpen() and Message.close then
      Message.close()
    end
  end

  local function finishPrompt(onDone)
    closePromptMessage()
    if onDone then onDone() end
  end

  local function askReuse(game, onDone)
    local session = currentSession()
    local candidate = chooseRepel(session)
    if not candidate then
      if onDone then onDone() end
      return
    end

    -- Instant/stay text makes the YES/NO box own the next input edge, matching
    -- FireRed's field choice flow without letting A first act as text-skip.
    Message.showStay("Use another REPEL?", {
      speed = 0,
      session = session,
    })

    Choice.yesNo(function(yes)
      closePromptMessage()

      if not yes then
        if onDone then onDone() end
        return
      end

      -- Re-check after the choice: another mod/UI may have touched the bag.
      session = currentSession() or session
      local bag = currentBag(session)
      candidate = chooseRepel(session)
      if not (session and bag and candidate) then
        if onDone then onDone() end
        return
      end

      local ok, kind = ItemUse.useField(session, bag, candidate, nil)
      if ok and kind == "repel" then
        rememberRepel(candidate)
      end
      if onDone then onDone() end
    end)
  end

  -- Keep the current implementation callback in the global dispatch so a
  -- hot reload updates the behavior without stacking another StepEvents wrapper.
  dispatch.askReuse = askReuse

  -- Remember Repels activated normally from the FireRed BAG or registered-item
  -- path. This hook composes with other item.use wrappers and does not alter the
  -- vanilla return values.
  mod.hooks:wrap("item.use", function(nextFn, game, battle, id, target, bag)
    local ok, kind, text = nextFn(game, battle, id, target, bag)
    if ok and kind == "repel" and isRepel(id) then
      rememberRepel(id)
    end
    return ok, kind, text
  end, -50)

  if not dispatch.baseOnRepelStep then
    dispatch.baseOnRepelStep = StepEvents.onRepelStep
  end

  -- Do not stack our own wrapper on hot reload. If another mod has wrapped the
  -- function after us, leave that chain intact instead of overwriting it.
  if not dispatch.installed then
    local base = dispatch.baseOnRepelStep
    StepEvents.onRepelStep = function(session, game, ...)
      local before = #StepEvents._queue
      local result = base(session, game, ...)

      -- Native FireRed appends exactly one repel_wore_off event when the counter
      -- reaches zero. Decorate only events created by this call, and keep their
      -- original run() behavior intact before adding our prompt.
      for i = before + 1, #StepEvents._queue do
        local ev = StepEvents._queue[i]
        if type(ev) == "table" and ev.type == "repel_wore_off"
            and not ev.__pokemonmod_gen3_repel_reuse_prompt then
          ev.__pokemonmod_gen3_repel_reuse_prompt = true
          local originalRun = ev.run
          if type(originalRun) == "function" then
            ev.run = function(onDone)
              return originalRun(function()
                local live = rawget(_G, PATCH_KEY)
                local ask = live and live.askReuse
                if type(ask) ~= "function" then
                  if onDone then onDone() end
                  return
                end
                -- Use the currently loaded implementation/save namespace after a
                -- hot reload, but retain this event's original FireRed game ref.
                ask(game, onDone)
              end)
            end
          end
        end
      end
      return result
    end
    dispatch.installed = true
  end

  mod.exports.chooseRepel = function()
    return chooseRepel(currentSession())
  end

  mod.log:info("Repel Reuse Prompt - Gen 3 installed for FireRed")
end
