# Changelog

## 1.0.2

- Ported the mod from Gen 2 to FireRed / Gen 3.
- Switched from Gen 2 `World:repelWoreOff` / `World:useRepel` to native Gen 3
  `StepEvents`, `Bag`, and `ItemUse` APIs.
- Preserves FireRed's native wear-off message, then opens a YES/NO reuse prompt.
- Remembers the last Repel type used through the public `item.use` hook.
- Added MAX REPEL -> SUPER REPEL -> REPEL fallback when the preferred type is out.
- Added Gen 3-specific id and FireRed-only manifest targeting.
- Avoids rebuilding the Repel counter or unrelated step-event logic.
