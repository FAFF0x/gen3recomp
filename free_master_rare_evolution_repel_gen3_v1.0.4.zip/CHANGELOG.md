# Changelog

## 1.0.4

- New FireRed/Game3 combined build.
- Merged Free Master Ball + Rare Candy, Free Evolution Shop and Free Max Repel into one mod.
- Uses the real `src.ui.game3.shop_menu` runtime.
- Adds MASTER BALL, RARE CANDY and MAX REPEL to normal Mart stock at ¥0.
- Adds a dedicated EVOLUTION SHOP to the native Mart root menu.
- Evolution inventory is discovered from FireRed evolution data (item and trade-item evolution methods).
- Added dynamic native root-menu sizing for four or more rows.
- Added duplicate-stock suppression and equivalent Evolution Shop coexistence guard.
- Compatible with Gen3 Modern UI's dynamic ShopMenu presenter.
- FireRed-only manifest with a unique combined mod ID.
