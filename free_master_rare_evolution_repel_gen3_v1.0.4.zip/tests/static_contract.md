# Static contract

- Manifest id is unique: `pokemonmod_gen3_free_master_rare_evolution_repel`.
- `games` contains only `firered`.
- Runtime references use `src.core.game3.*` / `src.ui.game3.*` only.
- Normal free items are resolved through FireRed item metadata.
- Evolution items are dynamically collected from EVO_ITEM / EVO_TRADE_ITEM rows.
- Native ShopMenu logic owns purchases; the mod only composes stock/root entries and prices.
- Duplicate inventory/root rows are suppressed.
