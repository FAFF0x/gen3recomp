-- Free Master/Rare + Evolution + Max Repel - Gen 3 v1.0.4
-- FireRed-only combined port of:
--   * free_master_rare_gen2
--   * free_evolution_shop_gen2
--   * free_max_repel_gen2
--
-- This build targets the real FireRed runtime (src.ui.game3.*).  It keeps the
-- native ShopMenu purchase/sell/quantity/capacity state machine intact and
-- composes with Modern UI by exposing all state through ShopMenu.ROOT/_items.

return function(mod)
  local VERSION = "1.0.4"
  local MOD_ID = "pokemonmod_gen3_free_master_rare_evolution_repel"

  local ItemsData = require("src.core.game3.items_data")
  local Pokemon = require("src.core.game3.pokemon")
  local ShopMenu = require("src.ui.game3.shop_menu")

  local function copyTable(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
  end

  local function copyList(src)
    local out = {}
    for i, v in ipairs(src or {}) do out[i] = v end
    return out
  end

  local function numeric(id)
    if ItemsData.toNumericId then
      local ok, n = pcall(ItemsData.toNumericId, id)
      if ok and n then return tonumber(n) end
    end
    return tonumber(id)
  end

  local function normalized(value)
    return tostring(value or ""):upper():gsub("[^A-Z0-9]", "")
  end

  local FREE_NORMAL_NAMES = { "MASTER_BALL", "RARE_CANDY", "MAX_REPEL" }
  local freeNormalIds = {}
  local freeNormalSet = {}
  for _, name in ipairs(FREE_NORMAL_NAMES) do
    local id = numeric(name)
    if id then
      freeNormalIds[#freeNormalIds + 1] = id
      freeNormalSet[id] = true
    else
      mod.log:warn("Unable to resolve FireRed item %s", name)
    end
  end

  -- Evolution methods from include/constants/pokemon.h / game3 evolution.lua.
  local EVO_TRADE_ITEM = 6
  local EVO_ITEM = 7
  local evolutionIds = nil
  local evolutionSet = {}

  -- Keep the raw metadata function so discovery cannot recurse through our
  -- zero-price wrapper.
  local rawInfo = ItemsData.info

  local function addEvolutionId(out, seen, id)
    id = tonumber(id)
    if not id or id <= 0 or seen[id] then return end
    local ok, info = pcall(rawInfo, id)
    if not ok or type(info) ~= "table" then return end
    seen[id] = true
    out[#out + 1] = id
  end

  local function discoverEvolutionItems()
    if evolutionIds then return evolutionIds end

    local ids, seen = {}, {}

    -- Stable FRLG stone order. The ROM uses 93..98 for these six stones.
    for id = 93, 98 do addEvolutionId(ids, seen, id) end

    -- Discover every held/item evolution actually present in the FireRed
    -- species data (King's Rock, Metal Coat, Dragon Scale, Up-Grade,
    -- DeepSeaTooth/Scale, etc.) instead of hard-coding fragile names.
    for species = 1, 500 do
      local ok, evolutions = pcall(Pokemon.evolutions, species)
      if ok and type(evolutions) == "table" then
        for _, evo in ipairs(evolutions) do
          local method = tonumber(evo.method or evo[1]) or 0
          local param = tonumber(evo.param or evo[2]) or 0
          if (method == EVO_ITEM or method == EVO_TRADE_ITEM) and param > 0 then
            addEvolutionId(ids, seen, param)
          end
        end
      end
    end

    local stoneRank = {}
    for id = 93, 98 do stoneRank[id] = id - 92 end
    table.sort(ids, function(a, b)
      local ra, rb = stoneRank[a] or 999, stoneRank[b] or 999
      if ra ~= rb then return ra < rb end
      local ia, ib = rawInfo(a) or {}, rawInfo(b) or {}
      return tostring(ia.name or a) < tostring(ib.name or b)
    end)

    evolutionIds = ids
    evolutionSet = {}
    for _, id in ipairs(ids) do evolutionSet[id] = true end
    return evolutionIds
  end

  local function dedupeItems(items)
    local out, seen = {}, {}
    for _, ref in ipairs(items or {}) do
      local id = numeric(ref) or ref
      local key = tostring(id)
      if not seen[key] then
        seen[key] = true
        out[#out + 1] = id
      end
    end
    return out, seen
  end

  local function augmentedNormalStock(items)
    local out, seen = dedupeItems(items)
    for _, id in ipairs(freeNormalIds) do
      local key = tostring(id)
      if not seen[key] then
        seen[key] = true
        out[#out + 1] = id
      end
    end
    return out
  end

  -- ---------------------------------------------------------------------
  -- Price layer
  -- ---------------------------------------------------------------------
  -- ShopMenu asks ItemsData.info() live for both BUY and SELL prices.  A
  -- chained wrapper is safer than replacing ROM tables and guarantees that
  -- free items cannot be bought at 0 then sold back for profit.
  if not ItemsData.__pokemonmodGen3FreeShopInfoPatched then
    local previousInfo = ItemsData.info
    ItemsData.info = function(id)
      local row = previousInfo(id)
      if type(row) ~= "table" then return row end
      local num = numeric(id) or tonumber(row.id)
      if num and (freeNormalSet[num] or evolutionSet[num]) then
        local patched = copyTable(row)
        patched.price = 0
        return patched
      end
      return row
    end
    ItemsData.__pokemonmodGen3FreeShopInfoPatched = MOD_ID
  else
    mod.log:info("A compatible Gen3 zero-price item metadata wrapper is already active")
  end

  -- ---------------------------------------------------------------------
  -- Evolution entry in the native FireRed Poké Mart root menu
  -- ---------------------------------------------------------------------
  local EVO_ROOT_ID = "pokemonmod_gen3_evolution_shop"
  local ownsEvolutionRoot = false

  local function hasEvolutionEntry()
    for _, row in ipairs(ShopMenu.ROOT or {}) do
      local id = normalized(row and row.id)
      local label = normalized(row and row.label)
      if id:find("EVOLUTION", 1, true) or label:find("EVOLUTION", 1, true) then
        return true
      end
    end
    return false
  end

  if not hasEvolutionEntry() then
    ShopMenu.ROOT = ShopMenu.ROOT or {}
    local insertAt = #ShopMenu.ROOT + 1
    for i, row in ipairs(ShopMenu.ROOT) do
      if row and row.id == "quit" then
        insertAt = i
        break
      end
    end
    table.insert(ShopMenu.ROOT, insertAt, {
      id = EVO_ROOT_ID,
      label = "EVOLUTION SHOP",
    })
    ownsEvolutionRoot = true
  else
    mod.log:info("An EVOLUTION SHOP root entry already exists; duplicate row suppressed")
  end

  local function restoreNormalStock()
    if ShopMenu._pokemonmodGen3NormalItems then
      ShopMenu._items = copyList(ShopMenu._pokemonmodGen3NormalItems)
    end
    ShopMenu._pokemonmodGen3EvolutionActive = false
  end

  -- ---------------------------------------------------------------------
  -- Shop open wrapper: add the three free normal-Mart items exactly once.
  -- ---------------------------------------------------------------------
  if not ShopMenu.__pokemonmodGen3CombinedShowPatched then
    local previousShow = ShopMenu.show
    ShopMenu.show = function(opts)
      opts = opts or {}

      -- Build the dynamic FireRed evolution catalogue only once the Game3
      -- dataset is active. This also arms zero prices for those item IDs.
      discoverEvolutionItems()

      local patchedOpts = copyTable(opts)
      patchedOpts.items = augmentedNormalStock(opts.items or {})

      previousShow(patchedOpts)

      -- A previous/equivalent wrapper may also have added stock; normalize the
      -- live list after it runs so imported mods never produce duplicate rows.
      local live = augmentedNormalStock(ShopMenu._items or patchedOpts.items)
      ShopMenu._pokemonmodGen3NormalItems = copyList(live)
      ShopMenu._pokemonmodGen3EvolutionActive = false
      ShopMenu._items = copyList(live)
    end
    ShopMenu.__pokemonmodGen3CombinedShowPatched = MOD_ID
  else
    mod.log:warn("A compatible Gen3 combined ShopMenu.show wrapper is already installed")
  end

  -- ---------------------------------------------------------------------
  -- Input wrapper: EVOLUTION SHOP reuses the native BUY state machine.
  -- ---------------------------------------------------------------------
  if ownsEvolutionRoot and not ShopMenu.__pokemonmodGen3EvolutionInputPatched then
    local previousHandleInput = ShopMenu.handleInput
    ShopMenu.handleInput = function(input)
      -- The native BUY->ROOT transition can finish asynchronously through
      -- Fade. Restore normal stock as soon as that transition completes.
      if ShopMenu.mode == "root" and ShopMenu._pokemonmodGen3EvolutionActive then
        restoreNormalStock()
      end

      if ShopMenu.open and ShopMenu.mode == "root" and input then
        local row = (ShopMenu.ROOT or {})[ShopMenu.cursor or 1]
        if row and row.id == EVO_ROOT_ID and input:wasPressed("a") then
          local evo = discoverEvolutionItems()
          ShopMenu._items = copyList(evo)
          ShopMenu._pokemonmodGen3EvolutionActive = true
          ShopMenu.mode = "buy"
          ShopMenu.cursor = 1
          ShopMenu.scroll = 0
          ShopMenu.qty = 1
          ShopMenu.yesNoCursor = 1
          ShopMenu._pending = nil
          ShopMenu._status = nil
          pcall(function() require("src.core.game3.audio").playSe(5) end)
          return
        elseif row and row.id == "buy" and input:wasPressed("a") then
          restoreNormalStock()
        end
      end

      return previousHandleInput(input)
    end
    ShopMenu.__pokemonmodGen3EvolutionInputPatched = MOD_ID
  end

  -- ---------------------------------------------------------------------
  -- Native root-menu fallback without Modern UI.
  -- FireRed's stock ShopMenu frame is sized for BUY/SELL/SEE YA (3 rows), so
  -- draw a dynamic-height root when our fourth EVOLUTION SHOP row is present.
  -- Modern UI renders after this and reads the same ROOT table dynamically.
  -- ---------------------------------------------------------------------
  if ownsEvolutionRoot and not ShopMenu.__pokemonmodGen3EvolutionDrawPatched then
    local previousDraw = ShopMenu.draw
    ShopMenu.draw = function()
      if not (ShopMenu.open and ShopMenu.mode == "root") then
        return previousDraw()
      end

      local Window = require("src.ui.game3.window")
      local rows = ShopMenu.ROOT or {}
      local contentH = math.max(6, #rows * 2)
      Window.stdFrame(Window.template(2, 1, 17, contentH))

      for i, row in ipairs(rows) do
        local yPx = 10 + (i - 1) * 16
        if i == ShopMenu.cursor then Window.cursorPx(20, yPx) end
        Window.printPx((row and (row.label or row.id)) or "?", 28, yPx)
      end

      Window.dialogueFrame()
      if ShopMenu._status then
        local lines = {}
        for line in tostring(ShopMenu._status):gmatch("[^\r\n]+") do
          lines[#lines + 1] = line
        end
        if #lines > 0 then Window.print(lines[1], 2, 15, { clipTiles = 26 }) end
        if #lines > 1 then Window.print(lines[2], 2, 17, { clipTiles = 26 }) end
      end
    end
    ShopMenu.__pokemonmodGen3EvolutionDrawPatched = MOD_ID
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.supportedGames = { "firered" }
  mod.exports.normalFreeItems = copyList(freeNormalIds)
  mod.exports.getEvolutionItems = function()
    return copyList(discoverEvolutionItems())
  end
  mod.exports.features = {
    freeMasterBall = true,
    freeRareCandy = true,
    freeMaxRepel = true,
    evolutionShop = true,
  }

  mod.log:info(
    "Gen3 combined free shop installed: %d normal free items; evolution catalogue is discovered from FireRed data on first Mart open",
    #freeNormalIds
  )
end
