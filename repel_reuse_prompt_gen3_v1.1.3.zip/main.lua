-- Repel Reuse Prompt - Gen 3 / FireRed + LeafGreen
-- v1.1.3: native EXTRAS integration matching EXP Share Modes
-- Ported from the Gen 2 implementation to Pokemon Recomp's native game3 runtime.
--
-- Design goals:
--   * FireRed + LeafGreen only (manifest + Gen 3 runtime guard).
--   * Preserve the native Gen 3 Repel counter and StepEvents queue.
--   * Preserve any existing repel_wore_off event behavior by decorating it,
--     rather than replacing the counter or rebuilding step-event logic.
--   * Use ItemUse.useField for re-use so bag consumption / hooks stay native.
--   * Avoid duplicate installation when this implementation is hot-reloaded.

local MOD_ID = "pokemonmod_gen3_repel_reuse_prompt"
local PATCH_KEY = "__pokemonmod_gen3_repel_reuse_prompt_dispatch_v3"

local Runtime = require("src.core.game3.runtime")
local StepEvents = require("src.core.game3.step_events")
local ItemsData = require("src.core.game3.items_data")
local Bag = require("src.core.game3.bag")
local ItemUse = require("src.core.game3.item_use")
local Choice = require("src.ui.game3.choice")
local Message = require("src.ui.game3.message")
local Dex = require("src.core.game3.dex")
local Pokemon = require("src.core.game3.pokemon")
local FieldSemantics = require("src.core.game3.field_semantics")
local Encounters = require("src.core.game3.encounters")

local FALLBACK_ORDER = {
  ItemsData.toNumericId("MAX_REPEL") or 84,
  ItemsData.toNumericId("SUPER_REPEL") or 83,
  ItemsData.toNumericId("REPEL") or 86,
}

local function numericId(id)
  return ItemsData.toNumericId(id) or tonumber(id) or id
end

local function isRepel(id)
  if id == nil then return false end
  local num = numericId(id)
  if ItemsData.REPEL_STEPS[num] ~= nil then return true end
  if ItemsData.REPEL_STEPS[id] ~= nil then return true end
  return ItemsData.fieldUseKind and ItemsData.fieldUseKind(id) == "repel" or false
end

local function currentSession()
  return Runtime and Runtime.getSession and Runtime.getSession() or nil
end

local function currentBag(session)
  return session and (session.bag or session.inventory) or nil
end

local function repelVar(session)
  if FieldSemantics and FieldSemantics.var then
    local ok, value = pcall(FieldSemantics.var, session, "repelSteps")
    if ok and value ~= nil then return value end
  end
  return 0x4020
end

local function repelSteps(session)
  if type(session) ~= "table" then return 0 end
  local direct = tonumber(session.repelSteps)
  if direct ~= nil then return direct end
  local vars = session.vars
  if type(vars) == "table" then
    return tonumber(vars[repelVar(session)]) or 0
  end
  return 0
end

local function repelActive(session)
  return repelSteps(session) > 0
end

local function resolvedSpecies(raw)
  if raw == nil then return nil end
  if type(raw) == "number" then return raw end
  if Pokemon and Pokemon.speciesOf then
    local ok, sp = pcall(Pokemon.speciesOf, { species = raw })
    if ok and sp then return tonumber(sp) or sp end
  end
  if Pokemon and Pokemon.speciesFromName then
    local ok, sp = pcall(Pokemon.speciesFromName, tostring(raw))
    if ok and sp then return tonumber(sp) or sp end
  end
  return tonumber(raw)
end

local function alreadyCaught(session, rawSpecies)
  if type(session) ~= "table" then return false end
  local sp = resolvedSpecies(rawSpecies)
  if not sp then return false end

  local dex = session.dex
  if Dex and Dex.isCaught and dex then
    local ok, caught = pcall(Dex.isCaught, dex, sp)
    if ok and caught == true then return true end
  end

  -- Compatibility fallback for saves/expansion packs that mirror Pokédex flags
  -- into the host-style session.pokedex table instead of session.dex.
  local pd = session.pokedex
  if type(pd) == "table" then
    local caught = pd.caught or pd.owned
    if type(caught) == "table" then
      if caught[sp] == true or caught[tostring(sp)] == true then return true end
      local nat = Pokemon and Pokemon.national and Pokemon.national(sp) or nil
      if nat and (caught[nat] == true or caught[tostring(nat)] == true) then return true end
    end
  end

  return false
end

-- Execute the native encounter roll with the Repel counter temporarily hidden.
-- This keeps the engine's normal terrain/rate/slot/level/RNG logic but prevents
-- vanilla FRLG's lead-level Repel rule from discarding a candidate before this
-- mod can inspect its species. The real Repel counter is restored immediately.
local function rollIgnoringVanillaRepel(nextFn, encounterTable, ctx, session)
  if type(session) ~= "table" then return nextFn(encounterTable, ctx) end

  local vars = type(session.vars) == "table" and session.vars or nil
  local rv = repelVar(session)
  local oldDirect = session.repelSteps
  local oldVar = vars and vars[rv] or nil
  local oldBuff = Encounters and Encounters._encounterRateBuff or nil

  session.repelSteps = 0
  if vars then vars[rv] = 0 end

  local packed = { pcall(nextFn, encounterTable, ctx) }

  session.repelSteps = oldDirect
  if vars then vars[rv] = oldVar end
  -- Native Repel keeps the encounter-rate bank at zero while active.
  if Encounters and oldBuff ~= nil then Encounters._encounterRateBuff = 0 end

  if not packed[1] then error(packed[2], 0) end
  return packed[2]
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  mod.options:define({
    {
      key = "uncaught_repel",
      label = "REPEL: UNCAUGHT ONLY",
      type = "toggle",
      default = true,
    },
  })

  -- Runtime menu override. mod.options is intentionally read-only from a mod;
  -- the Start-menu selector stores the active value in the mod save namespace.
  -- If the player has never changed it in-game, fall back to the Mod Manager
  -- option/default above.
  local function uncaughtOnlyEnabled()
    local saved = mod.save:get("uncaught_repel_runtime")
    if type(saved) == "boolean" then return saved end
    return mod.options:get("uncaught_repel") == true
  end

  local function setUncaughtOnly(enabled)
    mod.save:set("uncaught_repel_runtime", enabled and true or false)
    return enabled and true or false
  end

  local dispatch = rawget(_G, PATCH_KEY)
  if type(dispatch) ~= "table" then
    dispatch = {}
    rawset(_G, PATCH_KEY, dispatch)
  end

  -- Hot reload / duplicate-copy safety: only one game3 StepEvents wrapper is
  -- installed for this implementation. The active owner/save handle is updated.
  dispatch.mod = mod
  dispatch.uncaughtOnlyEnabled = uncaughtOnlyEnabled
  dispatch.setUncaughtOnly = setUncaughtOnly

  local function installOptionsMenuRow()
    -- Use the exact integration model used by EXP Share Modes Gen 3:
    -- require option_rows lazily, append a unique row id to the desired group,
    -- then wrap the current Rows.build so other mods remain in the chain.
    local okRows, Rows = pcall(require, "src.ui.game3.option_rows")
    if not okRows or type(Rows) ~= "table" or type(Rows.build) ~= "function" then
      mod.log:warn("FRLG option rows unavailable; REPEL MODE remains available from Mod Manager")
      return false
    end

    local rowId = "pokemonmod_repel_mode"
    local group
    for _, g in ipairs(Rows.GROUPS or {}) do
      if g.id == "group.extras" then
        group = g
        break
      end
    end

    if group then
      local found = false
      for _, id in ipairs(group.members or {}) do
        if id == rowId then
          found = true
          break
        end
      end
      if not found then
        group.members = group.members or {}
        group.members[#group.members + 1] = rowId
      end
    else
      mod.log:warn("FRLG EXTRAS option group not found")
      return false
    end

    Rows._pokemonmodRepelModeOwners = Rows._pokemonmodRepelModeOwners or {}
    if Rows._pokemonmodRepelModeOwners[MOD_ID] then
      return true
    end

    local previousBuild = Rows.build
    Rows.build = function(ctx)
      local rows = previousBuild(ctx) or {}

      for _, row in ipairs(rows) do
        if row.id == rowId or row.label == "REPEL MODE" then
          return rows
        end
      end

      rows[#rows + 1] = {
        id = rowId,
        label = "REPEL MODE",
        value = function()
          return uncaughtOnlyEnabled() and "UNCAUGHT" or "BLOCK ALL"
        end,
        step = function(_, _)
          setUncaughtOnly(not uncaughtOnlyEnabled())
          return true
        end,
      }
      return rows
    end

    Rows._pokemonmodRepelModeOwners[MOD_ID] = true
    return true
  end

  local optionsMenuInstalled = installOptionsMenuRow()

  local function rememberRepel(id)
    if not isRepel(id) then return end
    local n = numericId(id)
    mod.save:set("lastRepel", n)
  end

  local function chooseRepel(session)
    local bag = currentBag(session)
    if not bag then return nil end

    local preferred = mod.save:get("lastRepel")
    if preferred ~= nil and isRepel(preferred) and Bag.has(bag, preferred, 1) then
      return numericId(preferred)
    end

    for _, id in ipairs(FALLBACK_ORDER) do
      if Bag.has(bag, id, 1) then return id end
    end
    return nil
  end

  local function closePromptMessage()
    if Message and Message.isOpen and Message.isOpen() and Message.close then
      Message.close()
    end
  end

  local function finishPrompt(onDone)
    closePromptMessage()
    if onDone then onDone() end
  end

  local function askReuse(game, onDone)
    local session = currentSession()
    local candidate = chooseRepel(session)
    if not candidate then
      if onDone then onDone() end
      return
    end

    -- Instant/stay text makes the YES/NO box own the next input edge, matching
    -- FRLG's field choice flow without letting A first act as text-skip.
    Message.showStay("Use another REPEL?", {
      speed = 0,
      session = session,
    })

    Choice.yesNo(function(yes)
      closePromptMessage()

      if not yes then
        if onDone then onDone() end
        return
      end

      -- Re-check after the choice: another mod/UI may have touched the bag.
      session = currentSession() or session
      local bag = currentBag(session)
      candidate = chooseRepel(session)
      if not (session and bag and candidate) then
        if onDone then onDone() end
        return
      end

      local ok, kind = ItemUse.useField(session, bag, candidate, nil)
      if ok and kind == "repel" then
        rememberRepel(candidate)
      end
      if onDone then onDone() end
    end)
  end

  -- Keep the current implementation callback in the global dispatch so a
  -- hot reload updates the behavior without stacking another StepEvents wrapper.
  dispatch.askReuse = askReuse

  -- Remember Repels activated normally from the FRLG BAG or registered-item
  -- path. This hook composes with other item.use wrappers and does not alter the
  -- vanilla return values.
  mod.hooks:wrap("item.use", function(nextFn, game, battle, id, target, bag)
    local ok, kind, text = nextFn(game, battle, id, target, bag)
    if ok and kind == "repel" and isRepel(id) then
      rememberRepel(id)
    end
    return ok, kind, text
  end, -50)

  -- Repel encounter behavior:
  --   option ON  -> only species not yet caught may start a random encounter;
  --   option OFF -> an active Repel suppresses every random encounter, even if
  --                 the rolled Pokémon is the same/higher level than the lead.
  -- No active Repel means completely native encounter behavior.
  mod.hooks:wrap("encounter.roll", function(nextFn, encounterTable, ctx)
    local session = currentSession()
    if not repelActive(session) then
      return nextFn(encounterTable, ctx)
    end

    -- Let the native engine perform its normal roll without the vanilla
    -- level-based Repel rejection; our option owns the final decision instead.
    local enc = rollIgnoringVanillaRepel(nextFn, encounterTable, ctx, session)

    if not uncaughtOnlyEnabled() then
      return nil
    end
    if not enc then return nil end
    if alreadyCaught(session, enc.species) then return nil end
    return enc
  end, 80)

  if not dispatch.baseOnRepelStep then
    dispatch.baseOnRepelStep = StepEvents.onRepelStep
  end

  -- Do not stack our own wrapper on hot reload. If another mod has wrapped the
  -- function after us, leave that chain intact instead of overwriting it.
  if not dispatch.installed then
    local base = dispatch.baseOnRepelStep
    StepEvents.onRepelStep = function(session, game, ...)
      local before = #StepEvents._queue
      local result = base(session, game, ...)

      -- Native FRLG appends exactly one repel_wore_off event when the counter
      -- reaches zero. Decorate only events created by this call, and keep their
      -- original run() behavior intact before adding our prompt.
      for i = before + 1, #StepEvents._queue do
        local ev = StepEvents._queue[i]
        if type(ev) == "table" and ev.type == "repel_wore_off"
            and not ev.__pokemonmod_gen3_repel_reuse_prompt then
          ev.__pokemonmod_gen3_repel_reuse_prompt = true
          local originalRun = ev.run
          if type(originalRun) == "function" then
            ev.run = function(onDone)
              return originalRun(function()
                local live = rawget(_G, PATCH_KEY)
                local ask = live and live.askReuse
                if type(ask) ~= "function" then
                  if onDone then onDone() end
                  return
                end
                -- Use the currently loaded implementation/save namespace after a
                -- hot reload, but retain this event's original FRLG game ref.
                ask(game, onDone)
              end)
            end
          end
        end
      end
      return result
    end
    dispatch.installed = true
  end

  mod.exports.version = "1.1.3"
  mod.exports.generation = 3
  mod.exports.game = "frlg"
  mod.exports.supportedGames = { "firered", "leafgreen" }

  mod.exports.chooseRepel = function()
    return chooseRepel(currentSession())
  end
  mod.exports.repelActive = function()
    return repelActive(currentSession())
  end
  mod.exports.isCaught = function(species)
    return alreadyCaught(currentSession(), species)
  end
  mod.exports.uncaughtOnlyEnabled = uncaughtOnlyEnabled
  mod.exports.setUncaughtOnly = setUncaughtOnly
  mod.exports.optionsLocation = "START > OPTION > EXTRAS"
  mod.exports.optionsMenuInstalled = optionsMenuInstalled

  mod.log:info("Repel Reuse Prompt - Gen 3 v1.1.3 loaded (REPEL MODE: START > OPTION > EXTRAS)")
end
