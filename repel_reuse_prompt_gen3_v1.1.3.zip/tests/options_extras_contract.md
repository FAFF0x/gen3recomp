# v1.1.3 native EXTRAS option contract

Reference implementation: EXP Share Modes Gen 3 v1.0.3.

Expected integration:
- lazy `pcall(require, "src.ui.game3.option_rows")`
- locate `Rows.GROUPS` entry with id `group.extras`
- append unique member id `pokemonmod_repel_mode`
- save current `Rows.build` as `previousBuild`
- wrapper calls `previousBuild(ctx)` first
- append row `{ id="pokemonmod_repel_mode", label="REPEL MODE", ... }`
- owner guard stored on the Rows module
- exported `optionsMenuInstalled == true` when installation succeeds

In game:
START -> OPTION -> EXTRAS -> REPEL MODE
