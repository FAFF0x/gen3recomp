# v1.1.2 REPEL MODE Options / Extras regression

- [ ] Open Start -> Options: EXTRAS is present.
- [ ] Open EXTRAS: REPEL MODE is listed.
- [ ] REPEL MODE displays `UNCAUGHT` by default on a fresh mod save.
- [ ] LEFT/RIGHT or A changes the value between `UNCAUGHT` and `BLOCK ALL`.
- [ ] Close and reopen Options: the selected value remains.
- [ ] Restart the game: the selected value remains.
- [ ] UNCAUGHT filters already-caught species while Repel is active.
- [ ] UNCAUGHT allows uncaught species regardless of lead level.
- [ ] BLOCK ALL suppresses every random wild encounter while Repel is active.
- [ ] With no active Repel, encounters are unchanged.
- [ ] The old separate REPEL MODE row is absent from the Start menu.
- [ ] FireRed and LeafGreen expose the same Extras row.
