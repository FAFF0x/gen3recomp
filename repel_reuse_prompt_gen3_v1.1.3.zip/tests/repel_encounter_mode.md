# Repel encounter mode regression

- Option `uncaught_repel` exists, is a toggle, and defaults to true.
- No active Repel: `encounter.roll` delegates unchanged.
- Active Repel + option ON + uncaught rolled species: encounter survives regardless of lead level.
- Active Repel + option ON + caught rolled species: encounter is suppressed.
- Active Repel + option OFF: every random walking encounter is suppressed.
- Repel counter is restored after every native encounter roll, including errors.
- Native encounter-rate buff remains zero while Repel is active.
- Fishing is not modified by this `encounter.roll` hook.
- Repel reuse prompt and fallback item order remain unchanged.
