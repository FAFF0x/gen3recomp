# v1.1.1 REPEL MODE Start-menu regression

- [ ] Open Start: a `REPEL MODE` row is visible before SAVE (or appended if SAVE is unavailable).
- [ ] Select REPEL MODE: Start closes and a two-choice menu appears.
- [ ] Choose UNCAUGHT ONLY: the setting is saved and the confirmation message appears.
- [ ] With an active Repel, already-caught species do not start encounters.
- [ ] With an active Repel, uncaught species can start encounters regardless of lead level.
- [ ] Choose BLOCK ALL: with an active Repel, no random wild encounter can start.
- [ ] Reopen REPEL MODE: cursor defaults to the currently saved mode.
- [ ] Close/reopen the game: the selected mode remains active.
- [ ] Repel reuse prompt still appears when the Repel wears off.
- [ ] FireRed and LeafGreen both expose the menu row.
