local root = (... and ... ~= "" and ...) or "."
local entryPath = root .. "/main.lua"

local now = 0
_G.love = { timer = { getTime = function() return now end } }

local current = "firered"
package.preload["src.core.game3.profile"] = function()
  return {
    forSession = function(session)
      local id = type(session) == "table" and session.version or current
      return { id = id, family = id == "emerald" and "rse" or "frlg" }
    end,
  }
end

local bagCalls, pyramidCalls = {}, {}
local BagMenu
BagMenu = {
  mode = "list", _session = nil, _switch = nil, _open = nil, _exit = nil,
  show = function(session)
    BagMenu._session = session
    BagMenu.mode = "list"
    return true
  end,
}
package.preload["src.ui.game3.bag_menu"] = function() return BagMenu end

local RseBag = {
  handleInput = function(input, bag)
    bagCalls[#bagCalls + 1] = {
      up = input:wasPressed("up"), down = input:wasPressed("down"),
      left = input:wasPressed("left"), right = input:wasPressed("right"),
      heldUp = input:isDown("up"), a = input:wasPressed("a"), bag = bag,
    }
  end,
}
package.preload["src.ui.game3.rse.bag_menu"] = function() return RseBag end

local PyramidBag
PyramidBag = {
  _st = {},
  show = function(opts)
    PyramidBag._st.session = opts and opts.session
    PyramidBag._st.mode = "list"
    PyramidBag._st.suspended = false
    return true
  end,
  handleInput = function(input)
    pyramidCalls[#pyramidCalls + 1] = {
      up = input:wasPressed("up"), heldUp = input:isDown("up"),
      down = input:wasPressed("down"), a = input:wasPressed("a"),
    }
  end,
}
package.preload["src.ui.game3.rse.pyramid_bag"] = function() return PyramidBag end

local function makeMod()
  local logs = {}
  return {
    generation = 3,
    exports = {},
    log = {
      info = function(_, s) logs[#logs + 1] = "I:" .. tostring(s) end,
      error = function(_, s) logs[#logs + 1] = "E:" .. tostring(s) end,
    },
    _logs = logs,
  }
end

local function input(opts)
  opts = opts or {}
  return {
    wasPressed = function(_, k) return opts.pressed == k or (opts.pressedSet and opts.pressedSet[k]) or false end,
    isDown = function(_, k) return opts.held == k or (opts.heldSet and opts.heldSet[k]) or false end,
  }
end

local entry = assert(loadfile(entryPath))()
assert(type(entry) == "function")

-- FireRed guard: no handlers are replaced.
local originalRse = RseBag.handleInput
local originalPyr = PyramidBag.handleInput
local fr = makeMod()
entry(fr)
assert(fr.exports.active == false)
assert(fr.exports.emeraldOnly == true)
assert(RseBag.handleInput == originalRse)
assert(PyramidBag.handleInput == originalPyr)

-- Emerald installs both final gates.
current = "emerald"
local em = makeMod()
entry(em)
assert(em.exports.active == true)
assert(em.exports.game == "emerald")
assert(em.exports.profileFamily == "rse")
assert(em.exports.supportedGames[1] == "emerald")
assert(em.exports.targets.bag and em.exports.targets.pyramidBag)
assert(em.exports.targets.help == false and em.exports.targets.pokenav == false)
assert(RseBag.handleInput ~= originalRse)
assert(PyramidBag.handleInput ~= originalPyr)

local session = { version = "emerald" }
BagMenu.show(session)

-- Same physical edge observed multiple fixed updates: exactly one downstream edge.
now = 0
local heldUp = input({ pressed = "up", held = "up" })
RseBag.handleInput(heldUp, BagMenu)
RseBag.handleInput(heldUp, BagMenu)
assert(#bagCalls == 2)
assert(bagCalls[1].up == true)
assert(bagCalls[2].up == false)
assert(bagCalls[1].heldUp == false and bagCalls[2].heldUp == false)

-- No repeat before 1 second; repeat at/after deadline.
now = 0.99
RseBag.handleInput(input({ held = "up" }), BagMenu)
assert(bagCalls[#bagCalls].up == false)
now = 1.00
RseBag.handleInput(input({ held = "up" }), BagMenu)
assert(bagCalls[#bagCalls].up == true)
now = 1.20
RseBag.handleInput(input({ held = "up" }), BagMenu)
assert(bagCalls[#bagCalls].up == false)
now = 1.30
RseBag.handleInput(input({ held = "up" }), BagMenu)
assert(bagCalls[#bagCalls].up == true)

-- Release resets; action mode is edge-only with no held repeat.
RseBag.handleInput(input({}), BagMenu)
BagMenu.mode = "action"
now = 2.0
RseBag.handleInput(input({ pressed = "down", held = "down" }), BagMenu)
assert(bagCalls[#bagCalls].down == true)
now = 4.0
RseBag.handleInput(input({ held = "down" }), BagMenu)
assert(bagCalls[#bagCalls].down == false)

-- Non-directional input survives the proxy.
RseBag.handleInput(input({ pressed = "a" }), BagMenu)
assert(bagCalls[#bagCalls].a == true)

-- Pyramid bag uses the same real-time gate and never sees held directions.
PyramidBag.show({ session = session })
now = 10
local pyrUp = input({ pressed = "up", held = "up" })
PyramidBag.handleInput(pyrUp)
PyramidBag.handleInput(pyrUp)
assert(pyramidCalls[1].up == true and pyramidCalls[2].up == false)
assert(pyramidCalls[1].heldUp == false and pyramidCalls[2].heldUp == false)
now = 11.0
PyramidBag.handleInput(input({ held = "up" }))
assert(pyramidCalls[#pyramidCalls].up == true)

PyramidBag.handleInput(input({}))
PyramidBag._st.mode = "toss"
now = 20
PyramidBag.handleInput(input({ pressed = "up", held = "up" }))
assert(pyramidCalls[#pyramidCalls].up == true)
now = 25
PyramidBag.handleInput(input({ held = "up" }))
assert(pyramidCalls[#pyramidCalls].up == false)

print("contract-ok")
