# Emerald real-time repeat regression checklist

## Normal RSE Bag

- One UP/DOWN tap moves exactly one row even if several fixed updates see the same `wasPressed` edge.
- LEFT/RIGHT pocket movement is also de-duplicated.
- Holding a direction produces no second move for about 1.00 second.
- Continued holding repeats about every 0.30 second.
- The cadence is independent of GAME SPEED.
- Action grids, toss quantity, confirmations and special Bag modes remain one movement per physical press.
- Downstream directional `isDown` is false, so another logic-frame repeat wrapper cannot bypass the final gate.

## Battle Pyramid Bag

- One UP/DOWN tap moves exactly one row.
- The screen's native snapshot repeat does not see held directional state.
- Holding in list mode repeats after about 1.00 second and then about every 0.30 second.
- Action/toss/confirmation/swap modes remain edge-only.

## Runtime scope

- Emerald profile installs both input gates.
- FireRed and LeafGreen install neither gate, even if the manifest is bypassed.
- No FRLG Help-system patch.
- No PokeNav patch.
- No battle-input or overworld-input patch.
