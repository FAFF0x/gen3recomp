-- Stable Menu Navigation - Gen 3 / Emerald
-- v1.3.0
--
-- Pokemon Emerald uses a different RSE bag skin and a separate Battle Pyramid
-- bag. Both can observe the same physical directional edge more than once when
-- GAME SPEED runs several fixed updates before the rendered input frame changes.
--
-- This Emerald-only port owns the final directional gate for those two RSE
-- inventory screens and drives held movement from wall-clock time instead of
-- logic-frame counters.

local VERSION = "1.3.0"
local MOD_ID = "pokemonmod_gen3_stable_menu_navigation_emerald"
local PATCH_KEY = "__pokemonmod_gen3_stable_menu_navigation_emerald_v1"
local LOGIC_HZ = 60
local DIRS = { "up", "down", "left", "right" }

-- Deliberately slow, matching the final FRLG v1.2.0 feel.
local BAG_DELAY_FRAMES = 60
local PYRAMID_DELAY_FRAMES = 60
local REPEAT_RATE_FRAMES = 18

local function wallTime()
  if love and love.timer and type(love.timer.getTime) == "function" then
    local ok, value = pcall(love.timer.getTime)
    if ok and type(value) == "number" then return value end
  end
  if os and type(os.clock) == "function" then return os.clock() end
  return 0
end

local function sec(frames)
  return math.max(0, tonumber(frames) or 0) / LOGIC_HZ
end

local function runtimeSession()
  local Runtime = package.loaded["src.core.game3.runtime"]
  return Runtime and Runtime.getSession and Runtime.getSession() or nil
end

local function isEmerald(session)
  session = session or runtimeSession()
  if type(session) == "table" and session.version == "emerald" then return true end
  local ok, Profile = pcall(require, "src.core.game3.profile")
  if not (ok and Profile and Profile.forSession) then return false end
  local okP, row = pcall(Profile.forSession, session)
  return okP and type(row) == "table" and row.id == "emerald" and row.family == "rse"
end

local function clearState(state)
  state.dir = nil
  state.nextAt = nil
  state.lastAt = nil
end

local function pressed(input, key)
  return input and type(input.wasPressed) == "function" and input:wasPressed(key) == true
end

local function down(input, key)
  return input and type(input.isDown) == "function" and input:isDown(key) == true
end

local function firstPressedDir(input)
  for _, key in ipairs(DIRS) do
    if pressed(input, key) then return key end
  end
  return nil
end

local function firstHeldDir(input)
  for _, key in ipairs(DIRS) do
    if down(input, key) then return key end
  end
  return nil
end

-- Consume a physical directional edge once, then create slow held repeats from
-- real time. This prevents several fixed updates from reusing one wasPressed().
local function realtimeDirection(state, input, delayFrames, rateFrames, allowRepeat)
  local now = wallTime()
  local edge = firstPressedDir(input)
  local held = firstHeldDir(input)
  local dir = held or edge

  if not dir then
    clearState(state)
    return nil
  end

  if state.dir ~= dir then
    state.dir = dir
    state.nextAt = now + sec(delayFrames)
    state.lastAt = now
    return dir
  end

  if not allowRepeat or not held then return nil end

  if type(state.nextAt) ~= "number" then
    state.nextAt = now + sec(delayFrames)
    return nil
  end

  if now >= state.nextAt then
    state.nextAt = now + math.max(0.001, sec(rateFrames))
    state.lastAt = now
    return held
  end

  return nil
end

local function isDir(key)
  return key == "up" or key == "down" or key == "left" or key == "right"
end

-- RSE screens build their own repeat state from both wasPressed and isDown.
-- Directional held state must therefore be hidden from the downstream screen;
-- our synthetic edge is the only directional event it receives.
local function makeInputProxy(input, synthetic)
  return setmetatable({
    wasPressed = function(_, key)
      if isDir(key) then return synthetic == key end
      return pressed(input, key)
    end,
    isDown = function(_, key)
      if isDir(key) then return false end
      return down(input, key)
    end,
  }, { __index = input })
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  if not isEmerald(nil) then
    mod.exports.active = false
    mod.exports.reason = "Emerald runtime required"
    mod.exports.version = VERSION
    mod.exports.emeraldOnly = true
    mod.exports.supportedGames = { "emerald" }
    return
  end

  local okBag, BagMenu = pcall(require, "src.ui.game3.bag_menu")
  local okRse, RseBag = pcall(require, "src.ui.game3.rse.bag_menu")
  local okPyr, PyramidBag = pcall(require, "src.ui.game3.rse.pyramid_bag")

  if not okBag or type(BagMenu) ~= "table" or type(BagMenu.show) ~= "function" then
    mod.log:error("Stable Menu Navigation Emerald could not access the shared Gen 3 BagMenu")
    mod.exports.active = false
    mod.exports.reason = "Gen 3 BagMenu unavailable"
    return
  end
  if not okRse or type(RseBag) ~= "table" or type(RseBag.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation Emerald could not access the RSE Bag skin")
    mod.exports.active = false
    mod.exports.reason = "Emerald RSE Bag unavailable"
    return
  end
  if not okPyr or type(PyramidBag) ~= "table" or type(PyramidBag.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation Emerald could not access the Battle Pyramid Bag")
    mod.exports.active = false
    mod.exports.reason = "Emerald Battle Pyramid Bag unavailable"
    return
  end

  local installed = rawget(_G, PATCH_KEY)
  if type(installed) == "table" and installed.active == true then
    mod.exports.active = true
    mod.exports.shared = true
    mod.exports.mode = "emerald_rse_realtime_repeat"
    mod.exports.version = VERSION
    mod.exports.generation = 3
    mod.exports.game = "emerald"
    mod.exports.profileFamily = "rse"
    mod.exports.emeraldOnly = true
    mod.exports.supportedGames = { "emerald" }
    return
  end

  local bagState = {}
  local pyramidState = {}

  local baseBagShow = BagMenu.show
  local baseRseHandleInput = RseBag.handleInput
  local basePyramidShow = PyramidBag.show
  local basePyramidHandleInput = PyramidBag.handleInput

  -- Capture diagnostics after higher-priority visual/menu mods have loaded.
  local modernBagDetected = type(rawget(BagMenu, "__pokemonmodModernBagGen3DispatchV1")) == "table"
    or type(rawget(RseBag, "__pokemonmodModernBagGen3DispatchV1")) == "table"

  BagMenu.show = function(...)
    clearState(bagState)
    return baseBagShow(...)
  end

  RseBag.handleInput = function(input, bag)
    bag = bag or BagMenu
    if not isEmerald(bag and bag._session) then
      return baseRseHandleInput(input, bag)
    end

    -- Only the normal item list repeats. RSE action grids, toss quantity,
    -- confirmations and special modes remain one movement per physical press.
    local allowRepeat = bag and bag.mode == "list"
      and not bag._switch and not bag._open and not bag._exit
    local synthetic = realtimeDirection(
      bagState, input, BAG_DELAY_FRAMES, REPEAT_RATE_FRAMES, allowRepeat
    )
    return baseRseHandleInput(makeInputProxy(input, synthetic), bag)
  end

  if type(basePyramidShow) == "function" then
    PyramidBag.show = function(...)
      clearState(pyramidState)
      return basePyramidShow(...)
    end
  end

  PyramidBag.handleInput = function(input)
    local st = PyramidBag._st or {}
    local sess = st.session or runtimeSession()
    if not isEmerald(sess) then return basePyramidHandleInput(input) end

    -- The Pyramid bag's snapshot() normally creates logic-frame held repeats.
    -- Hide directional isDown and feed only our wall-clock synthetic edge.
    local allowRepeat = st.mode == "list" and not st.suspended
    local synthetic = realtimeDirection(
      pyramidState, input, PYRAMID_DELAY_FRAMES, REPEAT_RATE_FRAMES, allowRepeat
    )
    return basePyramidHandleInput(makeInputProxy(input, synthetic))
  end

  rawset(_G, PATCH_KEY, {
    active = true,
    owner = MOD_ID,
    version = VERSION,
    bag = RseBag,
    pyramidBag = PyramidBag,
    bagHandleInput = RseBag.handleInput,
    pyramidHandleInput = PyramidBag.handleInput,
  })

  mod.exports.active = true
  mod.exports.shared = false
  mod.exports.mode = "emerald_rse_realtime_repeat"
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "emerald"
  mod.exports.profileFamily = "rse"
  mod.exports.emeraldOnly = true
  mod.exports.supportedGames = { "emerald" }
  mod.exports.logicHz = LOGIC_HZ
  mod.exports.bagInitialDelayFrames = BAG_DELAY_FRAMES
  mod.exports.pyramidInitialDelayFrames = PYRAMID_DELAY_FRAMES
  mod.exports.repeatRateFrames = REPEAT_RATE_FRAMES
  mod.exports.bagInitialDelaySeconds = sec(BAG_DELAY_FRAMES)
  mod.exports.pyramidInitialDelaySeconds = sec(PYRAMID_DELAY_FRAMES)
  mod.exports.repeatRateSeconds = sec(REPEAT_RATE_FRAMES)
  mod.exports.deduplicatesDirectionalEdges = true
  mod.exports.bagRepeatOnlyInList = true
  mod.exports.pyramidRepeatOnlyInList = true
  mod.exports.finalRseBagInputGate = true
  mod.exports.modernBagDetected = modernBagDetected
  mod.exports.requiredLoadPriority = 900
  mod.exports.targets = { bag = true, pyramidBag = true, help = false, pokenav = false }

  mod.log:info(
    "Stable Menu Navigation Gen 3 enabled: Emerald RSE Bag + Battle Pyramid real-time input gates"
  )
end
