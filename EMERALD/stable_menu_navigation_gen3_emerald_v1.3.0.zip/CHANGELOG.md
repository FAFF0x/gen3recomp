# Changelog

## 1.3.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to **Pokemon Emerald only**.
- New mod ID: `pokemonmod_gen3_stable_menu_navigation_emerald`.
- Manifest target changed to `games: ["emerald"]`.
- Added an explicit Emerald/RSE runtime guard.
- Replaced the FRLG Bag input patch with a final wrapper on `src.ui.game3.rse.bag_menu.handleInput`.
- Added stable real-time navigation to Emerald's separate Battle Pyramid Bag.
- Suppresses downstream directional held state so RSE logic-frame repeat cannot bypass the limiter.
- Removed the FRLG Help-system target; Emerald does not use that retail Help system.
- Bag and Pyramid list scrolling use a 60-frame-equivalent (~1.00 s) initial delay and 18-frame-equivalent (~0.30 s) repeat at 60 Hz.
- Action grids, toss/quantity screens and confirmation submenus stay one movement per physical press.
- Does not modify PokeNav, battle input, overworld movement, animations or text speed.
- Preserves priority 900 for final-gate compatibility with UI/Bag mods.

## 1.2.0 (FRLG source)

- Final input gate after Modern Bag.
- 60-frame Bag initial delay and 18-frame repeats.
- Directional edge de-duplication at high GAME SPEED.
