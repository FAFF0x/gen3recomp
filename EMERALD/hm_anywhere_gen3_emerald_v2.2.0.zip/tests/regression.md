# v2.2.0 Emerald regression checklist

- Manifest ID is `hm_anywhere_gen3_emerald` and `games` contains only `emerald`.
- No Kanto/Sevii Fly destination table remains.
- HM list contains HM01-HM08, including DIVE.
- Field TM list contains TM28 DIG and TM43 SECRET POWER.
- Native RSE Fly selector is reached through `Field.executeFieldMove({action="fly"})`.
- DIVE is delegated to the native Emerald dive engine.
- `FieldMoves.partyMoveUser` fallback activates only on Emerald, with CONTEXT enabled, and only for an owned supported machine.
- `script.command/checkpartymove` fallback changes VAR_RESULT only when vanilla reports slot 6 (not found).
- Normal Emerald START gets HM/TM entries; Safari/Pike/Pyramid/Link special menus are not modified.
- Context OFF restores the vanilla learned-move requirement.
- Modern UI presenter state is saved/restored for both the shared and RSE option-menu state shapes.
