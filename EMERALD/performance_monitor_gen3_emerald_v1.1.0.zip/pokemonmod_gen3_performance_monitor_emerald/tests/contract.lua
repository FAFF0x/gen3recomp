-- Lightweight contract test for the Emerald-only / Gen 3 port.
local registeredHooks, registeredEvents = {}, {}
local activeVersion = "emerald"

package.loaded["src.core.GameVersion"] = {
  get = function() return activeVersion end,
}
package.loaded["src.core.game3.profile"] = {
  forSession = function(session)
    local id = session and session.version or activeVersion
    if id == "emerald" then return { id = "emerald", family = "rse" } end
    return { id = id or "firered", family = "frlg" }
  end,
}

local function makeMod(generation)
  return {
    generation = generation,
    hooks = {
      wrap = function(_, name, cb, priority)
        registeredHooks[name] = { cb = cb, priority = priority }
        return function() end
      end,
    },
    events = {
      on = function(_, name, cb, priority)
        registeredEvents[name] = { cb = cb, priority = priority }
        return function() end
      end,
    },
    exports = {},
    log = {
      info = function() end,
      warn = function() end,
      error = function(_, msg) error(msg) end,
    },
  }
end

local chunk = assert(loadfile(arg[1]))
local install = assert(chunk())

-- Hard generation guard.
registeredHooks, registeredEvents = {}, {}
activeVersion = "emerald"
install(makeMod(2))
assert(next(registeredHooks) == nil and next(registeredEvents) == nil,
  "Emerald monitor activated for a non-Gen3 mod context")

-- Hard game guard: a forced FireRed load must remain inert.
registeredHooks, registeredEvents = {}, {}
activeVersion = "firered"
local frMod = makeMod(3)
install(frMod)
assert(next(registeredHooks) == nil and next(registeredEvents) == nil,
  "Emerald monitor activated on FireRed")

-- Emerald installs only the shared input/render seams plus game.ready.
registeredHooks, registeredEvents = {}, {}
activeVersion = "emerald"
local mod = makeMod(3)
install(mod)
assert(registeredHooks["input.step"], "input.step hook not registered")
assert(registeredHooks["render.hud"], "render.hud hook not registered")
assert(registeredEvents["game.ready"], "game.ready event not registered")
assert(type(mod.exports.getSnapshot) == "function", "snapshot export missing")
assert(type(mod.exports.getDiagnosticReport) == "function", "diagnostic export missing")
assert(type(mod.exports.exportDiagnosticReport) == "function", "report export missing")

-- Shared hook contracts must preserve downstream behavior.
local stepCalls = 0
local stepResult = registeredHooks["input.step"].cb(function(game, dt)
  stepCalls = stepCalls + 1
  return "step-ok", game, dt
end, { phase = "field", session = { version = "emerald" } }, 1/60)
assert(stepCalls == 1 and stepResult == "step-ok", "input.step downstream contract broken")

local hudCalls = 0
local hudResult = registeredHooks["render.hud"].cb(function(game, viewport)
  hudCalls = hudCalls + 1
  return "hud-ok"
end, { phase = "field", session = { version = "emerald" } }, { gameX = 0, gameY = 0 })
assert(hudCalls == 1 and hudResult == "hud-ok", "render.hud downstream contract broken")

-- A minimal Emerald game.ready event must be safe even when no other mods exist.
registeredEvents["game.ready"].cb({ game = {
  phase = "field",
  session = { version = "emerald", map = "EM_LITTLEROOT_TOWN" },
} })

assert(mod.exports.version == "1.1.0", "version export missing")
assert(mod.exports.generation == 3, "generation export missing")
assert(mod.exports.game == "emerald", "Emerald game export missing")
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald",
  "Emerald-only support missing")
assert(mod.exports.emeraldOnly == true, "emeraldOnly export missing")
assert(mod.exports.rseRuntime == true, "rseRuntime export missing")

print("performance-monitor-gen3-emerald-contract-ok")
