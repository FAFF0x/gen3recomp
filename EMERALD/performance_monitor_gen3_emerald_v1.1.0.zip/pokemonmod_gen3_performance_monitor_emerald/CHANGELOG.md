# Changelog

## 1.1.0
- Converted the mod from FireRed/LeafGreen to a dedicated Emerald-only build.
- Changed the manifest target to `games: ["emerald"]`.
- Changed the mod id to `pokemonmod_gen3_performance_monitor_emerald` so the Emerald build can coexist with the FR/LG build.
- Added an explicit `GameVersion` runtime guard so a forced load on FireRed/LeafGreen does not register profiling hooks.
- Replaced FR/LG game detection with Emerald detection using the active Game3 version/session.
- Added Emerald/RSE profile metadata to diagnostic environment snapshots.
- Moved diagnostic storage to the Emerald mod namespace through the new mod id.
- Kept shared Game3 Runtime, Map, Stack, renderer and profiler seams because Emerald's RSE implementation uses those same engine-level hooks.
- Preserved FPS, frame-time, renderer, memory, per-mod attribution, slow-frame correlation, provenance callbacks and 10-second diagnostics.
- Preserved Modern UI compatibility.

## 1.0.2
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Added explicit FRLG runtime compatibility exports.
- Replaced the hardcoded diagnostic `env.game = "firered"` with FRLG detection and a safe `frlg` fallback.
- Corrected the text export header from "GEN 2" to "GEN 3".
- Kept the shared Game3 Runtime, Map, Stack and profiling logic unchanged.
