# Changelog

## 2.1.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Added dedicated mod ID `pokemonmod_gen3_move_learn_stats_emerald` so it does not collide with the FR/LG build.
- Added Emerald runtime/profile guards in addition to `games: ["emerald"]`.
- Integrated with Emerald's RSE Summary skin while preserving the shared native `select_move` state.
- Added support for Emerald's BATTLE MOVES / CONTEST MOVES toggle during move selection.
- Contest view now shows Contest category, Appeal, Jam and the Emerald Contest effect description.
- Kept native Emerald HM protection, including HM08 DIVE.
- Added string move-ID normalization through the active Emerald constants profile.
- Retained Modern UI compatibility by drawing after the normal HUD chain rather than replacing the Summary UI.
- Updated tests and documentation for Emerald.

## 2.0.2

- FireRed/LeafGreen source version used as the conversion base.
