local root = os.getenv("MOD_ROOT") or "."

local SummaryMenu = {
  open = true,
  _mode = "select_move",
  _cursor = 1,
  _moveCursor = 2,
  _moveToLearn = 85,
  _hmNotice = false,
  _playerState = { version = "emerald" },
}
local mon = {
  moves = { 33, 45, 57, 291 },
  maxPp = { 35, 40, 18, 10 },
}
SummaryMenu._party = { mon }

local defs = {
  [33] = { name = "TACKLE", power = 40, accuracy = 100, pp = 35, type = 0 },
  [45] = { name = "GROWL", power = 0, accuracy = 100, pp = 40, type = 0 },
  [57] = { name = "SURF", power = 95, accuracy = 100, pp = 15, type = 11 },
  [291] = { name = "DIVE", power = 60, accuracy = 100, pp = 10, type = 11 },
  [85] = { name = "THUNDERBOLT", power = 95, accuracy = 100, pp = 15, type = 13 },
}
local names = { [33]="TACKLE", [45]="GROWL", [57]="SURF", [291]="DIVE", [85]="THUNDERBOLT" }

package.preload["src.core.game3.pokemon"] = function()
  return {
    moveIdAt = function(m, s) return m.moves[s] end,
    battleMove = function(id) return defs[tonumber(id)] end,
    moveName = function(id) return names[tonumber(id)] end,
    isHmMove = function(id) return tonumber(id) == 291 end,
    battleMoveId = function(name) return name == "THUNDERBOLT" and 85 or nil end,
  }
end
package.preload["src.ui.game3.summary_menu"] = function() return SummaryMenu end
package.preload["src.ui.game3.stack"] = function()
  return { top = function() return { id = "summary", mod = SummaryMenu } end }
end
package.preload["src.core.game3.summary_data"] = function()
  return { moveDescription = function(id) return "Battle description " .. tostring(id) end }
end
package.preload["src.core.game3.profile"] = function()
  return { forSession = function(s) return { id = s and s.version or "emerald", family = "rse" } end }
end
package.preload["src.core.game3.runtime"] = function()
  return { getSession = function() return SummaryMenu._playerState end }
end
package.preload["src.core.game3.constants"] = function()
  return { of = function() return { id = function(_, kind, value) if kind == "moves" and value == "THUNDERBOLT" then return 85 end end } end }
end
package.preload["src.ui.game3.rse.scene_kit"] = function()
  return {
    loadLua = function(path)
      assert(path == "data/generated/gba/pokemon/contest_moves.lua")
      return {
        moves = {
          [45] = { effect = 1, category = 2 },
          [85] = { effect = 2, category = 4 },
          [291] = { effect = 3, category = 1 },
        },
        effects = {
          [1] = { appeal = 20, jam = 0, description = "Growl contest effect" },
          [2] = { appeal = 40, jam = 20, description = "Thunderbolt contest effect" },
          [3] = { appeal = 30, jam = 10, description = "Dive contest effect" },
        },
        categories = { [1] = "Beauty", [2] = "Cute", [4] = "Cool" },
      }
    end,
  }
end
local rseState = { contest = false }
package.preload["src.ui.game3.rse.summary_menu"] = function() return { _st = rseState } end

local hook
local mod = {
  exports = {},
  hooks = { wrap = function(_, name, fn, priority) hook = {name=name,fn=fn,priority=priority} end },
  find = function() return nil end,
  log = { warn=function() end, info=function() end },
}

assert(loadfile(root .. "/main.lua"))()(mod)
assert(mod.exports.version == "2.1.0")
assert(mod.exports.generation == 3 and mod.exports.game == "emerald")
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald")
assert(mod.exports.emeraldOnly == true and mod.exports.fireRedSupported == false)
assert(mod.exports.active == true and mod.exports.deferredTo == nil)
assert(hook and hook.name == "render.hud" and hook.priority == 1200)

local ctx = assert(mod.exports.context())
assert(ctx.cursor == 2 and ctx.contest == false)
assert(ctx.selected.name == "GROWL" and ctx.selected.power == "---" and ctx.selected.pp == "40")
assert(ctx.learning.name == "THUNDERBOLT" and ctx.learning.power == "95")
assert(ctx.learning.type == "ELECTRIC" and ctx.learning.accuracy == "100")
assert(ctx.learning.appeal == "4" and ctx.learning.jam == "2")
assert(ctx.learning.contestCategory == "COOL")

rseState.contest = true
ctx = assert(mod.exports.context())
assert(ctx.contest == true)
assert(ctx.selected.contestCategory == "CUTE" and ctx.selected.appeal == "2")

SummaryMenu._moveCursor = 4
ctx = assert(mod.exports.context())
assert(ctx.selected.name == "DIVE" and ctx.selected.hm == true)
SummaryMenu._moveCursor = 5
ctx = assert(mod.exports.context())
assert(ctx.cancel == true and ctx.selected == nil)

SummaryMenu._moveToLearn = "THUNDERBOLT"
ctx = assert(mod.exports.context())
assert(ctx.learningId == 85)

SummaryMenu._playerState = { version = "firered" }
assert(mod.exports.context() == nil)
SummaryMenu._playerState = { version = "emerald" }
SummaryMenu._mode = nil
assert(mod.exports.context() == nil)

print("pokemonmod_gen3_move_learn_stats_emerald contract: ok")
