-- Move Learn Stats - Gen 3 Emerald (Pokemon MOD) v2.1.0
-- Emerald-only conversion of the FireRed/LeafGreen v2.0.2 mod.
--
-- Emerald still funnels full-moveset learning through the shared Game3
-- SummaryMenu select_move state, but renders it through the RSE summary skin.
-- This mod observes that state only: Emerald remains authoritative for cursor,
-- input, HM protection, cancellation, move replacement, PP, messages, fanfares,
-- item consumption and Contest/Battle page switching.

local Pokemon = require("src.core.game3.pokemon")
local SummaryMenu = require("src.ui.game3.summary_menu")
local Stack = require("src.ui.game3.stack")
local SummaryData = require("src.core.game3.summary_data")
local Profile = require("src.core.game3.profile")
local Runtime = require("src.core.game3.runtime")

local MOD_ID = "pokemonmod_gen3_move_learn_stats_emerald"
local VERSION = "2.1.0"
local EQUIVALENT_MOD_IDS = {
  "move_learn_stats_gen3_emerald",
  "move_learn_stats_emerald",
  "move_learn_stats",
}

local TYPE_NAMES = {
  [0] = "NORMAL", [1] = "FIGHTING", [2] = "FLYING", [3] = "POISON",
  [4] = "GROUND", [5] = "ROCK", [6] = "BUG", [7] = "GHOST",
  [8] = "STEEL", [9] = "???", [10] = "FIRE", [11] = "WATER",
  [12] = "GRASS", [13] = "ELECTRIC", [14] = "PSYCHIC", [15] = "ICE",
  [16] = "DRAGON", [17] = "DARK",
}

local function isEmeraldSession(session)
  if type(session) == "table" and tostring(session.version or ""):lower() == "emerald" then return true end
  local ok, row = pcall(Profile.forSession, session)
  return ok and type(row) == "table" and tostring(row.id or ""):lower() == "emerald"
end

local function activeSession()
  local live = Runtime and Runtime.getSession and Runtime.getSession() or nil
  if live then return live end
  return SummaryMenu and (SummaryMenu._playerState or SummaryMenu._session) or nil
end

local function isEmeraldActive()
  return isEmeraldSession(activeSession())
end

local function normalizeMoveId(value, session)
  local id = tonumber(value)
  if id then return id end
  if type(value) ~= "string" or value == "" then return nil end
  local okC, Constants = pcall(require, "src.core.game3.constants")
  if okC and Constants and Constants.of then
    local ok, C = pcall(Constants.of, session or activeSession())
    if ok and C and C.id then
      local okId, resolved = pcall(C.id, C, "moves", value)
      if okId and tonumber(resolved) then return tonumber(resolved) end
    end
  end
  if Pokemon and type(Pokemon.battleMoveId) == "function" then
    local ok, resolved = pcall(Pokemon.battleMoveId, value)
    if ok and tonumber(resolved) then return tonumber(resolved) end
  end
  return nil
end

local function moveIdAt(mon, slot)
  if not mon or not slot then return nil end
  if Pokemon and type(Pokemon.moveIdAt) == "function" then
    local ok, id = pcall(Pokemon.moveIdAt, mon, slot)
    if ok and tonumber(id) then return tonumber(id) end
  end
  local entry = mon.moves and mon.moves[slot]
  if type(entry) == "table" then
    return normalizeMoveId(entry.id or entry.move or entry.moveId or entry.num or entry[1])
  end
  return normalizeMoveId(entry)
end

local function typeName(v)
  if type(v) == "string" and v ~= "" then return string.upper(v) end
  return TYPE_NAMES[tonumber(v)] or tostring(v or "---")
end

local function maxPpFor(mon, slot, def)
  local entry = mon and mon.moves and slot and mon.moves[slot]
  if type(entry) == "table" and tonumber(entry.maxPp) then
    return math.max(0, math.floor(tonumber(entry.maxPp)))
  end
  if mon and type(mon.maxPp) == "table" and slot and tonumber(mon.maxPp[slot]) then
    return math.max(0, math.floor(tonumber(mon.maxPp[slot])))
  end
  return math.max(0, math.floor(tonumber(def and def.pp) or 0))
end

local contestCache
local function contestPack()
  if contestCache ~= nil then return contestCache or nil end
  contestCache = false
  local ok, Kit = pcall(require, "src.ui.game3.rse.scene_kit")
  if ok and Kit and type(Kit.loadLua) == "function" then
    local okLoad, pack = pcall(Kit.loadLua, "data/generated/gba/pokemon/contest_moves.lua")
    if okLoad and type(pack) == "table" then contestCache = pack end
  end
  return contestCache or nil
end

local function contestStats(moveId)
  local pack = contestPack()
  local move = pack and pack.moves and pack.moves[tonumber(moveId) or -1]
  if type(move) ~= "table" then
    return { category = "---", appeal = "---", jam = "---", description = "" }
  end
  local effect = pack.effects and pack.effects[tonumber(move.effect) or -1] or nil
  local function hearts(v)
    v = tonumber(v)
    if not v or v == 0xFF then return "---" end
    return tostring(math.max(0, math.floor(v / 10)))
  end
  local category = pack.categories and pack.categories[tonumber(move.category) or -1]
  if type(category) ~= "string" or category == "" then category = tostring(move.category or "---") end
  return {
    category = string.upper(category),
    appeal = hearts(effect and effect.appeal),
    jam = hearts(effect and effect.jam),
    description = effect and tostring(effect.description or ""):gsub("\n", " ") or "",
  }
end

local function moveStats(moveId, mon, slot)
  moveId = normalizeMoveId(moveId)
  if not moveId or moveId <= 0 then return nil end
  local def = Pokemon.battleMove(moveId) or {}
  local name = Pokemon.moveName(moveId)
  if not name or name == "" or tostring(name):match("^MOVE ") then
    name = def.name or ("MOVE " .. tostring(moveId))
  end
  local power = tonumber(def.power) or 0
  local acc = tonumber(def.accuracy) or 0
  local desc = ""
  if SummaryData and type(SummaryData.moveDescription) == "function" then
    local ok, value = pcall(SummaryData.moveDescription, moveId, name)
    if ok and value then desc = tostring(value):gsub("\n", " ") end
  end
  local isHm = false
  if Pokemon and type(Pokemon.isHmMove) == "function" then
    local ok, value = pcall(Pokemon.isHmMove, moveId)
    isHm = ok and value == true
  end
  local contest = contestStats(moveId)
  return {
    id = moveId,
    name = tostring(name or "---"),
    power = power > 0 and tostring(math.floor(power)) or "---",
    accuracy = acc > 0 and tostring(math.floor(acc)) or "---",
    pp = tostring(maxPpFor(mon, slot, def)),
    type = typeName(def.type or def.kind),
    description = desc,
    hm = isHm,
    contestCategory = contest.category,
    appeal = contest.appeal,
    jam = contest.jam,
    contestDescription = contest.description,
  }
end

local function contestView()
  local ok, RseSummary = pcall(require, "src.ui.game3.rse.summary_menu")
  return ok and type(RseSummary) == "table" and type(RseSummary._st) == "table"
    and RseSummary._st.contest == true
end

local function context()
  if not isEmeraldActive() then return nil end
  if not (SummaryMenu and SummaryMenu.open and SummaryMenu._mode == "select_move") then return nil end
  local top = Stack and Stack.top and Stack.top() or nil
  if top and top.id and top.id ~= "summary" then return nil end
  local party = SummaryMenu._party or {}
  local mon = party[SummaryMenu._cursor or 1]
  local learnId = normalizeMoveId(SummaryMenu._moveToLearn, SummaryMenu._playerState or SummaryMenu._session)
  if not (mon and learnId and learnId > 0) then return nil end
  local cursor = math.max(1, math.min(5, math.floor(tonumber(SummaryMenu._moveCursor) or 1)))
  local selectedId = cursor <= 4 and moveIdAt(mon, cursor) or nil
  return {
    mon = mon,
    cursor = cursor,
    selected = selectedId and moveStats(selectedId, mon, cursor) or nil,
    learning = moveStats(learnId, nil, nil),
    learningId = learnId,
    cancel = cursor == 5,
    hmNotice = SummaryMenu._hmNotice == true,
    contest = contestView(),
  }
end

local fontCache = {}
local function font(size)
  size = math.max(10, math.floor(size + 0.5))
  if not fontCache[size] and love and love.graphics and love.graphics.newFont then
    local ok, f = pcall(love.graphics.newFont, size)
    if ok then
      if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
      fontCache[size] = f
    end
  end
  return fontCache[size]
end

local function setColor(c, a)
  love.graphics.setColor(c[1], c[2], c[3], a or c[4] or 1)
end

-- Hoenn/Emerald-oriented high-resolution overlay palette.
local C = {
  deep = { 16/255, 71/255, 60/255, 1 },
  green = { 38/255, 145/255, 93/255, 1 },
  pale = { 237/255, 250/255, 240/255, 1 },
  white = { 1, 1, 1, 1 },
  text = { 24/255, 54/255, 47/255, 1 },
  muted = { 88/255, 119/255, 106/255, 1 },
  yellow = { 1, 213/255, 58/255, 1 },
  red = { 224/255, 70/255, 70/255, 1 },
  teal = { 43/255, 173/255, 151/255, 1 },
}

local function roundRect(mode, x, y, w, h, r)
  love.graphics.rectangle(mode, x, y, w, h, r, r)
end

local function text(str, x, y, size, color, align, width)
  local f = font(size)
  if f then love.graphics.setFont(f) end
  setColor(color or C.text)
  if width then
    love.graphics.printf(tostring(str or ""), x, y, width, align or "left")
  else
    love.graphics.print(tostring(str or ""), x, y)
  end
end

local function statLine(label, value, x, y, w, fs)
  text(label, x, y, fs, C.muted)
  text(value, x, y, fs, C.text, "right", w)
end

local function moveCard(stats, x, y, w, h, title, scale, selected, contest)
  setColor(C.white, 0.97)
  roundRect("fill", x, y, w, h, 8 * scale)
  if selected then
    setColor(C.yellow, 0.96)
    love.graphics.setLineWidth(math.max(2, 3 * scale))
  else
    setColor(C.green, 0.48)
    love.graphics.setLineWidth(math.max(1, 2 * scale))
  end
  roundRect("line", x, y, w, h, 8 * scale)

  local pad = 11 * scale
  text(title, x + pad, y + pad, 12 * scale, C.muted)
  if not stats then
    text("KEEP CURRENT MOVESET", x + pad, y + 31 * scale, 17 * scale, C.text)
    text("Selecting the fifth row cancels learning.", x + pad, y + 58 * scale,
      12 * scale, C.muted, "left", w - pad * 2)
    return
  end
  text(stats.name, x + pad, y + 28 * scale, 18 * scale, C.deep)
  local badgeW = math.min(w * 0.38, 108 * scale)
  setColor(C.pale)
  roundRect("fill", x + w - badgeW - pad, y + 27 * scale, badgeW, 25 * scale, 6 * scale)
  text(contest and stats.contestCategory or stats.type, x + w - badgeW - pad, y + 32 * scale,
    11 * scale, C.green, "center", badgeW)

  local sy = y + 64 * scale
  local sw = w - pad * 2
  if contest then
    statLine("APPEAL", stats.appeal, x + pad, sy, sw, 12 * scale)
    statLine("JAM", stats.jam, x + pad, sy + 20 * scale, sw, 12 * scale)
    statLine("MAX PP", stats.pp, x + pad, sy + 40 * scale, sw, 12 * scale)
  else
    statLine("POWER", stats.power, x + pad, sy, sw, 12 * scale)
    statLine("ACCURACY", stats.accuracy, x + pad, sy + 20 * scale, sw, 12 * scale)
    statLine("MAX PP", stats.pp, x + pad, sy + 40 * scale, sw, 12 * scale)
  end
  if stats.hm then
    text("HM • CANNOT BE FORGOTTEN", x + pad, sy + 62 * scale, 11 * scale, C.red)
  else
    local desc = contest and stats.contestDescription or stats.description
    if desc ~= "" then text(desc, x + pad, sy + 62 * scale, 11 * scale, C.muted, "left", sw) end
  end
end

local function drawOverlay(viewport)
  local ctx = context()
  if not ctx or not (love and love.graphics) then return end
  local G = love.graphics
  local vx = tonumber(viewport and viewport.gameX) or 0
  local vy = tonumber(viewport and viewport.gameY) or 0
  local vw = tonumber(viewport and viewport.gameWidth) or G.getWidth()
  local vh = tonumber(viewport and viewport.gameHeight) or G.getHeight()
  if vw < 1 or vh < 1 then return end
  local s = math.max(0.72, math.min(vw / 960, vh / 640))
  local margin = math.max(10, 14 * s)
  local panelW = math.min(vw * 0.44, 430 * s)
  local panelH = math.min(vh - margin * 2, 372 * s)
  local x = vx + margin
  local y = vy + math.max(margin, (vh - panelH) / 2)

  setColor(C.deep, 0.95)
  roundRect("fill", x, y, panelW, panelH, 12 * s)
  setColor(ctx.contest and C.teal or C.yellow, 1)
  G.rectangle("fill", x, y, panelW, math.max(4, 5 * s))
  text(ctx.contest and "CONTEST MOVE COMPARISON" or "BATTLE MOVE COMPARISON",
    x + 15 * s, y + 15 * s, 18 * s, C.white)
  text(ctx.contest and "Contest data follows Emerald's Summary tab" or "Choose the move to replace",
    x + 15 * s, y + 42 * s, 12 * s, {0.80,0.91,0.86,1})

  local cardX = x + 12 * s
  local cardW = panelW - 24 * s
  local cardH = 129 * s
  moveCard(ctx.cancel and nil or ctx.selected, cardX, y + 69 * s, cardW, cardH,
    "SELECTED", s, true, ctx.contest)
  moveCard(ctx.learning, cardX, y + 207 * s, cardW, cardH, "LEARNING", s, false, ctx.contest)

  local footerY = y + panelH - 27 * s
  local warn = ctx.hmNotice or (ctx.selected and ctx.selected.hm)
  if warn then
    text("HM moves cannot be forgotten", x + 14 * s, footerY, 11 * s, C.red)
  else
    text(ctx.contest and "LEFT/RIGHT: BATTLE ↔ CONTEST   •   A REPLACE   •   B CANCEL"
      or "LEFT/RIGHT: BATTLE ↔ CONTEST   •   A REPLACE   •   B CANCEL",
      x + 14 * s, footerY, 10.5 * s, C.white)
  end
end

return function(mod)
  local deferredTo
  if type(mod.find) == "function" then
    for _, id in ipairs(EQUIVALENT_MOD_IDS) do
      local ok, handle = pcall(mod.find, id)
      if ok and type(handle) == "table" then
        deferredTo = id
        break
      end
    end
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "emerald"
  mod.exports.supportedGames = { "emerald" }
  mod.exports.emeraldOnly = true
  mod.exports.fireRedSupported = false
  mod.exports.leafGreenSupported = false
  mod.exports.rubySupported = false
  mod.exports.sapphireSupported = false
  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  mod.exports.moveStats = moveStats
  mod.exports.context = context
  mod.exports.isEmeraldActive = isEmeraldActive

  if deferredTo then
    if mod.log and type(mod.log.info) == "function" then
      mod.log:info("Move Learn Stats Emerald deferred to active equivalent mod: %s", tostring(deferredTo))
    end
    return
  end

  if mod.hooks and type(mod.hooks.wrap) == "function" then
    -- Paint after the active UI chain so this coexists with the native Emerald
    -- RSE Summary skin and with gen3_modern_ui without replacing either one.
    mod.hooks:wrap("render.hud", function(next, game, viewport)
      local result = next(game, viewport)
      if context() then
        local ok, err = pcall(drawOverlay, viewport)
        if not ok and mod.log and type(mod.log.warn) == "function" then
          mod.log:warn("Move Learn Stats Emerald overlay failed: %s", tostring(err))
        end
      end
      return result
    end, 1200)
  end

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info("[%s] v%s installed for Emerald/RSE Summary select_move", MOD_ID, VERSION)
  end
end
