# Static contract - Emerald

- `manifest.games` contiene solo `["emerald"]`.
- ID della mod: `reusable_machines_gen3_emerald`, distinto dalla build FR/LG.
- L'entry installa le patch solo quando `Profile.active().id == "emerald"` e `family == "rse"`.
- `ItemsData.applyProfile("emerald")` viene eseguito prima delle patch TM/HM.
- La rimozione TM è soppressa solo durante il teaching della TM corrispondente o dentro `ItemUse.useTm` Emerald.
- Le HM restano protette fuori da un `LearnMove.begin` Emerald attivo.
- Gen 1-3 usano prima `Pokemon.canLearnTmIndex` nativo Emerald.
- Gen 4+ possono usare la tabella estesa TM01-TM50/HM01-HM08 fino al National Dex #1025.
- Modern UI viene rilevata tramite `gen3_modern_ui_emerald`, non tramite l'ID FR/LG.
- Nessuna UI sostituisce Bag, Party Menu, Summary o Learn Move di Emerald.
