# Changelog

## 2.2.0 - Emerald-only conversion

- Convertita la mod da FireRed/LeafGreen a **Pokémon Emerald soltanto**.
- Nuovo ID `reusable_machines_gen3_emerald`, separato dalla build FR/LG.
- Manifest limitato a `games: ["emerald"]`.
- Aggiunto guard runtime `emerald` / `rse` prima di installare patch globali.
- Forzato il modello Bag/ItemsData Emerald prima di leggere TM/HM.
- `Pokemon.canLearnTmIndex` usa prima i dati nativi Emerald e applica la tabella estesa solo alle specie National Dex > 386.
- Consumo TM soppresso solo durante insegnamento Emerald; vendita/toss/rimozioni normali restano native.
- Protezione HM disattivata soltanto durante il normale `LearnMove.begin` Emerald.
- Compatibilità Modern UI aggiornata a `gen3_modern_ui_emerald`.
- Rilevamento Egg reso compatibile anche con `Pokemon.isEgg`.

# Changelog

## 2.1.0
- Added extended TM/HM compatibility for later-generation National Dex species.
- Preserved exact FRLG ROM compatibility for National Dex #001-#386.
- Added a 58-machine compatibility table for National Dex species through #1025.
- Patched `Pokemon.canLearnTmIndex` so the fix affects real TM/HM teaching, not only the Party preview.
- `ItemUse.checkTmPreflight`, Party `CAN LEARN` badges and direct TM use now share the same compatibility result.
- Fixed cases such as Buzzwole being incorrectly rejected for TM31 Brick Break.
- Reusable TM consumption and scoped HM replacement behavior are unchanged.
- FireRed + LeafGreen support and the existing `reusable_machines_gen3` id are preserved.

## 2.0.3
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Updated runtime `supportedGames` metadata for both FRLG games.
- Added explicit `game = "frlg"` and version metadata.
- Kept reusable TM teaching, scoped HM replacement, TM/HM compatibility preview, and native Game3 UI ownership unchanged.
- Preserved the existing `reusable_machines_gen3` id so this version upgrades the current mod instead of creating a duplicate.

## 2.0.2
- Added immediate TM/HM compatibility preview on the Party target screen.
- Every Pokémon now shows CAN LEARN, LEARNED, NOT ABLE, or EGG before selection.
- Added the selected machine + move name to the Party header overlay.
- Overlay is presentation-only and drawn after Modern UI, preserving native input/state.
- Kept reusable TM and forgettable-HM behavior from v2.0.1 unchanged.


## 2.0.1

- Port nativo a FireRed / Game3.
- Target esclusivo `firered`.
- TM01-TM50 riutilizzabili dopo insegnamento riuscito.
- Vendita/toss delle TM non alterati.
- HM sostituibili durante il normale flusso LearnMove senza disabilitare globalmente la protezione HM.
- Compatibilità con UI Game3/Modern UI mantenendo i menu engine-owned.
- ID/namespace separato `reusable_machines_gen3` e guardie anti-doppia patch.
