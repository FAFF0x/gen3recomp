# Changelog

## 1.2.0
- Converted the mod from FireRed/LeafGreen to **Emerald only**.
- Added a dedicated Emerald manifest id so the FR/LG and Emerald packages can coexist.
- Added a runtime Emerald profile guard in addition to the manifest target.
- Adapted the PartyMenu action injection to Emerald's dynamic RSE field-move list.
- Added a renderer bridge for Emerald's strict cursor-option renderer, preventing `RENAME` from triggering an unknown-action assertion.
- Switched the naming flow to use Emerald's active naming-screen manifest/template data.
- Pre-fills the naming screen with the current nickname or species name.
- Added restrictions for Emerald special party contexts: Safari, Battle Pike, Battle Pyramid, Multi Partner Room, Link and Union Room.
- Preserved Egg and battle restrictions and Modern UI compatibility.

## 1.1.3
- FireRed/LeafGreen release used as the conversion base.
