-- Nickname Changer - Gen 3 Emerald v1.2.0
-- Emerald-only conversion of FAFF0x's Gen 3 Nickname Changer.
--
-- Emerald uses the shared Game3 PartyMenu with an RSE-specific action manifest.
-- Unknown action ids assert inside the stock renderer, so this mod decorates the
-- live action list and supplies a narrow renderer bridge for the custom RENAME row.

local VERSION = "1.2.0"
local MOD_ID = "pokemonmod_gen3_nickname_changer_emerald"
local LABEL = "RENAME"
local INPUT_SENTINEL = "__pokemonmod_gen3_nickname_changer_emerald_input_v120"
local DRAW_SENTINEL = "__pokemonmod_gen3_nickname_changer_emerald_draw_v120"

local renameActive = false
local swallowPartyInputOnce = false

local function upper(value)
  return tostring(value or ""):upper()
end

local function isRenameLabel(value)
  local s = upper(value)
  return s == "RENAME" or s == "NICKNAME"
    or s:find("RENAME", 1, true) ~= nil
    or s:find("NICKNAME", 1, true) ~= nil
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local okParty, PartyMenu = pcall(require, "src.ui.game3.party_menu")
  local okNaming, Naming = pcall(require, "src.ui.game3.naming")
  local okPokemon, Pokemon = pcall(require, "src.core.game3.pokemon")
  local okProfile, Profile = pcall(require, "src.core.game3.profile")
  local okFont, FrlgFont = pcall(require, "src.ui.game3.frlg_font")

  if not okParty or type(PartyMenu) ~= "table"
      or not okNaming or type(Naming) ~= "table"
      or not okPokemon or type(Pokemon) ~= "table"
      or not okProfile or type(Profile) ~= "table" then
    mod.log:error("Emerald nickname runtime is unavailable")
    return
  end

  local function currentSession()
    if type(PartyMenu._session) == "table" then return PartyMenu._session end
    local Runtime = package.loaded["src.core.game3.runtime"]
    if not Runtime then
      local ok, loaded = pcall(require, "src.core.game3.runtime")
      if ok then Runtime = loaded end
    end
    return Runtime and Runtime.getSession and Runtime.getSession() or nil
  end

  local function isEmerald()
    local session = currentSession()
    local ok, row = pcall(Profile.forSession, session)
    if ok and type(row) == "table" and row.id ~= nil then
      return row.id == "emerald"
    end
    return type(session) == "table" and session.version == "emerald"
  end

  local function mapId()
    local Map = package.loaded["src.core.game3.map"]
    if type(Map) == "table" and type(Map.current) == "string" then return Map.current end
    local session = currentSession()
    return type(session) == "table" and session.map or nil
  end

  local function inRestrictedEmeraldContext()
    if not isEmerald() then return true end
    local session = currentSession()
    local here = mapId()

    -- Emerald special Start-menu party contexts should remain retail-only.
    local okData, Data = pcall(require, "src.ui.game3.rse.start_menu_data")
    if okData and type(Data) == "table" then
      if Data.PIKE_MAPS and Data.PIKE_MAPS[here or ""] then return true end
      if Data.PYRAMID_MAPS and Data.PYRAMID_MAPS[here or ""] then return true end
      if here ~= nil and here == Data.MULTI_PARTNER_ROOM then return true end
    end

    local okPike, Pike = pcall(require, "src.core.game3.rse.frontier.pike")
    if okPike and Pike and Pike.inBattlePike then
      local ok, active = pcall(Pike.inBattlePike, session)
      if ok and active == true then return true end
    end

    local okSafari, Safari = pcall(require, "src.core.game3.safari")
    if okSafari and Safari and Safari.isActive then
      local ok, active = pcall(Safari.isActive, session)
      if ok and active == true then return true end
    end

    local okLink, Link = pcall(require, "src.core.game3.link")
    if okLink and Link and Link.inLinkRoom then
      local ok, active = pcall(Link.inLinkRoom)
      if ok and active == true then return true end
    end

    local okUnion, Union = pcall(require, "src.core.game3.link.union_room")
    if okUnion and Union and Union.isUnionMap then
      local ok, active = pcall(Union.isUnionMap, here)
      if ok and active == true then return true end
    end

    return false
  end

  local function speciesName(mon)
    if not mon then return "POKEMON" end
    local species = Pokemon.speciesOf and Pokemon.speciesOf(mon)
      or tonumber(mon.species or mon.speciesId)
    local name = species and Pokemon.name and Pokemon.name(species)
    return (name and tostring(name)) or "POKEMON"
  end

  local function currentMon()
    local party = PartyMenu._party
    local idx = tonumber(PartyMenu.cursor) or 1
    return type(party) == "table" and party[idx] or nil
  end

  local function findRenameIndex(actions)
    if type(actions) ~= "table" then return nil end
    for i, action in ipairs(actions) do
      if isRenameLabel(action) then return i end
    end
    return nil
  end

  local function canRename()
    if not isEmerald() or inRestrictedEmeraldContext() then return false end
    local mon = currentMon()
    if not mon then return false end
    if Pokemon.isEgg and Pokemon.isEgg(mon) or mon.isEgg or mon.egg then return false end
    if PartyMenu._battle then return false end
    if PartyMenu._previousMode and PartyMenu._previousMode ~= "list" then return false end
    if PartyMenu._tutor or PartyMenu._chooseOrder or PartyMenu._minigameEligible then return false end
    return true
  end

  local function ensureRenameAction()
    if PartyMenu.mode ~= "action" or not canRename() then return false end
    local actions = PartyMenu.ACTIONS
    if type(actions) ~= "table" then return false end
    if findRenameIndex(actions) then return true end

    local insertAt
    for i, action in ipairs(actions) do
      if upper(action) == "SUMMARY" then
        insertAt = i + 1
        break
      end
    end
    if not insertAt then
      for i, action in ipairs(actions) do
        if upper(action) == "CANCEL" then
          insertAt = i
          break
        end
      end
    end
    table.insert(actions, insertAt or (#actions + 1), LABEL)
    return true
  end

  local function openNamingScreen(mon)
    if not isEmerald() or inRestrictedEmeraldContext() or not mon then return false end
    if Pokemon.isEgg and Pokemon.isEgg(mon) or mon.isEgg or mon.egg then return false end

    local species = Pokemon.speciesOf and Pokemon.speciesOf(mon)
      or tonumber(mon.species or mon.speciesId)
    local speciesLabel = speciesName(mon)
    local oldNickname = mon.nickname
    local seed = (type(oldNickname) == "string" and oldNickname ~= "")
      and oldNickname or speciesLabel

    PartyMenu.mode = "list"
    PartyMenu.actionCursor = 1
    renameActive = true
    swallowPartyInputOnce = false

    Naming.open({
      template = "NICKNAME",
      maxLen = 10,
      species = species,
      personality = mon.personality,
      seed = seed,
      initialText = seed,
      session = currentSession(),
      title = Naming.monTitle and Naming.monTitle(speciesLabel)
        or (speciesLabel .. "'s nickname?"),
      onDone = function(name)
        renameActive = false
        swallowPartyInputOnce = true

        if type(name) == "string" and name ~= "" then
          if upper(name) == upper(speciesLabel) then
            mon.nickname = nil
          else
            mon.nickname = name
          end
          mod.log:info("Renamed %s to %s", tostring(speciesLabel), tostring(name))
        end
        PartyMenu.mode = "list"
        PartyMenu.actionCursor = 1
        if PartyMenu.reloadSprites then pcall(PartyMenu.reloadSprites) end
      end,
    })
    return true
  end

  if not PartyMenu[INPUT_SENTINEL] then
    if type(PartyMenu.handleInput) ~= "function" then
      mod.log:error("Emerald PartyMenu input API changed; RENAME cannot be installed")
      return
    end

    local previousHandleInput = PartyMenu.handleInput
    PartyMenu.handleInput = function(input)
      if not isEmerald() then return previousHandleInput(input) end

      if renameActive and Naming.isOpen and Naming.isOpen() then return end
      if swallowPartyInputOnce then
        swallowPartyInputOnce = false
        return
      end

      if PartyMenu.mode == "action" then
        ensureRenameAction()
        local actions = PartyMenu.ACTIONS or {}
        local selected = actions[tonumber(PartyMenu.actionCursor) or 1]
        if isRenameLabel(selected) and input and input.wasPressed
            and input:wasPressed("a") and canRename() then
          pcall(function() require("src.core.game3.audio").playSe(5) end)
          openNamingScreen(currentMon())
          return
        end
      end

      local result = previousHandleInput(input)
      if PartyMenu.mode == "action" then ensureRenameAction() end
      return result
    end
    PartyMenu[INPUT_SENTINEL] = true
  end

  -- Emerald's RSE PartyMenu renderer asserts on unknown cursor-option ids.
  -- Temporarily present the custom row as CANCEL to vanilla, then replace only
  -- that row's visible text with RENAME using the Emerald party-menu insets.
  if not PartyMenu[DRAW_SENTINEL] and type(PartyMenu.draw) == "function"
      and okFont and type(FrlgFont) == "table" and type(FrlgFont.draw) == "function" then
    local previousDraw = PartyMenu.draw
    PartyMenu.draw = function(...)
      if not isEmerald() or PartyMenu.mode ~= "action" then
        return previousDraw(...)
      end
      ensureRenameAction()
      local actions = PartyMenu.ACTIONS
      local idx = findRenameIndex(actions)
      if not idx then return previousDraw(...) end

      local row = Profile.forSession(currentSession())
      local insets = row and row.ui and row.ui.party and row.ui.party.insets
        or { actX = 8, actY = 1 }
      local popH = #actions * 2
      local popX = 19
      local popY = 19 - popH
      local expectedX = popX * 8 + (tonumber(insets.actX) or 8)
      local expectedY = popY * 8 + (idx - 1) * 16 + (tonumber(insets.actY) or 1)

      local oldAction = actions[idx]
      local oldFontDraw = FrlgFont.draw
      local replaced = false
      actions[idx] = "CANCEL"
      FrlgFont.draw = function(text, x, y, opts)
        if not replaced and x == expectedX and y == expectedY then
          replaced = true
          text = LABEL
        end
        return oldFontDraw(text, x, y, opts)
      end

      local result = { pcall(previousDraw, ...) }
      FrlgFont.draw = oldFontDraw
      actions[idx] = oldAction
      if not result[1] then error(result[2], 0) end
      return unpack(result, 2)
    end
    PartyMenu[DRAW_SENTINEL] = true
  end

  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "emerald"
  mod.exports.supportedGames = { "emerald" }
  mod.exports.emeraldOnly = true
  mod.exports.isEmerald = isEmerald
  mod.exports.rename = function(mon) return openNamingScreen(mon) end
  mod.exports.isInstalled = function()
    return PartyMenu[INPUT_SENTINEL] == true
  end
  mod.exports.isRenaming = function()
    return renameActive and Naming.isOpen and Naming.isOpen() or false
  end
  mod.exports.actionLabel = LABEL
end
