-- Emerald contract test for Nickname Changer v1.2.0.
local mon = { species = 25, level = 20, nickname = nil, personality = 1234 }
local session = { version = "emerald", map = "EM_LITTLEROOT_TOWN", party = { mon } }

local PartyMenu = {
  _party = { mon }, _session = session, cursor = 1, mode = "list", _battle = false,
  _previousMode = "list", actionCursor = 1, ACTIONS = {},
}
function PartyMenu.handleInput(input)
  if PartyMenu.mode == "list" and input:wasPressed("a") then
    PartyMenu.ACTIONS = { "SUMMARY", "CUT", "SWITCH", "ITEM", "CANCEL" }
    PartyMenu.mode = "action"
    PartyMenu.actionCursor = 1
  end
end
function PartyMenu.reloadSprites() end

local fontCalls = {}
local FrlgFont = { draw = function(text, x, y) fontCalls[#fontCalls + 1] = { text, x, y } end }
function PartyMenu.draw()
  -- This simulates the current Emerald renderer's strict cursor-option lookup.
  for _, action in ipairs(PartyMenu.ACTIONS or {}) do
    assert(action ~= "RENAME" and action ~= "NICKNAME", "native renderer saw custom action")
  end
  local actions = PartyMenu.ACTIONS
  local popH, popX = #actions * 2, 19
  local popY = 19 - popH
  for i, action in ipairs(actions) do
    FrlgFont.draw(action, popX * 8 + 8, popY * 8 + (i - 1) * 16 + 1)
  end
end

local namingOpts
local namingOpen = false
local Naming = {
  monTitle = function(n) return n .. " nickname" end,
  open = function(opts) namingOpts = opts; namingOpen = true end,
  isOpen = function() return namingOpen end,
}
local Pokemon = {
  speciesOf = function(m) return m.species end,
  name = function(id) return id == 25 and "PIKACHU" or "POKEMON" end,
  isEgg = function(m) return m.isEgg == true end,
}
local Profile = {
  forSession = function(s)
    if s and s.version == "emerald" then
      return { id = "emerald", family = "rse", ui = { party = { insets = { actX = 8, actY = 1 } } } }
    end
    return { id = "firered", family = "frlg", ui = {} }
  end,
}
local StartData = {
  PIKE_MAPS = { EM_BATTLE_FRONTIER_BATTLE_PIKE_ROOM_NORMAL = true },
  PYRAMID_MAPS = { EM_BATTLE_FRONTIER_BATTLE_PYRAMID_FLOOR = "floor" },
  MULTI_PARTNER_ROOM = "EM_BATTLE_FRONTIER_BATTLE_TOWER_MULTI_PARTNER_ROOM",
}

package.loaded["src.ui.game3.party_menu"] = PartyMenu
package.loaded["src.ui.game3.naming"] = Naming
package.loaded["src.core.game3.pokemon"] = Pokemon
package.loaded["src.core.game3.profile"] = Profile
package.loaded["src.ui.game3.frlg_font"] = FrlgFont
package.loaded["src.ui.game3.rse.start_menu_data"] = StartData
package.loaded["src.core.game3.rse.frontier.pike"] = { inBattlePike = function() return false end }
package.loaded["src.core.game3.safari"] = { isActive = function() return false end }
package.loaded["src.core.game3.link"] = { inLinkRoom = function() return false end }
package.loaded["src.core.game3.link.union_room"] = { isUnionMap = function() return false end }
package.loaded["src.core.game3.audio"] = { playSe = function() end }
package.loaded["src.core.game3.map"] = { current = "EM_LITTLEROOT_TOWN" }

local mod = {
  generation = 3,
  log = { info = function() end, warn = function() end, error = function(_, msg) error(msg) end },
  exports = {},
}

assert(loadfile(arg[1]))()(mod)
assert(mod.exports.version == "1.2.0", "version export mismatch")
assert(mod.exports.game == "emerald", "Emerald game export mismatch")
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald", "Emerald-only export mismatch")
assert(mod.exports.emeraldOnly == true and mod.exports.isEmerald() == true, "Emerald runtime guard failed")

local function input(key)
  return { wasPressed = function(_, k) return k == key end }
end

PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "action", "party action popup did not open")
assert(table.concat(PartyMenu.ACTIONS, ",") == "SUMMARY,RENAME,CUT,SWITCH,ITEM,CANCEL",
  "RENAME was not inserted after SUMMARY while preserving Emerald field moves")

-- Native draw must never see the unknown custom action, but the visible row must.
fontCalls = {}
PartyMenu.draw()
assert(PartyMenu.ACTIONS[2] == "RENAME", "draw bridge did not restore custom action")
local visible = false
for _, c in ipairs(fontCalls) do if c[1] == "RENAME" then visible = true end end
assert(visible, "draw bridge did not render RENAME label")

PartyMenu.actionCursor = 2
PartyMenu.handleInput(input("a"))
assert(namingOpts and namingOpts.template == "NICKNAME", "Emerald naming screen not opened")
assert(namingOpts.maxLen == 10, "nickname length must be 10")
assert(namingOpts.species == 25 and namingOpts.seed == "PIKACHU", "naming context mismatch")
assert(namingOpts.initialText == "PIKACHU", "current name was not pre-filled")
assert(namingOpts.session == session, "Emerald session was not supplied to naming screen")

-- Modal ownership / one-edge swallow.
PartyMenu.mode = "action"
PartyMenu.actionCursor = 4
PartyMenu.handleInput(input("down"))
assert(PartyMenu.actionCursor == 4, "PartyMenu received input while Naming was open")
namingOpen = false
namingOpts.onDone("SPARKY")
PartyMenu.mode = "list"
PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "list", "confirm edge leaked after Naming closed")
PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "action", "PartyMenu did not resume after swallowed edge")
assert(mon.nickname == "SPARKY", "nickname was not stored")

-- Species name clears nickname.
PartyMenu.actionCursor = 2
PartyMenu.handleInput(input("a"))
namingOpen = false
namingOpts.onDone("PIKACHU")
assert(mon.nickname == nil, "species name should clear custom nickname")
PartyMenu.handleInput(input("none"))

-- Egg stays untouched.
mon.isEgg = true
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "CUT", "CANCEL" }
PartyMenu.handleInput(input("none"))
assert(#PartyMenu.ACTIONS == 3, "RENAME inserted for Egg")
mon.isEgg = false

-- Pike stays retail-only.
package.loaded["src.core.game3.map"].current = "EM_BATTLE_FRONTIER_BATTLE_PIKE_ROOM_NORMAL"
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "CANCEL" }
PartyMenu.handleInput(input("none"))
assert(#PartyMenu.ACTIONS == 2, "RENAME inserted in Battle Pike")
package.loaded["src.core.game3.map"].current = "EM_LITTLEROOT_TOWN"

-- Forced FireRed runtime must stay inert.
session.version = "firered"
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "SWITCH", "ITEM", "CANCEL" }
PartyMenu.handleInput(input("none"))
assert(#PartyMenu.ACTIONS == 4, "Emerald mod modified FireRed runtime")
assert(mod.exports.isEmerald() == false, "FireRed runtime reported as Emerald")

print("nickname-changer-gen3-emerald-contract-ok")
