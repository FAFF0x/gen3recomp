# Changelog

## 1.5.0 - Emerald conversion
- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Changed the mod id to `modern_battle_ui_gen3_emerald` so the Emerald build does not overwrite/conflict with the FRLG build.
- Changed manifest compatibility to `games = ["emerald"]` only.
- Added a runtime Emerald guard in addition to manifest filtering.
- Rebased presentation assumptions on Emerald's RSE battle profile instead of FRLG-specific battle flows.
- Added compact modern health cards for Emerald double battles and two-opponent battles.
- Added active-battler indication for player-side doubles.
- Added target-aware effectiveness lookup during double-battle target selection.
- Added Emerald Safari Zone command presentation: BALL / POKéBLOCK / GO NEAR / RUN.
- Preserved Professor Birch's first battle, Wally tutorial, Battle Frontier, double-battle logic, battle scripts, AI and native animations.
- Kept Emerald's generic SummaryMenu state as the move-learning state owner; the RSE summary skin remains untouched outside the covered battle-learning presentation.
- Reworked colors toward a Hoenn/Emerald palette while retaining Modern Battle UI readability.
- Updated README, mod card and tests for Emerald-only compatibility.
- Fixed stale test version assertions inherited from earlier FRLG releases.

## 1.4.0 - FRLG source release
- Added modern battle dialogue, choices, level-up stat growth and in-battle move-learning presentation.
- Kept native FRLG input, sequencing and battle calculations untouched.

## 1.3.1
- Added LeafGreen support alongside FireRed.

## 1.3.0
- Added SELECT move information and live move-effect explanations.

## 1.2.0
- Added move-effectiveness badges, live EXP and Pokédex caught-state display.
