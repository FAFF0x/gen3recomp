local root = assert(os.getenv("MODROOT"), "MODROOT missing")

-- Adapter-level tests for Emerald session detection, live EXP and Pokédex ownership.
local anim = { displayExpRatio = function() return 0.625 end, present = function() return nil end }
package.loaded["src.core.game3.battle.anim"] = anim
package.loaded["src.core.game3.battle.experience"] = { progress = function() return { progressPercent = 0.4 } end }
local session = { version="emerald", dex = { caught = { [25] = true, [7] = true } } }
package.loaded["src.core.game3.runtime"] = { getSession = function() return session end }
package.loaded["src.core.game3.profile"] = { forSession = function(s) return { id=s.version, battle={family=s.version == "emerald" and "rse" or "frlg"} } end }
package.loaded["src.core.game3.dex"] = { isCaught = function(dex, species) return dex.caught[species] == true end }

local G = assert(loadfile(root .. "/src/gen3.lua"))()
local battler = { species = 25, mon = { species = 25, level = 20, exp = 1000 } }
assert(G.isEmerald() == true, "Emerald session must be accepted")
session.version = "firered"
assert(G.isEmerald() == false, "FireRed session must be rejected")
session.version = "emerald"
assert(math.abs(G.expRatio("player", battler) - 0.625) < 0.0001, "animated EXP ratio must win")
anim.displayExpRatio = nil
assert(math.abs(G.expRatio("player", battler) - 0.4) < 0.0001, "EXP growth fallback")
assert(G.enemyCaught(battler, {}) == true, "caught species should be reported")
assert(G.enemyCaught({species=1, mon={species=1}}, {}) == false, "uncaught species should be reported")

-- Full HUD smoke test for singles and SELECT move info.
local shown = {}
local fontObj = {
  setFilter=function() end,
  getWidth=function(_, s) return #tostring(s) * 7 end,
  getHeight=function() return 14 end,
}
_G.love = { graphics = {
  newFont=function() return fontObj end,
  getFont=function() return fontObj end,
  setFont=function() end,
  setColor=function() end,
  rectangle=function() end,
  circle=function() end,
  arc=function() end,
  line=function() end,
  setLineWidth=function() end,
  push=function() end,
  pop=function() end,
  setScissor=function() end,
  print=function(v) shown[#shown+1]=tostring(v) end,
  printf=function(v) shown[#shown+1]=tostring(v) end,
} }

local player = { species=4, type1=10, mon={species=4, hp=30, maxHp=40, level=12, moves={1,2,3,4}, pp={10,10,10,10}, maxPp={10,10,10,10}} }
local enemy = { species=25, type1=12, mon={species=25, hp=20, maxHp=35, level=11} }
local state = { session=session, player=player, enemy=enemy }
local UI = { _mode="moves", _menuIndex=1, _moveIndex=1, _active=0, _target=nil }
package.loaded["src.core.game3.battle"] = {
  _phase="command",
  isActive=function() return true end,
  getState=function() return state end,
}
package.loaded["src.core.game3.battle.ui"] = UI
package.loaded["src.core.game3.battle.state"] = { displayName=function(b)
  if b == player then return "TORCHIC" end
  if b == enemy then return "TREECKO" end
  return b and b.label or "POKéMON"
end }
package.loaded["src.core.game3.battle.moves"] = {
  get=function(id)
    local defs = {
      [1]={type=10,power=40,accuracy=100,pp=25,category="special",effect=4,secondaryChance=10,target=0,priority=0},
      [2]={type=13,power=40,pp=30,category="special"},
      [3]={type=0,power=0,pp=40,accuracy=100,category="status",effect=18,target=8},
      [4]={type=11,power=40,pp=25,category="special"},
    }
    return defs[id]
  end,
  displayName=function(id) return ({[1]="EMBER",[2]="THUNDER",[3]="GROWL",[4]="WATER GUN"})[id] end,
}
package.loaded["src.core.game3.battle.types"] = {
  name=function(id) return ({[0]="NORMAL",[10]="FIRE",[11]="WATER",[12]="GRASS",[13]="ELECTRIC"})[id] or "NORMAL" end,
  effectiveness=function(atk, d1)
    if atk == 10 and d1 == 12 then return 2 end
    if atk == 10 and d1 == 11 then return 0.5 end
    if atk == 13 and d1 == 4 then return 0 end
    if atk == 11 and d1 == 12 then return 0.5 end
    return 1
  end,
}
package.loaded["src.core.game3.battle.anim"] = { present=function() return nil end, displayExpRatio=function() return 0.5 end }

local files = {}
for _, rel in ipairs({"src/gen3.lua","src/move_info.lua","src/hud.lua"}) do
  files[rel] = assert(io.open(root .. "/" .. rel, "rb")):read("*a")
end
local wraps = {}
local mod = {
  generation=3,
  read=function(_, rel) return files[rel] end,
  options={ values={}, define=function(self, rows) for _,r in ipairs(rows) do self.values[r.key]=r.default end end, get=function(self,k) return self.values[k] end },
  hooks={ wrap=function(_, name, fn) wraps[name]=fn end },
  log={ warn=function() end }, exports={},
}
assert(load(assert(io.open(root .. "/main.lua","rb")):read("*a"), "@main.lua"))()(mod)
local viewport={gameX=0,gameY=0,gameWidth=960,gameHeight=640}
wraps["render.hud"](function() return true end, {}, viewport)
local all = table.concat(shown, "|")
assert(all:find("×2 SUPER", 1, true), "super-effective badge missing")
assert(all:find("STATUS", 1, true), "status badge missing")
assert(all:find("×½ RESIST", 1, true), "resisted badge missing")
assert(all:find("EXP", 1, true), "EXP label missing")
assert(all:find("CAUGHT", 1, true), "caught indicator missing")
assert(all:find("SELECT  DETAILS", 1, true), "SELECT details hint missing")

-- MoveInfo should describe live Gen 3/Emerald status metadata.
local MI = assert(loadfile(root .. "/src/move_info.lua"))()
local growl = MI.describe({ power=0, category="status", accuracy=100, pp=40, effect=18, target=8, priority=0 })
assert(growl.short:find("Attack", 1, true), "Growl summary must mention Attack")
assert(growl.short:find("1 stage", 1, true), "Growl summary must mention one stage")
assert(growl.target == "Both foes", "Growl target should use Gen 3 target metadata")

-- SELECT overlay: D-pad remains, A/B/START are consumed.
UI._mode = "moves"
UI._moveIndex = 3
local input = { pressQueue={"select","a","right","b","start"}, state={a=true,b=true,start=true} }
wraps["input.step"](function() end, {input=input}, 1/60)
assert(#input.pressQueue == 1 and input.pressQueue[1] == "right", "info overlay should keep only directional input")
assert(input.state.a == false and input.state.b == false and input.state.start == false, "battle actions must be blocked while info is open")
shown = {}
wraps["render.hud"](function() return true end, {}, viewport)
all = table.concat(shown, "|")
assert(all:find("MOVE INFO", 1, true), "full move-info overlay missing")
assert(all:find("GROWL", 1, true), "selected move name missing from full info")
assert(all:find("Lowers foe's Attack by 1 stage.", 1, true), "Growl explanation missing")
assert(all:find("Both foes", 1, true), "move target detail missing")
assert(all:find("A / B LOCKED", 1, true), "input safety hint missing")
input.pressQueue={"select"}
wraps["input.step"](function() end, {input=input}, 1/60)
assert(#input.pressQueue == 0, "SELECT should be consumed by move-info overlay")

-- Emerald double battle: all four battlers get modern cards and target-aware
-- effectiveness follows Ui._target.cursor (id 3 here is the Water-type foe).
local p2 = { label="MUDKIP", species=7, type1=11, mon={species=7,hp=24,maxHp=30,level=12,moves={1},pp={10},maxPp={10}} }
local e2 = { label="WINGULL", species=278, type1=11, mon={species=278,hp=18,maxHp=28,level=11} }
player.label="TORCHIC"; enemy.label="TREECKO"
state = { session=session, double=true, player=player, enemy=enemy, battlers={[0]=player,[1]=enemy,[2]=p2,[3]=e2}, absent={} }
UI._mode="target"; UI._active=0; UI._moveIndex=1; UI._target={cursor=3,slot=1,battler=0}
shown = {}
wraps["render.hud"](function() return true end, {}, viewport)
all = table.concat(shown, "|")
assert(all:find("TORCHIC", 1, true), "double HUD missing battler 0")
assert(all:find("TREECKO", 1, true), "double HUD missing battler 1")
assert(all:find("MUDKIP", 1, true), "double HUD missing battler 2")
assert(all:find("WINGULL", 1, true), "double HUD missing battler 3")
assert(all:find("ACTIVE", 1, true), "active double-battle player marker missing")
assert(all:find("×½ RESIST", 1, true), "double target matchup must use selected Water target")

-- Emerald Safari menu uses Pokéblock / Go Near rather than FRLG Bait / Rock.
state = { session=session, safari=true, player=player, enemy=enemy }
UI._mode="menu"; UI._menuIndex=2; UI._active=0; UI._target=nil
shown = {}
wraps["render.hud"](function() return true end, {}, viewport)
all = table.concat(shown, "|")
assert(all:find("POKéBLOCK", 1, true), "Emerald Safari Pokéblock action missing")
assert(all:find("GO NEAR", 1, true), "Emerald Safari Go Near action missing")
assert(not all:find("ROCK", 1, true), "FRLG Safari ROCK action must not appear")

print("features-ok")
