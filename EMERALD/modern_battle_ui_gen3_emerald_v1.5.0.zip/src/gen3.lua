-- Emerald/RSE Game3 engine adapter. The shared battle engine remains authoritative.
local Gen3 = {}
local cache = {}

local function try(name)
  local hit = cache[name]
  if hit ~= nil then return hit or nil end
  local ok, module = pcall(require, name)
  cache[name] = ok and module or false
  return ok and module or nil
end
Gen3.try = try

function Gen3.battle() return try("src.core.game3.battle") end
function Gen3.ui() return try("src.core.game3.battle.ui") end
function Gen3.state() return try("src.core.game3.battle.state") end
function Gen3.moves() return try("src.core.game3.battle.moves") end
function Gen3.types() return try("src.core.game3.battle.types") end
function Gen3.anim() return try("src.core.game3.battle.anim") end
function Gen3.summaryData() return try("src.core.game3.summary_data") end
function Gen3.experience() return try("src.core.game3.battle.experience") end
function Gen3.runtime() return try("src.core.game3.runtime") end
function Gen3.profile() return try("src.core.game3.profile") end
function Gen3.dex() return try("src.core.game3.dex") end


local function sessionVersion(session)
  if type(session) ~= "table" then return nil end
  local v = session.version or session.gameVersion or session.game_version
  return v and tostring(v):lower() or nil
end

function Gen3.session(game)
  local R = Gen3.runtime()
  if R and R.getSession then
    local ok, value = pcall(R.getSession)
    if ok and type(value) == "table" then return value end
  end
  if type(game) == "table" then
    for _, value in ipairs({ game.session, game.playerState, game.state }) do
      if type(value) == "table" and sessionVersion(value) then return value end
    end
  end
  local B = Gen3.battle()
  if B and B.getState then
    local ok, st = pcall(B.getState)
    if ok and type(st) == "table" and type(st.session) == "table" then return st.session end
  end
  return nil
end

function Gen3.isEmerald(game, session)
  session = session or Gen3.session(game)
  if sessionVersion(session) == "emerald" then return true end
  local P = Gen3.profile()
  if P and P.forSession and type(session) == "table" then
    local ok, row = pcall(P.forSession, session)
    if ok and type(row) == "table" then
      if tostring(row.id or ""):lower() == "emerald" then return true end
      local battle = row.battle
      if type(battle) == "table" and battle.family == "rse" and tostring(row.id or ""):lower():find("emerald", 1, true) then
        return true
      end
    end
  end
  return false
end

function Gen3.battler(st, id)
  if type(st) ~= "table" then return nil end
  id = tonumber(id) or 0
  if id == 0 then return st.player or (st.battlers and st.battlers[0]) end
  if id == 1 then return st.enemy or (st.battlers and st.battlers[1]) end
  return st.battlers and st.battlers[id] or nil
end

function Gen3.targetBattler(snap)
  if not (snap and snap.state) then return nil end
  if not snap.state.double then return snap.state.enemy end
  local id = tonumber(snap.target)
  if id ~= nil then
    local b = Gen3.battler(snap.state, id)
    if b then return b end
  end
  return snap.state.enemy or Gen3.battler(snap.state, 1)
end

function Gen3.message() return try("src.ui.game3.message") end
function Gen3.choice() return try("src.ui.game3.choice") end
function Gen3.summaryMenu() return try("src.ui.game3.summary_menu") end
function Gen3.stack() return try("src.ui.game3.stack") end
function Gen3.statGrowth() return try("src.ui.game3.stat_growth") end
function Gen3.pokemon() return try("src.core.game3.pokemon") end
function Gen3.learnMove() return try("src.core.game3.battle.learn_move") end

function Gen3.messageContext()
  local M = Gen3.message()
  if not (M and M.isOpen) then return nil end
  local okOpen, open = pcall(M.isOpen)
  if not okOpen or open ~= true then return nil end

  local frame = M._frame
  if M.frameKind then
    local okFrame, value = pcall(M.frameKind)
    if okFrame and value then frame = value end
  end
  if frame ~= "battle" then return nil end

  local page = ""
  if M.currentPage then
    local okPage, value = pcall(M.currentPage)
    if okPage and value ~= nil then page = tostring(value) end
  end

  return {
    text = page,
    revealed = tonumber(M._revealed) or #page,
    total = tonumber(M._total) or #page,
    waiting = M._waiting == true,
    stay = M._stay == true,
    held = M._held == true,
  }
end

function Gen3.choiceContext()
  local C = Gen3.choice()
  if not (C and C.active == true and type(C.options) == "table") then return nil end
  local options = {}
  for i, value in ipairs(C.options) do options[i] = tostring(value or "") end
  return {
    kind = C.kind,
    style = C.style,
    options = options,
    cursor = math.max(1, tonumber(C.cursor) or 1),
    cols = math.max(1, tonumber(C.cols) or 1),
  }
end

function Gen3.statGrowthContext()
  local S = Gen3.statGrowth()
  if not (S and S._open == true) then return nil end
  return {
    mon = S._mon,
    oldStats = S._oldStats or {},
    newStats = S._newStats or {},
    page = math.max(1, tonumber(S._page) or 1),
  }
end

function Gen3.monName(mon)
  local P = Gen3.pokemon()
  if P and P.displayMonName then
    local ok, name = pcall(P.displayMonName, mon)
    if ok and name then return tostring(name) end
  end
  return tostring((mon and (mon.nickname or mon.name)) or "POKéMON")
end

function Gen3.monMoveId(mon, slot)
  local P = Gen3.pokemon()
  if P and P.moveIdAt then
    local ok, id = pcall(P.moveIdAt, mon, slot)
    if ok and id then return tonumber(id) or id end
  end
  local moves = mon and mon.moves
  local row = type(moves) == "table" and moves[slot] or nil
  if type(row) == "table" then row = row.id or row.moveId or row.move end
  return tonumber(row) or row
end

function Gen3.learnMoveContext()
  local S = Gen3.summaryMenu()
  if not (S and S.open == true and S._mode == "select_move" and S._moveToLearn) then return nil end

  local top = Gen3.stack()
  if top and top.top then
    local ok, row = pcall(top.top)
    if ok and type(row) == "table" and row.id and row.id ~= "summary" then return nil end
  end

  local party = S._party or {}
  local mon = party[tonumber(S._cursor) or 1]
  if not mon then return nil end

  local moves = {}
  for i = 1, 4 do moves[i] = Gen3.monMoveId(mon, i) end
  return {
    mon = mon,
    moves = moves,
    learning = tonumber(S._moveToLearn) or S._moveToLearn,
    cursor = math.max(1, math.min(5, tonumber(S._moveCursor) or 1)),
    hmNotice = S._hmNotice == true,
    forgetMove = S._forgetMove == true,
  }
end

function Gen3.battleActive()
  local B = Gen3.battle()
  if not (B and B.isActive) then return false end
  local ok, active = pcall(B.isActive)
  return ok and active == true
end

function Gen3.snapshot()
  local B = Gen3.battle()
  local U = Gen3.ui()
  if not (B and U and B.isActive and B.getState) then return nil end
  local okActive, active = pcall(B.isActive)
  if not okActive or not active then return nil end
  local okState, st = pcall(B.getState)
  if not okState or type(st) ~= "table" then return nil end
  return {
    battle = B,
    state = st,
    ui = U,
    phase = B._phase,
    mode = U._mode or "none",
    menuIndex = tonumber(U._menuIndex) or 1,
    moveIndex = tonumber(U._moveIndex) or 1,
    active = tonumber(U._active) or 0,
    target = type(U._target) == "table" and tonumber(U._target.cursor) or nil,
    safari = st.safari == true,
    wally = st.kinds and st.kinds.tutorial == "wally" or st.wally == true,
    twoOpponents = st.twoOpponents == true,
  }
end

function Gen3.displayName(battler)
  local S = Gen3.state()
  if S and S.displayName then
    local ok, name = pcall(S.displayName, battler)
    if ok and name then return tostring(name) end
  end
  local mon = battler and battler.mon
  return tostring((mon and (mon.nickname or mon.name)) or "POKéMON")
end

function Gen3.typeName(id)
  local T = Gen3.types()
  if T then
    local f = T.name or T.get
    if f then
      local ok, name = pcall(f, id)
      if ok and name then return tostring(name) end
    end
  end
  return "NORMAL"
end

function Gen3.moveDef(id)
  local M = Gen3.moves()
  if not (M and M.get) then return nil end
  local ok, def = pcall(M.get, id)
  return ok and def or nil
end

function Gen3.moveName(id)
  local M = Gen3.moves()
  if M and M.displayName then
    local ok, name = pcall(M.displayName, id)
    if ok and name then return tostring(name) end
  end
  return tostring(id or "-")
end

function Gen3.effectiveness(moveType, enemy)
  local T = Gen3.types()
  if not (T and T.effectiveness and enemy) then return 1 end
  local ok, mult = pcall(T.effectiveness, moveType, enemy.type1, enemy.type2)
  if ok and type(mult) == "number" then return mult end
  return 1
end

function Gen3.displayHp(side, battler)
  local mon = battler and battler.mon or {}
  local hp = tonumber(mon.hp) or 0
  local maxHp = tonumber(mon.maxHp) or math.max(hp, 1)
  local A = Gen3.anim()
  if A and A.present then
    local ok, p = pcall(A.present, side)
    if ok and type(p) == "table" then
      hp = tonumber(p.displayHp) or hp
      maxHp = tonumber(p.displayMaxHp) or maxHp
    end
  end
  return hp, math.max(1, maxHp)
end

function Gen3.expRatio(side, battler)
  if not (battler and battler.mon) then return nil end
  local A = Gen3.anim()
  if A and A.displayExpRatio then
    local ok, ratio = pcall(A.displayExpRatio, side, battler)
    if ok and type(ratio) == "number" then
      return math.max(0, math.min(1, ratio))
    end
  end
  local E = Gen3.experience()
  if E and E.progress then
    local ok, prog = pcall(E.progress, battler.mon)
    if ok and type(prog) == "table" then
      local ratio = tonumber(prog.progressPercent)
      if ratio then return math.max(0, math.min(1, ratio)) end
    end
  end
  return nil
end

function Gen3.enemyCaught(battler, battleState)
  if not battler then return nil end
  if battleState and battleState.ghostBattle and not battleState.ghostUnveiled then return nil end
  local species = tonumber(battler.species or (battler.mon and (battler.mon.species or battler.mon.speciesId)))
  if not species then return nil end
  local R = Gen3.runtime()
  local session
  if R and R.getSession then
    local ok, value = pcall(R.getSession)
    if ok then session = value end
  end
  local dex = session and (session.dex or session.pokedex)
  if not dex then return nil end
  local D = Gen3.dex()
  if D and D.isCaught then
    local ok, value = pcall(D.isCaught, dex, species)
    if ok then return value == true end
  end
  local side = dex.caught or dex.owned
  if type(side) == "table" then
    return side[species] == true or side[tostring(species)] == true
  end
  return false
end

function Gen3.statusLabel(battler)
  if not battler then return nil end
  local raw = battler.status or (battler.mon and (battler.mon.status or battler.mon.status1))
  if raw == nil or raw == 0 or raw == "" then return nil end
  if type(raw) == "string" then
    local s = raw:upper()
    if s:find("SLEEP", 1, true) or s == "SLP" then return "SLP" end
    if s:find("POISON", 1, true) or s == "PSN" or s == "TOX" then return "PSN" end
    if s:find("BURN", 1, true) or s == "BRN" then return "BRN" end
    if s:find("FREEZE", 1, true) or s == "FRZ" then return "FRZ" end
    if s:find("PAR", 1, true) then return "PAR" end
    return s:sub(1, 3)
  end
  local SD = Gen3.summaryData()
  if SD and SD.statusAilment then
    local ok, n = pcall(SD.statusAilment, { status = raw, hp = battler.mon and battler.mon.hp })
    if ok then
      return ({ [1] = "SLP", [2] = "PSN", [3] = "BRN", [4] = "FRZ", [5] = "PAR", [6] = "PSN" })[n]
    end
  end
  return "STS"
end

return Gen3
