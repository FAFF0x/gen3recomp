-- Modern Battle UI - Pokémon Emerald / RSE presentation layer.
-- v1.5.0 keeps the functional Emerald Game3 battle engine untouched and
-- redraws battle-facing chrome in a high-contrast Hoenn/emerald visual language.
-- Geometry is derived from the native 240x160 frame, while fonts are created at
-- final window size for readable widescreen/windowed rendering.
local Hud = {}
local Gen3
local MoveInfo
local moveInfoOpen = false
local GAME_W, GAME_H = 240, 160
local fonts = {}

local T = {
  bg = { 0.030, 0.300, 0.245, 0.985 },
  surface = { 0.975, 0.995, 0.985, 0.985 },
  raised = { 1.000, 0.955, 0.700, 1 },
  selected = { 1.000, 0.805, 0.245, 1 },
  accent = { 0.875, 0.175, 0.190, 1 },
  secondary = { 0.990, 0.770, 0.075, 1 },
  text = { 0.035, 0.205, 0.175, 1 },
  muted = { 0.285, 0.455, 0.410, 1 },
  divider = { 0.455, 0.745, 0.655, 1 },
  header = { 0.030, 0.405, 0.330, 1 },
  headerText = { 1.000, 1.000, 1.000, 1 },
  footer = { 0.025, 0.155, 0.135, 1 },
  hp = { 0.180, 0.690, 0.305, 1 },
  hpMid = { 0.975, 0.650, 0.090, 1 },
  hpLow = { 0.860, 0.180, 0.150, 1 },
  exp = { 0.180, 0.610, 0.930, 1 },
  caught = { 0.130, 0.620, 0.365, 1 },
  uncaught = { 0.420, 0.500, 0.565, 1 },
}

local TYPE_COLORS = {
  NORMAL={0.63,0.64,0.58}, FIRE={0.95,0.33,0.22}, WATER={0.25,0.50,0.94},
  ELECTRIC={0.96,0.78,0.16}, GRASS={0.34,0.72,0.29}, ICE={0.45,0.80,0.82},
  FIGHTING={0.76,0.24,0.20}, POISON={0.67,0.32,0.70}, GROUND={0.82,0.66,0.34},
  FLYING={0.59,0.51,0.90}, PSYCHIC={0.94,0.33,0.56}, BUG={0.65,0.72,0.15},
  ROCK={0.72,0.61,0.27}, GHOST={0.47,0.38,0.65}, DRAGON={0.45,0.25,0.90},
  DARK={0.39,0.31,0.27}, STEEL={0.67,0.67,0.76},
}

function Hud.init(engine, moveInfo)
  Gen3 = engine
  MoveInfo = moveInfo
end

function Hud.toggleMoveInfo()
  moveInfoOpen = not moveInfoOpen
  return moveInfoOpen
end

function Hud.closeMoveInfo() moveInfoOpen = false end
function Hud.moveInfoOpen() return moveInfoOpen end

local function clamp(v, a, b)
  v = tonumber(v) or a
  if v < a then return a end
  if v > b then return b end
  return v
end

local function safe(v)
  if v == nil then return "" end
  local s = tostring(v)
  s = s:gsub("<PK><MN>", "POKéMON")
  s = s:gsub("<PKMN>", "POKéMON")
  s = s:gsub("<LV>", "Lv")
  return s
end

local function setColor(c, alpha)
  alpha = alpha or 1
  love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * alpha)
end

local function font(size)
  size = math.max(12, math.floor((tonumber(size) or 12) + 0.5))
  if fonts[size] then return fonts[size] end
  local ok, f = pcall(love.graphics.newFont, size)
  if not ok or not f then f = love.graphics.getFont() end
  if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
  fonts[size] = f
  return f
end

local function layout(viewport)
  local x = tonumber(viewport.gameX) or 0
  local y = tonumber(viewport.gameY) or 0
  local w = tonumber(viewport.gameWidth) or GAME_W
  local h = tonumber(viewport.gameHeight) or GAME_H
  local sx, sy = w / GAME_W, h / GAME_H
  local s = math.max(1, math.min(sx, sy))
  return {
    x=x, y=y, w=w, h=h, sx=sx, sy=sy, s=s,
    X=function(n) return x + n * sx end,
    Y=function(n) return y + n * sy end,
    W=function(n) return n * sx end,
    H=function(n) return n * sy end,
    F=function(n) return math.max(12, n * s) end,
    R=function(n) return math.max(3, n * s) end,
  }
end

local function roundRect(mode, x, y, w, h, r)
  love.graphics.rectangle(mode, x, y, w, h, r, r)
end

local function text(L, value, x, y, nativeSize, color, align, nativeWidth)
  local f = font(L.F(nativeSize))
  love.graphics.setFont(f)
  setColor(color or T.text)
  value = safe(value)
  if nativeWidth then
    love.graphics.printf(value, L.X(x), L.Y(y), L.W(nativeWidth), align or "left")
  else
    love.graphics.print(value, L.X(x), L.Y(y))
  end
end

local function panel(L, x, y, w, h, selected)
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w), L.H(h)
  setColor(selected and T.raised or T.surface)
  roundRect("fill", px, py, pw, ph, L.R(math.min(5, h * 0.13)))
  setColor(selected and T.accent or T.divider, selected and 0.80 or 0.62)
  love.graphics.setLineWidth(math.max(1, L.s * 0.55))
  roundRect("line", px, py, pw, ph, L.R(math.min(5, h * 0.13)))
end

local function nativeFill(L, c, x, y, w, h, alpha)
  setColor(c, alpha)
  love.graphics.rectangle("fill", L.X(x), L.Y(y), L.W(w), L.H(h))
end

local function typeColor(name)
  return TYPE_COLORS[tostring(name or "NORMAL"):upper()] or TYPE_COLORS.NORMAL
end

local function hpColor(ratio)
  if ratio <= 0.25 then return T.hpLow end
  if ratio <= 0.50 then return T.hpMid end
  return T.hp
end

local function drawBar(L, x, y, w, h, value, maxValue)
  local ratio = clamp((tonumber(value) or 0) / math.max(1, tonumber(maxValue) or 1), 0, 1)
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w), L.H(h)
  setColor(T.divider, 0.34)
  roundRect("fill", px, py, pw, ph, ph / 2)
  setColor(hpColor(ratio))
  roundRect("fill", px, py, math.max(1, pw * ratio), ph, ph / 2)
end

local function drawRatioBar(L, x, y, w, h, ratio, color)
  ratio = clamp(ratio or 0, 0, 1)
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w), L.H(h)
  setColor(T.divider, 0.26)
  roundRect("fill", px, py, pw, ph, ph / 2)
  if ratio > 0 then
    setColor(color or T.exp)
    roundRect("fill", px, py, math.max(1, pw * ratio), ph, ph / 2)
  end
end

local function caughtBadge(L, caught, x, y, w)
  if caught == nil then return end
  local h = 7.2
  local c = caught and T.caught or T.uncaught
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w), L.H(h)
  setColor(c, caught and 0.96 or 0.86)
  roundRect("fill", px, py, pw, ph, L.R(2.5))

  -- Tiny Poké Ball glyph, drawn as vectors so it needs no external asset.
  local cx, cy = L.X(x + 4.0), L.Y(y + h / 2)
  local r = math.max(2, L.s * 1.75)
  setColor({1,1,1,1})
  love.graphics.circle("fill", cx, cy, r)
  setColor(T.accent)
  love.graphics.arc("fill", "closed", cx, cy, r, math.pi, math.pi * 2)
  setColor(T.footer, 0.95)
  love.graphics.setLineWidth(math.max(1, L.s * 0.55))
  love.graphics.circle("line", cx, cy, r)
  love.graphics.line(cx - r, cy, cx + r, cy)
  love.graphics.circle("fill", cx, cy, math.max(1, r * 0.34))
  setColor({1,1,1,1})
  love.graphics.circle("fill", cx, cy, math.max(0.8, r * 0.17))

  text(L, caught and "CAUGHT" or "NOT CAUGHT", x + 8, y + 0.55, 4.0, {1,1,1,1}, "left", w - 9)
end

local function chip(L, label, x, y, w)
  local c = typeColor(label)
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w or 28), L.H(9)
  setColor(c, 0.94)
  roundRect("fill", px, py, pw, ph, L.R(3))
  -- Dark ink is more readable on the bright type chips used by Modern UI.
  text(L, tostring(label or "NORMAL"):upper(), x, y + 1.0, 4.6, {0.03,0.06,0.09,1}, "center", w or 28)
end

local STATUS_COLORS = {
  SLP={0.44,0.52,0.66,1}, PSN={0.68,0.34,0.72,1}, BRN={0.92,0.34,0.21,1},
  FRZ={0.35,0.72,0.88,1}, PAR={0.96,0.73,0.12,1}, STS={0.48,0.54,0.62,1},
}

local function battlerCard(L, side, battler, opts, battleState)
  if not (battler and battler.mon) then return end
  local player = side == "player"
  local x, y, w, h
  if player then x, y, w, h = 122, 67, 113, 43 else x, y, w, h = 5, 5, 113, 37 end
  panel(L, x, y, w, h, false)

  local t1 = Gen3.typeName(battler.type1)
  local tc = typeColor(t1)
  nativeFill(L, tc, x, y, w, 2.6, 0.96)

  local name = Gen3.displayName(battler)
  local lv = tonumber(battler.mon.level) or 1
  text(L, name, x + 6, y + 4.0, 6.0, T.text, "left", w - 36)
  text(L, "Lv " .. tostring(lv), x + w - 31, y + 4.4, 5.0, T.muted, "right", 25)

  if player then
    -- Live EXP ratio follows the native battle animation when one is running,
    -- and falls back to the actual Gen3 growth curve otherwise.
    local expRatio = Gen3.expRatio(side, battler)
    text(L, "EXP", x + 6, y + 13.4, 3.8, T.muted)
    drawRatioBar(L, x + 20, y + 15.0, w - 27, 2.0, expRatio or 0, T.exp)

    local hp, maxHp = Gen3.displayHp(side, battler)
    text(L, "HP", x + 6, y + 20.1, 4.2, T.muted)
    drawBar(L, x + 18, y + 21.3, w - 25, 3.6, hp, maxHp)
    text(L, string.format("%d / %d", math.max(0, math.floor(hp + 0.5)), math.floor(maxHp + 0.5)),
      x + 6, y + 27.2, 4.3, T.muted, "left", w - 40)

    local status = Gen3.statusLabel(battler)
    if status then
      local sc = STATUS_COLORS[status] or STATUS_COLORS.STS
      local sw, sy = 23, y + h - 9.2
      local px, py, pw, ph = L.X(x + w - sw - 5), L.Y(sy), L.W(sw), L.H(6.8)
      setColor(sc)
      roundRect("fill", px, py, pw, ph, L.R(2.4))
      text(L, status, x + w - sw - 5, sy + 0.35, 3.9, {1,1,1,1}, "center", sw)
    else
      chip(L, t1, x + w - 34, y + h - 10.0, 29)
    end
  else
    local hp, maxHp = Gen3.displayHp(side, battler)
    text(L, "HP", x + 6, y + 16.2, 4.3, T.muted)
    drawBar(L, x + 18, y + 17.4, w - 25, 3.8, hp, maxHp)
    if opts.enemyHp then
      text(L, string.format("%d / %d", math.max(0, math.floor(hp + 0.5)), math.floor(maxHp + 0.5)),
        x + 6, y + 23.0, 4.1, T.muted, "left", 48)
    end

    local caught = Gen3.enemyCaught(battler, battleState)
    caughtBadge(L, caught, x + 6, y + h - 10.0, 48)

    local status = Gen3.statusLabel(battler)
    if status then
      local sc = STATUS_COLORS[status] or STATUS_COLORS.STS
      local sw, sy = 23, y + h - 10.0
      local px, py, pw, ph = L.X(x + w - sw - 5), L.Y(sy), L.W(sw), L.H(7.2)
      setColor(sc)
      roundRect("fill", px, py, pw, ph, L.R(2.5))
      text(L, status, x + w - sw - 5, sy + 0.5, 4.0, {1,1,1,1}, "center", sw)
    end
  end
end


local DOUBLE_RECTS = {
  [1] = { 4, 4, 116, 25 },
  [3] = { 4, 31, 116, 25 },
  [0] = { 120, 57, 116, 25 },
  [2] = { 120, 84, 116, 25 },
}

local function doubleBattlerCard(L, id, battler, opts, battleState, activeId)
  if not (battler and battler.mon) then return end
  if battleState and battleState.absent and battleState.absent[id] then return end
  local r = DOUBLE_RECTS[id]
  if not r then return end
  local x, y, w, h = r[1], r[2], r[3], r[4]
  local player = (id % 2) == 0
  local active = player and tonumber(activeId) == id
  panel(L, x, y, w, h, active)

  local t1 = Gen3.typeName(battler.type1)
  nativeFill(L, typeColor(t1), x, y, 2.4, h, 0.98)
  local name = Gen3.displayName(battler)
  local lv = tonumber(battler.mon.level) or 1
  text(L, name, x + 5.5, y + 2.2, 4.8, T.text, "left", w - 39)
  text(L, "Lv " .. tostring(lv), x + w - 34, y + 2.4, 4.0, T.muted, "right", 28)

  local hp, maxHp = Gen3.displayHp(id, battler)
  text(L, "HP", x + 5.5, y + 10.5, 3.4, T.muted)
  drawBar(L, x + 17, y + 11.5, w - 23, 3.1, hp, maxHp)
  if player then
    local ratio = Gen3.expRatio(id, battler)
    if ratio ~= nil then drawRatioBar(L, x + 5.5, y + 19.5, 53, 2.0, ratio, T.exp) end
    local status = Gen3.statusLabel(battler)
    if status then
      text(L, status, x + w - 28, y + 17.0, 3.35, STATUS_COLORS[status] or STATUS_COLORS.STS, "right", 22)
    elseif active then
      text(L, "ACTIVE", x + w - 34, y + 17.0, 3.2, T.accent, "right", 28)
    end
  else
    local caught = Gen3.enemyCaught(battler, battleState)
    if caught ~= nil then
      text(L, caught and "CAUGHT" or "NOT CAUGHT", x + 5.5, y + 17.0, 3.15,
        caught and T.caught or T.uncaught, "left", 47)
    end
    local status = Gen3.statusLabel(battler)
    if status then
      text(L, status, x + w - 28, y + 17.0, 3.35, STATUS_COLORS[status] or STATUS_COLORS.STS, "right", 22)
    elseif opts.enemyHp then
      text(L, string.format("%d/%d", math.max(0, math.floor(hp + 0.5)), math.floor(maxHp + 0.5)),
        x + w - 50, y + 17.0, 3.15, T.muted, "right", 44)
    end
  end
end

local COMMANDS = {
  {"FIGHT", "Moves"}, {"BAG", "Items"}, {"POKéMON", "Party"}, {"RUN", "Escape"},
}

-- Emerald's Safari Zone does not use FRLG's BAIT/ROCK commands.
local SAFARI_COMMANDS = {
  {"BALL", "Throw"}, {"POKéBLOCK", "Bait"}, {"GO NEAR", "Approach"}, {"RUN", "Escape"},
}


local function commandCard(L, label, hint, x, y, w, h, selected)
  panel(L, x, y, w, h, selected)
  if selected then nativeFill(L, T.accent, x, y, 2.2, h, 1) end
  text(L, label, x + 5.2, y + 2.0, 5.8, T.text, "left", w - 9)
  text(L, hint, x + 5.2, y + 10.4, 4.2, selected and T.text or T.muted, "left", w - 9)
end

local function drawMenu(L, snap)
  nativeFill(L, T.header, 0, 110, 240, 50, 1)
  nativeFill(L, T.accent, 0, 110, 240, 2.2, 1)
  nativeFill(L, T.secondary, 0, 157.5, 240, 2.5, 1)

  local active = snap.state.player
  if snap.state.double and snap.state.battlers then active = snap.state.battlers[snap.active] or active end
  text(L, "WHAT WILL", 7, 118, 4.7, {0.83,0.92,1,1})
  text(L, Gen3.displayName(active), 7, 127, 6.8, T.headerText, "left", 63)
  text(L, "DO?", 7, 142, 4.7, {0.83,0.92,1,1})

  local pos = {{75,115},{158,115},{75,137},{158,137}}
  local commands = snap.safari and SAFARI_COMMANDS or COMMANDS
  for i=1,4 do
    local c = commands[i]
    commandCard(L, c[1], c[2], pos[i][1], pos[i][2], 77, 19, snap.menuIndex == i)
  end
end

local function effLabel(mult)
  if mult <= 0 then return "NO EFFECT", T.muted end
  if mult >= 4 then return "SUPER ×4", T.hp end
  if mult >= 2 then return "SUPER ×2", T.hp end
  if mult < 0.5 then return "RESIST ×¼", T.hpLow end
  if mult < 1 then return "RESIST ×½", {0.92,0.48,0.16,1} end
  return "NORMAL ×1", T.muted
end

local function effCompact(def, enemy)
  if not def then return "—", T.muted end
  local power = tonumber(def.power) or 0
  local cat = tostring(def.category or ""):lower()
  if power <= 0 or cat == "status" then return "STATUS", T.muted end
  local mult = Gen3.effectiveness(def.type, enemy)
  if mult <= 0 then return "×0 IMMUNE", T.muted end
  if mult >= 4 then return "×4 SUPER", T.caught end
  if mult >= 2 then return "×2 SUPER", T.caught end
  if mult < 0.5 then return "×¼ RESIST", T.hpLow end
  if mult < 1 then return "×½ RESIST", {0.92,0.48,0.16,1} end
  return "×1 NORMAL", {0.28,0.48,0.68,1}
end

local function moveCard(L, name, typeName, def, enemy, x, y, w, h, selected)
  panel(L, x, y, w, h, selected)
  local tc = typeColor(typeName)
  nativeFill(L, tc, x, y, 2.2, h, 0.98)
  text(L, name, x + 5.2, y + 2.0, 4.7, T.text, "left", w - 9)

  -- Effectiveness is visible on every move immediately, not only after the
  -- cursor reaches it.  Status moves are explicitly labelled instead.
  local badge, ec = effCompact(def, enemy)
  local bx, by, bw, bh = x + 5.0, y + 10.4, w - 10.0, 6.2
  local px, py, pw, ph = L.X(bx), L.Y(by), L.W(bw), L.H(bh)
  setColor(ec, selected and 0.96 or 0.84)
  roundRect("fill", px, py, pw, ph, L.R(2.2))
  text(L, badge, bx, by + 0.15, 3.8, {1,1,1,1}, "center", bw)
end

local function activeMoveContext(snap)
  local battler = snap.state.player
  if snap.state.double and snap.state.battlers then battler = snap.state.battlers[snap.active] or battler end
  local mon = battler and battler.mon
  local moves = mon and mon.moves or {}
  local id = moves[snap.moveIndex]
  local def = id and Gen3.moveDef(id) or nil
  return battler, mon, moves, id, def
end

local function drawMoveMenu(L, snap, opts)
  nativeFill(L, T.header, 0, 110, 240, 50, 1)
  nativeFill(L, T.accent, 0, 110, 240, 2.2, 1)
  nativeFill(L, T.secondary, 0, 157.5, 240, 2.5, 1)

  local battler, mon, moves = activeMoveContext(snap)
  local pos = {{4,115},{76,115},{4,137},{76,137}}

  for i=1,4 do
    local id = moves[i]
    local def = id and Gen3.moveDef(id) or nil
    local name = id and Gen3.moveName(id) or "-"
    local tname = Gen3.typeName(def and def.type)
    moveCard(L, name, tname, def, Gen3.targetBattler(snap), pos[i][1], pos[i][2], 68, 19, snap.moveIndex == i)
  end

  if opts.moveDetails then
    local _, _, _, id, def = activeMoveContext(snap)
    panel(L, 148, 115, 88, 41, false)
    if def then
      local tname = Gen3.typeName(def.type)
      chip(L, tname, 153, 118, 28)
      local cat = tostring(def.category or ((tonumber(def.power) or 0) == 0 and "status" or "special")):upper()
      text(L, cat, 184, 119, 4.2, T.muted, "right", 46)

      local pp = mon and mon.pp and tonumber(mon.pp[snap.moveIndex]) or tonumber(def.pp) or 0
      local maxPp = mon and mon.maxPp and tonumber(mon.maxPp[snap.moveIndex]) or tonumber(def.pp) or pp
      local pwr = (tonumber(def.power) or 0) > 0 and tostring(def.power) or "—"
      local acc = tonumber(def.accuracy)
      local accText = acc and acc > 0 and (tostring(math.floor(acc + 0.5)) .. "%") or "—"
      text(L, "PWR " .. pwr, 153, 129.1, 3.9, T.text)
      text(L, "ACC " .. accText, 180, 129.1, 3.9, T.text)
      text(L, string.format("PP %d/%d", pp, maxPp), 206, 129.1, 3.9, T.text, "right", 25)

      local info = MoveInfo and MoveInfo.describe and MoveInfo.describe(def) or nil
      local short = info and info.short or "Move information unavailable."
      text(L, short, 153, 137.3, 3.6, T.text, "left", 78)
      if opts.moveInfo then
        text(L, "SELECT  DETAILS", 153, 149.2, 3.35, T.header, "center", 78)
      end
    else
      text(L, "NO MOVE", 153, 130, 5.5, T.muted, "center", 78)
    end
  end
end

local function statTile(L, label, value, x, y, w)
  local px, py, pw, ph = L.X(x), L.Y(y), L.W(w), L.H(16)
  setColor(T.surface)
  roundRect("fill", px, py, pw, ph, L.R(3))
  setColor(T.divider, 0.55)
  roundRect("line", px, py, pw, ph, L.R(3))
  text(L, label, x + 2, y + 1.2, 3.35, T.muted, "center", w - 4)
  text(L, value, x + 2, y + 7.0, 4.5, T.text, "center", w - 4)
end

local function drawMoveInfoOverlay(L, snap)
  local _, mon, _, id, def = activeMoveContext(snap)
  if not (id and def) then return end
  local info = MoveInfo and MoveInfo.describe and MoveInfo.describe(def) or {
    short = "Move information unavailable.", long = "No detail provider is available.",
    target = "Unknown", priority = tonumber(def.priority) or 0,
  }

  -- Dim the native battle without discarding it: sprites remain visible as
  -- context behind a large, high-resolution information card.
  nativeFill(L, {0.015,0.040,0.075,1}, 0, 0, 240, 160, 0.82)
  panel(L, 8, 7, 224, 146, false)
  nativeFill(L, T.header, 8, 7, 224, 22, 1)
  nativeFill(L, T.accent, 8, 7, 3, 22, 1)
  nativeFill(L, T.secondary, 8, 27, 224, 2, 1)

  text(L, "MOVE INFO", 15, 11, 4.0, {0.82,0.92,1,1})
  text(L, Gen3.moveName(id), 15, 17.0, 7.1, T.headerText, "left", 142)
  local tname = Gen3.typeName(def.type)
  chip(L, tname, 164, 12, 30)
  local cat = tostring(def.category or ((tonumber(def.power) or 0) == 0 and "status" or "special")):upper()
  text(L, cat, 198, 14.0, 4.2, T.headerText, "center", 28)

  local pp = mon and mon.pp and tonumber(mon.pp[snap.moveIndex]) or tonumber(def.pp) or 0
  local maxPp = mon and mon.maxPp and tonumber(mon.maxPp[snap.moveIndex]) or tonumber(def.pp) or pp
  local pwr = (tonumber(def.power) or 0) > 0 and tostring(math.floor(tonumber(def.power) + 0.5)) or "—"
  local acc = tonumber(def.accuracy)
  local accText = acc and acc > 0 and (tostring(math.floor(acc + 0.5)) .. "%") or "—"
  local pri = tonumber(info.priority) or 0
  local priText = pri > 0 and ("+" .. tostring(pri)) or tostring(pri)

  statTile(L, "POWER", pwr, 15, 35, 37)
  statTile(L, "ACCURACY", accText, 56, 35, 43)
  statTile(L, "PP", string.format("%d/%d", pp, maxPp), 103, 35, 37)
  statTile(L, "PRIORITY", priText, 144, 35, 37)
  statTile(L, "TARGET", info.target or "—", 185, 35, 40)

  local isStatus = (tonumber(def.power) or 0) <= 0 or tostring(def.category or ""):lower() == "status"
  local matchText, matchColor
  if isStatus then
    matchText, matchColor = "STATUS MOVE — TYPE DAMAGE MATCHUP DOES NOT APPLY", T.muted
  else
    local target = Gen3.targetBattler(snap)
    local mult = Gen3.effectiveness(def.type, target)
    local label, ec = effLabel(mult)
    local who = snap.state.double and snap.target ~= nil and ("VS. TARGET " .. tostring(snap.target + 1)) or "VS. CURRENT FOE"
    matchText, matchColor = who .. ": " .. label, ec
  end
  local mx, my, mw, mh = L.X(15), L.Y(55), L.W(210), L.H(10)
  setColor(matchColor, 0.14)
  roundRect("fill", mx, my, mw, mh, L.R(2.5))
  setColor(matchColor, 0.75)
  roundRect("line", mx, my, mw, mh, L.R(2.5))
  text(L, matchText, 18, 57.0, 4.1, matchColor, "center", 204)

  text(L, "QUICK SUMMARY", 15, 70, 3.55, T.header)
  text(L, info.short or "—", 15, 76, 5.0, T.text, "left", 210)

  text(L, "EFFECT DETAILS", 15, 91, 3.55, T.header)
  text(L, info.long or info.short or "—", 15, 97, 4.25, T.text, "left", 210)

  if (tonumber(info.secondaryChance) or 0) > 0 then
    text(L, "SECONDARY CHANCE  " .. tostring(math.floor(info.secondaryChance + 0.5)) .. "%", 15, 126, 3.7, T.muted)
  else
    text(L, "TARGET  " .. tostring(info.target or "—"), 15, 126, 3.7, T.muted)
  end

  nativeFill(L, T.footer, 8, 138, 224, 15, 1)
  text(L, "D-PAD: CHANGE MOVE", 15, 142, 3.7, {0.82,0.92,1,1})
  text(L, "A / B LOCKED", 90, 142, 3.7, {0.82,0.92,1,1})
  text(L, "SELECT: CLOSE", 166, 142, 3.7, T.secondary, "right", 59)
end


local function visiblePrefix(value, count)
  value = safe(value)
  count = math.max(0, math.floor(tonumber(count) or #value))
  if count <= 0 then return "" end

  local i, glyphs = 1, 0
  while i <= #value and glyphs < count do
    local b = value:byte(i) or 0
    local len = 1
    if b >= 240 then len = 4
    elseif b >= 224 then len = 3
    elseif b >= 192 then len = 2 end
    i = i + len
    glyphs = glyphs + 1
  end
  return value:sub(1, math.max(0, i - 1))
end

local function dialogueTitle(body, choice)
  local upper = tostring(body or ""):upper()
  if upper:find("GREW TO", 1, true) or upper:find("LEVEL", 1, true) and upper:find("GREW", 1, true) then
    return "LEVEL UP"
  end
  if upper:find("LEARN", 1, true) or upper:find("FORGOT", 1, true) or upper:find("POOF", 1, true) then
    return "MOVE LEARNING"
  end
  if choice then return "DECISION" end
  return "BATTLE"
end

local function drawBattleDialog(L)
  local msg = Gen3.messageContext and Gen3.messageContext() or nil
  local choice = Gen3.choiceContext and Gen3.choiceContext() or nil
  if not msg then return false, choice end

  -- Completely cover the native Emerald/RSE battle textbox before drawing the modern
  -- window-space version. Input/typewriter timing remains owned by Message.
  nativeFill(L, T.footer, 0, 109, 240, 51, 1)
  nativeFill(L, T.secondary, 0, 109, 240, 2.2, 1)
  panel(L, 5, 114, 230, 39, false)
  nativeFill(L, T.header, 5, 114, 4, 39, 1)

  local body = visiblePrefix(msg.text, msg.revealed)
  text(L, dialogueTitle(msg.text, choice), 13, 117, 3.55, T.accent)
  text(L, body, 13, 124, 5.15, T.text, "left", 211)

  if msg.waiting and not choice then
    local hint = msg.stay and "WAITING FOR CHOICE" or "A  CONTINUE"
    text(L, hint, 151, 145.5, 3.35, T.muted, "right", 72)
  end
  return true, choice
end

local function drawModernChoice(L, choice)
  if not (choice and type(choice.options) == "table" and #choice.options > 0) then return false end

  local n = #choice.options
  local cols = math.max(1, tonumber(choice.cols) or 1)
  local rows = math.max(1, math.ceil(n / cols))
  local w = choice.kind == "yesno" and 70 or math.min(112, 58 * cols)
  local h = math.min(82, 12 + rows * 14)
  local x = 236 - w
  local y = choice.kind == "yesno" and 67 or math.max(25, 108 - h)

  -- Battle YES/NO lives around tile (24,9) in native Emerald/RSE. This panel is
  -- intentionally wider so the underlying vanilla choice frame is fully hidden.
  panel(L, x, y, w, h, false)
  nativeFill(L, T.header, x, y, w, 10, 1)
  text(L, "CHOOSE", x + 5, y + 2, 3.6, T.headerText)

  local cellW = (w - 8) / cols
  for i, label in ipairs(choice.options) do
    local col = (i - 1) % cols
    local row = math.floor((i - 1) / cols)
    local rx = x + 4 + col * cellW
    local ry = y + 12 + row * 14
    local selected = i == choice.cursor
    if selected then
      local px, py, pw, ph = L.X(rx), L.Y(ry), L.W(cellW - 2), L.H(11)
      setColor(T.raised)
      roundRect("fill", px, py, pw, ph, L.R(2.3))
      setColor(T.accent, 0.9)
      love.graphics.rectangle("fill", px, py, math.max(2, L.W(2)), ph)
    end
    text(L, tostring(label or ""), rx + 4, ry + 2.0, 4.6,
      selected and T.text or T.muted, "left", cellW - 7)
  end
  return true
end

local STAT_ROWS = {
  {"HP", "maxHp"}, {"ATTACK", "atk"}, {"DEFENSE", "def"},
  {"SP. ATK", "spa"}, {"SP. DEF", "spd"}, {"SPEED", "spe"},
}

local function drawStatGrowth(L)
  local ctx = Gen3.statGrowthContext and Gen3.statGrowthContext() or nil
  if not ctx then return false end

  -- Cover the native 10x11-tile level-up box at roughly (152,8).
  nativeFill(L, T.footer, 141, 2, 98, 106, 0.98)
  panel(L, 145, 5, 90, 99, false)
  nativeFill(L, T.header, 145, 5, 90, 14, 1)
  text(L, "LEVEL UP", 151, 8.5, 5.0, T.headerText)
  text(L, Gen3.monName and Gen3.monName(ctx.mon) or "POKéMON",
    151, 15.1, 3.6, {0.82,0.92,1,1}, "left", 75)

  local oldS, newS = ctx.oldStats or {}, ctx.newStats or {}
  for i, row in ipairs(STAT_ROWS) do
    local y = 23 + (i - 1) * 12.3
    local old = tonumber(oldS[row[2]]) or 0
    local new = tonumber(newS[row[2]]) or 0
    local value
    if ctx.page == 1 then
      local diff = new - old
      value = string.format("%+d", diff)
    else
      value = tostring(new)
    end
    text(L, row[1], 151, y, 3.65, T.muted)
    text(L, value, 207, y - 0.2, 4.4, ctx.page == 1 and T.caught or T.text, "right", 20)
  end

  text(L, ctx.page == 1 and "STAT GAINS" or "NEW TOTALS", 151, 96, 3.2, T.accent)
  return true
end

local function learnMoveRow(L, ctx, slot, x, y, w, h)
  local id = ctx.moves[slot]
  local def = id and Gen3.moveDef(id) or nil
  local name = id and Gen3.moveName(id) or "—"
  local selected = ctx.cursor == slot
  panel(L, x, y, w, h, selected)
  if selected then nativeFill(L, T.accent, x, y, 2.4, h, 1) end

  text(L, name, x + 6, y + 2.0, 4.8, id and T.text or T.muted, "left", w - 43)
  if def then
    local typeName = Gen3.typeName(def.type)
    chip(L, typeName, x + w - 34, y + 2.0, 29)
    local mon = ctx.mon or {}
    local pp = type(mon.pp) == "table" and tonumber(mon.pp[slot]) or tonumber(def.pp) or 0
    local maxPp = type(mon.maxPp) == "table" and tonumber(mon.maxPp[slot]) or tonumber(def.pp) or pp
    text(L, string.format("PP %d/%d", pp or 0, maxPp or 0), x + 6, y + 12.2, 3.4, T.muted)
  else
    text(L, "EMPTY SLOT", x + 6, y + 12.2, 3.4, T.muted)
  end
end

local function drawLearnMove(L)
  local ctx = Gen3.learnMoveContext and Gen3.learnMoveContext() or nil
  if not ctx then return false end

  -- SummaryMenu is intentionally still the input/state owner. We simply cover
  -- its native fullscreen renderer with a modern replacement using the same
  -- cursor and move-to-learn state.
  nativeFill(L, T.footer, 0, 0, 240, 160, 1)
  nativeFill(L, T.bg, 0, 0, 240, 160, 0.88)
  nativeFill(L, T.header, 0, 0, 240, 24, 1)
  nativeFill(L, T.secondary, 0, 22, 240, 2, 1)

  text(L, "LEARN A MOVE", 8, 5, 4.0, {0.82,0.92,1,1})
  text(L, Gen3.monName and Gen3.monName(ctx.mon) or "POKéMON",
    8, 11.5, 7.0, T.headerText, "left", 136)
  text(L, "CHOOSE A MOVE TO FORGET", 149, 8.5, 3.55, T.headerText, "right", 82)

  local rowY = {29, 51.5, 74, 96.5}
  for i=1,4 do
    learnMoveRow(L, ctx, i, 7, rowY[i], 138, 20.5)
  end

  local cancelSelected = ctx.cursor == 5
  panel(L, 7, 119, 138, 22, cancelSelected)
  if cancelSelected then nativeFill(L, T.accent, 7, 119, 2.4, 22, 1) end
  text(L, "DO NOT LEARN", 13, 122, 4.6, cancelSelected and T.text or T.muted)
  text(L, Gen3.moveName(ctx.learning), 13, 130.3, 3.65,
    cancelSelected and T.accent or T.muted, "left", 122)

  panel(L, 150, 29, 83, 112, false)
  nativeFill(L, T.header, 150, 29, 83, 15, 1)
  text(L, "NEW MOVE", 156, 33, 4.0, T.headerText)

  local newDef = Gen3.moveDef(ctx.learning)
  local newName = Gen3.moveName(ctx.learning)
  text(L, newName, 156, 49, 6.0, T.text, "left", 70)
  if newDef then
    local tname = Gen3.typeName(newDef.type)
    chip(L, tname, 156, 61, 30)
    local pwr = (tonumber(newDef.power) or 0) > 0 and tostring(math.floor(tonumber(newDef.power) + 0.5)) or "—"
    local acc = tonumber(newDef.accuracy)
    local accText = acc and acc > 0 and tostring(math.floor(acc + 0.5)) .. "%" or "—"
    text(L, "POWER  " .. pwr, 156, 74, 3.7, T.muted)
    text(L, "ACC.   " .. accText, 156, 82, 3.7, T.muted)
    text(L, "PP     " .. tostring(tonumber(newDef.pp) or "—"), 156, 90, 3.7, T.muted)

    local info = MoveInfo and MoveInfo.describe and MoveInfo.describe(newDef) or nil
    text(L, info and info.short or "Choose a move to forget.", 156, 102, 3.45, T.text, "left", 68)
  else
    text(L, "Move data unavailable.", 156, 70, 3.8, T.muted, "left", 68)
  end

  if ctx.hmNotice then
    nativeFill(L, T.accent, 153, 124, 77, 13, 0.96)
    text(L, "HM MOVES CAN'T BE FORGOTTEN", 156, 127.2, 3.0, {1,1,1,1}, "center", 70)
  end

  nativeFill(L, T.footer, 0, 145, 240, 15, 1)
  text(L, "D-PAD  SELECT", 8, 149, 3.7, {0.82,0.92,1,1})
  text(L, "A  CONFIRM", 92, 149, 3.7, {0.82,0.92,1,1})
  text(L, "B  CANCEL", 178, 149, 3.7, T.secondary, "right", 54)
  return true
end

local function drawBadge(L, snap)
  -- Kept subtle: useful to verify the overlay is active without polluting the UI.
  local label = "MBUI  " .. tostring(snap.mode or "none"):upper()
  local f = font(L.F(3.8))
  love.graphics.setFont(f)
  local tw = f:getWidth(label)
  local pad = L.W(2.7)
  local x = L.x + L.w - tw - pad * 2 - L.W(2)
  local y = L.Y(2)
  local h = math.max(f:getHeight() + L.H(1.4), L.H(7.5))
  setColor(T.footer, 0.88)
  roundRect("fill", x, y, tw + pad * 2, h, L.R(2.5))
  setColor(T.secondary)
  love.graphics.rectangle("fill", x, y, tw + pad * 2, math.max(2, L.H(1)))
  setColor({0.96,0.985,1,1})
  love.graphics.print(label, x + pad, y + math.max(1, L.H(0.7)))
end

function Hud.draw(_game, viewport, opts)
  if not (viewport and love and love.graphics and Gen3) then return end
  local snap = Gen3.snapshot()
  if not snap then return end
  opts = opts or {}
  local L = layout(viewport)
  local G = love.graphics

  G.push("all")
  G.setScissor(L.x, L.y, L.w, L.h)

  -- Native battle scenery, sprites and animations remain untouched.  Only the
  -- vanilla chrome is covered by the modern cards/panels drawn afterwards.
  if snap.state.double then
    for _, id in ipairs({1, 3, 0, 2}) do
      local b = Gen3.battler and Gen3.battler(snap.state, id) or nil
      doubleBattlerCard(L, id, b, opts, snap.state, snap.active)
    end
  else
    battlerCard(L, "enemy", snap.state.enemy, opts, snap.state)
    battlerCard(L, "player", snap.state.player, opts, snap.state)
  end

  if snap.mode == "menu" then
    drawMenu(L, snap)
  elseif snap.mode == "moves" or snap.mode == "target" then
    drawMoveMenu(L, snap, opts)
  end

  if opts.moveInfo and moveInfoOpen and (snap.mode == "moves" or snap.mode == "target") then
    drawMoveInfoOverlay(L, snap)
  elseif snap.mode ~= "moves" and snap.mode ~= "target" then
    moveInfoOpen = false
  end

  -- Post-action battle UI used to fall through to vanilla in v1.3.1.
  -- Render these after the normal cards/menus so they fully cover native chrome.
  local learnOpen = drawLearnMove(L)
  if not learnOpen then
    drawStatGrowth(L)
    local _, choice = drawBattleDialog(L)
    drawModernChoice(L, choice or (Gen3.choiceContext and Gen3.choiceContext() or nil))
  end

  if not learnOpen then drawBadge(L, snap) end

  G.setScissor()
  G.pop()
end

return Hud
