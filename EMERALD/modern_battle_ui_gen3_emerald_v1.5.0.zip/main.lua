-- MODERN BATTLE UI - GEN 3 (EMERALD) v1.5.0
-- Emerald-only conversion for the RSE Game3 runtime.
-- Battle rules, scripts and animation ownership stay native; this mod only
-- replaces battle-facing presentation after the Emerald frame is rendered.
return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local VERSION = "1.5.0"
  local MOD_ID = "modern_battle_ui_gen3_emerald"

  local function readModule(rel)
    local source = mod:read(rel)
    if not source then error("[" .. MOD_ID .. "] missing mod file: " .. rel) end
    return assert(load(source, "@" .. MOD_ID .. "/" .. rel))()
  end

  local Gen3 = readModule("src/gen3.lua")
  local MoveInfo = readModule("src/move_info.lua")
  local Hud = readModule("src/hud.lua")
  Hud.init(Gen3, MoveInfo)

  mod.options:define({
    { key = "enabled", label = "MODERN BATTLE UI", type = "toggle", default = true },
    { key = "enemy_hp", label = "ENEMY HP NUMBERS", type = "toggle", default = false },
    { key = "move_details", label = "MOVE DETAILS", type = "toggle", default = true },
    { key = "move_info", label = "SELECT MOVE INFO", type = "toggle", default = true },
  })

  -- SELECT opens a read-only move-info panel while Emerald's RSE battle move
  -- grid owns input. Directions stay live; A/B/START are suppressed while the
  -- panel is open so inspecting a move cannot accidentally choose an action.
  mod.hooks:wrap("input.step", function(next, game, dt)
    next(game, dt)
    if not Gen3.isEmerald(game) then
      Hud.closeMoveInfo()
      return
    end
    if mod.options:get("enabled") == false or mod.options:get("move_info") == false then
      Hud.closeMoveInfo()
      return
    end

    local snap = Gen3.snapshot()
    local input = game and game.input
    if not (snap and input and (snap.mode == "moves" or snap.mode == "target")) then
      Hud.closeMoveInfo()
      return
    end

    local q = type(input.pressQueue) == "table" and input.pressQueue or nil
    if not q then return end
    local selectPressed = false
    for _, btn in ipairs(q) do
      if btn == "select" then selectPressed = true break end
    end
    if selectPressed then Hud.toggleMoveInfo() end

    local block = Hud.moveInfoOpen()
    local filtered = {}
    for _, btn in ipairs(q) do
      if btn == "select" then
        -- SELECT belongs to the info overlay while the move grid is open.
      elseif block and (btn == "a" or btn == "b" or btn == "start") then
        -- Keep the detail screen read-only and safe.
      else
        filtered[#filtered + 1] = btn
      end
    end
    input.pressQueue = filtered
    if block and type(input.state) == "table" then
      input.state.a = false
      input.state.b = false
      input.state.start = false
    end
  end)

  -- Emerald uses the RSE battle profile (Birch first battle, Wally tutorial,
  -- doubles/two-opponent battles, RSE Safari and Battle Frontier). The shared
  -- battle state remains authoritative; this is a final screen-space pass only.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    if mod.options:get("enabled") == false or not Gen3.isEmerald(game) then return result end
    local ok, err = pcall(Hud.draw, game, viewport, {
      enemyHp = mod.options:get("enemy_hp") == true,
      moveDetails = mod.options:get("move_details") ~= false,
      moveInfo = mod.options:get("move_info") ~= false,
    })
    if not ok then
      mod.log:warn("%s render failed: %s", MOD_ID, tostring(err))
    end
    return result
  end)

  mod.exports.version = VERSION
  mod.exports.emeraldOnly = true
  mod.exports.emeraldRuntime = true
  mod.exports.rseRuntime = true
  mod.exports.fireRedRuntime = false
  mod.exports.frlgRuntime = false
  mod.exports.supportedGames = { "emerald" }
  mod.exports.enginePath = "src.core.game3.battle"
  mod.exports.battleFamily = "rse"
  mod.exports.completeBattlePresentation = true
  mod.exports.modernBattleDialogue = true
  mod.exports.modernBattleMoveLearning = true
  mod.exports.modernDoubleBattleHud = true
  mod.exports.emeraldSafariMenu = true
  mod.exports.isBattleActive = Gen3.battleActive
end
