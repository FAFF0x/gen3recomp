# Changelog

## 1.2.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Replaced Oak's Lab / FRLG starter-variable interception with Emerald's native Route 101 Birch starter flow.
- Integrated directly with `src.ui.game3.rse.starter_choose` so random species are shown with the correct Emerald starter UI labels and sprites.
- Preserved Emerald's native `giveStarter` path and `VAR_STARTER_MON` selection semantics.
- Removed FRLG-specific confirmation-text patching and Oak Poké Ball logic.
- Added Emerald May/Brendan rival-family replacement for Route 103, optional Rustboro, Route 110, Route 119, and Lilycove battles.
- Added Emerald-only runtime guards in addition to the Emerald-only manifest.
- Assigned the separate mod ID `random_starter_roster_gen3_emerald` to avoid colliding with the FR/LG build.

## 1.1.0

- Original FireRed/LeafGreen version.
