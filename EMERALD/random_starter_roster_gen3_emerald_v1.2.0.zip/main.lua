-- Random Starter Roster - Gen 3 Emerald v1.2.0
-- Emerald only. Replaces Birch's Route 101 starter chooser roster with a fresh
-- random trio of distinct base-stage Pokemon from genuine three-stage families.
-- The chosen launch roster is committed after the starter is received so
-- May/Brendan keep the corresponding random starter family for every rival battle.

return function(mod)
  local Pokemon = require("src.core.game3.pokemon")
  local Profile = require("src.core.game3.profile")

  -- Emerald has 411 real Gen 1-3 species in its internal species table;
  -- SPECIES_EGG follows at 412.
  local SPECIES_LAST = 411

  -- Emerald rival trainer IDs. The suffix in pret's trainer constant denotes
  -- the PLAYER'S vanilla starter selection. The rival receives the next slot:
  -- player Treecko (slot 1) -> rival Torchic (slot 2)
  -- player Torchic (slot 2) -> rival Mudkip  (slot 3)
  -- player Mudkip  (slot 3) -> rival Treecko (slot 1)
  --
  -- Route 103 / Route 110 / Route 119
  -- pret/pokeemerald include/constants/opponents.h
  local RIVAL_SLOT_BY_TRAINER = {
    -- Brendan: MUDKIP selection -> Treecko family (slot 1)
    [520]=1, [521]=1, [522]=1,
    -- Brendan: TREECKO selection -> Torchic family (slot 2)
    [523]=2, [524]=2, [525]=2,
    -- Brendan: TORCHIC selection -> Mudkip family (slot 3)
    [526]=3, [527]=3, [528]=3,

    -- May: MUDKIP selection -> Treecko family (slot 1)
    [529]=1, [530]=1, [531]=1,
    -- May: TREECKO selection -> Torchic family (slot 2)
    [532]=2, [533]=2, [534]=2,
    -- May: TORCHIC selection -> Mudkip family (slot 3)
    [535]=3, [536]=3, [537]=3,

    -- Optional Rustboro rival battle
    [593]=1, -- Brendan Rustboro Mudkip
    [592]=2, -- Brendan Rustboro Treecko
    [599]=3, -- Brendan Rustboro Torchic
    [600]=1, -- May Rustboro Mudkip
    [768]=2, -- May Rustboro Treecko
    [769]=3, -- May Rustboro Torchic

    -- Lilycove rival battle
    [661]=1, -- Brendan Lilycove Mudkip
    [662]=2, -- Brendan Lilycove Treecko
    [663]=3, -- Brendan Lilycove Torchic
    [664]=1, -- May Lilycove Mudkip
    [665]=2, -- May Lilycove Treecko
    [666]=3, -- May Lilycove Torchic
  }

  -- Detect the stage of Emerald's three vanilla starter families inside rival
  -- parties so the replacement keeps the correct evolutionary stage.
  local VANILLA_FAMILY_STAGE = {
    TREECKO=1, GROVYLE=2, SCEPTILE=3,
    TORCHIC=1, COMBUSKEN=2, BLAZIKEN=3,
    MUDKIP=1, MARSHTOMP=2, SWAMPERT=3,
  }

  local poolCache
  local pathCache = {}
  local launchRoster
  local committedRosterCache
  local currentPlayerSlot

  local function copyTable(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
  end

  local function copyRoster(roster)
    return { tonumber(roster[1]), tonumber(roster[2]), tonumber(roster[3]) }
  end

  local function evoTarget(row)
    if type(row) ~= "table" then return nil end
    local n = tonumber(row.target or row.species or row.into or row[3])
    if n and n > 0 then return n end
    return nil
  end

  local function validSpecies(sp)
    sp = tonumber(sp)
    if not sp or sp < 1 or sp > SPECIES_LAST then return false end
    local nat = Pokemon.national(sp)
    if not nat or nat < 1 or nat > 386 then return false end
    local key = Pokemon.keyName and Pokemon.keyName(sp)
    return type(key) == "string" and key ~= "" and key ~= "EGG"
  end

  -- Return one complete base -> middle -> final evolution path.
  local function threeStagePath(base)
    base = tonumber(base)
    if not base then return nil end
    local cached = pathCache[base]
    if cached ~= nil then return cached or nil end

    for _, first in ipairs(Pokemon.evolutions(base) or {}) do
      local mid = evoTarget(first)
      if mid and validSpecies(mid) then
        for _, second in ipairs(Pokemon.evolutions(mid) or {}) do
          local final = evoTarget(second)
          if final and validSpecies(final) then
            local path = { base, mid, final }
            pathCache[base] = path
            return path
          end
        end
      end
    end

    pathCache[base] = false
    return nil
  end

  local function candidatePool()
    if poolCache then return poolCache end

    -- Force Emerald's national/evolution data to be installed before scanning.
    Pokemon.evolutions(1)

    local hasPre = {}
    for sp = 1, SPECIES_LAST do
      if validSpecies(sp) then
        for _, row in ipairs(Pokemon.evolutions(sp) or {}) do
          local target = evoTarget(row)
          if target and validSpecies(target) then hasPre[target] = true end
        end
      end
    end

    local pool = {}
    for sp = 1, SPECIES_LAST do
      if validSpecies(sp) and not hasPre[sp] and threeStagePath(sp) then
        pool[#pool + 1] = sp
      end
    end

    table.sort(pool, function(a, b)
      return (Pokemon.national(a) or 9999) < (Pokemon.national(b) or 9999)
    end)

    poolCache = pool
    return pool
  end

  local MODULUS = 2147483647

  -- Process/startup entropy: stable for one application run, new on restart.
  local function launchSeed()
    local state = 104729

    local function mix(value)
      local n = tonumber(value) or 0
      n = math.floor(math.abs(n)) % MODULUS
      state = (state * 48271 + n + 1) % MODULUS
      if state <= 0 then state = 1 end
    end

    if os and os.time then mix(os.time()) end
    if os and os.clock then mix(os.clock() * 1000000) end

    if love and love.timer and love.timer.getTime then
      local ok, t = pcall(love.timer.getTime)
      if ok then mix((tonumber(t) or 0) * 1000000) end
    end

    local token = tostring({})
    local hex = token:match("0x(%x+)")
    if hex then mix(tonumber(hex, 16) or 0) end

    return state
  end

  local launchState = launchSeed()

  local function nextRand(state)
    state = (state * 48271) % MODULUS
    if state <= 0 then state = 1 end
    return state, state
  end

  local function rosterValid(roster)
    if type(roster) ~= "table" or #roster ~= 3 then return false end
    local allowed, seen = {}, {}
    for _, sp in ipairs(candidatePool()) do allowed[sp] = true end
    for i = 1, 3 do
      local sp = tonumber(roster[i])
      if not sp or not allowed[sp] or seen[sp] then return false end
      seen[sp] = true
    end
    return true
  end

  local function generateRoster(excludeRoster)
    local pool = candidatePool()
    assert(#pool >= 3, "Random Starter Roster Emerald: fewer than three eligible species")

    local excluded = {}
    if rosterValid(excludeRoster) then
      for i = 1, 3 do excluded[tonumber(excludeRoster[i])] = true end
    end

    -- Prefer a completely different trio from the previous application launch.
    local bag = {}
    for _, sp in ipairs(pool) do
      if not excluded[sp] then bag[#bag + 1] = sp end
    end
    if #bag < 3 then
      bag = {}
      for _, sp in ipairs(pool) do bag[#bag + 1] = sp end
    end

    launchState = (launchState + 104729) % MODULUS
    if launchState <= 0 then launchState = 1 end
    local state = launchState

    for i = #bag, 2, -1 do
      local r
      state, r = nextRand(state)
      local j = (r % i) + 1
      bag[i], bag[j] = bag[j], bag[i]
    end
    launchState = state

    return { bag[1], bag[2], bag[3] }
  end

  local function runtimeSession()
    local Runtime = package.loaded["src.core.game3.runtime"]
    if not Runtime then
      local ok, loaded = pcall(require, "src.core.game3.runtime")
      if ok then Runtime = loaded end
    end
    if Runtime and Runtime.getSession then
      local ok, session = pcall(Runtime.getSession)
      if ok and type(session) == "table" then return session end
    end
    return nil
  end

  local function isEmeraldSession(session)
    local ok, row = pcall(Profile.forSession, session)
    return ok and type(row) == "table" and row.id == "emerald"
  end

  local function mapId(session)
    local id = session and session.map
    if not id then
      local Map = package.loaded["src.core.game3.map"]
      id = Map and Map.current
    end
    return tostring(id or "")
  end

  local function isRoute101(session)
    local key = mapId(session):upper():gsub("[^A-Z0-9]", "")
    return key == "ROUTE101" or key:sub(-8) == "ROUTE101"
  end

  local function partyIsEmpty(session)
    if type(session) ~= "table" then return false end
    local party = session.party
    if type(party) ~= "table" then return true end
    for _, mon in pairs(party) do
      if mon ~= nil then return false end
    end
    return true
  end

  -- Emerald's initial starter selection happens from Birch's bag on Route 101.
  -- The SYS_POKEMON_GET flag is already set before ChooseStarter runs, so the
  -- reliable runtime gate is Emerald + Route 101 + no party yet.
  local function initialBirchChoice(session)
    session = session or runtimeSession()
    return isEmeraldSession(session) and isRoute101(session) and partyIsEmpty(session)
  end

  local function logRoster(prefix, roster)
    if not (mod.log and mod.log.info and rosterValid(roster)) then return end
    local names = {}
    for i = 1, 3 do
      names[i] = Pokemon.name(roster[i]) or Pokemon.keyName(roster[i]) or tostring(roster[i])
    end
    mod.log:info("%s: %s / %s / %s", prefix, names[1], names[2], names[3])
  end

  -- Preview roster is process-local. It is deliberately rerolled after closing
  -- and reopening the application until a starter is actually chosen.
  local function ensureLaunchRoster()
    if rosterValid(launchRoster) then return launchRoster end

    local previous = mod.save:get("lastLaunchRoster")
    if not rosterValid(previous) then
      -- Migration from v1.0/v1.1 packages: use the old roster only as an
      -- exclusion source, never as this launch's preview.
      previous = mod.save:get("roster")
    end

    launchRoster = generateRoster(previous)
    mod.save:set("lastLaunchRoster", copyRoster(launchRoster))
    logRoster("Emerald random starter launch roster", launchRoster)
    return launchRoster
  end

  local function commitRoster(roster)
    if not rosterValid(roster) then return end
    committedRosterCache = copyRoster(roster)
    mod.save:set("committedRoster", copyRoster(roster))
    -- Preserve legacy key for compatibility with tools and older versions.
    mod.save:set("roster", copyRoster(roster))
    logRoster("Emerald committed starter roster", roster)
  end

  local function ensureCommittedRoster()
    if rosterValid(committedRosterCache) then return committedRosterCache end

    local saved = mod.save:get("committedRoster")
    if not rosterValid(saved) then saved = mod.save:get("roster") end
    if rosterValid(saved) then
      committedRosterCache = copyRoster(saved)
      return committedRosterCache
    end

    -- Defensive fallback for a save where the mod was enabled only after the
    -- starter sequence. Normal new games commit during Birch's Route 101 gift.
    committedRosterCache = generateRoster(mod.save:get("lastLaunchRoster"))
    commitRoster(committedRosterCache)
    return committedRosterCache
  end

  ---------------------------------------------------------------------------
  -- Emerald starter chooser integration
  ---------------------------------------------------------------------------

  local StarterChoose = require("src.ui.game3.rse.starter_choose")
  local FieldRse = require("src.core.game3.scripting.natives_field_rse")

  -- Emerald renders the three labels and sprites directly from the starter
  -- chooser manifest. Give this one screen instance a private manifest copy
  -- whose species list is our launch roster. No FireRed/LeafGreen text patching
  -- or Oak script-variable interception is used.
  local previousStarterNew = StarterChoose.new
  StarterChoose.new = function(opts)
    local screen = previousStarterNew(opts)
    local session = runtimeSession()
    if initialBirchChoice(session) and screen and type(screen.man) == "table" then
      local roster = ensureLaunchRoster()
      local man = copyTable(screen.man)
      man.species = copyRoster(roster)
      screen.man = man
      screen._randomStarterRosterEmerald = true
    end
    return screen
  end

  -- The native Emerald GiveStarter path sets VAR_STARTER_MON and then resolves
  -- the species through StarterChoose.species(nil, selection). Preserve that
  -- native function and all of its side effects; temporarily supply the random
  -- species only for this synchronous initial gift, then restore the resolver.
  local previousGiveStarter = FieldRse.giveStarter
  FieldRse.giveStarter = function(ctx, selection, session)
    session = session or runtimeSession()
    if not initialBirchChoice(session) then
      return previousGiveStarter(ctx, selection, session)
    end

    local roster = ensureLaunchRoster()
    local slot = (tonumber(selection) or 0) + 1
    if slot < 1 or slot > 3 or not roster[slot] then
      return previousGiveStarter(ctx, selection, session)
    end

    local previousSpecies = StarterChoose.species
    StarterChoose.species = function(man, selected)
      if man == nil and tonumber(selected) == tonumber(selection) then
        return roster[slot]
      end
      return previousSpecies(man, selected)
    end

    local results = { pcall(previousGiveStarter, ctx, selection, session) }
    StarterChoose.species = previousSpecies

    if not results[1] then error(results[2], 0) end

    currentPlayerSlot = slot
    commitRoster(roster)
    return unpack(results, 2)
  end

  ---------------------------------------------------------------------------
  -- Emerald May / Brendan rival consistency
  ---------------------------------------------------------------------------

  mod.hooks:wrap("trainer.party", function(nextFn, trainerClass, trainerId, party)
    local base = nextFn(trainerClass, trainerId, party) or party

    -- Extra runtime guard: even if the package is manually forced into another
    -- Gen 3 game, it must not patch FireRed, LeafGreen, Ruby, or Sapphire.
    if not isEmeraldSession(runtimeSession()) then return base end

    local slot = RIVAL_SLOT_BY_TRAINER[tonumber(trainerId)]
    if not slot or type(base) ~= "table" then return base end

    local roster = ensureCommittedRoster()
    local path = threeStagePath(roster[slot])
    if not path then return base end

    local out = {}
    for i, mon in ipairs(base) do
      local row = copyTable(mon)
      local key = type(row.species) == "string"
        and row.species
        or Pokemon.keyName(tonumber(row.speciesId or row.species))
      local stage = key and VANILLA_FAMILY_STAGE[key]

      if stage then
        local repl = path[stage] or path[#path]
        row.species = Pokemon.keyName(repl) or repl
        row.speciesId = repl

        -- Recompute legal level-up moves for the substituted species at the
        -- rival battle's level rather than inheriting Hoenn-starter-only moves.
        local G3 = require("src.mods.Gen3Compat")
        local learned = Pokemon.movesAtLevel(repl, tonumber(row.level or row.lvl) or 5) or {}
        local namedMoves = {}
        for _, moveId in ipairs(learned) do
          local moveName = G3.moveName and G3.moveName(moveId) or nil
          if moveName then namedMoves[#namedMoves + 1] = moveName end
        end
        row.moves = (#namedMoves > 0) and namedMoves or nil
        row.moveIds = nil
      end

      out[i] = row
    end

    return out
  end, 420)

  mod.exports.version = "1.2.0"
  mod.exports.supportedGames = { "emerald" }
  mod.exports.rerollsEveryLaunch = true
  mod.exports.commitAfterStarterChoice = true
  mod.exports.initialStarterLocation = "EM_ROUTE101"
  mod.exports.eligibleSpecies = function()
    local out = {}
    for i, sp in ipairs(candidatePool()) do out[i] = Pokemon.keyName(sp) or sp end
    return out
  end
  mod.exports.currentRoster = function()
    local session = runtimeSession()
    local roster
    if initialBirchChoice(session) then
      roster = ensureLaunchRoster()
    else
      roster = ensureCommittedRoster()
    end
    local out = {}
    for i = 1, 3 do out[i] = Pokemon.keyName(roster[i]) or roster[i] end
    return out
  end
  mod.exports.currentPlayerSlot = function() return currentPlayerSlot end
  -- Emerald's starter confirmation is generic and the screen renders the
  -- species name dynamically, so no text overrides are needed.
  mod.exports.confirmationTextPatches = function() return 0 end
end
