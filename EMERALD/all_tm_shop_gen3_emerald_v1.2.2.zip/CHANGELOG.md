# Changelog

## 1.2.2 — Evolution Shop coexistence + FREE badge fix

- Fixed `TM/HM SHOP` being visible but not opening when the Emerald Evolution Shop mod was also enabled.
- Added a public `ShopMenu.handleInput` activation bridge that intercepts only the TM/HM row and delegates every other root action unchanged.
- Raised load priority to 230 and declared the Emerald Evolution Shop as an optional dependency so this compatibility layer loads after it.
- Replaced the overflowing `FREE` text with a bounded pill/badge and reserved label width so it cannot overlap `TM/HM SHOP`.
- Kept the mod Emerald-only and preserved the existing mod ID for in-place upgrade from 1.2.1.

## 1.2.1 — Modern UI shop-root compatibility
- Fixed `TM/HM SHOP` being selectable in Emerald state but invisible under Modern UI.
- Added a root-only high-priority `render.hud` compatibility presenter that reads live `ShopMenu.ROOT`.
- The compatibility presenter activates only for normal Emerald Poké Mart root menus.
- BUY lists, SELL, quantity dialogs, Decoration Marts and the dedicated catalogue remain untouched.
- Updated the optional Modern UI dependency id from legacy `gen3_modern_ui` to `gen3_modern_ui_emerald`.
- Preserves any additional composable shop-root rows instead of hardcoding BUY / SELL / QUIT.

## 1.2.0 — Emerald conversion
- Converted the mod to Pokémon Emerald only.
- Changed mod id to `all_tm_shop_gen3_emerald` so the Emerald build can coexist with the FR/LG build.
- Replaced the FireRed/LeafGreen `ShopMenu.ROOT`-only integration with an Emerald RSE shop adapter.
- Added TM/HM SHOP to normal Emerald Poké Mart roots while preserving native BUY / SELL / QUIT behavior.
- Kept Emerald Decoration Shops untouched.
- Preserved composable shared Mart rows for compatibility with other shop extensions.
- Added Emerald runtime/profile guards around pricing, stock filtering, renderer and catalogue opening.
- Removed FireRed/LeafGreen Quest Log purchase recording.
- Updated user-facing storage text from TM CASE to Emerald's TM/HM POCKET.
- Retained all 50 TMs + 8 HMs, free pricing, filters, move details and the dedicated high-resolution catalogue.
- Updated the catalogue palette for an Emerald/Hoenn presentation.

## 1.1.5
- FireRed/LeafGreen release used as the conversion base.
