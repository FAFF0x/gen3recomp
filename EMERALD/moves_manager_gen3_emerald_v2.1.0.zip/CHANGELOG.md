# Changelog

## 2.1.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to Pokémon Emerald only.
- Changed mod ID to `moves_manager_gen3_emerald` and target game to `emerald`.
- Added runtime Emerald profile guarding.
- Added safe custom rendering for the `MOVES` Party action to avoid the native RSE cursor-option assert.
- Added Emerald Party-context restrictions for Safari, Battle Pike, Battle Pyramid, Multi Partner, Link/Union Room, battle, tutor and multi-select modes.
- Kept move replacement/reordering on the shared profile-aware Game3 Pokémon APIs.
- Verified HM protection includes Emerald HM08 Dive.
- Added a third move-detail page for Emerald Contest category, Appeal, Jam and effect description.
- Kept optional Modern UI high-resolution presentation.

## 2.0.2 - FireRed/LeafGreen source

- Source version used for this Emerald conversion.
