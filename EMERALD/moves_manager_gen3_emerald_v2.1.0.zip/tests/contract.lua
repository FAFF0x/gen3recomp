local build = (... and ...) or "."
local mainPath = build .. "/main.lua"

local stack = { layers = {} }
function stack.push(id, mod, opts) stack.layers[#stack.layers+1] = {id=id,mod=mod,opts=opts} end
function stack.pop(id) if stack.layers[#stack.layers] and stack.layers[#stack.layers].id == id then table.remove(stack.layers) end end
function stack.top() return stack.layers[#stack.layers] end

local currentSession = nil
local safariActive = false
local currentMap = nil
local linkActive = false

local pokemon = {
  _evolutions = { [1] = { { target = 2 } } },
  _learnsets = { [1]={{1,10},{5,20}}, [2]={{10,30}} },
  install=function() end,
  speciesOf=function(mon) return mon.species end,
  evolutions=function(sp) return pokemon._evolutions[sp] or {} end,
  learnset=function(sp) return pokemon._learnsets[sp] or {} end,
  moveIdAt=function(mon,i) return mon.moves[i] end,
  moveName=function(id) return "MOVE"..tostring(id) end,
  battleMove=function(id) return { pp=20,power=40,accuracy=100,type=0,category="physical",priority=0,target="FOE",effect=0 } end,
  moveMaxPp=function() return 20 end,
  isHmMove=function(id) return id==291 end,
  isEgg=function(mon) return mon and (mon.isEgg or mon.egg) or false end,
  displayName=function(mon) return mon.nickname or "MON" end,
  replaceMove=function(mon,slot,id) local old=mon.moves[slot]; if old==291 then return nil,"hm" end; mon.moves[slot]=id; mon.pp[slot]=20; mon.maxPp[slot]=20; return old end,
  teachMove=function(mon,id) for i=1,4 do if not mon.moves[i] then mon.moves[i]=id; mon.pp[i]=20; mon.maxPp[i]=20; return true,i end end return false end,
  swapMoves=function(mon,a,b)
    mon.moves[a],mon.moves[b]=mon.moves[b],mon.moves[a]
    mon.pp[a],mon.pp[b]=mon.pp[b],mon.pp[a]
    mon.maxPp[a],mon.maxPp[b]=mon.maxPp[b],mon.maxPp[a]
    return true
  end,
}

local party = { open=false,mode="list",cursor=1,ACTIONS={},actionCursor=1,_battle=false,_previousMode="list" }
function party.close() party.open=false; party.mode="list"; stack.pop("party") end
function party.show(p,ov,opts)
  party.open=true; party._party=p; party._session=opts.session; party.mode="list"; party._previousMode="list"
  party._battle=false; party._chooseOrder=nil; party._tutor=nil
  stack.push("party",party,{})
end
function party.handleInput(input)
  if party.mode=="list" and input:wasPressed("a") then
    party.mode="action"; party.ACTIONS={"SUMMARY","SWITCH","ITEM","CANCEL"}; party.actionCursor=1
  end
end
local nativeDrawCalls=0
function party.draw()
  nativeDrawCalls=nativeDrawCalls+1
  for _,a in ipairs(party.ACTIONS or {}) do assert(a~="MOVES", "custom action leaked into native renderer") end
end

local profile = {}
function profile.forSession(s)
  s=s or currentSession
  if not s then return nil end
  if tostring(s.version):lower()=="emerald" then
    return {id="emerald",family="rse",ui={party={insets={msgX=0,msgY=1,actX=8,actY=1,cursorX=0}}}}
  end
  return {id=tostring(s.version or "firered"),family="frlg",ui={}}
end

package.preload["src.ui.game3.stack"] = function() return stack end
package.preload["src.ui.game3.party_menu"] = function() return party end
package.preload["src.core.game3.pokemon"] = function() return pokemon end
package.preload["src.core.game3.battle.moves"] = function() return { numForName=function() end, get=pokemon.battleMove, displayName=pokemon.moveName } end
package.preload["src.core.game3.battle.types"] = function() return { name=function() return "NORMAL" end, isPhysical=function() return true end } end
package.preload["src.core.game3.summary_data"] = function() return { moveDescription=function() return "desc" end } end
package.preload["src.ui.game3.frlg_font"] = function() return { draw=function() end, COLOR={NORMAL={},BLUE={},MALE_NPC={}} } end
package.preload["src.core.game3.runtime"] = function() return { getSession=function() return currentSession end } end
package.preload["src.core.game3.profile"] = function() return profile end
package.preload["src.ui.game3.window"] = function() return {stdFrame=function() end,template=function() return {} end,cursorPx=function() end} end
package.preload["src.core.game3.rom_text"] = function() return {plain=function(k) return k end} end
package.preload["src.ui.game3.rse.scene_kit"] = function()
  return {loadLua=function(path)
    assert(path=="data/generated/gba/pokemon/contest_moves.lua")
    return {moves={[10]={effect=1,category=0}},effects={[1]={appeal=20,jam=10,description="contest-desc"}},categories={[0]="Cool"}}
  end}
end
package.preload["src.core.game3.safari"] = function() return {isActive=function() return safariActive end} end
package.preload["src.ui.game3.rse.start_menu_data"] = function() return {
  PIKE_MAPS={EM_BATTLE_FRONTIER_BATTLE_PIKE_ROOM_NORMAL=true},
  PYRAMID_MAPS={EM_BATTLE_FRONTIER_BATTLE_PYRAMID_FLOOR="floor"},
  MULTI_PARTNER_ROOM="EM_BATTLE_FRONTIER_BATTLE_TOWER_MULTI_PARTNER_ROOM",
} end
package.preload["src.core.game3.map"] = function() return {current=currentMap} end
package.preload["src.core.game3.link"] = function() return {link=true,inLinkRoom=function() return linkActive end} end
package.preload["src.core.game3.link.union_room"] = function() return {isUnionMap=function(map) return map=="EM_UNION_ROOM" end} end

local hooks = {}
local events = {}
local mod = {
  generation=3,
  hooks={wrap=function(_,name,fn,priority) hooks[name]=fn end},
  events={on=function(_,name,fn) events[name]=fn end},
  exports={},
  log={warn=function() end},
}

local chunk = assert(loadfile(mainPath))
chunk()(mod)
assert(mod.exports.generation==3)
assert(mod.exports.version=="2.1.0")
assert(mod.exports.game=="emerald")
assert(mod.exports.supportedGames[1]=="emerald" and #mod.exports.supportedGames==1)
assert(mod.exports.rseOnly==true)
assert(mod.exports.screenId=="moves_manager_gen3_emerald")
assert(type(mod.exports.replaceMove)=="function" and type(mod.exports.swapMoves)=="function")
assert(type(hooks["render.hud"])=="function")

local mon={species=2,level=10,nickname="TEST",moves={10,20,30,40},pp={10,11,12,13},maxPp={20,20,20,20}}
local session={version="emerald",party={mon},map="EM_LITTLEROOT_TOWN"}
currentSession=session
party.open=true; party._party=session.party; party._session=session; party.mode="list"; party.cursor=1; party._previousMode="list"
stack.push("party",party,{})
local pressed={a=true}
local input={wasPressed=function(_,k) return pressed[k] or false end}
party.handleInput(input)
assert(party.mode=="action")
local found
for i,a in ipairs(party.ACTIONS) do if a=="MOVES" then found=i end end
assert(found,"MOVES action not injected on Emerald normal party")
party.draw()
assert(nativeDrawCalls==1,"native party draw not called")
assert(party.ACTIONS[found]=="MOVES","MOVES action was not restored after safe draw")
party.actionCursor=found
party.handleInput(input)
assert(stack.top() and stack.top().id=="moves_manager_gen3_emerald","Emerald manager not opened")

local ok,reason=mod.exports.replaceMove(mon,1,30)
assert(ok==false and reason=="duplicate")
local ok2=mod.exports.swapMoves(mon,1,2)
assert(ok2 and mon.moves[1]==20 and mon.moves[2]==10 and mon.maxPp[1]==20)

local hmMon={species=2,level=10,moves={291,20,30,40},pp={5,10,10,10},maxPp={5,20,20,20}}
local hmOk,hmReason=mod.exports.replaceMove(hmMon,1,10)
assert(hmOk==false and hmReason=="hm_locked","Emerald HM08 Dive was not protected")

-- FireRed guard: no injection and exported open refuses.
local frMon={species=2,level=10,moves={10,20,30,40},pp={10,10,10,10},maxPp={20,20,20,20}}
local fr={version="firered",party={frMon},map="FR_PALLET_TOWN"}
currentSession=fr
party.open=true; party._party=fr.party; party._session=fr; party.mode="action"; party._previousMode="list"; party.ACTIONS={"SUMMARY","SWITCH","ITEM","CANCEL"}; party.actionCursor=1
party.handleInput({wasPressed=function() return false end})
for _,a in ipairs(party.ACTIONS) do assert(a~="MOVES","MOVES injected into FireRed") end
assert(mod.exports.open(frMon,fr)==false,"FireRed runtime guard failed")

-- Emerald special contexts must not expose MOVES.
currentSession=session
local function assertRestricted(map, safari, link)
  session.map=map; currentMap=map; safariActive=safari or false; linkActive=link or false
  party.open=true; party._party=session.party; party._session=session; party.mode="action"; party._previousMode="list"; party.ACTIONS={"SUMMARY","SWITCH","ITEM","CANCEL"}
  party.handleInput({wasPressed=function() return false end})
  for _,a in ipairs(party.ACTIONS) do assert(a~="MOVES","MOVES injected in restricted context "..tostring(map)) end
end
assertRestricted("EM_SAFARI_ZONE_NORTHWEST",true,false)
assertRestricted("EM_BATTLE_FRONTIER_BATTLE_PIKE_ROOM_NORMAL",false,false)
assertRestricted("EM_BATTLE_FRONTIER_BATTLE_PYRAMID_FLOOR",false,false)
assertRestricted("EM_BATTLE_FRONTIER_BATTLE_TOWER_MULTI_PARTNER_ROOM",false,false)
assertRestricted("EM_LITTLEROOT_TOWN",false,true)
assertRestricted("EM_UNION_ROOM",false,false)

print("moves_manager_gen3_emerald_contract: ok")
