-- Pokecenter Max Happiness Gen 3 v1.1.0
-- Emerald-only standalone port.
--
-- Pokemon Emerald's Pokemon Center nurse uses special HealPlayerParty
-- (special id 0), but runs under the RSE/Emerald Game3 profile and EM_* maps.
-- This hook stays scoped to Emerald Pokemon Center 1F maps so whiteout,
-- scripted battle heals, link-room heals, and other healing paths remain vanilla.

local HEAL_PLAYER_PARTY = 0x00
local MAX_FRIENDSHIP = 255
local EMERALD_PREFIX = "EM_"
local CENTER_SUFFIX = "_POKEMON_CENTER_1F"

local function mapIdFromContext(ctx)
  if type(ctx) ~= "table" then return nil end

  if ctx.mapId ~= nil then
    return tostring(ctx.mapId)
  end

  local ow = ctx.overworld
  local map = ow and ow.map
  if type(map) == "table" and map.id ~= nil then
    return tostring(map.id)
  elseif type(map) == "string" then
    return map
  end

  local session = ctx.session or ctx.save
  if type(session) == "table" and session.map ~= nil then
    return tostring(session.map)
  end

  return nil
end

local function isEmeraldPokemonCenter(ctx)
  local id = mapIdFromContext(ctx)
  if not id then return false end
  id = id:upper()

  -- Emerald map ids are EM_<LOCATION>_POKEMON_CENTER_1F.
  -- The explicit EM_ prefix prevents accidental FR/LG activation even if
  -- this package is force-enabled outside its manifest target.
  return id:sub(1, #EMERALD_PREFIX) == EMERALD_PREFIX
    and id:sub(-#CENTER_SUFFIX) == CENTER_SUFFIX
end

local function isEmeraldRuntime()
  local ok, Profile = pcall(require, "src.core.game3.profile")
  if not ok or type(Profile) ~= "table" or type(Profile.active) ~= "function" then
    return false
  end
  local okProfile, active = pcall(Profile.active)
  return okProfile and type(active) == "table"
    and active.id == "emerald" and active.family == "rse"
end

local function isEgg(mon)
  if type(mon) ~= "table" then return false end

  local ok, Pokemon = pcall(require, "src.core.game3.pokemon")
  if ok and type(Pokemon) == "table" and type(Pokemon.isEgg) == "function" then
    local okEgg, egg = pcall(Pokemon.isEgg, mon)
    if okEgg then return egg == true end
  end

  -- Safe fallback matching Game3's opaque Egg placeholder.
  if mon.isEgg == true or mon.egg == true then return true end
  return tonumber(mon.species or mon.speciesId) == 412
end

local function maximizeParty(session)
  local changed = 0
  local party = type(session) == "table" and session.party or nil
  if type(party) ~= "table" then return changed end

  for _, mon in ipairs(party) do
    if type(mon) == "table" and not isEgg(mon) then
      local old = tonumber(mon.friendship or mon.happiness)
      if old ~= MAX_FRIENDSHIP then changed = changed + 1 end

      -- Game3 code uses friendship as the canonical Gen3 value, while some
      -- compatibility paths still read happiness. Keep both aliases synced.
      mon.friendship = MAX_FRIENDSHIP
      mon.happiness = MAX_FRIENDSHIP
    end
  end

  return changed
end

return function(mod)
  if not mod or not mod.hooks or type(mod.hooks.wrap) ~= "function" then
    error("Pokecenter Max Happiness Emerald requires Mod API hook support")
  end

  -- Manifest targeting is the primary gate; this runtime guard prevents the
  -- hook from doing anything if the package is force-enabled on another cart.
  if not isEmeraldRuntime() then
    if mod.log and mod.log.info then
      mod.log:info("Emerald profile not active; Pokecenter happiness hook not installed")
    end
    return
  end

  mod.hooks:wrap("script.command", function(next, ctx, op, row)
    -- Run Emerald's native special first. Friendship is independent of the
    -- HP/status/PP heal and can be synchronized immediately afterwards.
    local result = next(ctx, op, row)

    local specialId = type(row) == "table" and tonumber(row.id or row[1]) or nil
    if op == "special"
        and specialId == HEAL_PLAYER_PARTY
        and isEmeraldPokemonCenter(ctx) then
      local session = ctx and (ctx.session or ctx.save)
      local changed = maximizeParty(session)

      if mod.log and mod.log.info then
        mod.log:info(
          "Emerald Pokemon Center heal on %s: friendship set to 255 (%d changed)",
          tostring(mapIdFromContext(ctx) or "?"), changed
        )
      end
    end

    return result
  end, 0)

  mod.exports.version = "1.1.0"
  mod.exports.game = "emerald"
  mod.exports.supportedGames = { "emerald" }

  mod.exports.maximizePartyHappiness = function(session)
    local target = session
    if target == nil and mod.game then
      target = mod.game.session or mod.game.save
    end
    return maximizeParty(target)
  end

  mod.exports.maximizePartyFriendship = mod.exports.maximizePartyHappiness

  if mod.log and mod.log.info then
    mod.log:info("Installed Emerald Pokemon Center heal -> max friendship hook")
  end
end
