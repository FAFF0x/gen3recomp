-- Pokédex Plus - Gen 3 / Emerald
-- v1.1.1: Emerald Pokédex entry formatter fix (no FRLG gText_Lbs dependency).
-- IMPORTANT: do not use debug.traceback here; the mod sandbox may not expose debug.
local MOD_ID = "pokemonmod_gen3_pokedex_plus_emerald"
local STACK_ID = "pokemonmod_gen3_pokedex_plus_emerald"
local EQUIVALENTS = {
  "pokedex_plus_gen3_emerald",
  "pokemonmod_pokedex_plus_gen3_emerald",
}

local function norm(s)
  return tostring(s or ""):upper():gsub("é", "E"):gsub("É", "E"):gsub("[^A-Z0-9]", "")
end

local function safeRequire(path)
  local ok, m = pcall(require, path)
  return ok and m or nil
end

local function runtimeSession(game)
  if game and game.session then return game.session end
  local R = package.loaded["src.core.game3.runtime"] or safeRequire("src.core.game3.runtime")
  return R and R.getSession and R.getSession() or nil
end

local function isEmerald(session)
  if type(session) == "table" and session.version == "emerald" then return true end
  local GameVersion = safeRequire("src.core.GameVersion")
  if session == nil and GameVersion and GameVersion.get and GameVersion.get() == "emerald" then return true end
  local Profile = safeRequire("src.core.game3.profile")
  if not (Profile and Profile.forSession) then return false end
  local ok, row = pcall(Profile.forSession, session)
  return ok and type(row) == "table" and row.id == "emerald" and row.family == "rse"
end

local function install(mod)
  if not isEmerald(runtimeSession()) then
    mod.exports.active = false
    mod.exports.game = "emerald"
    mod.exports.supportedGames = { "emerald" }
    mod.exports.inactiveReason = "emerald-only"
    return
  end

  local Pokemon = require("src.core.game3.pokemon")
  local Dex = require("src.core.game3.dex")
  local PokedexData = require("src.core.game3.pokedex_data")
  local Types = require("src.core.game3.battle.types")
  local Stack = require("src.ui.game3.stack")
  local FrlgFont = require("src.ui.game3.frlg_font")
  local Screens = require("src.ui.game3.screens")

  local Plus = {
    open = false,
    screen = "list", -- list | filters | detail
    cursor = 1,
    scroll = 0,
    query = "",
    typeFilter = -1, -- -1 = ANY
    statusFilter = "ANY", -- ANY | SEEN | CAUGHT | UNSEEN
    sortMode = "NUMBER", -- NUMBER | NAME | TYPE
    filterCursor = 1,
    searchEdit = false,
    kbCursor = 1,
    selected = 1,
    detailTab = 1,
    detailScroll = 0,
    _session = nil,
    _dex = nil,
    _rows = {},
    _detail = nil,
    _dataReady = false,
  }

  local TABS = { "OVERVIEW", "DEX ENTRY", "STATS", "EVOLUTION", "LEVEL MOVES", "HABITAT" }
  local TYPE_IDS = { -1, 0,1,2,3,4,5,6,7,8,10,11,12,13,14,15,16,17 }
  local LIST_VISIBLE = 9
  local FILTER_ROWS = { "SEARCH", "TYPE", "STATUS", "SORT", "RESET", "APPLY" }
  local STATUS_FILTERS = { "ANY", "SEEN", "CAUGHT", "UNSEEN" }
  local SORT_MODES = { "NUMBER", "NAME", "TYPE" }
  local KB_KEYS = {
    "A","B","C","D","E","F","G",
    "H","I","J","K","L","M","N",
    "O","P","Q","R","S","T","U",
    "V","W","X","Y","Z","BACK","CLEAR","DONE",
  }
  local KB_COLS = 7

  local TEXT = {
    fg = { 0x18/255, 0x18/255, 0x18/255, 1 },
    shadow = { 0xD0/255, 0xD0/255, 0xD0/255, 1 },
  }
  local ORANGE = {
    fg = { 1, 139/255, 57/255, 1 },
    shadow = { 205/255, 65/255, 57/255, 1 },
  }
  local MUTED = {
    fg = { 0x60/255, 0x60/255, 0x60/255, 1 },
    shadow = { 0xE8/255, 0xE0/255, 0xCE/255, 1 },
  }

  local function ensureData()
    if Plus._dataReady then return end
    if not Pokemon._names then pcall(Pokemon.install, nil) end
    pcall(PokedexData.init)
    Plus._dataReady = true
  end

  local function natDex(sp)
    if Pokemon.national then return tonumber(Pokemon.national(sp)) or tonumber(sp) or 0 end
    return tonumber(sp) or 0
  end

  local function nationalMode()
    return PokedexData.isNationalUnlocked(Plus._session, Plus._dex) == true
  end

  local function visibleMax()
    if nationalMode() then return Dex.NATIONAL_MAX or 386 end
    local ok, n = pcall(Dex.regionalMax, "emerald")
    return ok and tonumber(n) or 202
  end

  local function dexOrderRows()
    local out = {}
    local national = nationalMode()
    for nat = 1, (Dex.NATIONAL_MAX or 386) do
      local sp = Pokemon.speciesFromNational and Pokemon.speciesFromNational(nat) or nat
      if sp and sp > 0 then
        if national then
          out[#out + 1] = { species = sp, number = nat, national = nat }
        else
          local ok, reg = pcall(Dex.regionalNumber, sp, "emerald")
          reg = ok and tonumber(reg) or nil
          if reg then out[#out + 1] = { species = sp, number = reg, national = nat } end
        end
      end
    end
    if not national then table.sort(out, function(a, b) return a.number < b.number end) end
    return out
  end

  local function seen(sp)
    return Plus._dex and Dex.isSeen(Plus._dex, sp) or false
  end

  local function caught(sp)
    return Plus._dex and Dex.isCaught(Plus._dex, sp) or false
  end

  local function revealUnseen()
    if mod.options and mod.options.get then
      return mod.options:get("reveal_unseen") ~= false
    end
    return true
  end

  local function typeMatches(sp, tid)
    if tid == -1 then return true end
    local ts = Pokemon.types and Pokemon.types(sp) or {}
    for _, t in ipairs(ts or {}) do
      if tonumber(t) == tonumber(tid) then return true end
    end
    return false
  end

  -- Rebuilt only when opening the screen or changing a filter/search.
  local function rebuildRows()
    ensureData()
    local rows = {}
    local q = norm(Plus.query)
    local reveal = revealUnseen()
    local national = nationalMode()
    for _, dexRow in ipairs(dexOrderRows()) do
      local sp = dexRow.species
      local isSeen = seen(sp)
      local isCaught = caught(sp)
      if reveal or isSeen or isCaught then
        local name = Pokemon.name(sp) or ("POKéMON " .. tostring(dexRow.number))
        local statusOk = Plus.statusFilter == "ANY"
          or (Plus.statusFilter == "CAUGHT" and isCaught)
          or (Plus.statusFilter == "SEEN" and isSeen)
          or (Plus.statusFilter == "UNSEEN" and not isSeen and not isCaught)
        if statusOk and (q == "" or norm(name):find(q, 1, true)) and typeMatches(sp, Plus.typeFilter) then
          rows[#rows + 1] = {
            species = sp,
            nat = dexRow.number,
            national = dexRow.national,
            regional = national and (Dex.regionalNumber and Dex.regionalNumber(sp, "emerald") or nil) or dexRow.number,
            name = name,
            seen = isSeen,
            caught = isCaught,
            primaryType = ((Pokemon.types and Pokemon.types(sp)) or {})[1] or 0,
          }
        end
      end
    end
    if Plus.sortMode == "NAME" then
      table.sort(rows, function(a, b)
        local an, bn = norm(a.name), norm(b.name)
        if an == bn then return a.nat < b.nat end
        return an < bn
      end)
    elseif Plus.sortMode == "TYPE" then
      table.sort(rows, function(a, b)
        if a.primaryType == b.primaryType then return a.nat < b.nat end
        return a.primaryType < b.primaryType
      end)
    end
    Plus._rows = rows
    Plus.cursor = math.max(1, math.min(#rows > 0 and #rows or 1, Plus.cursor))
    Plus.scroll = math.max(0, math.min(Plus.scroll, math.max(0, #rows - LIST_VISIBLE)))
    if Plus.cursor <= Plus.scroll then Plus.scroll = Plus.cursor - 1 end
    if Plus.cursor > Plus.scroll + LIST_VISIBLE then Plus.scroll = Plus.cursor - LIST_VISIBLE end
    if rows[Plus.cursor] then Plus.selected = rows[Plus.cursor].species end
    return rows
  end

  local function rows()
    return Plus._rows or {}
  end

  local function clampCursor()
    local list = rows()
    local n = #list
    if n == 0 then
      Plus.cursor, Plus.scroll = 1, 0
      return
    end
    Plus.cursor = math.max(1, math.min(n, Plus.cursor))
    if Plus.cursor <= Plus.scroll then Plus.scroll = Plus.cursor - 1 end
    if Plus.cursor > Plus.scroll + LIST_VISIBLE then Plus.scroll = Plus.cursor - LIST_VISIBLE end
    Plus.scroll = math.max(0, math.min(Plus.scroll, math.max(0, n - LIST_VISIBLE)))
    Plus.selected = list[Plus.cursor].species
  end

  local function currentRow()
    return rows()[Plus.cursor]
  end

  local function typeNames(sp)
    local out, last = {}, nil
    for _, tid in ipairs((Pokemon.types and Pokemon.types(sp)) or {}) do
      local n = Types.name(tid)
      if n and n ~= last then out[#out + 1] = n; last = n end
    end
    if #out == 0 then out[1] = "UNKNOWN" end
    return out
  end

  local function stats(sp)
    local s = Pokemon.stats(sp) or {}
    local r = {
      hp = s.hp or 0, atk = s.atk or 0, def = s.def or 0,
      spe = s.spe or 0, spa = s.spa or 0, spd = s.spd or 0,
    }
    r.total = r.hp + r.atk + r.def + r.spe + r.spa + r.spd
    return r
  end

  local EVO_NAME = {
    [1] = "FRIENDSHIP", [2] = "FRIENDSHIP DAY", [3] = "FRIENDSHIP NIGHT",
    [4] = "LEVEL", [5] = "TRADE", [6] = "TRADE + ITEM", [7] = "ITEM",
    [8] = "LEVEL ATK > DEF", [9] = "LEVEL ATK = DEF", [10] = "LEVEL ATK < DEF",
    [11] = "LEVEL / SILCOON", [12] = "LEVEL / CASCOON", [13] = "LEVEL",
    [14] = "LEVEL + EMPTY SLOT", [15] = "BEAUTY",
  }

  -- Compatibility view for pokemonmod_gen3_trade_evolution_fix.  The evolution
  -- mod owns the mechanics; Pokédex Plus only changes the text shown here.
  -- This fallback table supports v1.2.1, which predates a public requirement
  -- query export.  If a future version exposes requirementFor(), prefer it.
  local TRADE_FIX_REQUIREMENTS = {
    KADABRA   = { ALAKAZAM = { level = 40 } },
    MACHOKE   = { MACHAMP  = { level = 40 } },
    GRAVELER  = { GOLEM    = { level = 40 } },
    HAUNTER   = { GENGAR   = { level = 40 } },
    POLIWHIRL = { POLITOED = { level = 40, item = "KING'S ROCK" } },
    SLOWPOKE  = { SLOWKING = { level = 37, item = "KING'S ROCK" } },
    ONIX      = { STEELIX  = { level = 40, item = "METAL COAT" } },
    SCYTHER   = { SCIZOR   = { level = 40, item = "METAL COAT" } },
    SEADRA    = { KINGDRA  = { level = 40, item = "DRAGON SCALE" } },
    PORYGON   = { PORYGON2 = { level = 40, item = "UP-GRADE" } },
    CLAMPERL  = {
      HUNTAIL = { level = 40, item = "DEEPSEATOOTH" },
      GOREBYSS = { level = 40, item = "DEEPSEASCALE" },
    },
  }

  local function tradeFixRequirement(sourceSp, targetSp)
    if not (mod and mod.find) then return nil end
    local peer = mod.find("pokemonmod_gen3_trade_evolution_fix_emerald")
      or mod.find("pokemonmod_gen3_trade_evolution_fix")
    if not peer then return nil end

    local sourceKey = Pokemon.keyName and Pokemon.keyName(sourceSp) or nil
    local targetKey = Pokemon.keyName and Pokemon.keyName(targetSp) or nil
    if not sourceKey or not targetKey then return nil end

    local ex = peer.exports
    if ex and type(ex.requirementFor) == "function" then
      local ok, req = pcall(ex.requirementFor, sourceKey, targetKey)
      if ok and type(req) == "table" then return req end
    end

    local bySource = TRADE_FIX_REQUIREMENTS[sourceKey]
    return bySource and bySource[targetKey] or nil
  end

  local function evoLine(sourceSp, e)
    local method = tonumber(e.method or e[1]) or 0
    local param = tonumber(e.param or e[2]) or 0
    local target = tonumber(e.target or e[3]) or 0
    local targetName = Pokemon.name(target) or tostring(target)

    local req = tradeFixRequirement(sourceSp, target)
    if req then
      local how = "LEVEL " .. tostring(tonumber(req.level) or 40)
      if req.item and tostring(req.item) ~= "" then
        how = how .. " + " .. tostring(req.item)
      end
      return how .. " -> " .. targetName
    end

    local how = EVO_NAME[method] or ("METHOD " .. method)
    if method == 4 or (method >= 8 and method <= 14) then
      how = how .. " " .. param
    elseif method == 15 then
      how = how .. " " .. param
    elseif method == 6 or method == 7 then
      local ItemsData = safeRequire("src.core.game3.items_data")
      local itemName = ItemsData and ItemsData.displayName and ItemsData.displayName(param) or tostring(param)
      how = how .. " " .. tostring(itemName)
    end
    return how .. " -> " .. targetName
  end

  local function learnRows(sp)
    local out = {}
    for _, e in ipairs(Pokemon.learnset(sp) or {}) do
      local lv = tonumber(e.level or e[1]) or 0
      local mv = tonumber(e.move or e[2]) or 0
      out[#out + 1] = { level = lv, move = mv, name = Pokemon.moveName(mv) }
    end
    return out
  end

  local function areaRows(sp)
    local RsePokedex = safeRequire("src.ui.game3.rse.pokedex")
    local Area = safeRequire("src.ui.game3.rse.pokedex_area")
    local Mapsec = safeRequire("src.ui.game3.rse.mapsec")
    if not (RsePokedex and RsePokedex.newView and RsePokedex.areaContext and Area and Area.findMapsWithMon and Mapsec) then
      return {}
    end
    local okView, view = pcall(RsePokedex.newView, { session = Plus._session or {}, dex = Plus._dex })
    if not okView or type(view) ~= "table" then return {} end
    local okCtx, ctx = pcall(RsePokedex.areaContext, view)
    if not okCtx or type(ctx) ~= "table" then return {} end
    local okFound, found = pcall(Area.findMapsWithMon, sp, ctx)
    if not okFound or type(found) ~= "table" then return {} end

    local out, seenSec = {}, {}
    local function add(sec, kind)
      sec = tonumber(sec)
      if not sec or seenSec[sec] then return end
      seenSec[sec] = true
      local name = Mapsec.name and Mapsec.name(sec) or ""
      if not name or name == "" then name = "MAP SECTION " .. tostring(sec) end
      out[#out + 1] = { sec = sec, label = name, kind = kind or "area" }
    end
    for _, a in ipairs(found.overworld or {}) do add(a.sec, "overworld") end
    for _, sec in ipairs(found.special or {}) do add(sec, "special") end
    table.sort(out, function(a, b) return tostring(a.label) < tostring(b.label) end)
    return out
  end

  -- Emerald/RSE entry formatter.  Do not call PokedexData.getEntry() here:
  -- that shared helper still appends the FRLG-only ROM key gText_Lbs, which is
  -- absent from Emerald's script cache.  The native RSE Pokédex already owns
  -- the correct height/weight formatting, including the literal "lbs." suffix.
  local function emeraldDexEntry(sp)
    local raw = Pokemon.dexEntry and Pokemon.dexEntry(sp) or {}
    if type(raw) ~= "table" then raw = {} end
    local RsePokedex = safeRequire("src.ui.game3.rse.pokedex")

    local heightFormatted
    if RsePokedex and type(RsePokedex.heightText) == "function" then
      local ok, text = pcall(RsePokedex.heightText, tonumber(raw.height) or 0)
      if ok then heightFormatted = text end
    end
    if not heightFormatted then
      local dm = tonumber(raw.height) or 0
      local inchesTenths = math.floor(10000 * dm / 254)
      if inchesTenths % 10 >= 5 then inchesTenths = inchesTenths + 10 end
      local feet = math.floor(inchesTenths / 120)
      local inches = math.floor((inchesTenths - feet * 120) / 10)
      heightFormatted = string.format("%2d'%02d\"", feet, inches)
    end

    local weightFormatted
    if RsePokedex and type(RsePokedex.weightText) == "function" then
      local ok, text = pcall(RsePokedex.weightText, tonumber(raw.weight) or 0)
      if ok then weightFormatted = text end
    end
    if not weightFormatted then
      local hg = tonumber(raw.weight) or 0
      local lbsHund = math.floor((hg * 100000) / 4536)
      if lbsHund % 10 >= 5 then lbsHund = lbsHund + 10 end
      local wholeLbs = math.floor(lbsHund / 100)
      local fracLbs = math.floor((lbsHund % 100) / 10)
      weightFormatted = string.format("%4d.%d lbs.", wholeLbs, fracLbs)
    end

    local category = tostring(raw.category or "")
    return {
      category = category,
      categoryName = category ~= "" and (category .. " POKéMON") or "POKéMON",
      heightDm = tonumber(raw.height) or 0,
      weightHg = tonumber(raw.weight) or 0,
      heightFormatted = heightFormatted,
      weightFormatted = weightFormatted,
      description = tostring(raw.description or ""),
      description2 = tostring((raw.description2 and raw.description2 ~= "") and raw.description2 or raw.description or ""),
      pokemonScale = raw.pokemonScale or 256,
      pokemonOffset = raw.pokemonOffset or 0,
      trainerScale = raw.trainerScale or 256,
      trainerOffset = raw.trainerOffset or 0,
    }
  end

  -- Detail data is snapshotted once on entry, not regenerated every frame.
  local function buildDetail(sp)
    local meta = Pokemon.speciesMeta(sp) or {}
    local de = Pokemon.dexEntry and Pokemon.dexEntry(sp) or {}
    local pde = emeraldDexEntry(sp)
    local evos = {}
    for _, e in ipairs(Pokemon.evolutions(sp) or {}) do evos[#evos + 1] = evoLine(sp, e) end
    Plus._detail = {
      species = sp,
      nat = nationalMode() and natDex(sp) or (Dex.regionalNumber(sp, "emerald") or natDex(sp)),
      national = natDex(sp),
      name = Pokemon.name(sp) or tostring(sp),
      types = typeNames(sp),
      stats = stats(sp),
      meta = meta,
      dexEntry = de,
      pokedexEntry = pde,
      evos = evos,
      moves = learnRows(sp),
      areas = areaRows(sp),
      front = false, -- lazy-loaded only on Overview
    }
  end

  local function entryPageCount(d)
    return 1
  end

  local function entryDescription(d)
    local e = d and d.pokedexEntry or {}
    return tostring(e.description or ""), "EMERALD"
  end

  local function playSe(id)
    pcall(function() require("src.core.game3.audio").playSe(id) end)
  end

  local function playCry(sp)
    pcall(function() require("src.core.game3.audio").playCry(sp) end)
  end

  local function openNativeArea(sp)
    local session = Plus._session
    if not isEmerald(session) then return false end
    local Pokedex = Screens.get("pokedex", session)
    if not (Pokedex and Pokedex.show) then return false end
    local ok, state = pcall(Pokedex.show, Plus._dex, { session = session })
    if not ok or type(state) ~= "table" then return false end
    local nat = natDex(sp)
    -- Use a one-entry view so AREA also works when Pokédex Plus is configured
    -- to reveal an unseen Pokémon that the retail Emerald list would omit.
    state.list = {
      count = 1,
      items = { [0] = { dexNum = nat, seen = seen(sp), owned = caught(sp) } },
    }
    state.selected = 0
    state.pageBackup = Pokedex.PAGE and Pokedex.PAGE.MAIN or 0
    state.info = { scrolling = false, monDone = false, bgLoaded = false, skipCry = true, mon = nil }
    state.state = 0
    state.fn = "loadArea"
    return true
  end

  local function cycleValue(list, current, dir)
    local idx = 1
    for i, v in ipairs(list) do if v == current then idx = i break end end
    idx = ((idx - 1 + dir) % #list) + 1
    return list[idx]
  end

  local function cycleType(dir)
    Plus.typeFilter = cycleValue(TYPE_IDS, Plus.typeFilter, dir)
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
    playSe(5)
  end

  local function cycleStatus(dir)
    Plus.statusFilter = cycleValue(STATUS_FILTERS, Plus.statusFilter, dir)
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
    playSe(5)
  end

  local function cycleSort(dir)
    Plus.sortMode = cycleValue(SORT_MODES, Plus.sortMode, dir)
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
    playSe(5)
  end

  local function clearFilters()
    Plus.query = ""
    Plus.typeFilter = -1
    Plus.statusFilter = "ANY"
    Plus.sortMode = "NUMBER"
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
  end

  local function appendSearch(ch)
    ch = tostring(ch or ""):upper()
    if not ch:match("^[A-Z0-9]$") then return end
    if #Plus.query >= 12 then return end
    Plus.query = Plus.query .. ch
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
  end

  local function backspaceSearch()
    if Plus.query == "" then return false end
    Plus.query = Plus.query:sub(1, -2)
    Plus.cursor, Plus.scroll = 1, 0
    rebuildRows()
    return true
  end

  local function searchKeyAction(key)
    if key == "BACK" then
      backspaceSearch()
    elseif key == "CLEAR" then
      Plus.query = ""; Plus.cursor, Plus.scroll = 1, 0; rebuildRows()
    elseif key == "DONE" then
      Plus.searchEdit = false
    else
      appendSearch(key)
    end
    playSe(5)
  end

  local function openFilters()
    Plus.screen = "filters"
    Plus.filterCursor = 1
    Plus.searchEdit = false
    Plus.kbCursor = math.max(1, math.min(#KB_KEYS, Plus.kbCursor or 1))
    playSe(5)
  end

  function Plus.show(session, dex)
    if not isEmerald(session) then return false end
    ensureData()
    Plus._session = session
    Plus._dex = dex or (session and session.dex) or Dex.new()
    Plus.open = true
    Plus.screen = "list"
    Plus.cursor, Plus.scroll = 1, 0
    Plus.detailTab, Plus.detailScroll = 1, 0
    Plus.searchEdit = false
    Plus._detail = nil
    rebuildRows()
    Stack.push(STACK_ID, Plus, { hideBelow = true, fullscreen = true })
    playSe(5)
  end

  function Plus.close()
    if not Plus.open then return end
    Plus.open = false
    Plus._detail = nil
    Stack.pop(STACK_ID)
    playSe(9)
  end

  function Plus.handleInput(input)
    if not Plus.open then return end

    if Plus.screen == "list" then
      local list = rows()
      if input:wasPressed("up") then
        Plus.cursor = math.max(1, Plus.cursor - 1); clampCursor(); playSe(5)
      elseif input:wasPressed("down") then
        Plus.cursor = math.min(#list > 0 and #list or 1, Plus.cursor + 1); clampCursor(); playSe(5)
      elseif input:wasPressed("left") or input:wasPressed("l") then
        Plus.cursor = math.max(1, Plus.cursor - LIST_VISIBLE); clampCursor(); playSe(5)
      elseif input:wasPressed("right") or input:wasPressed("r") then
        Plus.cursor = math.min(#list > 0 and #list or 1, Plus.cursor + LIST_VISIBLE); clampCursor(); playSe(5)
      elseif input:wasPressed("a") then
        local row = currentRow()
        if row then
          Plus.selected = row.species
          buildDetail(row.species)
          Plus.screen = "detail"
          Plus.detailTab, Plus.detailScroll = 1, 0
          playSe(5)
          if row.seen or revealUnseen() then playCry(row.species) end
        end
      elseif input:wasPressed("start") or input:wasPressed("select") then
        openFilters()
      elseif input:wasPressed("b") then
        Plus.close()
      end
      return
    end

    if Plus.screen == "filters" then
      if Plus.searchEdit then
        local cols = KB_COLS
        local rowsN = math.ceil(#KB_KEYS / cols)
        local pos = Plus.kbCursor
        local row = math.floor((pos - 1) / cols)
        local col = (pos - 1) % cols
        if input:wasPressed("left") then col = (col - 1 + cols) % cols; playSe(5)
        elseif input:wasPressed("right") then col = (col + 1) % cols; playSe(5)
        elseif input:wasPressed("up") then row = (row - 1 + rowsN) % rowsN; playSe(5)
        elseif input:wasPressed("down") then row = (row + 1) % rowsN; playSe(5)
        elseif input:wasPressed("a") then searchKeyAction(KB_KEYS[pos]); return
        elseif input:wasPressed("select") then Plus.query = ""; rebuildRows(); playSe(5); return
        elseif input:wasPressed("start") then Plus.searchEdit = false; playSe(5); return
        elseif input:wasPressed("b") then
          if not backspaceSearch() then Plus.searchEdit = false end
          playSe(9); return
        end
        local np = row * cols + col + 1
        if np > #KB_KEYS then np = #KB_KEYS end
        Plus.kbCursor = np
        return
      end

      local rowId = FILTER_ROWS[Plus.filterCursor]
      if input:wasPressed("up") then
        Plus.filterCursor = ((Plus.filterCursor - 2) % #FILTER_ROWS) + 1; playSe(5)
      elseif input:wasPressed("down") then
        Plus.filterCursor = (Plus.filterCursor % #FILTER_ROWS) + 1; playSe(5)
      elseif input:wasPressed("left") then
        if rowId == "TYPE" then cycleType(-1)
        elseif rowId == "STATUS" then cycleStatus(-1)
        elseif rowId == "SORT" then cycleSort(-1) end
      elseif input:wasPressed("right") then
        if rowId == "TYPE" then cycleType(1)
        elseif rowId == "STATUS" then cycleStatus(1)
        elseif rowId == "SORT" then cycleSort(1) end
      elseif input:wasPressed("a") then
        if rowId == "SEARCH" then Plus.searchEdit = true; playSe(5)
        elseif rowId == "TYPE" then cycleType(1)
        elseif rowId == "STATUS" then cycleStatus(1)
        elseif rowId == "SORT" then cycleSort(1)
        elseif rowId == "RESET" then clearFilters(); playSe(5)
        elseif rowId == "APPLY" then Plus.screen = "list"; playSe(5) end
      elseif input:wasPressed("start") then
        Plus.screen = "list"; playSe(5)
      elseif input:wasPressed("b") then
        Plus.screen = "list"; Plus.searchEdit = false; playSe(9)
      end
      return
    end

    local d = Plus._detail
    local sp = d and d.species or Plus.selected
    if input:wasPressed("left") or input:wasPressed("l") then
      Plus.detailTab = ((Plus.detailTab - 2) % #TABS) + 1
      Plus.detailScroll = 0
      playSe(5)
    elseif input:wasPressed("right") or input:wasPressed("r") then
      Plus.detailTab = (Plus.detailTab % #TABS) + 1
      Plus.detailScroll = 0
      playSe(5)
    elseif input:wasPressed("up") then
      Plus.detailScroll = math.max(0, Plus.detailScroll - 1)
      playSe(5)
    elseif input:wasPressed("down") then
      local maxScroll = 0
      if d then
        if Plus.detailTab == 2 then maxScroll = 0
        elseif Plus.detailTab == 4 then maxScroll = math.max(0, #d.evos - 6)
        elseif Plus.detailTab == 5 then maxScroll = math.max(0, #d.moves - 7)
        elseif Plus.detailTab == 6 then maxScroll = math.max(0, #d.areas - 7) end
      end
      Plus.detailScroll = math.min(maxScroll, Plus.detailScroll + 1)
      playSe(5)
    elseif input:wasPressed("select") then
      playCry(sp)
    elseif input:wasPressed("start") and Plus.detailTab == 6 then
      openNativeArea(sp)
    elseif input:wasPressed("b") then
      Plus.screen = "list"
      Plus._detail = nil
      playSe(9)
    end
  end

  -- -------------------------------------------------------------------------
  -- Vanilla Emerald/RSE renderer
  --
  -- Pokédex Plus remains a custom stack, but the 240x160 fallback now uses an
  -- Emerald-style green/teal presentation and never touches FRLG PokédexChrome.

  local EM = {
    bg = { 12/255, 65/255, 57/255, 1 },
    panel = { 221/255, 239/255, 214/255, 1 },
    panel2 = { 191/255, 224/255, 195/255, 1 },
    header = { 36/255, 133/255, 105/255, 1 },
    header2 = { 24/255, 96/255, 83/255, 1 },
    select = { 247/255, 218/255, 95/255, 1 },
    text = { fg = { 20/255, 38/255, 31/255, 1 }, shadow = { 1, 1, 1, .55 } },
    white = { fg = { 1, 1, 1, 1 }, shadow = { 0, 0, 0, .45 } },
    muted = { fg = { 77/255, 99/255, 88/255, 1 }, shadow = { 1, 1, 1, .35 } },
    accent = { fg = { 154/255, 91/255, 19/255, 1 }, shadow = { 1, 1, 1, .35 } },
  }

  local function box(x, y, w, h, color, radius)
    love.graphics.setColor(color)
    if radius and love.graphics.rectangle then love.graphics.rectangle("fill", x, y, w, h, radius, radius)
    else love.graphics.rectangle("fill", x, y, w, h) end
  end

  local function outline(x, y, w, h)
    love.graphics.setColor(1, 1, 1, .35)
    love.graphics.rectangle("line", x, y, w, h)
  end

  local function header(title, right)
    box(0, 0, 240, 16, EM.header2)
    box(0, 16, 240, 2, EM.header)
    FrlgFont.draw(title, 7, 3, { small = true, colors = EM.white, maxWidth = 165 })
    if right then FrlgFont.draw(right, 174, 3, { small = true, colors = EM.white, maxWidth = 60 }) end
  end

  local function footer(left, right)
    box(0, 143, 240, 17, EM.header2)
    FrlgFont.draw(left or "", 5, 147, { small = true, colors = EM.white, maxWidth = 110 })
    FrlgFont.draw(right or "", 121, 147, { small = true, colors = EM.white, maxWidth = 114 })
  end

  local function arrow(x, y, down)
    love.graphics.setColor(1, 1, 1, .9)
    if down then love.graphics.polygon("fill", x, y, x + 8, y, x + 4, y + 5)
    else love.graphics.polygon("fill", x + 4, y, x, y + 5, x + 8, y + 5) end
  end

  local function typeBadge(tid, x, y)
    local name = Types.name(tid) or "?"
    box(x, y, 33, 10, { 44/255, 119/255, 102/255, 1 }, 3)
    FrlgFont.draw(name, x + 2, y + 1, { small = true, colors = EM.white, maxWidth = 29 })
  end

  local function drawTypeBadges(sp, x, y)
    local ts = Pokemon.types and Pokemon.types(sp) or {}
    if ts[1] then typeBadge(ts[1], x, y) end
    if ts[2] and ts[2] ~= ts[1] then typeBadge(ts[2], x + 35, y) end
  end

  local function drawList()
    box(0, 0, 240, 160, EM.bg)
    local list = rows()
    header(nationalMode() and "NATIONAL DEX +" or "HOENN DEX +", string.format("%d/%d", #list, visibleMax()))
    box(7, 21, 226, 117, EM.panel, 4); outline(7, 21, 226, 117)
    for i = 1, LIST_VISIBLE do
      local idx = Plus.scroll + i
      local row = list[idx]
      if not row then break end
      local y = 24 + (i - 1) * 13
      if idx == Plus.cursor then box(10, y - 1, 220, 12, EM.select, 3) end
      FrlgFont.draw(string.format("№%03d", row.nat), 14, y, { small = true, colors = EM.text, maxWidth = 36 })
      if row.caught then FrlgFont.draw("●", 51, y, { small = true, colors = EM.accent, maxWidth = 9 }) end
      local showData = row.seen or revealUnseen()
      FrlgFont.draw(showData and row.name or "----------", 63, y, { small = true, colors = EM.text, maxWidth = 82 })
      if showData and row.caught then drawTypeBadges(row.species, 151, y) end
    end
    if Plus.scroll > 0 then arrow(224, 23, false) end
    if Plus.scroll + LIST_VISIBLE < #list then arrow(224, 131, true) end
    footer("START/SELECT FILTER", "A DATA   B BACK")
  end

  local function ensureFront(d)
    if d.front ~= false then return d.front end
    local pic
    if Pokemon.dexFrontPic then
      local personality = Dex.defaultPersonality and Dex.defaultPersonality(Plus._dex, d.species) or nil
      pic = Pokemon.dexFrontPic(d.species, personality)
    elseif Pokemon.frontPic then pic = Pokemon.frontPic(d.species) end
    d.front = pic or nil
    return d.front
  end

  local function detailBase(d, section)
    box(0, 0, 240, 160, EM.bg)
    header(d.name, string.format("%d/%d", Plus.detailTab, #TABS))
    box(7, 22, 226, 116, EM.panel, 4); outline(7, 22, 226, 116)
    box(10, 25, 220, 14, EM.panel2, 3)
    FrlgFont.draw(section, 14, 28, { small = true, colors = EM.text, maxWidth = 105 })
    FrlgFont.draw(string.format("№%03d", d.nat), 122, 28, { small = true, colors = EM.accent, maxWidth = 38 })
    drawTypeBadges(d.species, 161, 27)
  end

  local function drawOverview(d)
    detailBase(d, "OVERVIEW")
    local pic = ensureFront(d)
    if pic and pic.image then love.graphics.setColor(1,1,1,1); love.graphics.draw(pic.image, 161, 43) end
    local e = d.pokedexEntry or {}
    FrlgFont.draw(tostring(e.categoryName or e.category or "UNKNOWN POKéMON"), 15, 48, { small = true, colors = EM.text, maxWidth = 135 })
    FrlgFont.draw("HT  "..tostring(e.heightFormatted or "?"), 15, 63, { small = true, colors = EM.text, maxWidth = 130 })
    FrlgFont.draw("WT  "..tostring(e.weightFormatted or "?"), 15, 77, { small = true, colors = EM.text, maxWidth = 130 })
    local status = caught(d.species) and "CAUGHT" or (seen(d.species) and "SEEN" or "UNSEEN")
    FrlgFont.draw("STATUS  "..status, 15, 98, { small = true, colors = EM.accent, maxWidth = 105 })
    FrlgFont.draw("FRIEND  "..tostring(d.meta.friendship or "?"), 15, 112, { small = true, colors = EM.text })
    FrlgFont.draw("CATCH  "..tostring(d.meta.catchRate or "?"), 119, 98, { small = true, colors = EM.text })
    FrlgFont.draw("GROWTH  "..tostring(d.meta.growthRate or "?"), 119, 112, { small = true, colors = EM.text, maxWidth = 105 })
  end

  local function drawPokedexEntry(d)
    detailBase(d, "DEX ENTRY")
    local e = d.pokedexEntry or {}
    local desc = entryDescription(d)
    FrlgFont.draw("EMERALD", 14, 47, { small = true, colors = EM.accent })
    FrlgFont.draw(tostring(e.categoryName or e.category or "UNKNOWN POKéMON"), 72, 47, { small = true, colors = EM.text, maxWidth = 148 })
    FrlgFont.draw("HT  "..tostring(e.heightFormatted or "?"), 14, 62, { small = true, colors = EM.text })
    FrlgFont.draw("WT  "..tostring(e.weightFormatted or "?"), 119, 62, { small = true, colors = EM.text })
    if desc == "" then desc = "NO POKéDEX ENTRY AVAILABLE." end
    local wrapped = FrlgFont.wrap(desc, 204, { small = true })
    FrlgFont.draw(wrapped, 14, 82, { small = true, colors = EM.text, maxWidth = 204, linePitch = 11 })
  end

  local function statBar(x, y, label, value)
    value = tonumber(value) or 0
    FrlgFont.draw(label, x, y, { small = true, colors = EM.text, maxWidth = 52 })
    FrlgFont.draw(string.format("%3d", value), x + 52, y, { small = true, colors = EM.text, maxWidth = 23 })
    box(x + 78, y + 3, 78, 5, { 142/255, 177/255, 151/255, 1 }, 2)
    box(x + 78, y + 3, math.max(1, math.floor(78 * math.min(255, value) / 255)), 5, EM.header, 2)
  end

  local function drawStats(d)
    detailBase(d, "BASE STATS")
    local s = d.stats
    statBar(17, 48, "HP", s.hp); statBar(17, 62, "ATTACK", s.atk); statBar(17, 76, "DEFENSE", s.def)
    statBar(17, 91, "SP.ATK", s.spa); statBar(17, 105, "SP.DEF", s.spd); statBar(17, 119, "SPEED", s.spe)
    FrlgFont.draw("TOTAL "..tostring(s.total), 176, 119, { small = true, colors = EM.accent, maxWidth = 50 })
  end

  local function drawTextList(d, title, data, fmt, visible)
    detailBase(d, title)
    if #data == 0 then FrlgFont.draw("NO DATA", 82, 79, { colors = EM.muted }); return end
    visible = visible or 6
    local first = Plus.detailScroll + 1
    for i = 0, visible - 1 do
      local v = data[first + i]; if not v then break end
      local y = 48 + i * 13
      if i % 2 == 1 then box(13, y - 1, 211, 12, { 205/255, 231/255, 205/255, 1 }, 2) end
      FrlgFont.draw(fmt(v), 17, y, { small = true, colors = EM.text, maxWidth = 201 })
    end
    if Plus.detailScroll > 0 then arrow(220, 45, false) end
    if Plus.detailScroll + visible < #data then arrow(220, 126, true) end
  end

  local function drawEvolution(d) drawTextList(d, "EVOLUTION", d.evos, function(v) return tostring(v) end, 6) end
  local function drawMoves(d) drawTextList(d, "LEVEL MOVES", d.moves, function(v) return string.format("Lv%-3d  %s", v.level, v.name or "?") end, 7) end
  local function drawHabitat(d)
    drawTextList(d, "HABITAT / AREA", d.areas, function(v) return tostring(v.label) end, 6)
    FrlgFont.draw("START: NATIVE EMERALD AREA", 58, 128, { small = true, colors = EM.accent, maxWidth = 164 })
  end

  local function drawFilters()
    box(0,0,240,160,EM.bg); header("SEARCH & FILTER LAB", string.format("%d", #rows()))
    box(7,22,226,116,EM.panel,4); outline(7,22,226,116)
    if Plus.searchEdit then
      FrlgFont.draw("NAME  "..(Plus.query ~= "" and Plus.query or "_"), 14, 27, { small=true, colors=EM.text, maxWidth=205 })
      local cols=KB_COLS
      for i,key in ipairs(KB_KEYS) do
        local c=(i-1)%cols; local r=math.floor((i-1)/cols)
        local x=14+c*31; local y=45+r*20
        if i==Plus.kbCursor then box(x-2,y-2,29,15,EM.select,3) end
        FrlgFont.draw(key, x, y, { small=true, colors=EM.text, maxWidth=26 })
      end
      footer("A TYPE  B DELETE", "SELECT CLEAR START DONE")
      return
    end
    local values={ SEARCH=Plus.query~="" and Plus.query or "(NONE)", TYPE=Plus.typeFilter==-1 and "ANY" or (Types.name(Plus.typeFilter) or "ANY"), STATUS=Plus.statusFilter, SORT=Plus.sortMode, RESET="CLEAR ALL", APPLY="RETURN" }
    for i,id in ipairs(FILTER_ROWS) do
      local y=28+(i-1)*17
      if i==Plus.filterCursor then box(12,y-2,216,15,EM.select,3) end
      FrlgFont.draw(id,16,y,{small=true,colors=EM.text,maxWidth=65})
      FrlgFont.draw(tostring(values[id] or ""),88,y,{small=true,colors=EM.text,maxWidth=132})
    end
    footer("↑↓ PICK  ←→ CHANGE", "A OK   B BACK")
  end

  local function drawDetail()
    local d=Plus._detail
    if not d then return drawList() end
    if Plus.detailTab==1 then drawOverview(d)
    elseif Plus.detailTab==2 then drawPokedexEntry(d)
    elseif Plus.detailTab==3 then drawStats(d)
    elseif Plus.detailTab==4 then drawEvolution(d)
    elseif Plus.detailTab==5 then drawMoves(d)
    else drawHabitat(d) end
    footer("←→ PAGE  ↑↓ SCROLL", "SELECT CRY   B BACK")
  end

  -- -------------------------------------------------------------------------
  -- Modern UI bridge
  --
  -- gen3_modern_ui intentionally only presents known native stack ids.  This
  -- mod owns a custom stack id, so it paints a matching window-space overlay
  -- when Modern UI is enabled while keeping the native 240x160 renderer as a
  -- fallback.  Input/state always remain owned by Plus.

  local MODERN_UI_IDS = { "gen3_modern_ui_emerald", "gen3_modern_ui" }
  local modernFonts = {}
  local MODERN = {
    bg = { 0.075, 0.285, 0.565, 0.995 },
    surface = { 0.975, 0.990, 1.000, 1 },
    raised = { 1.000, 0.965, 0.745, 1 },
    selected = { 1.000, 0.820, 0.250, 1 },
    accent = { 0.900, 0.175, 0.175, 1 },
    secondary = { 1.000, 0.790, 0.030, 1 },
    text = { 0.055, 0.180, 0.315, 1 },
    muted = { 0.285, 0.405, 0.510, 1 },
    divider = { 0.510, 0.720, 0.900, 1 },
    header = { 0.090, 0.330, 0.650, 1 },
    headerText = { 1.000, 1.000, 1.000, 1 },
    footer = { 0.045, 0.145, 0.270, 1 },
    footerText = { 0.960, 0.985, 1.000, 1 },
    good = { 0.180, 0.690, 0.305, 1 },
  }

  local TYPE_COLOR = {
    NORMAL={.66,.66,.47,1}, FIRE={.94,.50,.19,1}, WATER={.41,.56,.94,1},
    GRASS={.47,.78,.31,1}, ELECTRIC={.97,.82,.19,1}, ICE={.60,.85,.85,1},
    FIGHTING={.75,.19,.16,1}, POISON={.63,.25,.63,1}, GROUND={.88,.75,.41,1},
    FLYING={.66,.56,.94,1}, PSYCHIC={.97,.35,.53,1}, BUG={.66,.72,.13,1},
    ROCK={.72,.63,.22,1}, GHOST={.44,.35,.60,1}, DRAGON={.44,.22,.97,1},
    STEEL={.72,.72,.82,1}, DARK={.44,.35,.28,1}, UNKNOWN={.45,.50,.56,1},
  }

  local function modernUiPresent()
    if not mod.find then return false end
    for _, id in ipairs(MODERN_UI_IDS) do
      local ok, other = pcall(mod.find, id)
      if ok and other ~= nil then return true end
    end
    return false
  end

  local function mf(size)
    size = math.max(12, math.floor((tonumber(size) or 12) + 0.5))
    local key = tostring(size)
    if modernFonts[key] then return modernFonts[key] end
    local ok, f = pcall(love.graphics.newFont, size)
    if not ok or not f then f = love.graphics.getFont() end
    if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    modernFonts[key] = f
    return f
  end

  local function mc(c, alpha)
    alpha = alpha or 1
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * alpha)
  end

  local function rr(mode, x, y, w, h, r)
    love.graphics.rectangle(mode, x, y, w, h, r or 6, r or 6)
  end

  local function mt(value, x, y, size, c, align, width)
    love.graphics.setFont(mf(size))
    mc(c or MODERN.text)
    value = tostring(value or "")
    if width then
      love.graphics.printf(value, x, y, width, align or "left")
    else
      love.graphics.print(value, x, y)
    end
  end

  local function mfit(value, width, preferred, minSize)
    value = tostring(value or "")
    preferred = math.max(8, math.floor((tonumber(preferred) or 12) + 0.5))
    minSize = math.max(8, math.floor((tonumber(minSize) or 9) + 0.5))
    local size = preferred
    while size > minSize do
      local f = mf(size)
      if f:getWidth(value) <= width then return size end
      size = size - 1
    end
    return minSize
  end

  local function msplitLabel(label, width, preferred, minSize)
    label = tostring(label or "")
    if mf(preferred):getWidth(label) <= width then return { label }, preferred end
    local words = {}
    for word in label:gmatch("%S+") do words[#words + 1] = word end
    if #words >= 2 then
      local left = table.concat(words, " ", 1, #words - 1)
      local right = words[#words]
      local size = preferred
      while size >= minSize do
        local f = mf(size)
        if f:getWidth(left) <= width and f:getWidth(right) <= width then
          return { left, right }, size
        end
        size = size - 1
      end
      return { left, right }, minSize
    end
    return { label }, mfit(label, width, preferred, minSize)
  end

  local function mlayout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
    local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
    local base = math.max(0.64, math.min(w / 720, h / 480))
    local pad = math.max(9, 13 * base)
    local headerH = math.max(42, 49 * base)
    local footerH = math.max(27, 30 * base)
    return {
      x=x, y=y, w=w, h=h, s=base, pad=pad, gap=math.max(6, 9*base),
      title=math.max(20,24*base), body=math.max(15,17*base),
      small=math.max(13,14*base), tiny=math.max(12,12*base),
      row=math.max(30,35*base), headerH=headerH, footerH=footerH,
      contentY=y+headerH, contentH=h-headerH-footerH,
    }
  end

  local function mbackdrop(L, subtitle)
    love.graphics.setScissor(L.x, L.y, L.w, L.h)
    mc(MODERN.bg); love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    mc(MODERN.header); love.graphics.rectangle("fill", L.x, L.y, L.w, L.headerH)
    mc(MODERN.accent); love.graphics.rectangle("fill", L.x, L.y, L.w, math.max(3,4*L.s))
    mc(MODERN.secondary); love.graphics.rectangle("fill", L.x, L.contentY-math.max(2,3*L.s), L.w, math.max(2,3*L.s))
    mt("POKéDEX+", L.x+L.pad, L.y+math.max(7,L.pad*.55), L.title, MODERN.headerText)
    if subtitle and subtitle ~= "" then
      mt(subtitle, L.x+L.w*.52, L.y+math.max(10,L.pad*.75), L.small, MODERN.secondary, "right", L.w*.48-L.pad)
    end
  end

  local function mpanel(x,y,w,h,selected)
    mc(selected and MODERN.raised or MODERN.surface)
    rr("fill",x,y,w,h,8)
    mc(selected and MODERN.accent or MODERN.divider, selected and .70 or .46)
    love.graphics.setLineWidth(1); rr("line",x,y,w,h,8)
  end

  local function mselected(x,y,w,h)
    mc(MODERN.selected,.97); rr("fill",x,y,w,h,7)
    mc(MODERN.accent); love.graphics.rectangle("fill",x,y,math.max(3,w*.008),h)
  end

  local function mhint(L, value)
    local fy=L.y+L.h-L.footerH
    mc(MODERN.footer); love.graphics.rectangle("fill",L.x,fy,L.w,L.footerH)
    mc(MODERN.secondary,.95); love.graphics.rectangle("fill",L.x,fy,L.w,math.max(2,3*L.s))
    mt(value,L.x+L.pad,fy+math.max(6,L.footerH*.28),L.tiny,MODERN.footerText,"left",L.w-L.pad*2)
  end

  local function mcount(side)
    local n=0
    for _,v in pairs(side or {}) do if v then n=n+1 end end
    return n
  end

  local function micon(sp,x,y,size)
    local ok, icon = pcall(Pokemon.icon, sp)
    if not ok or not (icon and icon.image) then return false end
    local q = icon.quads and (icon.quads[0] or icon.quads[1])
    if not q then return false end
    local iw, ih = tonumber(icon.w) or 32, tonumber(icon.h) or 32
    mc({1,1,1,1})
    love.graphics.draw(icon.image,q,x,y,0,size/iw,size/ih)
    return true
  end

  local function mpill(label,x,y,w,h,c)
    c=c or MODERN.accent
    mc(c,.94); rr("fill",x,y,w,h,h/2)
    local lum=(c[1]+c[2]+c[3])/3
    mt(label,x,y+math.max(1,h*.12),math.max(11,h*.52),lum>.68 and MODERN.text or {1,1,1,1},"center",w)
  end

  local function mtypePills(sp,x,y,L,maxW)
    local names=typeNames(sp)
    local gap=math.max(4,5*L.s)
    local w=math.min(82*L.s, math.max(54, (maxW-gap)/2))
    for i=1,math.min(2,#names) do
      local name=names[i]
      mpill(name,x+(i-1)*(w+gap),y,w,math.max(20,23*L.s),TYPE_COLOR[name] or TYPE_COLOR.UNKNOWN)
    end
  end

  local function modernList(L)
    mbackdrop(L,"EMERALD RESEARCH")
    local cy=L.contentY+L.pad
    local ch=L.y+L.h-L.footerH-L.pad-cy
    local sideW=math.min(L.w*.24,230*L.s)
    local sx=L.x+L.pad
    mpanel(sx,cy,sideW,ch,false)
    local dex=Plus._dex or {}
    mt("SEEN",sx+L.pad,cy+L.pad,L.small,MODERN.muted)
    mt(tostring(mcount(dex.seen)),sx+L.pad,cy+L.pad+L.small*1.35,L.title,MODERN.accent)
    mt("CAUGHT",sx+L.pad,cy+L.pad+L.small*1.35+L.title*1.25,L.small,MODERN.muted)
    mt(tostring(mcount(dex.caught or dex.owned)),sx+L.pad,cy+L.pad+L.small*2.7+L.title*1.25,L.title,MODERN.accent)
    local filterLines = {
      Plus.query~="" and ("NAME: "..Plus.query) or "NAME: ANY",
      Plus.typeFilter~=-1 and ("TYPE: "..Types.name(Plus.typeFilter)) or "TYPE: ANY",
      "STATUS: "..Plus.statusFilter,
      "SORT: "..Plus.sortMode,
      tostring(#rows()).." MATCHES",
    }
    local headingH = L.small * 1.1
    local lineH = L.tiny * 1.28
    local totalH = headingH + L.gap * 0.7 + (#filterLines * lineH)
    local fy = math.max(cy + L.pad + L.small * 4.0, cy + ch - L.pad - totalH)
    mt("ACTIVE FILTERS", sx + L.pad, fy, L.small, MODERN.muted)
    local filterY = fy + headingH + L.gap * 0.35
    local filterW = sideW - L.pad * 2
    for i, line in ipairs(filterLines) do
      local color = (i == #filterLines) and MODERN.accent or MODERN.text
      mt(line, sx + L.pad, filterY + (i - 1) * lineH, L.tiny, color, "left", filterW)
    end

    local rx=sx+sideW+L.gap
    local rw=L.x+L.w-L.pad-rx
    mpanel(rx,cy,rw,ch,false)
    local list=rows()
    local rowH=math.max(30,L.row*.82)
    local maxRows=math.max(1,math.floor((ch-L.gap*2)/rowH))
    maxRows=math.min(9,maxRows)
    local first=math.max(1,Plus.scroll+1)
    for vis=0,maxRows-1 do
      local idx=first+vis
      local row=list[idx]
      if not row then break end
      local yy=cy+L.gap+vis*rowH
      if idx==Plus.cursor then mselected(rx+L.gap,yy,rw-L.gap*2,rowH-3) end
      if vis>0 then mc(MODERN.divider,.45); love.graphics.line(rx+L.gap*1.5,yy,rx+rw-L.gap*1.5,yy) end
      local showData=row.seen or revealUnseen()
      local ix=rx+L.gap*1.7
      if showData then micon(row.species,ix,yy+3,rowH-7) end
      mt(showData and row.name or "-----",ix+rowH,yy+math.max(4,rowH*.15),L.body,MODERN.text,"left",rw*.46)
      mt(string.format("№%03d%s",row.nat,row.caught and "  ●" or ""),rx+rw-L.gap-rw*.22,yy+math.max(5,rowH*.18),L.small,row.caught and MODERN.accent or MODERN.muted,"right",rw*.20)
    end
    mhint(L,"↑↓ NAVIGATE   ←→ PAGE   A DETAILS   START / SELECT FILTER LAB   B BACK")
  end

  local function modernFilters(L)
    mbackdrop(L,"SEARCH & FILTER LAB")
    local cy=L.contentY+L.pad
    local ch=L.y+L.h-L.footerH-L.pad-cy
    local leftW=math.min(L.w*.40,390*L.s)
    local lx=L.x+L.pad
    local rx=lx+leftW+L.gap
    local rw=L.x+L.w-L.pad-rx
    mpanel(lx,cy,leftW,ch,false)
    mpanel(rx,cy,rw,ch,false)

    if Plus.searchEdit then
      mt("POKéMON NAME",lx+L.pad,cy+L.pad,L.small,MODERN.muted)
      local boxY=cy+L.pad+L.small*1.55
      mc(MODERN.raised); rr("fill",lx+L.pad,boxY,leftW-L.pad*2,math.max(34,40*L.s),7)
      mt(Plus.query~="" and Plus.query or "TYPE TO SEARCH…",lx+L.pad*1.5,boxY+8*L.s,L.body,Plus.query~="" and MODERN.text or MODERN.muted,"left",leftW-L.pad*3)
      local gridY=boxY+math.max(34,40*L.s)+L.gap*1.5
      local cols=KB_COLS
      local cellGap=math.max(4,5*L.s)
      local cellW=(leftW-L.pad*2-cellGap*(cols-1))/cols
      local cellH=math.max(30,33*L.s)
      for i,key in ipairs(KB_KEYS) do
        local rrn=math.floor((i-1)/cols); local cc=(i-1)%cols
        local x=lx+L.pad+cc*(cellW+cellGap); local y=gridY+rrn*(cellH+cellGap)
        if i==Plus.kbCursor then mselected(x,y,cellW,cellH) else mc(MODERN.raised,.55); rr("fill",x,y,cellW,cellH,6) end
        local label=key=="BACK" and "⌫" or (key=="CLEAR" and "CLR" or (key=="DONE" and "DONE" or key))
        mt(label,x,y+math.max(5,cellH*.18),L.small,i==Plus.kbCursor and MODERN.text or MODERN.muted,"center",cellW)
      end
      mt("Keyboard: type letters directly • Controller: choose keys",lx+L.pad,cy+ch-L.pad-L.tiny*1.3,L.tiny,MODERN.muted,"left",leftW-L.pad*2)
    else
      mt("FILTER STACK",lx+L.pad,cy+L.pad,L.small,MODERN.muted)
      local rowY=cy+L.pad+L.small*1.65
      local rowH=math.max(42,L.row*1.08)
      for i,rowId in ipairs(FILTER_ROWS) do
        local y=rowY+(i-1)*rowH
        if y+rowH>cy+ch-L.pad then break end
        if i==Plus.filterCursor then mselected(lx+L.pad,y,leftW-L.pad*2,rowH-5) else mc(MODERN.raised,.45); rr("fill",lx+L.pad,y,leftW-L.pad*2,rowH-5,7) end
        mt(rowId,lx+L.pad*1.6,y+6*L.s,L.small,i==Plus.filterCursor and MODERN.text or MODERN.muted)
        mt(filterValue(rowId),lx+leftW*.40,y+5*L.s,L.body,i==Plus.filterCursor and MODERN.accent or MODERN.text,"right",leftW*.52-L.pad)
      end
    end

    local selectedRow = FILTER_ROWS[Plus.filterCursor]
    mt("LIVE RESULTS",rx+L.pad,cy+L.pad,L.small,MODERN.muted)
    mt(tostring(#rows()),rx+rw-L.pad-rw*.25,cy+L.pad*.75,L.title,MODERN.accent,"right",rw*.25)

    local previewTop=cy+L.pad+L.title*1.5
    if not Plus.searchEdit and (selectedRow=="TYPE" or selectedRow=="STATUS" or selectedRow=="SORT") then
      mt(selectedRow.." OPTIONS",rx+L.pad,previewTop,L.tiny,MODERN.muted)
      local oy=previewTop+L.tiny*1.5
      if selectedRow=="TYPE" then
        local cols=6; local gap=math.max(4,5*L.s)
        local cw=(rw-L.pad*2-gap*(cols-1))/cols
        local chp=math.max(24,27*L.s)
        for i,tid in ipairs(TYPE_IDS) do
          local rrn=math.floor((i-1)/cols); local cc=(i-1)%cols
          local x=rx+L.pad+cc*(cw+gap); local y=oy+rrn*(chp+gap)
          local label=tid==-1 and "ANY" or Types.name(tid)
          local active=tid==Plus.typeFilter
          local c=tid==-1 and MODERN.muted or (TYPE_COLOR[label] or MODERN.muted)
          if active then mc(MODERN.selected); rr("fill",x,y,cw,chp,7); mc(MODERN.accent); rr("line",x,y,cw,chp,7)
          else mc(c,.72); rr("fill",x,y,cw,chp,7) end
          mt(label,x,y+math.max(4,chp*.16),L.tiny,active and MODERN.text or {1,1,1,1},"center",cw)
        end
        previewTop=oy+math.ceil(#TYPE_IDS/cols)*(chp+gap)+L.gap
      elseif selectedRow=="STATUS" then
        local gap=math.max(6,7*L.s); local cw=(rw-L.pad*2-gap*3)/4; local chp=math.max(30,34*L.s)
        for i,label in ipairs(STATUS_FILTERS) do
          local x=rx+L.pad+(i-1)*(cw+gap); local active=label==Plus.statusFilter
          if active then mselected(x,oy,cw,chp) else mc(MODERN.raised,.55); rr("fill",x,oy,cw,chp,7) end
          mt(label,x,oy+math.max(6,chp*.18),L.tiny,active and MODERN.text or MODERN.muted,"center",cw)
        end
        previewTop=oy+chp+L.gap*1.5
      else
        local gap=math.max(6,7*L.s); local cw=(rw-L.pad*2-gap*2)/3; local chp=math.max(34,38*L.s)
        for i,label in ipairs(SORT_MODES) do
          local x=rx+L.pad+(i-1)*(cw+gap); local active=label==Plus.sortMode
          if active then mselected(x,oy,cw,chp) else mc(MODERN.raised,.55); rr("fill",x,oy,cw,chp,7) end
          mt(label,x,oy+math.max(7,chp*.19),L.small,active and MODERN.text or MODERN.muted,"center",cw)
        end
        previewTop=oy+chp+L.gap*1.5
      end
      mt("← / → changes the highlighted option",rx+L.pad,previewTop-L.tiny*.2,L.tiny,MODERN.muted,"left",rw-L.pad*2)
      previewTop=previewTop+L.tiny*1.4
    elseif not Plus.searchEdit and selectedRow=="SEARCH" then
      mc(MODERN.raised,.55); rr("fill",rx+L.pad,previewTop,rw-L.pad*2,math.max(38,42*L.s),7)
      mt(Plus.query~="" and Plus.query or "ANY NAME",rx+L.pad*1.5,previewTop+9*L.s,L.body,Plus.query~="" and MODERN.text or MODERN.muted,"left",rw-L.pad*3)
      previewTop=previewTop+math.max(38,42*L.s)+L.gap
    end

    local list=rows()
    local available=cy+ch-L.pad-L.small*2.6-previewTop
    local rowH=math.max(32,L.row*.84)
    local previewN=math.min(7,#list,math.max(1,math.floor(available/rowH)))
    if #list==0 then
      mt("NO MATCHES",rx+L.pad,previewTop+L.gap,L.body,MODERN.accent)
      mt("Try clearing a filter or shortening the name.",rx+L.pad,previewTop+L.gap+L.body*1.5,L.small,MODERN.muted,"left",rw-L.pad*2)
    else
      for i=1,previewN do
        local row=list[i]; local y=previewTop+(i-1)*rowH
        mc(i==1 and MODERN.raised or MODERN.surface,.72); rr("fill",rx+L.pad,y,rw-L.pad*2,rowH-4,7)
        micon(row.species,rx+L.pad*1.4,y+3,rowH-9)
        mt(row.name,rx+L.pad*1.4+rowH,y+6*L.s,L.small,MODERN.text,"left",rw*.50)
        local status=row.caught and "CAUGHT" or (row.seen and "SEEN" or "UNSEEN")
        mt(status,rx+rw-L.pad-rw*.30,y+6*L.s,L.tiny,row.caught and MODERN.good or MODERN.muted,"right",rw*.28)
      end
    end
    if not Plus.searchEdit then
      mt("Filters combine instantly • RESET restores the full Dex",rx+L.pad,cy+ch-L.pad-L.small*1.15,L.tiny,MODERN.muted,"left",rw-L.pad*2)
    end
    mhint(L,Plus.searchEdit and "TYPE / A ENTER   B DELETE   SELECT CLEAR   START DONE" or "↑↓ ROW   ←→ CHANGE   A EDIT / APPLY   START APPLY   B BACK")
  end

  local function detailTabs(L,x,y,w)
    local gap = math.max(4, 5 * L.s)
    local tw = (w - gap * (#TABS - 1)) / #TABS
    local tabH = math.max(30, 36 * L.s)
    local textW = tw - math.max(8, 10 * L.s)
    for i, label in ipairs(TABS) do
      local tx = x + (i - 1) * (tw + gap)
      local active = i == Plus.detailTab
      if active then
        mc(MODERN.selected); rr("fill", tx, y, tw, tabH, 6)
      else
        mc(MODERN.raised, .55); rr("fill", tx, y, tw, tabH, 6)
      end
      local lines, size = msplitLabel(label, textW, L.tiny, math.max(9, L.tiny - 2))
      local color = active and MODERN.text or MODERN.muted
      if #lines == 1 then
        mt(lines[1], tx, y + math.max(6, tabH * 0.20), size, color, "center", tw)
      else
        local lineGap = math.max(1, 1.5 * L.s)
        local totalTextH = size * 2 + lineGap
        local ty = y + math.max(3, (tabH - totalTextH) / 2 - 1)
        mt(lines[1], tx, ty, size, color, "center", tw)
        mt(lines[2], tx, ty + size + lineGap, size, color, "center", tw)
      end
    end
    return tabH
  end

  local function statBar(L,x,y,w,label,value,maxValue)
    value=tonumber(value) or 0; maxValue=math.max(1,tonumber(maxValue) or 255)
    mt(label,x,y,L.small,MODERN.muted)
    mt(tostring(value),x+w-54*L.s,y,L.small,MODERN.text,"right",50*L.s)
    local by=y+L.small*1.35
    local bh=math.max(6,7*L.s)
    mc(MODERN.divider,.35); rr("fill",x,by,w,bh,bh/2)
    mc(value>=100 and MODERN.good or MODERN.accent); rr("fill",x,by,w*math.min(1,value/maxValue),bh,bh/2)
  end

  local function modernDetail(L)
    local d=Plus._detail
    if not d then return modernList(L) end
    mbackdrop(L,(TABS[Plus.detailTab] or "DATA").."  "..Plus.detailTab.."/"..#TABS)
    local cy=L.contentY+L.pad
    local ch=L.y+L.h-L.footerH-L.pad-cy
    local sideW=math.min(L.w*.29,285*L.s)
    local sx=L.x+L.pad
    mpanel(sx,cy,sideW,ch,false)
    local iconSize=math.min(sideW*.48,ch*.28,110*L.s)
    local ix=sx+(sideW-iconSize)/2
    micon(d.species,ix,cy+L.pad,iconSize)
    local ny=cy+L.pad+iconSize+L.gap
    mt(d.name,sx+L.pad,ny,L.title*.78,MODERN.text,"center",sideW-L.pad*2)
    mt(string.format("№%03d",d.nat),sx+L.pad,ny+L.title*.82,L.small,MODERN.accent,"center",sideW-L.pad*2)
    local py=ny+L.title*.82+L.small*1.45
    mtypePills(d.species,sx+L.pad,py,L,sideW-L.pad*2)
    local status=caught(d.species) and "CAUGHT" or (seen(d.species) and "SEEN" or "UNSEEN")
    mpill(status,sx+L.pad,cy+ch-L.pad-math.max(24,27*L.s),sideW-L.pad*2,math.max(24,27*L.s),caught(d.species) and MODERN.good or MODERN.muted)

    local rx=sx+sideW+L.gap
    local rw=L.x+L.w-L.pad-rx
    mpanel(rx,cy,rw,ch,false)
    local tabH=detailTabs(L,rx+L.gap,cy+L.gap,rw-L.gap*2)
    local bx=rx+L.gap*1.6
    local by=cy+L.gap+tabH+L.gap*1.4
    local bw=rw-L.gap*3.2
    local bottom=cy+ch-L.gap

    if Plus.detailTab==1 then
      local values={
        {"BASE FRIENDSHIP",d.meta.friendship or "—"},
        {"CATCH RATE",d.meta.catchRate or "—"},
        {"GROWTH RATE",d.meta.growthRate or "—"},
        {"HEIGHT",(d.pokedexEntry and d.pokedexEntry.heightFormatted) or (d.dexEntry and d.dexEntry.height) or "—"},
        {"WEIGHT",(d.pokedexEntry and d.pokedexEntry.weightFormatted) or (d.dexEntry and d.dexEntry.weight) or "—"},
      }
      local rowH=math.max(34,L.row*.92)
      for i,v in ipairs(values) do
        local yy=by+(i-1)*rowH
        if yy+rowH>bottom then break end
        if i>1 then mc(MODERN.divider,.45); love.graphics.line(bx,yy,bx+bw,yy) end
        mt(v[1],bx,yy+6*L.s,L.small,MODERN.muted)
        mt(tostring(v[2]),bx+bw*.58,yy+5*L.s,L.body,MODERN.text,"right",bw*.42)
      end
    elseif Plus.detailTab==2 then
      local e=d.pokedexEntry or {}
      local desc,version=entryDescription(d)
      mt("POKéDEX ENTRY",bx,by,L.body,MODERN.accent)
      mt(version,bx+bw*.68,by,L.small,MODERN.muted,"right",bw*.32)
      local metaY=by+L.body*1.6
      mc(MODERN.raised,.55); rr("fill",bx,metaY,bw,math.max(46,50*L.s),7)
      mt(tostring(e.categoryName or e.category or "UNKNOWN POKéMON"),bx+L.gap,metaY+6*L.s,L.small,MODERN.text,"left",bw-L.gap*2)
      mt("HT  "..tostring(e.heightFormatted or "?"),bx+L.gap,metaY+26*L.s,L.tiny,MODERN.muted)
      mt("WT  "..tostring(e.weightFormatted or "?"),bx+bw*.48,metaY+26*L.s,L.tiny,MODERN.muted,"left",bw*.48-L.gap)
      local textY=metaY+math.max(46,50*L.s)+L.gap*1.5
      if desc=="" then desc="NO POKéDEX ENTRY AVAILABLE." end
      mt(desc,bx,textY,L.small,MODERN.text,"left",bw)
      if entryPageCount(d)>1 then
        mt("EMERALD POKéDEX ENTRY",bx,bottom-L.small*1.1,L.tiny,MODERN.muted,"right",bw)
      end
    elseif Plus.detailTab==3 then
      local s=d.stats
      local vals={{"HP",s.hp},{"ATTACK",s.atk},{"DEFENSE",s.def},{"SP. ATK",s.spa},{"SP. DEF",s.spd},{"SPEED",s.spe}}
      local colGap=L.gap*2
      local cw=(bw-colGap)/2
      for i,v in ipairs(vals) do
        local col=(i-1)%2; local row=math.floor((i-1)/2)
        statBar(L,bx+col*(cw+colGap),by+row*math.max(54,58*L.s),cw,v[1],v[2],200)
      end
      mt("BASE STAT TOTAL",bx,math.min(bottom-L.body,by+math.max(54,58*L.s)*3),L.body,MODERN.accent)
      mt(tostring(s.total),bx+bw*.72,math.min(bottom-L.body,by+math.max(54,58*L.s)*3),L.body,MODERN.accent,"right",bw*.28)
    else
      local data,title,fmt,maxVisible
      if Plus.detailTab==4 then data=d.evos; title="EVOLUTION PATH"; fmt=function(v) return tostring(v) end
      elseif Plus.detailTab==5 then data=d.moves; title="LEVEL-UP MOVES"; fmt=function(v) return string.format("Lv%-3d  %s",v.level,v.name) end
      else data=d.areas; title="HABITAT / AREA"; fmt=function(v) return tostring(v.label) end end
      mt(title,bx,by,L.body,MODERN.accent)
      local yy=by+L.body*1.6
      local rowH=math.max(31,L.row*.82)
      maxVisible=math.max(1,math.floor((bottom-yy)/rowH))
      if #data==0 then
        mt("NO DATA",bx,yy+L.gap,L.body,MODERN.muted)
      else
        local first=Plus.detailScroll+1
        for i=0,maxVisible-1 do
          local v=data[first+i]; if not v then break end
          local ry=yy+i*rowH
          mc(MODERN.raised,.60); rr("fill",bx,ry,bw,rowH-4,6)
          mt(fmt(v),bx+L.gap,ry+math.max(5,rowH*.18),L.small,MODERN.text,"left",bw-L.gap*2)
        end
      end
      if Plus.detailTab==6 then
        mt("START opens native EMERALD AREA",bx,bottom-L.small*1.1,L.small,MODERN.muted,"right",bw)
      end
    end
    mhint(L,"←→ PAGE   ↑↓ SCROLL   SELECT CRY   B BACK"..(Plus.detailTab==6 and "   START AREA" or ""))
  end

  -- Preserve the exact v1.0.8 graphics isolation, but make cleanup sandbox-safe.
  -- `debug` is intentionally NOT used: it is not guaranteed in the mod sandbox.
  -- All renderers called below contain no additional love.graphics.push/pop, so
  -- this one protected pair is sufficient and cannot leak when a draw errors.
  local function withGraphicsState(fn)
    if not (love and love.graphics) then return false, "graphics unavailable" end
    local g=love.graphics
    g.push("all")
    local ok,err=pcall(fn)
    -- Cleanup is unconditional and happens before propagating the draw error.
    pcall(g.setScissor)
    pcall(g.setShader)
    pcall(g.setColor,1,1,1,1)
    pcall(g.setLineWidth,1)
    g.pop()
    return ok,err
  end

  local function drawModern(viewport)
    if not (Plus.open and modernUiPresent() and love and love.graphics) then return end
    local top=Stack.top and Stack.top() or nil
    if not (top and top.id==STACK_ID) then return end
    local L=mlayout(viewport)
    local ok,err=withGraphicsState(function()
      if Plus.screen=="list" then modernList(L) elseif Plus.screen=="filters" then modernFilters(L) else modernDetail(L) end
    end)
    if not ok then error(err,0) end
  end

  function Plus.draw()
    if not Plus.open then return end
    -- Keep the proven v1.0.8 split: Modern UI and vanilla never draw together.
    if modernUiPresent() then return end
    local ok,err=withGraphicsState(function()
      if Plus.screen == "list" then drawList() elseif Plus.screen == "filters" then drawFilters() else drawDetail() end
    end)
    if not ok then error(err,0) end
  end

  mod.hooks:wrap("input.key", function(nextFn, game, ev)
    if Plus.open and ev and ev.phase == "pressed" then
      local key = tostring(ev.key or ""):lower()
      if key:match("^[a-z0-9]$") then
        if Plus.screen == "list" then openFilters() end
        if Plus.screen == "filters" then
          Plus.filterCursor = 1
          Plus.searchEdit = true
          appendSearch(key:upper())
          return true
        end
      end
      if Plus.screen == "filters" and Plus.searchEdit then
        if key == "backspace" then backspaceSearch(); return true end
        if key == "delete" then Plus.query = ""; rebuildRows(); return true end
        if key == "return" or key == "kpenter" or key == "escape" then Plus.searchEdit = false; return true end
      end
    end
    return nextFn(game, ev)
  end, 950)

  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result=nextFn(game, viewport)
    local ok, err=pcall(drawModern, viewport)
    if not ok and mod.log and mod.log.warn then
      mod.log:warn("[%s] Modern UI bridge draw failed: %s", MOD_ID, tostring(err))
    end
    return result
  end, 900)

  -- Defer if another equivalent Pokédex Plus already owns this feature.
  local deferred
  if mod.find then
    for _, id in ipairs(EQUIVALENTS) do
      local other = mod.find(id)
      if other then deferred = id break end
    end
  end
  if deferred then
    mod.exports.active = false
    mod.exports.deferredTo = deferred
    return
  end

  local StartMenu = require("src.ui.game3.start_menu")
  if StartMenu._pokemonmodPokedexPlusEmeraldOwner and StartMenu._pokemonmodPokedexPlusEmeraldOwner ~= MOD_ID then
    mod.exports.active = false
    mod.exports.deferredTo = StartMenu._pokemonmodPokedexPlusEmeraldOwner
    return
  end
  StartMenu._pokemonmodPokedexPlusEmeraldOwner = MOD_ID

  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    local session = runtimeSession(game)
    if not isEmerald(session) then return out end
    if type(out) ~= "table" then return out end

    for _, row in ipairs(out) do
      if type(row) == "table" and row.__pokemonmodGen3PokedexPlus then return out end
      if type(row) == "table" and norm(row.label) == "POKEDEX" and tostring(row.label or ""):find("+", 1, true) then
        return out
      end
    end

    for i, row in ipairs(out) do
      if type(row) == "table" and (row.value == "pokedex" or norm(row.label) == "POKEDEX") then
        local repl = {}
        for k, v in pairs(row) do repl[k] = v end
        repl.label = "POKéDEX+"
        repl.value = nil
        repl.__pokemonmodGen3PokedexPlus = true
        repl.onSelect = function()
          local session = runtimeSession(game)
          Plus.show(session, session and session.dex)
        end
        out[i] = repl
        break
      end
    end
    return out
  end, 250)

  mod.exports.active = true
  mod.exports.version = "1.1.1"
  mod.exports.game = "emerald"
  mod.exports.profileFamily = "rse"
  mod.exports.emeraldOnly = true
  mod.exports.supportedGames = { "emerald" }
  mod.exports.screen = Plus
  mod.exports.getBaseStats = stats
  mod.exports.getHabitats = areaRows
  mod.exports.getEvolutions = function(sp) return Pokemon.evolutions(sp) end
  mod.exports.getLevelMoves = learnRows
  mod.exports.searchByName = function(q)
    local old = Plus.query
    Plus.query = q or ""
    local oldRows = Plus._rows
    rebuildRows()
    local result = Plus._rows
    Plus.query = old
    Plus._rows = oldRows
    return result
  end
  mod.exports.setFilters = function(opts)
    opts = opts or {}
    if opts.query ~= nil then Plus.query = tostring(opts.query) end
    if opts.type ~= nil then Plus.typeFilter = tonumber(opts.type) or -1 end
    if opts.status ~= nil then Plus.statusFilter = tostring(opts.status):upper() end
    if opts.sort ~= nil then Plus.sortMode = tostring(opts.sort):upper() end
    Plus.cursor, Plus.scroll = 1, 0
    return rebuildRows()
  end
end

return function(mod)
  mod.options:define({{
    key = "reveal_unseen",
    type = "toggle",
    label = "REVEAL UNSEEN DATA",
    default = true,
  }})
  install(mod)
end
