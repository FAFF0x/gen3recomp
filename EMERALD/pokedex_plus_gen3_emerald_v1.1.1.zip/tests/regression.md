# Emerald regression checklist

- Manifest targets only `emerald` and uses the Emerald-only mod id.
- FireRed/LeafGreen runtime exits before registering hooks.
- START menu `POKéDEX` becomes `POKéDEX+` only in Emerald.
- Before National Dex: list uses Hoenn regional numbers/order from `Dex.regionalNumber` / `Dex.regionalMax`.
- After National Dex: list uses National 001-386 order.
- Search/filter rebuild remains event-driven rather than per-frame.
- DEX ENTRY uses the active Emerald cache entry and has no FireRed/LeafGreen version toggle.
- Evolution text handles all Gen 3 evolution method ids 1-15.
- Habitat uses `src.ui.game3.rse.pokedex_area` and RSE map sections.
- Habitat START opens Emerald's native RSE AREA screen for the selected species, including Plus-revealed unseen species.
- Vanilla fallback does not require `src.ui.game3.pokedex_chrome`.
- Modern UI bridge still fits Active Filters and long detail-tab labels.
