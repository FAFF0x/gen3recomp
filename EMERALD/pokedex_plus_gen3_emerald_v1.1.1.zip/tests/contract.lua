local mode = arg[1] or "emerald"
local root = arg[2] or "."

local currentSession = { version = mode, dex = { seen = {}, caught = {} } }
local hooks = {}
local pushes = {}
local nativeAreaState = nil

package.preload["src.core.game3.runtime"] = function()
  return { getSession = function() return currentSession end }
end
package.preload["src.core.GameVersion"] = function()
  return { get = function() return mode end }
end
package.preload["src.core.game3.profile"] = function()
  return {
    forSession = function(s)
      local v = s and s.version or mode
      if v == "emerald" then return { id = "emerald", family = "rse" } end
      return { id = v, family = "frlg" }
    end,
  }
end

package.preload["src.core.game3.pokemon"] = function()
  return {
    _names = true,
    national = function(sp) return tonumber(sp) end,
    speciesFromNational = function(nat) return tonumber(nat) end,
    name = function(sp) return "MON" .. tostring(sp) end,
    keyName = function(sp) return "MON" .. tostring(sp) end,
    types = function() return { 1 } end,
    stats = function() return { hp=45, atk=50, def=40, spe=60, spa=65, spd=55 } end,
    speciesMeta = function() return { friendship=70, catchRate=45, growthRate=3 } end,
    dexEntry = function() return { category="TEST", height=10, weight=100, description="EMERALD ENTRY" } end,
    evolutions = function() return {} end,
    learnset = function() return {} end,
    moveName = function(id) return "MOVE"..tostring(id) end,
    install = function() return true end,
  }
end
package.preload["src.core.game3.dex"] = function()
  return {
    NATIONAL_MAX = 386,
    KANTO_MAX = 151,
    new = function() return { seen={}, caught={} } end,
    isSeen = function(dex, sp) return dex.seen and dex.seen[sp] == true end,
    isCaught = function(dex, sp) return dex.caught and dex.caught[sp] == true end,
    regionalMax = function(version) assert(version == "emerald"); return 3 end,
    regionalNumber = function(sp, version)
      assert(version == "emerald")
      local t = { [252]=1, [255]=2, [258]=3 }
      return t[tonumber(sp)]
    end,
    defaultPersonality = function() return 0 end,
  }
end
package.preload["src.core.game3.pokedex_data"] = function()
  return {
    init = function() return true end,
    isNationalUnlocked = function() return false end,
    getEntry = function() error("Emerald Pokédex Plus must not call FRLG PokedexData.getEntry") end,
  }
end
package.preload["src.core.game3.battle.types"] = function()
  return { name = function(id) return id == 1 and "NORMAL" or "TYPE"..tostring(id) end }
end
package.preload["src.ui.game3.stack"] = function()
  return {
    push = function(id, screen, opts) pushes[#pushes+1] = {id=id,screen=screen,opts=opts} end,
    pop = function() end,
    top = function() return pushes[#pushes] end,
  }
end
package.preload["src.ui.game3.frlg_font"] = function()
  return {
    draw = function() end,
    wrap = function(s) return s end,
    measure = function(s) return #tostring(s) * 6 end,
  }
end
package.preload["src.ui.game3.start_menu"] = function() return {} end
package.preload["src.core.game3.audio"] = function()
  return { playSe=function() end, playCry=function() end }
end
package.preload["src.ui.game3.rse.pokedex_area"] = function()
  return {
    findMapsWithMon = function(sp, ctx)
      assert(sp == 252)
      return { overworld = { { sec=5 } }, special = { 9 } }
    end,
  }
end
package.preload["src.ui.game3.rse.mapsec"] = function()
  return { name = function(sec) return ({[5]="ROUTE 101",[9]="PETALBURG WOODS"})[sec] or "UNKNOWN" end }
end
package.preload["src.ui.game3.rse.pokedex_list"] = function()
  return {
    create = function(ctx, mode, order)
      return { count=1, items={ [0]={ dexNum=252, seen=true, owned=true } } }
    end,
  }
end
local rsePokedex = {
  PAGE = { MAIN=0 },
  heightText = function(h) return " 3'03\"" end,
  weightText = function(w) return " 22.0 lbs." end,
  newView = function(opts) return { session=opts.session, dex=opts.dex } end,
  areaContext = function(view) return { session=view.session } end,
  show = function(dex, opts)
    nativeAreaState = { session=opts.session, dex=dex, ctx={}, dexMode=0, dexOrder=0, list={count=0,items={}} }
    return nativeAreaState
  end,
}
package.preload["src.ui.game3.rse.pokedex"] = function() return rsePokedex end
package.preload["src.ui.game3.screens"] = function()
  return { get=function(id, session) assert(id=="pokedex"); assert(session.version=="emerald"); return rsePokedex end }
end

local mod = {
  exports = {},
  options = {
    define = function(self, defs) self.defs = defs end,
    get = function(self, key) return true end,
  },
  hooks = {
    wrap = function(self, name, fn, prio) hooks[name] = fn end,
  },
  find = function() return nil end,
  log = { warn=function() end },
}

local factory = assert(loadfile(root .. "/pokedex_plus_emerald.lua"))()
assert(type(factory) == "function")
factory(mod)

if mode ~= "emerald" then
  assert(mod.exports.active == false)
  assert(mod.exports.inactiveReason == "emerald-only")
  assert(next(hooks) == nil, "non-Emerald runtime must not register hooks")
  print("contract-fire-ok")
  return
end

assert(mod.exports.active == true)
assert(mod.exports.version == "1.1.1")
assert(mod.exports.game == "emerald")
assert(mod.exports.profileFamily == "rse")
assert(mod.exports.emeraldOnly == true)
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald")
assert(type(hooks["ui.start_menu.items"]) == "function")
assert(type(hooks["input.key"]) == "function")
assert(type(hooks["render.hud"]) == "function")

local menu = hooks["ui.start_menu.items"](function(game, items) return items end,
  { session=currentSession }, { { id="pokedex", label="POKéDEX" }, { id="pokemon", label="POKéMON" } })
assert(menu[1].label == "POKéDEX+")
assert(type(menu[1].onSelect) == "function")
menu[1].onSelect()

local screen = mod.exports.screen
assert(screen.open == true)
assert(#screen._rows == 3, "Hoenn regional order should contain only mapped species in this contract")
assert(screen._rows[1].species == 252 and screen._rows[1].nat == 1)
assert(screen._rows[2].species == 255 and screen._rows[2].nat == 2)
assert(screen._rows[3].species == 258 and screen._rows[3].nat == 3)
assert(pushes[#pushes].id == "pokemonmod_gen3_pokedex_plus_emerald")
assert(pushes[#pushes].opts.fullscreen == true)

local habitats = mod.exports.getHabitats(252)
assert(#habitats == 2)
assert(habitats[1].label == "PETALBURG WOODS" or habitats[1].label == "ROUTE 101")

local function input(key)
  return { wasPressed=function(self, k) return k == key end }
end
screen.handleInput(input("a"))
assert(screen.screen == "detail")
assert(screen._detail.pokedexEntry.heightFormatted == " 3'03\"")
assert(screen._detail.pokedexEntry.weightFormatted == " 22.0 lbs.")
assert(screen._detail.pokedexEntry.categoryName == "TEST POKéMON")
for i=1,5 do screen.handleInput(input("right")) end
assert(screen.detailTab == 6)
screen.handleInput(input("start"))
assert(nativeAreaState ~= nil)
assert(nativeAreaState.fn == "loadArea")
assert(nativeAreaState.selected == 0)
assert(nativeAreaState.list.items[0].dexNum == 252)
assert(type(nativeAreaState.info) == "table")

print("contract-emerald-ok")
