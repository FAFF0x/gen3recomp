# Changelog

## 1.1.1
- Fixed Emerald crash when opening a Pokémon detail page: `PokedexData.getEntry()` tried to resolve the FRLG-only ROM key `gText_Lbs`.
- Replaced that path with Emerald/RSE-native height and weight formatters from `src.ui.game3.rse.pokedex`.
- Read category and description directly from the active Emerald Pokédex entry.
- Updated Modern UI optional dependency/detection to prefer `gen3_modern_ui_emerald`.
- Added a regression contract that deliberately makes `PokedexData.getEntry()` fail if called.

## 1.1.0
- Converted Pokédex Plus from FireRed/LeafGreen to Pokémon Emerald only.
- Added separate `pokemonmod_gen3_pokedex_plus_emerald` id so the Emerald build can coexist with the FRLG build.
- Added strict Emerald/RSE runtime guard.
- Replaced Kanto/National list logic with Hoenn/National logic using the Emerald profile's regional Dex mappings.
- Replaced FRLG habitat marker logic with Emerald's native `rse.pokedex_area` calculation.
- START on Habitat now opens the native Emerald AREA screen.
- Replaced dual FireRed/LeafGreen entry switching with the Emerald Pokédex entry.
- Expanded evolution labels for Gen 3 methods used by Emerald, including stat-based, Wurmple, Nincada and Beauty evolutions.
- Rebuilt the vanilla 240×160 fallback as an Emerald-style renderer and removed the FireRed `PokedexChrome` dependency.
- Preserved Modern UI presentation and the v1.0.24 text-overflow fixes.
- Preserved Search & Filter Lab, stats, evolution, level-move and cry features.

## 1.0.24 (FRLG source)
- Fixed Modern UI Active Filters and detail-tab text overflow.
