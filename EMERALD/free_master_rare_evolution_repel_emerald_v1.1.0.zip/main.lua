-- Free Master/Rare + Evolution + Max Repel - Emerald v1.1.0
-- Emerald-only Gen 3 port of the FRLG combined shop mod.
--
-- Emerald does not use the FRLG Mart root renderer/input path. The shared
-- src.ui.game3.shop_menu delegates to src.ui.game3.rse.shop_menu, whose root
-- menu is private to the RSE implementation. This port therefore keeps the
-- native Emerald BUY/SELL/list/quantity/purchase state machine, while adding
-- a small Emerald-aware root adapter for the EVOLUTION SHOP entry.

return function(mod)
  local VERSION = "1.1.0"
  local MOD_ID = "pokemonmod_gen3_emerald_free_master_rare_evolution_repel"

  local Profile = require("src.core.game3.profile")
  local activeProfile = Profile.active and Profile.active() or nil
  if not activeProfile or activeProfile.id ~= "emerald" then
    mod.log:warn("%s is Emerald-only; active Game3 profile is %s", MOD_ID,
      tostring(activeProfile and activeProfile.id or "unknown"))
    return
  end

  local ItemsData = require("src.core.game3.items_data")
  local Pokemon = require("src.core.game3.pokemon")
  local ShopMenu = require("src.ui.game3.shop_menu")

  local function copyTable(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
  end

  local function copyList(src)
    local out = {}
    for i, v in ipairs(src or {}) do out[i] = v end
    return out
  end

  local function numeric(id)
    if ItemsData.toNumericId then
      local ok, n = pcall(ItemsData.toNumericId, id)
      if ok and n then return tonumber(n) end
    end
    return tonumber(id)
  end

  local function normalized(value)
    return tostring(value or ""):upper():gsub("[^A-Z0-9]", "")
  end

  local function isEmeraldSession(session)
    if type(session) == "table" and type(session.version) == "string" and session.version ~= "" then
      return session.version == "emerald"
    end
    local ok, row = pcall(Profile.forSession, session)
    return ok and row and row.id == "emerald"
  end

  local FREE_NORMAL_NAMES = { "MASTER_BALL", "RARE_CANDY", "MAX_REPEL" }
  local freeNormalIds = {}
  local freeNormalSet = {}
  for _, name in ipairs(FREE_NORMAL_NAMES) do
    local id = numeric(name)
    if id then
      freeNormalIds[#freeNormalIds + 1] = id
      freeNormalSet[id] = true
    else
      mod.log:warn("Unable to resolve Emerald item %s", name)
    end
  end

  -- pokeemerald/include/constants/pokemon.h
  local EVO_TRADE_ITEM = 6
  local EVO_ITEM = 7
  local evolutionIds = nil
  local evolutionSet = {}

  -- Keep the pre-mod metadata function so catalogue discovery cannot recurse
  -- through our own zero-price wrapper.
  local rawInfo = ItemsData.info

  local function addEvolutionId(out, seen, id)
    id = tonumber(id)
    if not id or id <= 0 or seen[id] then return end
    local ok, info = pcall(rawInfo, id)
    if not ok or type(info) ~= "table" then return end
    seen[id] = true
    out[#out + 1] = id
  end

  local function discoverEvolutionItems()
    if evolutionIds then return evolutionIds end

    local ids, seen = {}, {}

    -- Emerald's six evolution stones, resolved by symbolic item name rather
    -- than FRLG numeric assumptions. They are inserted first for a stable,
    -- familiar catalogue order.
    local stoneNames = {
      "SUN_STONE", "MOON_STONE", "FIRE_STONE",
      "THUNDER_STONE", "WATER_STONE", "LEAF_STONE",
    }
    local stoneRank = {}
    for rank, name in ipairs(stoneNames) do
      local id = numeric(name)
      if id then
        stoneRank[id] = rank
        addEvolutionId(ids, seen, id)
      end
    end

    -- Discover all actual Emerald item/trade-item evolutions from the active
    -- species dataset: King's Rock, Metal Coat, Dragon Scale, Up-Grade,
    -- DeepSeaTooth/Scale, etc. Pokemon.SPECIES_EGG is the first non-regular
    -- species sentinel in this runtime; fall back to a generous scan if absent.
    local lastSpecies = (tonumber(Pokemon.SPECIES_EGG) and tonumber(Pokemon.SPECIES_EGG) - 1) or 500
    for species = 1, lastSpecies do
      local ok, evolutions = pcall(Pokemon.evolutions, species)
      if ok and type(evolutions) == "table" then
        for _, evo in ipairs(evolutions) do
          local method = tonumber(evo.method or evo[1]) or 0
          local param = tonumber(evo.param or evo[2]) or 0
          if (method == EVO_ITEM or method == EVO_TRADE_ITEM) and param > 0 then
            addEvolutionId(ids, seen, param)
          end
        end
      end
    end

    table.sort(ids, function(a, b)
      local ra, rb = stoneRank[a] or 999, stoneRank[b] or 999
      if ra ~= rb then return ra < rb end
      local ia, ib = rawInfo(a) or {}, rawInfo(b) or {}
      return tostring(ia.name or a) < tostring(ib.name or b)
    end)

    evolutionIds = ids
    evolutionSet = {}
    for _, id in ipairs(ids) do evolutionSet[id] = true end
    return evolutionIds
  end

  local function dedupeItems(items)
    local out, seen = {}, {}
    for _, ref in ipairs(items or {}) do
      local id = numeric(ref) or ref
      local key = tostring(id)
      if not seen[key] then
        seen[key] = true
        out[#out + 1] = id
      end
    end
    return out, seen
  end

  local function augmentedNormalStock(items)
    local out, seen = dedupeItems(items)
    for _, id in ipairs(freeNormalIds) do
      local key = tostring(id)
      if not seen[key] then
        seen[key] = true
        out[#out + 1] = id
      end
    end
    return out
  end

  -- ---------------------------------------------------------------------
  -- Emerald price layer
  -- ---------------------------------------------------------------------
  -- RseShop asks ItemsData.info() live for normal-Mart prices. Chaining this
  -- function preserves other metadata wrappers and also prevents a free-buy /
  -- paid-sell loop because the sell path sees the same zero base price.
  if not ItemsData.__pokemonmodEmeraldFreeShopInfoPatched then
    local previousInfo = ItemsData.info
    ItemsData.info = function(id)
      local row = previousInfo(id)
      if type(row) ~= "table" then return row end
      local num = numeric(id) or tonumber(row.id)
      if num and (freeNormalSet[num] or evolutionSet[num]) then
        local patched = copyTable(row)
        patched.price = 0
        return patched
      end
      return row
    end
    ItemsData.__pokemonmodEmeraldFreeShopInfoPatched = MOD_ID
  else
    mod.log:info("An Emerald zero-price item metadata wrapper is already active")
  end

  -- ---------------------------------------------------------------------
  -- Shared root metadata for UI mods + our native Emerald adapter
  -- ---------------------------------------------------------------------
  local EVO_ROOT_ID = "pokemonmod_emerald_evolution_shop"
  local ownsEvolutionRoot = false

  local function hasEvolutionEntry()
    for _, row in ipairs(ShopMenu.ROOT or {}) do
      local id = normalized(row and row.id)
      local label = normalized(row and row.label)
      if id:find("EVOLUTION", 1, true) or label:find("EVOLUTION", 1, true) then
        return true
      end
    end
    return false
  end

  if not hasEvolutionEntry() then
    ShopMenu.ROOT = ShopMenu.ROOT or {}
    local insertAt = #ShopMenu.ROOT + 1
    for i, row in ipairs(ShopMenu.ROOT) do
      if row and row.id == "quit" then
        insertAt = i
        break
      end
    end
    table.insert(ShopMenu.ROOT, insertAt, {
      id = EVO_ROOT_ID,
      label = "EVOLUTION SHOP",
    })
    ownsEvolutionRoot = true
  else
    mod.log:info("An EVOLUTION SHOP root entry already exists; duplicate row suppressed")
  end

  local function isNormalEmeraldMart()
    return ShopMenu.open
      and ShopMenu._rse ~= nil
      and ShopMenu._martType == "NORMAL"
      and isEmeraldSession(ShopMenu._session)
  end

  local function restoreNormalStock()
    if ShopMenu._pokemonmodEmeraldNormalItems then
      ShopMenu._items = copyList(ShopMenu._pokemonmodEmeraldNormalItems)
      ShopMenu._rowsGen = (ShopMenu._rowsGen or 0) + 1
    end
    ShopMenu._pokemonmodEmeraldEvolutionActive = false
  end

  -- ---------------------------------------------------------------------
  -- Shop open wrapper
  -- ---------------------------------------------------------------------
  -- Important Emerald difference: call the native show() FIRST with the
  -- original items table so its mart lookup can still recognize decoration
  -- marts. Only then augment NORMAL Poké Mart stock.
  if not ShopMenu.__pokemonmodEmeraldCombinedShowPatched then
    local previousShow = ShopMenu.show
    ShopMenu.show = function(opts)
      opts = opts or {}

      discoverEvolutionItems()
      previousShow(opts)

      if isNormalEmeraldMart() then
        local live = augmentedNormalStock(ShopMenu._items or opts.items or {})
        ShopMenu._pokemonmodEmeraldNormalItems = copyList(live)
        ShopMenu._pokemonmodEmeraldEvolutionActive = false
        ShopMenu._items = copyList(live)
        ShopMenu._rowsGen = (ShopMenu._rowsGen or 0) + 1
      else
        -- Decoration marts in Lilycove/Slateport use a different inventory
        -- system and must never receive normal item IDs.
        ShopMenu._pokemonmodEmeraldNormalItems = nil
        ShopMenu._pokemonmodEmeraldEvolutionActive = false
      end
    end
    ShopMenu.__pokemonmodEmeraldCombinedShowPatched = MOD_ID
  else
    mod.log:warn("A compatible Emerald ShopMenu.show wrapper is already installed")
  end

  local function playSelect()
    pcall(function()
      local SE = require("src.core.game3.se_ids")
      require("src.core.game3.audio").playSe(SE.SE_SELECT or 5)
    end)
  end

  local function openEvolutionBuy()
    local function activate()
      ShopMenu._items = copyList(discoverEvolutionItems())
      ShopMenu._pokemonmodEmeraldEvolutionActive = true
      ShopMenu._rowsGen = (ShopMenu._rowsGen or 0) + 1
      ShopMenu.mode = "buy"
      ShopMenu.state = "list"
      ShopMenu.cursor = 1
      ShopMenu.scroll = 0
      ShopMenu.row = 0
      ShopMenu.qty = 1
      ShopMenu.yesNoCursor = 1
      ShopMenu.yesCursor = 1
      ShopMenu._pending = nil
      ShopMenu._itemId = nil
      ShopMenu._maxQty = nil
      ShopMenu._totalCost = nil
      ShopMenu._status = nil
    end

    local okF, Fade = pcall(require, "src.ui.game3.fade")
    if okF and Fade and Fade.begin and love and love.graphics then
      ShopMenu._fading = true
      Fade.begin(Fade.MODE.TO_BLACK, 1, function()
        activate()
        Fade.begin(Fade.MODE.FROM_BLACK, 1, function() ShopMenu._fading = false end)
      end)
    else
      activate()
    end
  end

  local function rootRows()
    return ShopMenu.ROOT or {}
  end

  local function nativeRootIndex(row)
    if not row then return nil end
    if row.id == "buy" then return 1 end
    if row.id == "sell" then return 2 end
    if row.id == "quit" then return 3 end
    return nil
  end

  -- ---------------------------------------------------------------------
  -- Emerald root/input adapter
  -- ---------------------------------------------------------------------
  -- RseShop's BUY/SELL/QUIT list is private, so ShopMenu.ROOT alone is not
  -- enough on Emerald. Intercept only the NORMAL-Mart root; all list, sell,
  -- quantity, confirmation, Premier Ball and Smart Shopper logic remains RSE.
  if ownsEvolutionRoot and not ShopMenu.__pokemonmodEmeraldEvolutionInputPatched then
    local previousHandleInput = ShopMenu.handleInput
    ShopMenu.handleInput = function(input)
      if isNormalEmeraldMart()
          and ShopMenu.mode == "root"
          and ShopMenu.state == "root"
          and input then
        if ShopMenu._pokemonmodEmeraldEvolutionActive then restoreNormalStock() end

        local rows = rootRows()
        local count = #rows
        if count < 1 then return previousHandleInput(input) end
        if ShopMenu.cursor < 1 then ShopMenu.cursor = 1 end
        if ShopMenu.cursor > count then ShopMenu.cursor = count end

        if input:wasPressed("up") then
          if ShopMenu.cursor > 1 then
            ShopMenu.cursor = ShopMenu.cursor - 1
            playSelect()
          end
          return
        elseif input:wasPressed("down") then
          if ShopMenu.cursor < count then
            ShopMenu.cursor = ShopMenu.cursor + 1
            playSelect()
          end
          return
        elseif input:wasPressed("a") then
          local selected = rows[ShopMenu.cursor]
          if selected and selected.id == EVO_ROOT_ID then
            playSelect()
            openEvolutionBuy()
            return
          end

          -- Hand BUY/SELL/QUIT back to Emerald's own RSE root handler using
          -- the native three-row cursor index, then restore our logical cursor
          -- only if the action did not leave the root.
          local native = nativeRootIndex(selected)
          if native then
            local logical = ShopMenu.cursor
            ShopMenu.cursor = native
            local result = previousHandleInput(input)
            if ShopMenu.open and ShopMenu.mode == "root" and ShopMenu.state == "root" then
              ShopMenu.cursor = math.min(logical, #rootRows())
            end
            return result
          end
          return
        elseif input:wasPressed("b") then
          -- Native Emerald B-at-root performs the proper shop shutdown/TV
          -- bookkeeping. Its action does not depend on the current row.
          return previousHandleInput(input)
        end
        return
      end

      local result = previousHandleInput(input)

      -- Emerald's free-price quantity code derives max quantity from money /
      -- max(1, price). For a ¥0 item that would limit a player with ¥0 to one
      -- copy. Restore the intended free-shop behavior: allow the native cap.
      if isNormalEmeraldMart() and ShopMenu.state == "qty"
          and tonumber(ShopMenu._totalCost) == 0 then
        ShopMenu._maxQty = 99
      end

      -- RseShop returns from BUY to root asynchronously through Fade.
      if isNormalEmeraldMart()
          and ShopMenu.mode == "root"
          and ShopMenu.state == "root"
          and ShopMenu._pokemonmodEmeraldEvolutionActive then
        restoreNormalStock()
      end

      return result
    end
    ShopMenu.__pokemonmodEmeraldEvolutionInputPatched = MOD_ID
  end

  -- ---------------------------------------------------------------------
  -- Native Emerald root renderer fallback
  -- ---------------------------------------------------------------------
  -- The stock RSE renderer also has a private three-row root. Render only the
  -- NORMAL-Mart root ourselves so the fourth row appears without Modern UI.
  if ownsEvolutionRoot and not ShopMenu.__pokemonmodEmeraldEvolutionDrawPatched then
    local previousDraw = ShopMenu.draw
    ShopMenu.draw = function()
      if not (isNormalEmeraldMart() and ShopMenu.mode == "root" and ShopMenu.state == "root") then
        return previousDraw()
      end

      local Window = require("src.ui.game3.window")
      local FrlgFont = require("src.ui.game3.frlg_font")
      local RomText = require("src.core.game3.rom_text")
      local rows = rootRows()
      local labels, width = {}, 0

      for i, row in ipairs(rows) do
        local label
        if row.id == "buy" then label = RomText.plain("gText_ShopBuy")
        elseif row.id == "sell" then label = RomText.plain("gText_ShopSell")
        elseif row.id == "quit" then label = RomText.plain("gText_ShopQuit")
        else label = row.label or tostring(row.id or "?") end
        labels[i] = label
        width = math.max(width, FrlgFont.measure(label))
      end

      -- Mirrors pokeemerald/src/shop.c:201 sizing, but grows to four rows.
      local tpl = Window.template(2, 1, math.max(1, math.floor((width + 8 + 7) / 8)), #rows * 2)
      Window.stdFrame(tpl)
      if Window.fill then Window.fill(tpl, 1, 1, 1, 1) end
      local pitch = Window.optionHeight()
      for i, label in ipairs(labels) do
        local y = tpl.top * 8 + 1 + (i - 1) * pitch
        Window.printPx(label, tpl.left * 8 + 8, y)
        if i == ShopMenu.cursor then Window.cursorPx(tpl.left * 8, y) end
      end

      Window.dialogueFrame()
      local y = 15 * 8 + 1
      for line in tostring(ShopMenu._status or ""):gmatch("[^\n]+") do
        Window.printPx(line, 2 * 8, y)
        y = y + FrlgFont.linePitch()
      end
    end
    ShopMenu.__pokemonmodEmeraldEvolutionDrawPatched = MOD_ID
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.supportedGames = { "emerald" }
  mod.exports.normalFreeItems = copyList(freeNormalIds)
  mod.exports.getEvolutionItems = function()
    return copyList(discoverEvolutionItems())
  end
  mod.exports.features = {
    freeMasterBall = true,
    freeRareCandy = true,
    freeMaxRepel = true,
    evolutionShop = true,
    emeraldRseShopAdapter = true,
  }

  mod.log:info(
    "Emerald free shop installed: %d normal free items; evolution catalogue is discovered from Emerald data on first Mart open",
    #freeNormalIds
  )
end
