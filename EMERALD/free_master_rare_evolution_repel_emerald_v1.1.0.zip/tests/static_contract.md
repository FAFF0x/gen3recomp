# Static contract — Emerald port

- Manifest id is unique: `pokemonmod_gen3_emerald_free_master_rare_evolution_repel`.
- `games` contains exactly `emerald`.
- Runtime guard refuses non-Emerald Game3 profiles.
- Runtime references use `src.core.game3.*` / `src.ui.game3.*` and Emerald's RSE shop delegate.
- Normal free items are resolved through the active Emerald/Game3 item metadata.
- Normal stock augmentation happens after native Mart identification, preserving decoration marts.
- Evolution items are dynamically collected from Emerald EVO_ITEM / EVO_TRADE_ITEM rows.
- The Emerald Evolution Shop reuses the RSE BUY/list/quantity/confirm/purchase state machine.
- The private RSE root menu is adapted for the Evolution Shop instead of assuming FRLG `ShopMenu.ROOT` is rendered natively.
- Duplicate inventory/root rows are suppressed.
- Zero-price quantities may reach the Emerald native item stack cap even with zero money.
