# Changelog

## 1.1.0 — Emerald-only conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Assigned a separate package id: `pokemonmod_gen3_emerald_free_master_rare_evolution_repel`, avoiding install conflicts with the FR/LG build.
- Reworked the shop integration around Emerald's `src.ui.game3.rse.shop_menu` path.
- Added an Emerald-native four-row normal-Mart root with EVOLUTION SHOP.
- Preserved the native Emerald BUY/SELL/list/quantity/confirmation/purchase logic.
- Preserved native Premier Ball bonus and Smart Shopper shop-history behavior by delegating purchases to RSE shop code.
- Normal stock is augmented only after Mart type detection, so decoration marts are not polluted with item IDs.
- Replaced the FRLG numeric evolution-stone assumption with symbolic Emerald item resolution.
- Evolution catalogue is discovered from Emerald's active species/evolution dataset.
- Corrected free-price quantity handling so ¥0 items are not limited by the player's current money.
- Added Emerald-only runtime metadata, documentation and static contract.

## 1.0.5 — Original FR/LG build

- Added LeafGreen support alongside FireRed.
- Shared FRLG Game3 ShopMenu implementation.
