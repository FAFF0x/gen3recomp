package.path = './?.lua;./?/init.lua;' .. package.path

local root = assert(arg[1], 'root')
local session = { version = 'emerald' }
local pike = false
local drawn = {}
local pushed, popped

local Pokemon = {}
function Pokemon.displayMonName(mon) return mon.nickname or 'TREECKO' end
function Pokemon.name() return 'TREECKO' end
function Pokemon.applyStats(mon)
  local iv, ev = mon.ivs, mon.evs
  mon.maxHp = 20 + (iv.hp or 0) + math.floor((ev.hp or 0) / 4)
  mon.attack = 10 + (iv.atk or 0) + math.floor((ev.atk or 0) / 4)
  mon.defense = 10 + (iv.def or 0) + math.floor((ev.def or 0) / 4)
  mon.spAtk = 10 + (iv.spa or 0) + math.floor((ev.spa or 0) / 4)
  mon.spDef = 10 + (iv.spd or 0) + math.floor((ev.spd or 0) / 4)
  mon.speed = 10 + (iv.spe or 0) + math.floor((ev.spe or 0) / 4)
  return mon
end

local PartyMenu = {
  mode='list', cursor=1, actionCursor=1, _battle=false,
  ACTIONS={'SUMMARY','SWITCH','ITEM','CANCEL'},
}
function PartyMenu.reloadSprites() end
function PartyMenu.handleInput(input)
  if PartyMenu.mode == 'list' and input:wasPressed('a') then
    PartyMenu.ACTIONS = {'SUMMARY','CUT','SWITCH','ITEM','CANCEL'}
    PartyMenu._fieldMoveNames = { CUT=true }
    PartyMenu.mode='action'; PartyMenu.actionCursor=1
  elseif PartyMenu.mode == 'action' then
    if input:wasPressed('down') then PartyMenu.actionCursor = PartyMenu.actionCursor % #PartyMenu.ACTIONS + 1 end
  end
end
function PartyMenu.draw()
  assert(PartyMenu.mode == 'action')
  for _, a in ipairs(PartyMenu.ACTIONS) do assert(a ~= 'IV/EV', 'native renderer received custom action') end
  local idx = 2
  local popY = 19 - #PartyMenu.ACTIONS * 2
  require('src.ui.game3.frlg_font').draw('CANCEL', 19*8+8, popY*8+(idx-1)*16+1, {})
end

local Stack = { _top=nil }
function Stack.push(id,obj) pushed=id; Stack._top={id=id,obj=obj} end
function Stack.pop(id) popped=id; Stack._top=nil end
function Stack.top() return Stack._top end

local Window = {}
function Window.stdFrame() end
function Window.template(...) return {...} end
function Window.cursorPx() end

local FrlgFont = { COLOR={NORMAL={},DARK_GRAY={},BLUE={},RED={}} }
function FrlgFont.draw(text,x,y,opts) drawn[#drawn+1]={text=text,x=x,y=y} end

local Profile = {}
function Profile.forSession(s)
  return { id=(s and s.version) or 'emerald', family=((s and s.version)=='emerald') and 'rse' or 'frlg', ui={party={insets={actX=8,actY=1,cursorX=0,msgX=0,msgY=1}}} }
end
function Profile.family(s) return Profile.forSession(s).family end

package.preload['src.core.game3.pokemon'] = function() return Pokemon end
package.preload['src.ui.game3.party_menu'] = function() return PartyMenu end
package.preload['src.ui.game3.stack'] = function() return Stack end
package.preload['src.ui.game3.window'] = function() return Window end
package.preload['src.ui.game3.frlg_font'] = function() return FrlgFont end
package.preload['src.core.game3.profile'] = function() return Profile end
package.preload['src.core.game3.runtime'] = function() return {getSession=function() return session end} end
package.preload['src.core.game3.rse.frontier.pike'] = function() return {inBattlePike=function() return pike end} end
package.preload['src.core.game3.audio'] = function() return {playSe=function() end} end

local wrapped
local mod = { exports={}, hooks={ wrap=function(self,name,fn,priority) wrapped=fn end }, log={info=function() end} }
local init = assert(loadfile(root .. '/main.lua'))()
init(mod)

local function press(key)
  return {wasPressed=function(_,k) return k==key end, isDown=function() return false end}
end
local function eq(a,b,msg) assert(a==b, (msg or 'eq')..': '..tostring(a)..' ~= '..tostring(b)) end
local function has(t,v) for _,x in ipairs(t or {}) do if x==v then return true end end return false end

-- Emerald normal field list: preserve CUT and insert after SUMMARY.
PartyMenu._party={{species=1,level=5,hp=20,maxHp=20,nickname='TREECKO',ivs={},evs={},moves={1}}}
PartyMenu.mode='list'; PartyMenu._battle=false; pike=false
PartyMenu.handleInput(press('a'))
eq(PartyMenu.mode,'action','entered action')
eq(PartyMenu.ACTIONS[1],'SUMMARY','summary first')
eq(PartyMenu.ACTIONS[2],'IV/EV','editor after summary')
eq(PartyMenu.ACTIONS[3],'CUT','field move preserved')

-- Native renderer bridge must never expose IV/EV to the underlying renderer,
-- but must draw the custom label in its visible row.
drawn={}
PartyMenu.draw()
local saw=false
for _,d in ipairs(drawn) do if d.text=='IV/EV' then saw=true end end
assert(saw,'custom IV/EV label not substituted')
eq(PartyMenu.ACTIONS[2],'IV/EV','action restored after draw')

-- Open editor and verify START/max helpers.
PartyMenu.actionCursor=2
PartyMenu.handleInput(press('a'))
eq(pushed,'dv_ev_editor_gen3_emerald','editor layer')
local mon=PartyMenu._party[1]
assert(mod.exports.Editor.isOpen(),'editor open')
mod.exports.Editor.maxAll()
for _,k in ipairs({'hp','atk','def','spa','spd','spe'}) do eq(mon.ivs[k],31,'iv '..k); eq(mon.evs[k],255,'ev '..k) end
assert(mod.exports.totalEv(mon)==1530,'raw total ev')
mod.exports.Editor.close()
eq(popped,'dv_ev_editor_gen3_emerald','editor popped')
eq(PartyMenu.mode,'action','returns to action')

-- Egg skip.
PartyMenu._party={{species=1,isEgg=true,ivs={},evs={}}}; PartyMenu.mode='list'; PartyMenu.ACTIONS={'SUMMARY','SWITCH','ITEM','CANCEL'}
PartyMenu.handleInput(press('a'))
assert(not has(PartyMenu.ACTIONS,'IV/EV'),'egg must not receive editor')

-- Battle Pike restriction.
PartyMenu._party={{species=1,ivs={},evs={}}}; PartyMenu.mode='list'; PartyMenu.ACTIONS={'SUMMARY','SWITCH','ITEM','CANCEL'}; pike=true
PartyMenu.handleInput(press('a'))
assert(not has(PartyMenu.ACTIONS,'IV/EV'),'pike must not receive editor')
pike=false

-- FireRed forced load must remain inert.
session.version='firered'; PartyMenu._party={{species=1,ivs={},evs={}}}; PartyMenu.mode='list'; PartyMenu.ACTIONS={'SUMMARY','SWITCH','ITEM','CANCEL'}
PartyMenu.handleInput(press('a'))
assert(not has(PartyMenu.ACTIONS,'IV/EV'),'firered runtime must remain inert')
assert(mod.exports.isEmerald()==false,'firered runtime guard')
session.version='emerald'
assert(mod.exports.isEmerald()==true,'emerald runtime guard')

eq(mod.exports.version,'2.1.0','version')
eq(#mod.exports.supportedGames,1,'supported count')
eq(mod.exports.supportedGames[1],'emerald','supported emerald')
assert(mod.exports.emeraldOnly==true and mod.exports.rseRuntime==true and mod.exports.fireRedRuntime==false,'runtime exports')
assert(type(wrapped)=='function','render hook')

print('emerald-contract-ok')
