# DV EV Editor Gen 3 Emerald v2.1.0 smoke-test checklist

- Manifest ID is `dv_ev_editor_gen3_emerald`.
- Manifest target is exactly `emerald`.
- No `firered`, `leafgreen`, `ruby`, or `sapphire` target remains.
- Runtime guard reports Emerald only.
- Party action injection occurs only in the normal Emerald field party menu and skips Eggs.
- Battle menus and Battle Pike restricted party actions do not receive `IV/EV`.
- `IV/EV` is inserted after `SUMMARY` while preserving Emerald field-move actions.
- Native Emerald Party Menu drawing does not assert on the custom action label.
- IV values clamp to 0..31.
- EV values clamp to 0..255.
- START max sets all six IVs to 31 and all six EVs to 255.
- Stat recalculation calls shared Game3 `Pokemon.applyStats` and preserves missing HP/fainted state.
- Editor stack layer is `dv_ev_editor_gen3_emerald` and returns to the Party action menu on B.
