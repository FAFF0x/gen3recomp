# Changelog

## 2.1.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Added dedicated id `dv_ev_editor_gen3_emerald` and `games: ["emerald"]`.
- Added Emerald/RSE runtime guard.
- Adapted party-action injection to Emerald's dynamically generated field action list, including RSE field moves.
- Prevented IV/EV injection into battle, multi-select, Egg and Battle Pike restricted menus.
- Added a safe custom-label renderer bridge so Emerald's native party renderer can display `IV/EV` without asserting on an unknown action id.
- Preserved six-IV/six-EV editing, immediate Game3 stat recalculation and HP preservation.
- Restyled the editor overlay toward an Emerald/Hoenn palette while retaining Modern UI compatibility.

## 2.0.3 - FireRed/LeafGreen source

- Original FR/LG Game3 build used as the conversion base.
