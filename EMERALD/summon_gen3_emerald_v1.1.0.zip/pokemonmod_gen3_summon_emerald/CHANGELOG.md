# Changelog

## 1.1.0
- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- New manifest/mod id: `pokemonmod_gen3_summon_emerald`.
- Target changed to `games: ["emerald"]` with an explicit Emerald/RSE runtime guard.
- SUMMON is injected only into Emerald's normal Start menu; Safari, Battle Pyramid, Link/Union and other special RSE Start menus are left untouched.
- Kept the profile-aware Game3 `WorldAPI:startWildBattle` path so Emerald's RSE battle transition, music, map/terrain scene selection, TV/rematch side effects and return-to-field logic remain native.
- Updated the high-resolution presenter to an Emerald/teal visual identity and removed FireRed labels.
- Added Emerald-specific exports (`game = "emerald"`, `family = "rse"`, `emeraldOnly = true`).

## 1.0.4
- FireRed + LeafGreen release (source version for this port).
