local root = (... and (...):match("^(.*)/tests/contract%.lua$")) or "."
local mainPath = root .. "/main.lua"

local current = { id = "emerald", family = "rse" }
local session = { version = "emerald", party = { { species = 1, hp = 20, level = 12 } } }
local pushed, popped = {}, {}
local startClosed = false
local battleCall = nil

package.preload["src.core.game3.runtime"] = function()
  return { getSession = function() return session end }
end
package.preload["src.core.game3.profile"] = function()
  return { forSession = function(_) return current end }
end
package.preload["src.ui.game3.stack"] = function()
  local S = {}
  function S.push(id, mod, opts) pushed[#pushed+1] = {id=id, mod=mod, opts=opts}; S._top={id=id,mod=mod}; return true end
  function S.pop(id) popped[#popped+1]=id; if S._top and S._top.id==id then S._top=nil end; return true end
  function S.top() return S._top end
  return S
end
package.preload["src.ui.game3.window"] = function()
  return { template=function(...) return {...} end, stdFrame=function() end, cursorPx=function() end, printPx=function() end }
end
package.preload["src.ui.game3.frlg_font"] = function()
  return { measure=function(s) return #tostring(s)*8 end }
end
package.preload["src.ui.game3.start_menu"] = function()
  local S = { _kind="normal", open=true }
  function S.isOpen() return S.open end
  function S.close() S.open=false; startClosed=true end
  return S
end
package.preload["src.world.game3.WorldAPI"] = function()
  local W = {}
  function W.new(game, modId)
    return { startWildBattle = function(_, species, level)
      battleCall = { game=game, modId=modId, species=species, level=level }
      return true
    end }
  end
  return W
end
package.preload["src.core.game3.pokemon"] = function()
  return {
    _names = { [1]="BULBASAUR", [25]="PIKACHU" },
    _national = { toSpecies = { [1]=1, [25]=25 } },
    keyName = function(sp) return ({[1]="SPECIES_BULBASAUR",[25]="SPECIES_PIKACHU"})[sp] end,
    name = function(sp) return ({[1]="BULBASAUR",[25]="PIKACHU"})[sp] end,
    speciesFromNational = function(n) return ({[1]=1,[25]=25})[n] end,
  }
end
package.preload["src.core.game3.audio"] = function() return { playSe=function() end } end
package.preload["src.ui.game3.hud"] = function() return { openMessage=function() end } end

local init = assert(loadfile(mainPath))()

local function newMod()
  local hooks = {}
  local mod = {
    generation = 3,
    exports = {},
    hooks = {},
    ui = {},
    log = { info=function() end, warn=function() end },
  }
  function mod.hooks:wrap(name, fn, prio) hooks[name] = {fn=fn, prio=prio}; return true end
  mod._hooks = hooks
  return mod
end

-- Emerald installs all three hooks and exports Emerald-only metadata.
local mod = newMod()
init(mod)
assert(mod.exports.version == "1.1.0")
assert(mod.exports.game == "emerald")
assert(mod.exports.family == "rse")
assert(mod.exports.emeraldOnly == true)
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald")
assert(mod._hooks["input.key"] and mod._hooks["render.hud"] and mod._hooks["ui.start_menu.items"])

local StartMenu = require("src.ui.game3.start_menu")
local startHook = mod._hooks["ui.start_menu.items"].fn
local base = {
  {id="pokedex", label="POKéDEX"},
  {id="pokemon", label="POKéMON"},
  {id="save", label="SAVE"},
  {id="option", label="OPTION"},
  {id="exit", label="EXIT"},
}
local out = startHook(function(_, items) return items end, {phase="field"}, base)
local summonIndex, saveIndex, summonRow
for i,row in ipairs(out) do
  if row.id == "pokemonmod_gen3_summon_emerald" then summonIndex=i; summonRow=row end
  if row.id == "save" then saveIndex=i end
end
assert(summonIndex and saveIndex and summonIndex == saveIndex - 1, "SUMMON must be immediately before SAVE")

-- Duplicate protection.
local out2 = startHook(function(_, items) return items end, {}, out)
local count=0
for _,row in ipairs(out2) do if row.pokemonmodGen3Summon then count=count+1 end end
assert(count == 1)

-- Emerald special Start menus must remain untouched.
for _,kind in ipairs({"safari", "pyramid", "union"}) do
  StartMenu._kind = kind
  local special = startHook(function(_, items) return items end, {}, base)
  for _,row in ipairs(special) do assert(row.id ~= "pokemonmod_gen3_summon_emerald") end
end
StartMenu._kind = "normal"

-- Open SUMMON, type National Dex 25, submit, and verify native wild-battle path.
StartMenu.open = true
summonRow.onSelect({phase="field"})
assert(mod.exports.isOpen() == true)
local keyHook = mod._hooks["input.key"].fn
local function key(k) keyHook(function() return "downstream" end, {phase="field"}, {phase="pressed", key=k}) end
key("2"); key("5"); key("return")
assert(mod.exports.isOpen() == false)
assert(startClosed == true)
assert(battleCall and battleCall.species == 25 and battleCall.level == 12)
assert(battleCall.modId == "pokemonmod_gen3_summon_emerald")

-- FireRed forced-load guard: no hooks and no exports should be installed.
current = { id="firered", family="frlg" }
session = { version="firered", party={{species=1,hp=20,level=5}} }
local fr = newMod()
init(fr)
assert(next(fr._hooks) == nil, "FireRed must register no hooks")
assert(next(fr.exports) == nil, "FireRed must export nothing")

print("contract-ok")
