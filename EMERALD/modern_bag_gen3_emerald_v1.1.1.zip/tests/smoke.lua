package.path = './?.lua;./?/init.lua;' .. package.path

local ItemsData = {
  BAG_POCKET_ORDER={'ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH','KEY_ITEMS'},
  POCKET_ORDER={'ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH','KEY_ITEMS'},
  POCKET_LABEL={ITEMS='ITEMS',KEY_ITEMS='KEY ITEMS',POKE_BALLS='POKE BALLS',TM_CASE='TM CASE',BERRY_POUCH='BERRY POUCH'},
  CAPACITY={ITEMS=30,POKE_BALLS=16,TM_CASE=64,BERRY_POUCH=46,KEY_ITEMS=30},
  FIRST_TM=289,LAST_TM=338,FIRST_HM=339,LAST_HM=346,ITEM_TM_CASE=364,ITEM_BERRY_POUCH=365,
}
local names={[13]='POTION',[75]='X ATTACK',[95]='FIRE STONE',[289]='TM01',[339]='HM01',[139]='ORAN BERRY',[360]='BICYCLE',[4]='POKE BALL',[364]='TM CASE',[365]='BERRY POUCH'}
local pockets={[13]='ITEMS',[75]='ITEMS',[95]='ITEMS',[289]='TM_CASE',[339]='TM_CASE',[139]='BERRY_POUCH',[360]='KEY_ITEMS',[4]='POKE_BALLS',[364]='KEY_ITEMS',[365]='KEY_ITEMS'}
function ItemsData.applyProfile(version)
  assert(version=='emerald')
  ItemsData.BAG_POCKET_ORDER={'ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH','KEY_ITEMS'}
  ItemsData.POCKET_ORDER={'ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH','KEY_ITEMS'}
end
function ItemsData.toNumericId(id) return tonumber(id) end
function ItemsData.displayName(id) return names[tonumber(id)] or tostring(id) end
function ItemsData.description(id) return 'ITEM DESC '..tostring(id) end
function ItemsData.pocketOf(id) return pockets[tonumber(id)] or 'ITEMS' end
function ItemsData.info(id) return {registrability=(tonumber(id)==360) and 1 or 0} end
function ItemsData.fieldUseKind(id)
  id=tonumber(id); if id==13 then return 'heal' elseif id==75 then return 'battle' elseif id==95 then return 'evo' elseif id==289 or id==339 then return 'tm' end
  return 'none'
end
function ItemsData.isTm(id) id=tonumber(id); return id and id>=289 and id<=346 or false end
function ItemsData.isHm(id) id=tonumber(id); return id and id>=339 and id<=346 or false end
function ItemsData.tmNumber(id) id=tonumber(id); if id>=339 then return id-338 else return id-288 end end
package.preload['src.core.game3.items_data']=function() return ItemsData end
package.preload['src.core.game3.profile']=function()
  return {active=function() return {id='emerald',family='rse'} end}
end

local Items={GAME3_MAX_QTY=999}
function Items.clampGame3(q) return math.min(Items.GAME3_MAX_QTY, math.max(0,math.floor(q or 0))) end
package.preload['src.core.game3.items']=function() return Items end

local Bag={}
function Bag.listPocket(bag,pocket)
  local out={}; for _,s in ipairs((bag.pockets and bag.pockets[pocket]) or {}) do out[#out+1]={id=s.id,qty=s.qty,name=ItemsData.displayName(s.id),description=ItemsData.description(s.id),info=ItemsData.info(s.id)} end; return out
end
package.preload['src.core.game3.bag']=function() return Bag end

local BagMenu={open=false,pocketIdx=1,cursor=1,scroll=0,mode='list',ACTIONS={}}
function BagMenu.currentPocket() return ItemsData.BAG_POCKET_ORDER[BagMenu.pocketIdx] or 'ITEMS' end
function BagMenu.list(p) return Bag.listPocket(BagMenu._bag,p or BagMenu.currentPocket()) end
function BagMenu.show(session,opts) ItemsData.applyProfile('emerald'); BagMenu.open=true; BagMenu._session=session; BagMenu._bag=session.bag; BagMenu._battle=opts and opts.battle or false; BagMenu.pocketIdx=(opts and opts.pocketIdx) or 1; BagMenu.mode='list' end
function BagMenu.close() BagMenu.open=false end
function BagMenu.handleInput() end
function BagMenu.draw() end
package.preload['src.ui.game3.bag_menu']=function() return BagMenu end

local Stack={}
function Stack.top() return {id='bag',mod=BagMenu} end
package.preload['src.ui.game3.stack']=function() return Stack end
local RseBag={BAG_FRAME={ITEMS=1,KEY_ITEMS=2,POKE_BALLS=3,TM_CASE=4,BERRY_POUCH=5}}
function RseBag.handleInput(input,Bag) return Bag.handleInput(input) end
function RseBag.draw(Bag) return Bag.draw() end
package.preload['src.ui.game3.rse.bag_menu']=function() return RseBag end
package.preload['src.ui.game3.rse.bag_chrome']=function() return {drawItemIcon=function() return true end} end

local Pokemon={}
function Pokemon.moveFromTmItem(id) return tonumber(id)==289 and 1 or tonumber(id)==339 and 15 or nil end
function Pokemon.battleMove(id)
  if id==1 then return {type=0,power=80,accuracy=100,pp=15,effect=1,secondaryEffectChance=0} end
  return {type=0,power=50,accuracy=95,pp=30,effect=2,secondaryEffectChance=0}
end
function Pokemon.moveName(id) return id==1 and 'MEGA PUNCH' or 'CUT' end
package.preload['src.core.game3.pokemon']=function() return Pokemon end
package.preload['src.core.game3.summary_data']=function() return {moveDescription=function(_,n) return 'Full move effect for '..tostring(n)..'.' end} end
package.preload['src.core.game3.battle.items']=function() return {isBattleUsable=function(id) return tonumber(id)==75 end} end
package.preload['src.ui.game3.naming']=function() return {open=function(opts) if opts.onDone then opts.onDone('MEGA') end end} end

local saved, hooks={}, {}
local mod={
 save={get=function(_,k,d) local v=saved[k]; if v==nil then return d end; return v end,set=function(_,k,v) saved[k]=v end},
 options={define=function() end,get=function(_,k) return ({opening_pocket='medicine',hold_scroll_speed='fast'})[k] end},
 exports={}, find=function() return nil end, log={info=function() end,warn=function() end},
 hooks={wrap=function(_,name,fn,priority) hooks[name]={fn=fn,priority=priority} end},
}

local install=assert(loadfile('main.lua')); install()(mod)
assert(mod.exports.active==true)
assert(Items.GAME3_MAX_QTY==999999)
assert(ItemsData.CAPACITY.ITEMS==999999)
assert(hooks['input.key'] and hooks['input.gamepad'] and hooks['render.hud'])

local session={bag={pockets={
 ITEMS={{id=13,qty=3},{id=75,qty=2},{id=95,qty=1}},
 KEY_ITEMS={{id=360,qty=1},{id=364,qty=1},{id=365,qty=1}},
 POKE_BALLS={{id=4,qty=5}},
 TM_CASE={{id=289,qty=1},{id=339,qty=1}},
 BERRY_POUCH={{id=139,qty=4}},
}}, registeredItem=nil}
BagMenu.show(session,{})
-- Real Emerald BagMenu.show() reapplies the five-pocket profile internally.
-- The port must restore all eight logical tabs after that native initialization.
assert(#ItemsData.BAG_POCKET_ORDER==8)
assert(table.concat(ItemsData.BAG_POCKET_ORDER,',')=='FAV,MEDICINE,POKE_BALLS,TM_CASE,BERRY_POUCH,BATTLE,KEY_ITEMS,OTHER')
assert(BagMenu.currentPocket()=='MEDICINE')
local med=BagMenu.list(); assert(#med==1 and med[1].id==13)
BagMenu.pocketIdx=1; assert(BagMenu.currentPocket()=='FAV' and #BagMenu.list()==0)
BagMenu.pocketIdx=2; med=BagMenu.list(); assert(#med==1 and med[1].id==13)
BagMenu.pocketIdx=3; local balls=BagMenu.list(); assert(#balls==1 and balls[1].id==4)
BagMenu.pocketIdx=4
local mach=BagMenu.list(); assert(#mach==2 and ItemsData.isTm(mach[1].id))
BagMenu.pocketIdx=5; local berries=BagMenu.list(); assert(#berries==1 and berries[1].id==139)
BagMenu.pocketIdx=6; local battle=BagMenu.list(); assert(#battle==1 and battle[1].id==75)
BagMenu.pocketIdx=7; local keys=BagMenu.list(); assert(#keys==1 and keys[1].id==360)
BagMenu.pocketIdx=8; local other=BagMenu.list(); assert(#other==1 and other[1].id==95)
BagMenu.pocketIdx=4
assert(mach[1].name:find('HM01',1,true) or mach[1].name:find('TM01',1,true))
local mi=mod.exports.machineInfo(289)
assert(mi and mi.code=='TM01' and mi.name=='MEGA PUNCH' and mi.type=='NORMAL' and mi.class=='PHYSICAL')
assert(ItemsData.displayName(289)=='TM01  MEGA PUNCH')
local desc=ItemsData.description(289)
assert(desc:find('POWER 80',1,true) and desc:find('PP 15',1,true) and desc:find('Full move effect',1,true))

local function press(key)
  return {wasPressed=function(_,k) return k==key end,isDown=function() return false end}
end

-- START opens the redesigned TM/HM filter hub: NAME / TYPE / CLASS / SORT.
BagMenu.cursor=1; BagMenu.mode='list'
BagMenu.handleInput(press('start'))
assert(BagMenu.mode=='action' and BagMenu.ACTIONS[1]=='NAME')
assert(BagMenu.ACTIONS[2]=='TYPE' and BagMenu.ACTIONS[3]=='CLASS' and BagMenu.ACTIONS[4]=='SORT')
assert(BagMenu.ACTIONS[5]=='RESET' and BagMenu.ACTIONS[6]=='DONE')
-- Left/right edits filter values directly; SORT NUMBER -> NAME.
BagMenu.handleInput(press('down')); BagMenu.handleInput(press('down')); BagMenu.handleInput(press('down'))
BagMenu.handleInput(press('right'))
assert(mod.exports.machineFilters().sort=='NAME')
BagMenu.handleInput(press('up')); BagMenu.handleInput(press('up')); BagMenu.handleInput(press('up'))
-- NAME search uses the move name and combines with current filters.
BagMenu.handleInput(press('a'))
assert(mod.exports.machineFilters().query=='MEGA')
assert(#BagMenu.list()==1 and BagMenu.list()[1].id==289)
BagMenu.handleInput(press('b')); assert(BagMenu.mode=='list')

-- Keyboard I and controller Y open/close the dedicated move information state.
local keyHook=hooks['input.key'].fn
local padHook=hooks['input.gamepad'].fn
local passthrough=function() return 'NEXT' end
assert(keyHook(passthrough,{}, {phase='pressed',key='i'})==true)
assert(mod.exports.isMoveInfoOpen())
assert(keyHook(passthrough,{}, {phase='pressed',key='i'})==true)
assert(not mod.exports.isMoveInfoOpen())
assert(padHook(passthrough,{}, {phase='pressed',button='y'})==true)
assert(mod.exports.isMoveInfoOpen())
BagMenu.handleInput(press('b')); assert(not mod.exports.isMoveInfoOpen())

BagMenu.close(); assert(#ItemsData.BAG_POCKET_ORDER==5 and ItemsData.BAG_POCKET_ORDER[1]=='ITEMS' and ItemsData.BAG_POCKET_ORDER[2]=='POKE_BALLS')
-- Mock one high-resolution HUD pass for catalogue, filters and move info.
BagMenu.show(session,{})
local Font={}
function Font:getWidth(t) return #t*7 end
love={graphics={
  newFont=function() return Font end,getFont=function() return Font end,setFont=function() end,
  setColor=function() end,rectangle=function() end,setScissor=function() end,printf=function() end,
  getWidth=function() return 1280 end,getHeight=function() return 720 end,setLineWidth=function() end,
}}
BagMenu.pocketIdx=4; BagMenu.cursor=1; BagMenu.mode='list'
local render=hooks['render.hud'].fn
assert(render(function() return 'DRAWN' end,{}, {gameX=0,gameY=0,gameWidth=960,gameHeight=640})=='DRAWN')
assert(render(function() return 'SMALL' end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})=='SMALL')
BagMenu.handleInput(press('start'))
assert(render(function() return 'FILTERS' end,{}, {gameX=0,gameY=0,gameWidth=960,gameHeight=640})=='FILTERS')
assert(render(function() return 'FILTERS_SMALL' end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})=='FILTERS_SMALL')
BagMenu.handleInput(press('b'))
assert(keyHook(passthrough,{}, {phase='pressed',key='i'})==true)
assert(render(function() return 'INFO' end,{}, {gameX=0,gameY=0,gameWidth=960,gameHeight=640})=='INFO')
assert(render(function() return 'INFO_SMALL' end,{}, {gameX=0,gameY=0,gameWidth=240,gameHeight=160})=='INFO_SMALL')
BagMenu.handleInput(press('b'))

assert(mod.exports.supportedGames[1]=='emerald')
print('modern_bag_gen3_emerald v1.1.1 smoke OK')
