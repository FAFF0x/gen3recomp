# Static contract — Modern Bag Gen3 Emerald v1.1.1

- Manifest id: `pokemonmod_gen3_modern_bag_emerald`.
- Manifest target: `games: ["emerald"]` only.
- Active runtime profile must be `emerald`.
- Calls `ItemsData.applyProfile("emerald")` before capturing pocket order/capacity.
- Emerald physical pocket order is `ITEMS, POKE_BALLS, TM_CASE, BERRY_POUCH, KEY_ITEMS`.
- Reapplies the eight logical tab order after native `BagMenu.show()` because Emerald reapplies the five-pocket RSE profile during show.
- Reasserts the logical order before RSE input and draw passes so tab index and content cannot diverge.
- Uses `src.ui.game3.rse.bag_menu` for the Emerald Bag skin.
- Uses `src.ui.game3.rse.bag_chrome` for the Emerald 24×24 vertical icon atlas.
- Synthetic logical categories reuse the Emerald Items bag frame without relocating physical inventory.
- RSE owns normal list movement and native action grids.
- Modern Bag bypasses the RSE action grid only for its own tools/filter/move-info panels.
- Held-repeat input is synthesized before RSE consumes Up/Down.
- Logical categories do not relocate physical inventory slots.
- Native Emerald Game3 Bag owns USE/GIVE/TOSS/REGISTER/teach actions.
- TM/HM browsing retains the two-pane catalogue and move-detail overlays.
- Optional Modern UI integration uses `gen3_modern_ui_emerald`.
- The package uses a standalone Emerald id so it can coexist with the FRLG build.
