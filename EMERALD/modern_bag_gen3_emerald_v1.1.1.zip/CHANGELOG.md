# Changelog

## 1.1.1 - Emerald logical-tab synchronization fix

- Fixed the eight logical tabs becoming desynchronized from their contents after opening the Bag.
- Root cause: Emerald `BagMenu.show()` reapplies the native RSE profile and restores the five physical pocket order.
- Reapply the eight-tab Modern Bag order after native Bag initialization.
- Keep the logical order synchronized before RSE input and draw passes.
- Physical Emerald pockets are still never moved or rewritten.


## 1.1.0 — Emerald-only conversion

- Split the Emerald build into the standalone id `pokemonmod_gen3_modern_bag_emerald`.
- Targeted only `games: ["emerald"]`.
- Added an active-profile guard requiring the Emerald Game3 profile.
- Applied the Emerald bag profile before capturing pocket order and capacities.
- Switched custom item rendering from FRLG `bag_chrome` to `rse.bag_chrome`.
- Added scaling adaptation for Emerald's vertical 24×24 item icon atlas.
- Integrated with `src.ui.game3.rse.bag_menu` for Emerald list input and rendering.
- Added RSE bag-frame mappings for Favorites, Medicine, Battle and Other logical views.
- Changed standard logical-list cursor clamping to Emerald's eight visible rows.
- Prevented the RSE action grid from consuming input while Modern Bag custom panels are active.
- Added an RSE draw bridge so custom tools/filters do not render as invalid native action labels.
- Fixed last-pocket tracking when RSE consumes Left/Right before the shared BagMenu handler.
- Updated optional Modern UI dependency to `gen3_modern_ui_emerald`.
- Kept native Emerald USE/GIVE/TOSS/REGISTER/TM teaching authoritative.

## 1.0.4
- Added LeafGreen support alongside FireRed.
- Updated manifest game targets to `firered` and `leafgreen`.
- Added explicit runtime `supportedGames` metadata for both FRLG games.
- Kept the shared Game3 BagMenu, item-use, TM/HM catalogue, filters, favorites, pins and Modern UI integration unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.3

- Replaced the generic TM/HM Bag presentation with a dedicated full-area two-pane catalogue.
- Added a six-row move list on the left and an always-visible technical move card on the right.
- Move rows now show machine number, move name, type, class and power without opening another screen.
- The detail card now keeps type, class, Power, Accuracy, PP and the wrapped move effect visible at all times.
- Completely redesigned the START filter panel into a navigation column plus contextual visual selector.
- TYPE displays all available type chips at once; CLASS and SORT display their full option sets simultaneously.
- Left/Right now changes TYPE, CLASS and SORT directly; Up/Down changes filter section.
- NAME search remains A-to-edit and combines with all other filters.
- Redesigned Y/I Move Information as a spacious two-column technical sheet.
- Added responsive scaling, clipping and ellipsis handling to prevent labels from leaving their cards.
- Dedicated TM/HM overlays now render only when the Game3 Bag layer is topmost, preventing overlap with Party/Naming submenus.

## 1.0.2

- Rebuilt the FireRed TM/HM view around move data instead of generic item data.
- TM/HM rows now show machine number plus move name (for example `TM24 THUNDERBOLT`).
- The side detail panel now exposes type, class, power, accuracy, PP and a compact move effect.
- START now opens the dedicated NAME / TYPE / CLASS / SORT panel, matching the Gen2 feature set.
- NAME search now filters by the move name and combines with TYPE and CLASS filters.
- Added raw Keyboard `I` / Controller `Y` move-information shortcuts through the supported input hooks.
- Added a dedicated Move Information overlay with machine number, move name, type, class, power, accuracy, PP and move effect.
- Added a dedicated high-resolution filter overlay and widened the native fallback panel so long labels stay inside their boxes.
- Added numeric FireRed move-type decoding for correct type labels and Gen3 physical/special classification.

## 1.0.1

- Ported Modern Bag from Gen2 to native FireRed/Game3.
- Added FireRed-only manifest target and unique `pokemonmod_gen3_modern_bag` identity.
- Replaced the Gen2 PackMenu renderer patch with a Game3 `BagMenu` logical-view adapter.
- Added eight FireRed-aware logical categories: Favorites, Medicine, Balls, TM/HM, Berries, Battle, Key Items and Other.
- Preserved native FireRed USE/GIVE/TOSS/REGISTER/TM teach behavior by leaving items in their real Game3 pockets.
- Added persistent favorites and pins.
- Added Game3 naming-screen search.
- Added TM/HM filters for kind, type and damage class plus number/name/power sorting and move details.
- Expanded Game3 pocket/stack capacity while retaining native Bag mutation functions.
- Added automatic compatibility with `gen3_modern_ui` through the live BagMenu model.
- Added equivalent-mod deferral and runtime patch sentinels to prevent double installation.
