# Changelog

## 1.2.0 — Emerald/RSE conversion
- Converted the mod from FireRed/LeafGreen to Pokémon Emerald only.
- Added a unique Emerald mod id and hot-reload dispatch key.
- Added an explicit `emerald` / `rse` runtime guard.
- Pinned item metadata resolution to the Emerald profile.
- Preserved Emerald's native `StepEvents.onRepelStep` behavior, including Battle Pike and Battle Pyramid exclusions.
- Kept native RSE encounter generation and temporarily bypass only the native lead-level Repel rejection.
- Restore the RSE four-step encounter-immunity value when the mod suppresses a rolled encounter.
- Kept the native wear-off event before the reuse prompt.
- Updated EXTRAS integration for Emerald and gave the row a unique Emerald id.
- Added optional ordering with `gen3_modern_ui_emerald`.
- Export metadata now reports only Emerald support.

# Changelog

## 1.1.3
- Rebuilt `REPEL MODE` Options integration using the same proven pattern as `EXP Share Modes Gen 3`.
- `src.ui.game3.option_rows` is now loaded lazily with `pcall`.
- Added unique row id `pokemonmod_repel_mode` to the native `group.extras` membership list.
- Wrapped the current `Rows.build` through `previousBuild`, preserving wrappers installed by Modern UI and other mods.
- Added duplicate-owner protection matching the EXP Share implementation style.
- Exported `optionsMenuInstalled` for runtime diagnostics.
- Encounter behavior and Repel reuse prompt are unchanged.
- FireRed + LeafGreen support is preserved.

## 1.1.2
- Moved `REPEL MODE` from a separate Start-menu row to `Start > Options > Extras`.
- Added a native Game3 Options row with visible values `UNCAUGHT` and `BLOCK ALL`.
- LEFT/RIGHT or A directly toggles the Repel behavior from the Extras page.
- Patched `src.ui.game3.option_rows` rather than rebuilding or replacing the Options screen.
- Removed the separate `ui.start_menu.items` entry to avoid cluttering the Start menu.
- The selected mode remains persistent through the mod save namespace.
- Repel reuse prompt and FireRed + LeafGreen support are unchanged.

## 1.1.1
- Added a visible `REPEL MODE` entry to the in-game Start menu.
- `REPEL MODE` opens a two-choice selector: `UNCAUGHT ONLY` or `BLOCK ALL`.
- The selected mode is persisted in the mod save namespace and takes effect immediately.
- The Mod Manager toggle remains available as the default/fallback for saves that have not selected an in-game mode yet.
- Encounter filtering now reads the in-game runtime mode.
- Repel reuse prompt, Repel duration and FireRed + LeafGreen support are unchanged.

## 1.1.0
- Added the `REPEL: UNCAUGHT ONLY` toggle to the mod options menu.
- ON by default: active Repels allow random encounters only for species not yet caught in the Pokédex.
- In ON mode, the vanilla lead-level Repel restriction is bypassed, so an uncaught Pokémon may appear even below the lead Pokémon's level.
- OFF mode makes an active Repel suppress every random walking encounter, including same-level and higher-level Pokémon.
- The option is evaluated live on each encounter roll.
- Preserved native encounter rate, terrain/slot selection, Repel item duration, item consumption and the reuse prompt.
- FireRed + LeafGreen support and the existing mod id are preserved.

## 1.0.3
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Added explicit FRLG runtime metadata with `game = "frlg"` and `supportedGames`.
- Kept the shared Game3 Repel counter, `StepEvents.onRepelStep`, `ItemUse.useField`, Choice and Message logic unchanged.
- Preserved the existing `pokemonmod_gen3_repel_reuse_prompt` id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.2

- Ported the mod from Gen 2 to FireRed / Gen 3.
- Switched from Gen 2 `World:repelWoreOff` / `World:useRepel` to native Gen 3
  `StepEvents`, `Bag`, and `ItemUse` APIs.
- Preserves FireRed's native wear-off message, then opens a YES/NO reuse prompt.
- Remembers the last Repel type used through the public `item.use` hook.
- Added MAX REPEL -> SUPER REPEL -> REPEL fallback when the preferred type is out.
- Added Gen 3-specific id and FireRed-only manifest targeting.
- Avoids rebuilding the Repel counter or unrelated step-event logic.
