# v1.2.0 Emerald native EXTRAS option contract

Expected integration:
- active profile is `emerald` / family `rse`
- lazy `pcall(require, "src.ui.game3.option_rows")`
- locate `Rows.GROUPS` entry with id `group.extras`
- append unique member id `pokemonmod_emerald_repel_mode`
- save current `Rows.build` as `previousBuild`
- wrapper calls `previousBuild(ctx)` first
- append row `{ id="pokemonmod_emerald_repel_mode", label="REPEL MODE", ... }`
- owner guard stored on the Rows module
- exported `optionsMenuInstalled == true` when installation succeeds

In Emerald:
START -> OPTION -> EXTRAS -> REPEL MODE
