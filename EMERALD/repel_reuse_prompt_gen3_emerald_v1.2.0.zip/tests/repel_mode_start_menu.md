# Legacy Start-menu regression note

The old standalone `REPEL MODE` Start-menu row is intentionally absent.
For the Emerald v1.2.0 port the setting lives at:

START -> OPTION -> EXTRAS -> REPEL MODE
