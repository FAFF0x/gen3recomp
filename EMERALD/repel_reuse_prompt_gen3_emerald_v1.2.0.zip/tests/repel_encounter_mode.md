# Emerald Repel encounter mode regression

- Mod loads only for profile `emerald` / family `rse`.
- Option `uncaught_repel` exists, is a toggle, and defaults to true.
- No active Repel: `encounter.roll` delegates unchanged.
- Active Repel + option ON + uncaught rolled species: encounter survives regardless of lead level.
- Active Repel + option ON + caught rolled species: encounter is suppressed.
- Active Repel + option OFF: every random walking encounter is suppressed.
- Repel counter is restored after every native RSE encounter roll, including errors.
- When a candidate is suppressed, Emerald's `_immunitySteps` is restored rather than treated as a completed battle.
- RSE terrain/rate/slot/level/ability/outbreak/roamer logic remains native.
- Fishing is not modified by this walking `encounter.roll` hook.
- Battle Pike / Battle Pyramid dedicated encounter flows remain native.
- Repel reuse prompt and fallback item order remain MAX REPEL -> SUPER REPEL -> REPEL.
