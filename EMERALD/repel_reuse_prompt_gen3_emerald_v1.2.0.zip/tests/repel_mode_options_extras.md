# v1.2.0 Emerald REPEL MODE Options / Extras regression

- [ ] Boot Pokémon Emerald with the mod enabled.
- [ ] Open Start -> Option: EXTRAS is present.
- [ ] Open EXTRAS: REPEL MODE is listed.
- [ ] REPEL MODE displays `UNCAUGHT` by default on a fresh mod save.
- [ ] LEFT/RIGHT or A changes the value between `UNCAUGHT` and `BLOCK ALL`.
- [ ] Close/reopen Options: the selected value remains.
- [ ] Restart Emerald: the selected value remains.
- [ ] UNCAUGHT filters already-caught species while Repel is active.
- [ ] UNCAUGHT allows uncaught species regardless of lead level.
- [ ] BLOCK ALL suppresses random walking encounters while Repel is active.
- [ ] With no active Repel, encounters are unchanged.
- [ ] Repel expiration first shows Emerald's native wear-off message, then the reuse prompt.
- [ ] Battle Pike / Battle Pyramid behavior remains native.
