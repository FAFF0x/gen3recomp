local source = debug.getinfo(1, "S").source:sub(2)
local root = source:match("^(.*)tests/") or ""
root = root:gsub("/$", "")
if root == "" then root = "." end

local optionValue = "classic"
local emitted = {}
local evAwards = {}
local friendshipAwards = {}
local nativeCalls = 0

local Experience = {
  MAX_LEVEL = 100,
  expYield = function() return 100 end,
  recipientOpts = function(_, mon)
    return { luckyEgg = mon.luckyEgg == true, traded = mon.traded == true }
  end,
  apply = function(mon, amount)
    mon.exp = (mon.exp or 0) + amount
    local levels = mon.forceLevel and { 11 } or {}
    return { gained = amount, levels = levels }
  end,
  awardFoe = function()
    nativeCalls = nativeCalls + 1
    return { native = true }
  end,
}

local Runtime = {
  wantsHook = function(name) return name == "exp.gain" end,
  call = function(name, nextFn, ctx)
    assert(name == "exp.gain")
    assert(ctx.expShare == false)
    assert(ctx.shareMode == optionValue)
    return nextFn()
  end,
  wants = function(name) return name == "battle.exp_gained" end,
  emit = function(name, payload)
    emitted[#emitted + 1] = { name = name, payload = payload }
  end,
}

local Pokemon = {
  FRIENDSHIP_EVENT_GROW_LEVEL = 0,
  gainEVs = function(mon, foeSpecies)
    evAwards[#evAwards + 1] = { mon = mon, foeSpecies = foeSpecies }
  end,
  adjustFriendship = function(mon, event, ctx)
    friendshipAwards[#friendshipAwards + 1] = { mon = mon, event = event, ctx = ctx }
  end,
  currentMapSec = function() return 42 end,
}

local State = {
  ownsSlot = function(st, id, pi)
    assert(id == 0)
    if st.playerHalf then return pi <= st.playerHalf end
    if st.partyOwner and st.partyOwner.player then return st.partyOwner.player[pi] == 0 end
    return true
  end,
}

package.preload["src.core.game3.battle.experience"] = function() return Experience end
package.preload["src.mods.Runtime"] = function() return Runtime end
package.preload["src.mods.Gen3Compat"] = function()
  return { speciesView = function(sp) return { speciesId = sp } end }
end
package.preload["src.core.game3.pokemon"] = function() return Pokemon end
package.preload["src.core.game3.battle.state"] = function() return State end
package.preload["src.core.game3.profile"] = function()
  return { forSession = function(session) return { id = session and session.version or "firered" } end }
end

local mod = {
  options = {
    define = function() end,
    get = function(_, key) assert(key == "mode"); return optionValue end,
  },
  exports = {},
  log = { info = function() end, warn = function() end },
  find = function() return nil end,
}

assert(loadfile(root .. "/main.lua"))()(mod)
assert(mod.exports.active == true)
assert(mod.exports.emeraldOnly == true)
assert(mod.exports.supportedGames[1] == "emerald" and #mod.exports.supportedGames == 1)
assert(Experience._pokemonmod_exp_share_modes_owner == "pokemonmod_gen3_exp_share_modes_emerald")

local function mon(hp, extra)
  local m = { hp = hp, level = 10, species = 1, exp = 0 }
  for k, v in pairs(extra or {}) do m[k] = v end
  return m
end

local function fixture(version)
  local party = {
    mon(20),
    mon(30),
    mon(0),
    mon(25),
    mon(20, { isEgg = true }),
    mon(20, { level = 100 }),
  }
  local st = {
    session = { version = version or "emerald" },
    wild = true,
    playerParty = party,
    player = { partyIndex = 1, mon = party[1] },
    battlers = {},
    absent = {},
  }
  local foe = { species = 16, level = 14, mon = { species = 16, level = 14 }, participants = { [1] = true, [3] = true } }
  return st, foe
end

local function byIndex(out)
  local b = {}
  for _, row in ipairs(out) do b[row.partyIndex] = row.amount end
  return b
end

-- calculated = floor(100 * 14 / 7) = 200
optionValue = "off"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 200, "off participant gets full pool")
  assert(by[2] == nil and by[3] == nil and by[4] == nil, "off excludes bench/fainted")
end

optionValue = "classic"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 50 and by[2] == 50 and by[4] == 50, "classic keeps source divisor semantics")
  assert(by[5] == nil and by[6] == nil, "egg and lv100 do not receive EXP")
end

optionValue = "modern"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 200, "modern participant gets participant pool")
  assert(by[2] == 33 and by[4] == 33, "modern bench splits 50 percent pool")
end

-- Emerald partner battle: slots 1-3 belong to player, 4-6 to partner.
optionValue = "classic"
do
  local st, foe = fixture()
  st.double = true
  st.playerHalf = 3
  st.battlers[2] = { partyIndex = 4, mon = st.playerParty[4] }
  foe.participants = { [1] = true, [4] = true }
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] ~= nil and by[2] ~= nil, "player half receives shared EXP")
  assert(by[4] == nil, "NPC partner half excluded")
end

-- Emerald multi-owner mapping is also respected.
do
  local st, foe = fixture()
  st.double = true
  st.multi = true
  st.partyOwner = { player = { [1]=0, [2]=0, [3]=0, [4]=2, [5]=2, [6]=2 } }
  foe.participants = { [1] = true, [4] = true }
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[4] == nil, "partyOwner partner slots excluded")
end

-- Per-recipient bonuses remain intact.
do
  local st, foe = fixture()
  st.wild = false
  st.playerParty[1].luckyEgg = true
  st.playerParty[1].traded = true
  local by = byIndex(Experience.awardFoe(st, foe, { trainer = true }))
  assert(by[1] == 168, "Lucky Egg + trainer + traded bonuses preserved")
end

-- Native Emerald side effects are restored.
do
  local beforeEV = #evAwards
  local beforeFriend = #friendshipAwards
  local st, foe = fixture()
  st.playerParty[1].forceLevel = true
  Experience.awardFoe(st, foe, {})
  assert(#evAwards > beforeEV, "EV gain applied to recipients")
  assert(#friendshipAwards == beforeFriend + 1, "level-up friendship applied")
  assert(friendshipAwards[#friendshipAwards].event == 0, "correct friendship event")
end

-- Non-Emerald runtime must fall back to native award function.
do
  local st, foe = fixture("firered")
  local before = nativeCalls
  local out = Experience.awardFoe(st, foe, {})
  assert(nativeCalls == before + 1 and out.native == true, "FireRed falls back to native")
end

assert(#emitted > 0, "battle.exp_gained events emitted")
print("PASS Emerald EXP distribution")
