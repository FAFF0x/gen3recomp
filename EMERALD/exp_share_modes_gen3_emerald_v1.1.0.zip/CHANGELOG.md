# Changelog

## 1.1.0 - Emerald conversion

- Converted the mod from FireRed/LeafGreen to Pokemon Emerald only.
- Added a dedicated Emerald mod ID and `games: ["emerald"]` target.
- Integrated EXP SHARE MODE with Emerald's RSE Options menu.
- Added an Emerald runtime guard around the EXP award override.
- Added correct ownership filtering for Emerald partner/multi battles so NPC partner Pokémon never receive the player's shared EXP.
- Restored native Game3 EV gains for every EXP recipient.
- Restored friendship increases on level-up.
- Preserved double-battle battler refresh, EXP hooks, Lucky Egg/trainer/traded bonuses and level-up result data.

## 1.0.3 - FireRed/LeafGreen source version

- Previous FRLG build used as the base for this Emerald port.
