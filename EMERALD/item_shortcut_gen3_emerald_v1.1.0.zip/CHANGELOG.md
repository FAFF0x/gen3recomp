# Changelog

## 1.1.0 - Emerald-only conversion
- Converted the mod target from FireRed/LeafGreen to Pokemon Emerald only.
- Assigned the standalone mod id `pokemonmod_gen3_item_shortcut_emerald` so it can coexist with the FRLG package.
- Added a runtime Emerald profile guard for forced/manual installs.
- Applies `ItemsData.applyProfile("emerald")` before BAG enumeration so Emerald pocket order and capacities are active before the first hotkey use.
- Replaced FRLG item-icon rendering with `src.ui.game3.rse.bag_chrome` and the Emerald/RSE vertical 24x24 item atlas.
- Removed the FRLG VS Seeker post-use branch; Emerald field items use the profile-aware shared ItemUse implementation.
- Changed the custom presenter to an Emerald green/teal/gold visual treatment.
- Added a dedicated Emerald stack/runtime owner key and Emerald-only equivalent-mod detection.
- Kept the profile-aware shared Party Menu and Start-menu hook so Emerald-specific menu composition remains owned by the runtime.
- Added `gen3_modern_ui_emerald` as an optional dependency and gave the custom HUD presenter deterministic high priority.

## 1.0.5
- Added LeafGreen support alongside FireRed.
- Updated `manifest.json` and `mod.card` compatibility targets to `firered` + `leafgreen`.
- Added explicit runtime `supportedGames` metadata for both FRLG games.
- Kept the shared Game3 BAG, Party Menu, item-use, Start-menu and Modern UI presenter logic unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.4
- Added a high-resolution window-space presenter for the custom `item_shortcut_gen3` stack id.
- Matched Gen3 Modern UI's default Kanto palette: blue chrome, white surfaces, yellow selection, red accent and dark navy text.
- Main screen now uses a two-panel layout: five shortcut slots on the left and live selected-item details on the right.
- Added native FireRed item icons (when available), BAG quantity, pocket name, item description and a visible FAST badge.
- Restyled action selection, BAG item picker, control mapping, direct BAG assignment and input-capture screens.
- Kept the v1.0.3 FireRed stack/input contract unchanged.
- Added a `render.hud` presentation hook; underlying native UI remains only as a safe fallback.

## 1.0.3
- Fixed the invisible modal menu on FireRed: Game3 stack callbacks are now plain `draw()` / `handleInput(input)` functions, matching the actual runtime contract.
- Fixed the symptom where opening Item Shortcut froze field input while rendering nothing.
- Verified the custom stack id is intentionally ignored by `gen3_modern_ui`'s presenter list, so Modern UI no longer needs to own this screen; the native Game3 stack renders Item Shortcut correctly beneath the window-space overlay chain.
- Updated regression tests so `draw()` is called with zero arguments, exactly as `src/core/game3/gfx.lua` does.
- Keeps v1.0.2 deferred hotkey opening and the `ITEM SHORTCUT` Start-menu fallback.

## 1.0.2
- Deferred raw I/Y and K/X actions to the next `input.step` tick.
- Added `ITEM SHORTCUT` to the FireRed Start menu as a guaranteed fallback route.

## 1.0.1
- Initial FireRed-only port from the Gen2 package.
