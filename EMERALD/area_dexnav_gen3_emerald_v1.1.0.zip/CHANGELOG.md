# Changelog

## 1.1.0 — Emerald conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Added dedicated mod id `area_dexnav_gen3_emerald` to avoid collisions with the FR/LG package.
- Added runtime Emerald profile gating in addition to the manifest target.
- Switched test/reference maps to Emerald `EM_*` map ids.
- Preserved Emerald's native 12-slot land and 5-slot water encounter weighting.
- Added Emerald underwater handling: underwater maps select their water encounter table.
- Added Safari Zone guard so DexNav cannot bypass Emerald's Safari battle controller.
- Added Battle Pyramid/Pike guards for their special wild encounter flows.
- Added the Sootopolis legendary-story water encounter block.
- Retained the simple Area DexNav design: normal LAND/WATER species only; no outbreak, roamer, Feebas fishing, Rock Smash or fishing injection.
- Updated exports, logging and documentation for Emerald.

## 1.0.2

- Original FireRed/LeafGreen Gen 3 release.
