local script = (arg and arg[0]) or "tests/area_dexnav_gen3_emerald_test.lua"
local root = script:match("^(.*)[/\\]") or "tests"
local mainPath = root .. "/../main.lua"

local FLAG_SYS_SAFARI_MODE = 1001
local FLAG_LEGENDARIES_IN_SOOTOPOLIS = 1002

local state = {
  session = {
    version = "emerald",
    party = { { species = 1, hp = 20 } },
    dex = { seen = {}, caught = { [19] = true }, owned = {} },
    flags = {},
  },
  surfing = false,
  underwater = false,
  mapId = "EM_ROUTE101",
}

package.preload["src.core.game3.runtime"] = function()
  return { getSession = function() return state.session end }
end
package.preload["src.core.game3.profile"] = function()
  return {
    forSession = function(s) return { id = s and s.version or "firered", family = s and s.version == "emerald" and "rse" or "frlg" } end,
  }
end
package.preload["src.core.game3.constants"] = function()
  return {
    of = function(id)
      assert(id == "emerald")
      return {
        require = function(_, group, name)
          assert(group == "flags")
          if name == "FLAG_SYS_SAFARI_MODE" then return FLAG_SYS_SAFARI_MODE end
          if name == "FLAG_LEGENDARIES_IN_SOOTOPOLIS" then return FLAG_LEGENDARIES_IN_SOOTOPOLIS end
          error("unknown flag " .. tostring(name))
        end,
      }
    end,
  }
end
package.preload["src.core.game3.scripting.flags"] = function()
  return {
    getFlag = function(s, _, id) return s and s.flags and s.flags[id] == true end,
  }
end
package.preload["src.core.game3.player"] = function()
  return setmetatable({ moving = false, action = nil, fishing = false, fieldMoveAnim = 0 }, { __index = function(_, k)
    if k == "surfing" then return state.surfing end
    if k == "underwater" then return state.underwater end
  end })
end
package.preload["src.core.game3.pokemon"] = function()
  local byName = { WURMPLE=290, POOCHYENA=261, ZIGZAGOON=263, TENTACOOL=72, CLAMPERL=366 }
  return { speciesFromName = function(n) return byName[n] end }
end
package.preload["src.core.game3.dex"] = function()
  return {
    isCaught = function(dex, species)
      return (dex.caught and dex.caught[species]) == true or (dex.owned and dex.owned[species]) == true
    end,
  }
end
package.preload["src.ui.game3.hud"] = function()
  return {
    busy = function() return false end,
    openMessage = function(game, text) game.said = text end,
  }
end
package.preload["src.core.game3.field"] = function() return { locked = false } end
package.preload["src.core.game3.battle"] = function() return { isActive = function() return false end } end
package.preload["src.core.game3.rng"] = function() return { Random = function() return 0 end } end
package.preload["src.core.game3.rse.frontier.pyramid"] = function() return { FLOOR_MAP = "EM_BATTLE_PYRAMID_FLOOR" } end
package.preload["src.core.game3.rse.frontier.pike"] = function() return { WILD_ROOM = "EM_BATTLE_PIKE_WILD_ROOM" } end

local encounters = {
  EM_ROUTE101 = {
    land = { rate = 20, slots = {
      { species="WURMPLE", minLevel=2, maxLevel=3 },
      { species="WURMPLE", minLevel=2, maxLevel=4 },
      { species=19, minLevel=2, maxLevel=3 },
      { species=19, minLevel=2, maxLevel=4 },
      { species="WURMPLE", minLevel=3, maxLevel=5 },
      { species=19, minLevel=3, maxLevel=5 },
      { species="WURMPLE", minLevel=4, maxLevel=5 },
      { species=19, minLevel=4, maxLevel=5 },
      { species="WURMPLE", minLevel=5, maxLevel=5 },
      { species=19, minLevel=5, maxLevel=5 },
      { species="WURMPLE", minLevel=5, maxLevel=5 },
      { species=19, minLevel=5, maxLevel=5 },
    }},
    water = { rate = 10, slots = {
      { species="TENTACOOL", minLevel=10, maxLevel=15 },
      { species="TENTACOOL", minLevel=15, maxLevel=20 },
      { species="CLAMPERL", minLevel=20, maxLevel=20 },
      { species="TENTACOOL", minLevel=25, maxLevel=25 },
      { species="CLAMPERL", minLevel=30, maxLevel=30 },
    }},
  },
  EM_UNDERWATER_ROUTE124 = {
    water = { rate = 4, slots = {
      { species="CLAMPERL", minLevel=20, maxLevel=30 },
      { species="TENTACOOL", minLevel=20, maxLevel=30 },
      { species="CLAMPERL", minLevel=30, maxLevel=35 },
      { species="TENTACOOL", minLevel=30, maxLevel=35 },
      { species="CLAMPERL", minLevel=30, maxLevel=35 },
    }},
  },
  EM_SOOTOPOLIS_CITY = {
    water = { rate = 4, slots = {
      { species="TENTACOOL", minLevel=20, maxLevel=30 },
      { species="TENTACOOL", minLevel=20, maxLevel=30 },
      { species="CLAMPERL", minLevel=30, maxLevel=35 },
      { species="CLAMPERL", minLevel=30, maxLevel=35 },
      { species="CLAMPERL", minLevel=30, maxLevel=35 },
    }},
  },
}

local inputPressed = false
local hook
local started
local mod = {
  id = "area_dexnav_gen3_emerald",
  generation = 3,
  exports = {},
  content = { encounters = { get = function(_, id) return encounters[id] end } },
  world = {
    current = function() return { mapId = state.mapId } end,
    startWildBattle = function(_, species, level)
      started = { species = species, level = level }
      return true
    end,
  },
  hooks = { wrap = function(_, name, fn) if name == "input.step" then hook = fn end end },
  log = {
    info = function() end,
    warn = function() end,
    error = function(_, msg) error(msg) end,
  },
}

local init = assert(loadfile(mainPath))()
init(mod)
assert(type(hook) == "function", "input.step hook installed")
assert(mod.exports.version == "1.1.0", "Emerald version export")
assert(#mod.exports.supportedGames == 1 and mod.exports.supportedGames[1] == "emerald", "Emerald-only export")

local rows, terrain, mapId = mod.exports.candidates()
assert(terrain == "land" and mapId == "EM_ROUTE101", "Emerald land map selected")
assert(#rows == 6, "caught species slots removed, six Wurmple slots remain")
for _, r in ipairs(rows) do assert(r.species == 290, "only uncaught Wurmple survives") end
local target = mod.exports.pickTarget(nil, function() return 0 end)
assert(target.species == 290 and target.level == 2, "weighted target and min level")

state.surfing = true
state.session.dex.caught[72] = true
local waterRows, waterTerrain = mod.exports.candidates()
assert(waterTerrain == "water", "Surf selects Emerald water table")
assert(#waterRows == 2, "caught Tentacool water slots removed")
for _, r in ipairs(waterRows) do assert(r.species == 366, "only uncaught Clamperl remains") end

state.surfing = false
state.underwater = true
state.mapId = "EM_UNDERWATER_ROUTE124"
local underRows, underTerrain = mod.exports.candidates()
assert(underTerrain == "water", "underwater selects water table")
assert(#underRows > 0, "underwater Emerald table is usable")

state.underwater = false
state.mapId = "EM_ROUTE101"
state.session.dex.caught[290] = nil
local game = {
  phase = "field",
  input = { wasPressed = function(_, key) return key == "select" and inputPressed end },
}
inputPressed = true
hook(function() end, game, 1/60)
assert(started and started.species == 290, "SELECT starts an Emerald wild battle")

state.session.dex.caught[290] = true
started = nil
game.said = nil
hook(function() end, game, 1/60)
assert(started == nil and game.said and game.said:find("caught", 1, true), "complete area message")

state.session.dex.caught[290] = nil
state.session.flags[FLAG_SYS_SAFARI_MODE] = true
started = nil
game.said = nil
hook(function() end, game, 1/60)
assert(started == nil and game.said and game.said:find("can't", 1, true), "Safari mode is blocked")
state.session.flags[FLAG_SYS_SAFARI_MODE] = nil

state.mapId = "EM_SOOTOPOLIS_CITY"
state.surfing = true
state.session.flags[FLAG_LEGENDARIES_IN_SOOTOPOLIS] = true
local blocked, _, _, reason = mod.exports.candidates()
assert(#blocked == 0 and reason == "story_block", "Sootopolis story water block respected")
state.session.flags[FLAG_LEGENDARIES_IN_SOOTOPOLIS] = nil
state.surfing = false

state.mapId = "EM_BATTLE_PYRAMID_FLOOR"
local frontier, _, _, fReason = mod.exports.candidates()
assert(#frontier == 0 and fReason == "frontier", "Battle Pyramid special encounters are protected")

state.session.version = "firered"
state.mapId = "EM_ROUTE101"
local wrong, _, _, wrongReason = mod.exports.candidates()
assert(#wrong == 0 and wrongReason == "wrong_game", "runtime guard rejects non-Emerald sessions")

print("area_dexnav_gen3_emerald_test: ok")
