-- HM & Field TM Anywhere - Gen 3 / Emerald v2.2.1
-- Emerald/RSE-only conversion of the native Game3 HM Anywhere mod.

local HM_ROWS = {
  { item = 339, move = "CUT",        label = "CUT" },       -- HM01
  { item = 340, move = "FLY",        label = "FLY" },       -- HM02
  { item = 341, move = "SURF",       label = "SURF" },      -- HM03
  { item = 342, move = "STRENGTH",   label = "STRENGTH" },  -- HM04
  { item = 343, move = "FLASH",      label = "FLASH" },     -- HM05
  { item = 344, move = "ROCK_SMASH", label = "ROCK SMASH" },-- HM06
  { item = 345, move = "WATERFALL",  label = "WATERFALL" }, -- HM07
  { item = 346, move = "DIVE",       label = "DIVE" },      -- HM08 (Emerald/RSE)
}

-- Emerald field TMs handled by the native RSE field-move engine.
local TM_ROWS = {
  { item = 316, move = "DIG",          label = "DIG" },          -- TM28
  { item = 331, move = "SECRET_POWER", label = "SECRET POWER" }, -- TM43
}

local DEVICE_MON = {
  nickname = "FIELD DEVICE",
  name = "FIELD DEVICE",
  species = 25,
  speciesId = 25,
  level = 5,
  hp = 1,
  maxHp = 1,
  moves = {},
}

-- Use the mod loader's permitted require API. The mod sandbox deliberately
-- does not expose the global module cache, even with engine_internals.
local function optionalModule(name)
  local ok, module = pcall(require, name)
  return ok and type(module) == "table" and module or nil
end

local function runtimeSession()
  local Runtime = optionalModule("src.core.game3.runtime")
  return Runtime and Runtime.getSession and Runtime.getSession() or nil
end

local function runtimeGame()
  local Runtime = optionalModule("src.core.game3.runtime")
  return Runtime and Runtime._game or nil
end

local function isEmerald(session)
  session = session or runtimeSession()
  if type(session) == "table" and session.version == "emerald" then return true end
  local ok, Profile = pcall(require, "src.core.game3.profile")
  if not (ok and Profile and Profile.forSession) then return false end
  local okP, row = pcall(Profile.forSession, session)
  return okP and type(row) == "table" and row.id == "emerald"
end

local function contextualEnabled(mod)
  return mod.save:get("contextualActions", true) ~= false
end

local function setContextual(mod, enabled)
  mod.save:set("contextualActions", enabled and true or false)
end

local function bagHas(session, itemId)
  if not (session and session.bag) then return false end
  local ok, Bag = pcall(require, "src.core.game3.bag")
  return ok and Bag and Bag.has and Bag.has(session.bag, itemId, 1) == true
end

local function rowForMove(move)
  local FieldMoves = require("src.core.game3.field_moves")
  local target = FieldMoves.normalizeMoveId(move)
  for _, row in ipairs(HM_ROWS) do
    if FieldMoves.normalizeMoveId(row.move) == target then return row, "hm" end
  end
  for _, row in ipairs(TM_ROWS) do
    if FieldMoves.normalizeMoveId(row.move) == target then return row, "tm" end
  end
  return nil
end

local function ownsMove(session, move)
  local row = rowForMove(move)
  return row and bagHas(session, row.item) or false
end

local function helperMon(party)
  for i, mon in ipairs(party or {}) do
    if type(mon) == "table" and not mon.isEgg and not mon.egg then
      return mon, i - 1
    end
  end
  return DEVICE_MON, 6
end

local function currentMapId(session)
  local Map = optionalModule("src.core.game3.map")
  return tostring((session and session.map) or (Map and Map.current) or "")
end

local function isCaveMap(mapId, mapDef)
  local u = tostring(mapId or ""):upper()
  local mt = mapDef and tonumber(mapDef.mapType or mapDef.type)
  if mt == 4 then return true end -- MAP_TYPE_UNDERGROUND
  return u:find("CAVE", 1, true) ~= nil
      or u:find("TUNNEL", 1, true) ~= nil
      or u:find("VICTORY_ROAD", 1, true) ~= nil
      or u:find("METEOR_FALLS", 1, true) ~= nil
      or u:find("SEAFLOOR", 1, true) ~= nil
      or u:find("SHOAL", 1, true) ~= nil
end

local function buildContext(session, mon)
  local P = require("src.core.game3.player")
  local C = require("src.core.game3.collision")
  local Objects = require("src.core.game3.objects")
  local Map = require("src.core.game3.map")
  local FieldMoves = require("src.core.game3.field_moves")
  local Space = optionalModule("src.core.game3.scripting.space")
  local Flags = require("src.core.game3.scripting.flags")
  local d = ({ up={0,-1}, down={0,1}, left={-1,0}, right={1,0} })[P.facing or "down"] or {0,1}
  local px, py = P.cellX or 0, P.cellY or 0
  local fx, fy = px + d[1], py + d[2]
  local mapDef = Map.currentDef and Map.currentDef() or nil
  local mapId = currentMapId(session)
  local beh = C.behavior and C.behavior(fx, fy) or nil
  local cave = isCaveMap(mapId, mapDef)
  local elev = C.elevationAt and C.elevationAt(px, py) or (P.currentElevation or P.elevation or 0)
  local store = Space and Space.store
  local flashFlag = FieldMoves.SYS_FLAGS.FLASH_ACTIVE
  local flashActive = store and flashFlag and Flags.getFlag(store, nil, flashFlag) == true or false

  local query = nil
  if C.behavior and C.elevationAt then
    query = {
      x = px, y = py, elevation = elev,
      behavior = function(x, y) return C.behavior(x, y) end,
      elevationAt = function(x, y) return C.elevationAt(x, y) end,
      impassable = function(x, y)
        local walk = C.isWalkable and C.isWalkable(x, y)
        local water = C.isWater and C.isWater(x, y)
        return not (walk or water)
      end,
    }
  end

  local hyper = false
  if mon and mon.species then
    local okP, Pokemon = pcall(require, "src.core.game3.pokemon")
    local okK, Constants = pcall(require, "src.core.game3.constants")
    if okP and okK and Pokemon and Constants then
      local okA, ability = pcall(Pokemon.abilityId, mon.species, mon.personality)
      local okC, ec = pcall(Constants.of, "emerald")
      local hc = okC and ec and ec.abilities and ec.abilities.byName and ec.abilities.byName.ABILITY_HYPER_CUTTER
      hyper = okA and hc ~= nil and ability == hc
    end
  end

  return {
    party = session and session.party or {},
    mon = mon,
    store = store,
    session = session,
    mapId = mapId,
    x = px,
    y = py,
    facingObject = Objects.at and Objects.at(fx, fy) or nil,
    isFacingWater = (C.isWater and C.isWater(fx, fy)) or (C.isSurfable and C.isSurfable(beh)) or false,
    isSurfing = P.surfing == true,
    isUnderwater = P.underwater == true,
    hasCuttableGrass = C.isGrass and (C.isGrass(fx, fy) or C.isGrass(px, py)) or false,
    cutGrassQuery = query,
    hyperCutter = hyper,
    mapType = mapDef and (mapDef.mapType or mapDef.type),
    isCave = cave,
    isDarkCave = cave,
    isFlashActive = flashActive,
    canEscapeRope = cave,
    escapeWarp = session and session.escapeWarp,
    isFacingWaterfall = FieldMoves.isWaterfallBehavior and FieldMoves.isWaterfallBehavior(beh) or false,
    facing = P.facing or "down",
  }
end

local Menu = {
  open = false,
  kind = "hm",
  mode = "list",
  cursor = 1,
  scroll = 0,
  rows = {},
  items = {},
  title = "HM ANYWHERE",
  footer = "A USE  B BACK",
  screenId = "HmAnywhereEmerald",
  message = nil,
}

-- Present the custom HM/TM controller through the native Game3 `option`
-- surface.  Modern UI Gen3 already owns a presenter for that surface, while
-- the Stack still dispatches input/draw/update to `Menu` itself.  This keeps
-- the working HM logic independent from Modern UI and gives us a native
-- fallback when Modern UI is not installed.
local function menuLayerId()
  return "option"
end

local function optionMenuModule(session)
  local okS, Screens = pcall(require, "src.ui.game3.screens")
  if okS and Screens and Screens.get then
    local okO, O = pcall(Screens.get, "option", session or Menu.session or runtimeSession())
    if okO and O then return O end
  end
  return optionalModule("src.ui.game3.rse.option_menu")
    or optionalModule("src.ui.game3.option_menu")
end

local function saveOptionPresenterState()
  local O = optionMenuModule(Menu.session)
  if not O or Menu._optionPresenterSaved then return end
  if type(O._st) == "table" then
    local st = O._st
    Menu._optionPresenterSaved = {
      kind = "rse", module = O, cursor = O.cursor,
      ctx = st.ctx, pages = st.pages, onClose = st.onClose, k = st.k,
    }
  else
    Menu._optionPresenterSaved = {
      kind = "frlg", module = O,
      open = O.open, cursor = O.cursor, pages = O._pages, ctx = O._ctx,
      flat = O._flat, session = O._session, game = O._game, onClose = O._onClose,
    }
  end
end

local function restoreOptionPresenterState()
  local s = Menu._optionPresenterSaved
  local O = s and s.module or optionMenuModule(Menu.session)
  if not (O and s) then Menu._optionPresenterSaved = nil; return end
  if s.kind == "rse" and type(O._st) == "table" then
    O.cursor = s.cursor
    O._st.ctx, O._st.pages, O._st.onClose, O._st.k = s.ctx, s.pages, s.onClose, s.k
  else
    O.open, O.cursor, O._pages, O._ctx = s.open, s.cursor, s.pages, s.ctx
    O._flat, O._session, O._game, O._onClose = s.flat, s.session, s.game, s.onClose
  end
  Menu._optionPresenterSaved = nil
end

local function syncOptionPresenter()
  local O = optionMenuModule(Menu.session)
  if not O or not Menu.open then return end
  local pageRows = {}
  local count = math.max(0, #Menu.rows - 1) -- native presenters provide their own cancel/back affordance.
  for i = 1, count do
    local src = Menu.rows[i]
    local value = ""
    if src.id == "CONTEXT" then
      value = contextualEnabled(Menu.mod) and "ON" or "OFF"
    elseif not src.disabled and src.move then
      value = "USE"
    end
    local shown = tostring(src.label or src.id or "OPTION")
    if src.id == "CONTEXT" then shown = "CONTEXT ACTIONS" end
    pageRows[#pageRows + 1] = {
      id = src.id, label = shown,
      value = function() return value end,
    }
  end
  local scroll = Menu.scroll or 0
  O.cursor = Menu.cursor or 1
  if type(O._st) == "table" then
    O._st.ctx = { session = Menu.session, game = Menu.game, options = {} }
    O._st.pages = {{
      title = Menu.title or "HM ANYWHERE", rows = pageRows,
      index = Menu.cursor or 1, scroll = scroll,
    }}
    O._st.k = O._st.k or 0
  else
    O.open = true
    O._session = Menu.session
    O._game = Menu.game
    O._ctx = { session = Menu.session, game = Menu.game, options = {} }
    O._pages = {{
      title = Menu.title or "HM ANYWHERE", rows = pageRows,
      index = Menu.cursor or 1, scroll = scroll,
    }}
  end
end

local function rebuildRows(mod)
  local session = Menu.session or runtimeSession()
  local src = Menu.kind == "tm" and TM_ROWS or HM_ROWS
  local rows = {}
  for _, row in ipairs(src) do
    if bagHas(session, row.item) then
      rows[#rows + 1] = { id=row.move, move=row.move, label=row.label, item=row.item }
    end
  end
  if #rows == 0 then
    rows[#rows + 1] = {
      id = "EMPTY",
      label = Menu.kind == "tm" and "NO OWNED FIELD TM" or "NO OWNED HM",
      disabled = true,
    }
  end
  rows[#rows + 1] = {
    id="CONTEXT",
    label=contextualEnabled(mod) and "CONTEXT: ON" or "CONTEXT: OFF",
  }
  rows[#rows + 1] = { id="CANCEL", label="CANCEL" }
  Menu.rows, Menu.items = rows, rows
  if Menu.cursor < 1 then Menu.cursor = 1 end
  if Menu.cursor > #rows then Menu.cursor = #rows end
  syncOptionPresenter()
end

function Menu.show(kind, game, session, mod)
  Menu.open = true
  Menu.kind = kind == "tm" and "tm" or "hm"
  Menu.mode = "list"
  Menu.cursor = 1
  Menu.scroll = 0
  Menu.game = game or runtimeGame()
  Menu.session = session or runtimeSession()
  Menu.mod = mod
  Menu.message = nil
  Menu.title = Menu.kind == "tm" and "TM ANYWHERE" or "HM ANYWHERE"
  Menu.screenId = Menu.kind == "tm" and "TmAnywhereEmerald" or "HmAnywhereEmerald"
  saveOptionPresenterState()
  rebuildRows(mod)
  local Stack = require("src.ui.game3.stack")
  Stack.push(menuLayerId(), Menu, { hideBelow = true })
  syncOptionPresenter()
end

function Menu.close()
  if not Menu.open then return end
  local Stack = require("src.ui.game3.stack")
  Stack.pop(menuLayerId())
  Menu.open = false
  Menu.mode = "list"
  Menu.message = nil
  restoreOptionPresenterState()
end

local function closeToField()
  Menu.close()
  local StartMenu = optionalModule("src.ui.game3.start_menu")
  if StartMenu and StartMenu.isOpen and StartMenu.isOpen() then StartMenu.close(true) end
end

local function setMessage(text)
  text = tostring(text or "Can't use that here.")
  local ok, Message = pcall(require, "src.ui.game3.message")
  if ok and Message and Message.show then
    Message.show(text, function()
      if Message.close then Message.close() end
      syncOptionPresenter()
    end)
    return
  end
  Menu.message = text
end

local function useMove(row)
  if not row or not row.move then return end
  local session = Menu.session or runtimeSession()
  if not session then setMessage("Field data is unavailable."); return end
  if not isEmerald(session) then setMessage("This mod requires Pokemon Emerald."); return end
  if not ownsMove(session, row.move) then
    setMessage("You need the matching HM or TM in your Bag."); return
  end
  local FieldMoves = require("src.core.game3.field_moves")
  local mon = helperMon(session.party)
  local ok, res = pcall(function()
    return FieldMoves.fromMenu(row.move, buildContext(session, mon))
  end)
  if not ok then
    Menu.mod.log:warn("HM Anywhere %s failed: %s", row.move, tostring(res))
    setMessage("Field move failed. See the mod log for details."); return
  end
  if not (res and res.ok) then
    setMessage((res and res.text) or FieldMoves.TEXT.CANT_USE_HERE)
    return
  end
  closeToField()
  local Field = require("src.core.game3.field")
  if Field.executeFieldMove then Field.executeFieldMove(res) end
end

function Menu.handleInput(input)
  if not Menu.open or not input then return end
  if Menu.message then
    if input:wasPressed("a") or input:wasPressed("b") or input:wasPressed("start") then
      Menu.message = nil
    end
    return
  end
  local n = #Menu.rows
  if n < 1 then return end
  if input:wasPressed("up") then
    Menu.cursor = ((Menu.cursor - 2) % n) + 1
  elseif input:wasPressed("down") then
    Menu.cursor = (Menu.cursor % n) + 1
  elseif input:wasPressed("b") then
    Menu.close()
  elseif input:wasPressed("a") or input:wasPressed("start") then
    local row = Menu.rows[Menu.cursor]
    if row and row.id == "CANCEL" then
      Menu.close()
    elseif row and row.id == "CONTEXT" then
      setContextual(Menu.mod, not contextualEnabled(Menu.mod))
      rebuildRows(Menu.mod)
    else
      useMove(row)
    end
  end
  if Menu.open then syncOptionPresenter() end
end

function Menu.update()
  if Menu.open then syncOptionPresenter() end
end

local function clampScroll()
  local visible = 7
  local n = #Menu.rows
  if n <= visible then Menu.scroll = 0; return end
  if Menu.cursor - 1 < Menu.scroll then Menu.scroll = Menu.cursor - 1 end
  if Menu.cursor > Menu.scroll + visible then Menu.scroll = Menu.cursor - visible end
  if Menu.scroll < 0 then Menu.scroll = 0 end
  if Menu.scroll > n - visible then Menu.scroll = n - visible end
end

function Menu.draw()
  if not Menu.open then return end
  local Window = require("src.ui.game3.window")
  local FrlgFont = require("src.ui.game3.frlg_font")
  local Chrome = require("src.ui.game3.chrome")
  clampScroll()
  love.graphics.setColor(0.10, 0.38, 0.32, 1)
  love.graphics.rectangle("fill", 0, 0, 240, 160)
  love.graphics.setColor(1,1,1,1)
  Chrome.fixedStdFrame(2, 1, 26, 2)
  Window.printPx(Menu.title, 24, 10, { colors=FrlgFont.COLOR.NORMAL })
  Window.stdFrame(Window.template(4, 5, 22, 12))
  local visible = 7
  for slot=1, visible do
    local idx = Menu.scroll + slot
    local row = Menu.rows[idx]
    if not row then break end
    local y = 44 + (slot-1)*14
    if idx == Menu.cursor then Window.cursorPx(36, y) end
    Window.printPx(row.label or row.id or "?", 48, y, { colors=FrlgFont.COLOR.NORMAL })
  end
  FrlgFont.draw("A USE   B BACK", 48, 145, {
    colors=FrlgFont.COLOR.WHITE,
  })
  if Menu.message then
    Chrome.dialogueFrame()
    FrlgFont.draw(FrlgFont.wrap(Menu.message, 200), 20, 122, {
      maxWidth=200, linePitch=14, colors=FrlgFont.COLOR.NORMAL,
    })
  end
end

return function(mod)
  -- Emerald uses the shared Game3 field-move engine with RSE profile behavior.
  local FieldMoves = require("src.core.game3.field_moves")

  -- One patch owner per runtime. If an equivalent Gen3 mod patched the same
  -- seam first, do not stack a second ownership substitution.
  if not FieldMoves.__hmAnywhereEmeraldOriginalPartyMoveUser then
    local original = FieldMoves.partyMoveUser
    FieldMoves.__hmAnywhereEmeraldOriginalPartyMoveUser = original
    FieldMoves.__hmAnywhereEmeraldOwner = mod.id
    FieldMoves.partyMoveUser = function(party, moveIdentifier)
      local mon, slot = original(party, moveIdentifier)
      if mon then return mon, slot end
      if not contextualEnabled(mod) then return nil, 6 end
      local session = runtimeSession()
      if not isEmerald(session) then return nil, 6 end
      if not ownsMove(session, moveIdentifier) then return nil, 6 end
      return helperMon(party)
    end
  elseif FieldMoves.__hmAnywhereEmeraldOwner ~= mod.id then
    mod.log:warn("Another Emerald HM Anywhere implementation already owns field-move substitution; contextual patch not duplicated.")
  end

  -- Emerald field scripts (Cut/Rock Smash/Strength/etc.) use the RSE
  -- `checkpartymove` script opcode instead of calling partyMoveUser directly.
  -- Let vanilla run first; only replace its "not found" result (slot 6) when
  -- CONTEXT is enabled and the matching HM/TM is actually owned.
  mod.hooks:wrap("script.command", function(next_, ctx, op, row)
    local result = next_(ctx, op, row)
    if op ~= "checkpartymove" or not contextualEnabled(mod) then return result end
    local session = runtimeSession()
    if not isEmerald(session) then return result end
    local moveId = type(row) == "table" and (row.move or row[1]) or nil
    if not ownsMove(session, moveId) then return result end

    local runner = ctx and (ctx.runner or ctx.vm)
    local Space = optionalModule("src.core.game3.scripting.space")
    local store = (runner and runner.store) or (Space and Space.store)
    local vmctx = runner and runner.ctx
    if not (store and vmctx) then return result end
    local Flags = require("src.core.game3.scripting.flags")
    local ScriptCtx = require("src.core.game3.scripting.ctx")
    local found = Flags.getVar(store, vmctx, ScriptCtx.VAR_RESULT)
    if tonumber(found) ~= 6 then return result end

    local mon, slot = helperMon(session and session.party or {})
    if slot == 6 then return result end -- scripts need a real party slot
    local sp = mon and tonumber(mon.species or mon.speciesId) or 0
    Flags.setVar(store, vmctx, ScriptCtx.VAR_RESULT, slot or 6)
    Flags.setVar(store, vmctx, 0x8004, sp)
    return result
  end, 0, "hm_anywhere_gen3_emerald_checkpartymove")

  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    local out = next_(game, items)
    if type(out) ~= "table" then return out end
    local session = (game and game.session) or runtimeSession()
    if not isEmerald(session) then return out end
    local StartMenu = optionalModule("src.ui.game3.start_menu")
    if StartMenu and StartMenu._kind and StartMenu._kind ~= "normal" then return out end
    local function hasEntry(id, label)
      for _, e in ipairs(out) do
        if e.id == id or tostring(e.label or ""):upper() == label then return true end
      end
      return false
    end
    local function insertBeforeSave(entry)
      local at = #out + 1
      for i,e in ipairs(out) do
        if e.id == "save" or tostring(e.label or ""):upper() == "SAVE" then at=i; break end
      end
      table.insert(out, at, entry)
    end
    -- Emerald normal START only. Safari/Link/Battle Pike/Battle Pyramid and
    -- other restricted RSE start-menu variants keep their native entry sets.
    if not hasEntry("hm_anywhere_gen3_emerald_hm", "HM") then
      insertBeforeSave({
        id="hm_anywhere_gen3_emerald_hm", label="HM",
        desc={ "Use owned HMs", "without teaching" },
        onSelect=function(selectedGame, selectedSession)
          Menu.show("hm", selectedGame or game, selectedSession or session or runtimeSession(), mod)
        end,
      })
    end
    if not hasEntry("hm_anywhere_gen3_emerald_tm", "TM") then
      insertBeforeSave({
        id="hm_anywhere_gen3_emerald_tm", label="TM",
        desc={ "Use field TMs", "without teaching" },
        onSelect=function(selectedGame, selectedSession)
          Menu.show("tm", selectedGame or game, selectedSession or session or runtimeSession(), mod)
        end,
      })
    end
    return out
  end, 0, "hm_anywhere_gen3_emerald_start")

  mod.events:on("game.ready", function()
    if isEmerald(runtimeSession()) then
      mod.log:info("HM & Field TM Anywhere Gen3 Emerald v2.2.1 ready; contextual actions %s",
        contextualEnabled(mod) and "ON" or "OFF")
    end
  end)

  mod.exports.ownedHM = function(move)
    local row, kind = rowForMove(move)
    return kind == "hm" and row and bagHas(runtimeSession(), row.item) or false
  end
  mod.exports.ownedTM = function(move)
    local row, kind = rowForMove(move)
    return kind == "tm" and row and bagHas(runtimeSession(), row.item) or false
  end
  mod.exports.contextualEnabled = function() return contextualEnabled(mod) end
  mod.exports.setContextual = function(v) setContextual(mod, v) end
  mod.exports.version = "2.2.1"
  mod.exports.supportedGames = { "emerald" }
  mod.exports.emeraldOnly = true
  mod.exports.rseRuntime = true
  mod.exports.ownedMoves = { hm = HM_ROWS, tm = TM_ROWS }
  mod.exports.isEmerald = isEmerald
end
