package.path = "./?.lua;./?/init.lua;" .. package.path

local function check(v, msg)
  if not v then error(msg or "check failed", 2) end
end
local function eq(a, b, msg)
  if a ~= b then error((msg or "not equal") .. ": got " .. tostring(a) .. ", want " .. tostring(b), 2) end
end

local session = {
  version = "emerald",
  bag = { [339] = 1, [346] = 1, [316] = 1, [331] = 1 },
  party = { { species = 25, hp = 20, moves = {} } },
}

package.loaded["src.core.game3.runtime"] = {
  getSession = function() return session end,
  _game = { session = session },
}
package.loaded["src.core.game3.profile"] = {
  forSession = function(s)
    s = s or session
    local id = s and s.version or "emerald"
    return { id = id, family = id == "emerald" and "rse" or "frlg" }
  end,
}
package.loaded["src.core.game3.bag"] = {
  has = function(bag, id, n) return (bag[id] or 0) >= (n or 1) end,
}

local moveIds = {
  CUT = 15, FLY = 19, SURF = 57, STRENGTH = 70, FLASH = 148,
  ROCK_SMASH = 249, WATERFALL = 127, DIVE = 291,
  DIG = 91, SECRET_POWER = 290,
}
local FieldMoves = {
  normalizeMoveId = function(m)
    if type(m) == "number" then return m end
    return moveIds[tostring(m):upper():gsub("%s+", "_")]
  end,
  partyMoveUser = function() return nil, 6 end,
  SYS_FLAGS = { FLASH_ACTIVE = 123 },
  isWaterfallBehavior = function() return false end,
  TEXT = { CANT_USE_HERE = "CAN'T USE HERE" },
}
package.loaded["src.core.game3.field_moves"] = FieldMoves

local store = {}
local Flags = {
  getVar = function(st, _, id) return st[id] end,
  setVar = function(st, _, id, v) st[id] = v end,
  getFlag = function(st, _, id) return st[id] == true end,
}
package.loaded["src.core.game3.scripting.space"] = { store = store }
package.loaded["src.core.game3.scripting.flags"] = Flags
package.loaded["src.core.game3.scripting.ctx"] = { VAR_RESULT = 0x800D }
package.loaded["src.ui.game3.start_menu"] = { _kind = "normal" }
local stackTop, pushCount, popCount
package.loaded["src.ui.game3.stack"] = {
  push = function(id, screen) stackTop = { id = id, screen = screen }; pushCount = (pushCount or 0) + 1 end,
  pop = function(id)
    if stackTop and stackTop.id == id then stackTop = nil end
    popCount = (popCount or 0) + 1
  end,
}

local saved, wraps, events = {}, {}, {}
local mod = {
  id = "hm_anywhere_gen3_emerald",
  save = {
    get = function(_, k, default)
      local v = saved[k]
      if v == nil then return default end
      return v
    end,
    set = function(_, k, v) saved[k] = v end,
  },
  hooks = {
    wrap = function(_, name, fn) wraps[name] = fn end,
  },
  events = {
    on = function(_, name, fn) events[name] = fn end,
  },
  log = { warn = function() end, info = function() end },
  exports = {},
}

-- Reproduce the mod sandbox: require is available, package is not.
local env = {}
for k, v in pairs(_G) do if k ~= "package" and k ~= "_G" then env[k] = v end end
env._G = env
local chunk
if setfenv then
  chunk = assert(loadfile("main.lua"))
  setfenv(chunk, env)
else
  chunk = assert(loadfile("main.lua", "t", env))
end
local install = chunk()
install(mod)

-- Contract / target
check(mod.exports.emeraldOnly == true, "Emerald-only export")
eq(mod.exports.version, "2.2.1", "version")
eq(#mod.exports.supportedGames, 1, "supported game count")
eq(mod.exports.supportedGames[1], "emerald", "supported game")
eq(#mod.exports.ownedMoves.hm, 8, "HM count")
eq(mod.exports.ownedMoves.hm[8].move, "DIVE", "HM08 is Dive")
eq(mod.exports.ownedMoves.hm[8].item, 346, "HM08 item")
eq(#mod.exports.ownedMoves.tm, 2, "field TM count")
eq(mod.exports.ownedMoves.tm[2].move, "SECRET_POWER", "TM43 Secret Power")
eq(mod.exports.ownedMoves.tm[2].item, 331, "TM43 item")

-- Contextual partyMoveUser: owned machine substitutes a helper mon only on Emerald.
local mon, slot = FieldMoves.partyMoveUser(session.party, "DIVE")
eq(mon, session.party[1], "context helper mon")
eq(slot, 0, "context helper slot")
setContext = mod.exports.setContextual
setContext(false)
mon, slot = FieldMoves.partyMoveUser(session.party, "DIVE")
eq(mon, nil, "context off mon")
eq(slot, 6, "context off slot")
setContext(true)
session.version = "firered"
mon, slot = FieldMoves.partyMoveUser(session.party, "DIVE")
eq(mon, nil, "FR runtime guarded mon")
eq(slot, 6, "FR runtime guarded slot")
session.version = "emerald"

-- Emerald script bridge: vanilla checkpartymove says not found (6); owned HM supplies helper slot.
check(type(wraps["script.command"]) == "function", "script.command hook registered")
store[0x800D], store[0x8004] = nil, nil
local ret = wraps["script.command"](
  function(_, op, row)
    eq(op, "checkpartymove", "script op forwarded")
    eq(row[1], moveIds.CUT, "script row forwarded")
    store[0x800D] = 6
    return "vanilla"
  end,
  { runner = { ctx = {} } }, "checkpartymove", { [1] = moveIds.CUT }
)
eq(ret, "vanilla", "script return preserved")
eq(store[0x800D], 0, "script bridge slot")
eq(store[0x8004], 25, "script bridge species")

-- Never replace a real vanilla move user.
store[0x800D], store[0x8004] = nil, nil
wraps["script.command"](
  function() store[0x800D] = 1; store[0x8004] = 7; return true end,
  { runner = { ctx = {} } }, "checkpartymove", { [1] = moveIds.CUT }
)
eq(store[0x800D], 1, "vanilla user preserved")
eq(store[0x8004], 7, "vanilla species preserved")

-- Unsupported/unowned move remains not found.
store[0x800D], store[0x8004] = nil, nil
wraps["script.command"](
  function() store[0x800D] = 6; return true end,
  { runner = { ctx = {} } }, "checkpartymove", { [1] = 999 }
)
eq(store[0x800D], 6, "unsupported move not substituted")

-- Context off also leaves script result alone.
setContext(false)
store[0x800D] = nil
wraps["script.command"](
  function() store[0x800D] = 6; return true end,
  { runner = { ctx = {} } }, "checkpartymove", { [1] = moveIds.CUT }
)
eq(store[0x800D], 6, "script respects context off")
setContext(true)

-- START menu: inject HM/TM only in Emerald's normal start menu, before SAVE.
check(type(wraps["ui.start_menu.items"]) == "function", "start-menu hook registered")
local StartMenu = package.loaded["src.ui.game3.start_menu"]
StartMenu._kind = "normal"
local items = {
  { id = "pokemon", label = "POKEMON" },
  { id = "bag", label = "BAG" },
  { id = "save", label = "SAVE" },
  { id = "option", label = "OPTION" },
  { id = "exit", label = "EXIT" },
}
local out = wraps["ui.start_menu.items"](function(_, t) return t end, { session = session }, items)
local pos = {}
for i, e in ipairs(out) do pos[e.id] = i end
check(pos.hm_anywhere_gen3_emerald_hm ~= nil, "HM start entry")
check(pos.hm_anywhere_gen3_emerald_tm ~= nil, "TM start entry")
check(pos.hm_anywhere_gen3_emerald_hm < pos.save, "HM before save")
check(pos.hm_anywhere_gen3_emerald_tm < pos.save, "TM before save")

-- The injected HM entry actually opens and closes the custom Emerald submenu.
local hmEntry = out[pos.hm_anywhere_gen3_emerald_hm]
check(type(hmEntry.onSelect) == "function", "HM entry callback")
hmEntry.onSelect({ session = session }, session)
check(stackTop and stackTop.id == "option", "HM menu pushed on option surface")
check(stackTop.screen and stackTop.screen.open == true, "HM menu opened")
local pressedB = {
  wasPressed = function(_, key) return key == "b" end,
}
stackTop.screen.handleInput(pressedB)
check(stackTop == nil, "HM menu closed")
check((pushCount or 0) >= 1 and (popCount or 0) >= 1, "stack push/pop")

-- Special RSE start menus are preserved unchanged.
StartMenu._kind = "safari"
local special = { { id = "retire", label = "RETIRE" }, { id = "exit", label = "EXIT" } }
local specialOut = wraps["ui.start_menu.items"](function(_, t) return t end, { session = session }, special)
eq(#specialOut, 2, "Safari menu unchanged")
for _, e in ipairs(specialOut) do
  check(e.id ~= "hm_anywhere_gen3_emerald_hm" and e.id ~= "hm_anywhere_gen3_emerald_tm", "no HM/TM in Safari")
end

-- Non-Emerald runtime never receives menu entries.
StartMenu._kind = "normal"
session.version = "firered"
local fr = { { id = "save", label = "SAVE" } }
local frOut = wraps["ui.start_menu.items"](function(_, t) return t end, { session = session }, fr)
eq(#frOut, 1, "FR menu unchanged")
eq(frOut[1].id, "save", "FR entry preserved")
session.version = "emerald"

print("contract-ok")
