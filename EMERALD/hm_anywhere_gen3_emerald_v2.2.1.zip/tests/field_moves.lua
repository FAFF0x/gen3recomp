-- Run from the mod directory:
-- lua tests/field_moves.lua /path/to/gen1recomp/src/core/game3/field_moves.lua
-- Uses the real field-move engine. ROM/map/UI dependencies are fixtures;
-- this does not simulate animations, collision execution or a running game.
local enginePath = assert(arg[1], "Pass the engine field_moves.lua path")
local checks = 0
local function eq(actual, expected, label)
  checks = checks + 1
  assert(actual == expected, label .. ": got " .. tostring(actual) .. ", expected " .. tostring(expected))
end
local function module(name, value) package.loaded[name] = value; return value end
local session = { version = "emerald", bag = {}, party = {{ species = 25, moves = {} }},
  map = "EM_ROUTE104", escapeWarp = { map = "EM_ROUTE104", x = 1, y = 2 } }
local Runtime = module("src.core.game3.runtime", { getSession = function() return session end })
local profile = { id = "emerald", family = "rse" }
module("src.core.game3.profile", { forSession = function() return profile end })
module("src.core.game3.bag", { has = function(bag, id) return (bag[id] or 0) > 0 end })
local badgeMoves = { "CUT", "FLASH", "ROCK_SMASH", "STRENGTH", "SURF", "FLY", "DIVE", "WATERFALL" }
local badgeRows = {}
for i, move in ipairs(badgeMoves) do badgeRows[i] = { fieldMove = move, flag = 0x866 + i } end
local ids = { FLAG_SYS_USE_FLASH = 0x888, FLAG_SYS_USE_STRENGTH = 0x880 }
local Flags = module("src.core.game3.scripting.flags", {
  forVersion = function() return { BADGES = badgeRows, IDS = ids } end,
  getFlag = function(store, _, id)
    return store and store.flags and (store.flags[id] == true or store.flags[tostring(id)] == true) or false
  end,
  getVar = function(_, ctx, id) return ctx and ctx.specialVars[id] or 0 end,
  setVar = function(_, ctx, id, value) if ctx then ctx.specialVars[id] = value end end,
})
local Space = module("src.core.game3.scripting.space", { store = { flags = {}, vars = {} } })
module("src.core.game3.scripting.ctx", { VAR_RESULT = 0x800D })
module("src.core.game3.rom_text", { ascii = function(key) return key end })
module("src.core.game3.se_ids", {})
module("src.core.game3.constants", {
  versionOf = function() return session.version end,
  of = function() return { abilities = { byName = {} } } end,
})
module("src.core.game3.pokemon", {
  abilityId = function() return 0 end, moveName = function(id) return tostring(id) end,
})
module("src.core.game3.braille_field", {
  shouldDoRegisteel = function() return false end, shouldDoRegirock = function() return false end,
})
module("src.core.game3.dive", { trySetDiveWarp = function() return 1, { map = "EM_UNDERWATER" } end })
module("src.import.gba.map_catalog", { pretToEngine = function(name) return name end })
local P = module("src.core.game3.player", { cellX = 5, cellY = 5, facing = "up" })
local mapDef = { mapType = 1 }
module("src.core.game3.map", { current = session.map, currentDef = function() return mapDef end })
local object, water, behavior
module("src.core.game3.objects", { at = function() return object end })
module("src.core.game3.collision", {
  behavior = function() return behavior end, elevationAt = function() return 0 end,
  isWater = function() return water end, isWalkable = function() return true end,
  isGrass = function() return false end,
})
local executed, lastMessage, top, startClosed
module("src.core.game3.field", { executeFieldMove = function(payload) executed = payload end })
module("src.ui.game3.message", { show = function(text) lastMessage = text end })
local Start = module("src.ui.game3.start_menu", {
  _kind = "normal", isOpen = function() return true end,
  close = function(silent) startClosed = silent end,
})
module("src.ui.game3.stack", {
  push = function(_, screen) top = screen end, pop = function() top = nil end,
})
local FieldMoves = module("src.core.game3.field_moves", assert(loadfile(enginePath))())
local wraps, saved = {}, {}
local mod = {
  id = "hm_anywhere_gen3_emerald", exports = {},
  save = {
    get = function(_, key, default) if saved[key] == nil then return default end; return saved[key] end,
    set = function(_, key, value) saved[key] = value end,
  },
  hooks = { wrap = function(_, name, fn) wraps[name] = fn end },
  events = { on = function() end },
  log = { warn = function(_, ...) error(string.format(...)) end, info = function() end },
}
local env = {}
for k, v in pairs(_G) do if k ~= "package" and k ~= "_G" then env[k] = v end end
env._G = env
local chunk
if setfenv then chunk = assert(loadfile("main.lua")); setfenv(chunk, env)
else chunk = assert(loadfile("main.lua", "t", env)) end
chunk()(mod)
eq(env.package, nil, "sandbox has no package global")

local function openMove(move)
  local rows = wraps["ui.start_menu.items"](function(_, items) return items end, { session = session }, {})
  rows[1].onSelect({ session = session }, session)
  for i, row in ipairs(top.rows) do if row.move == move then top.cursor = i; return end end
  error("missing HM row: " .. move)
end
local function pressA() top.handleInput({ wasPressed = function(_, key) return key == "a" end }) end
local actions = { CUT = "cut_tree", FLASH = "flash", ROCK_SMASH = "rock_smash",
  STRENGTH = "strength", SURF = "surf", FLY = "fly", DIVE = "dive", WATERFALL = "waterfall" }
local function contextFor(move)
  object, water, behavior = nil, false, 0
  P.surfing = false
  mapDef.mapType = 1
  if move == "CUT" then object = { gfx = FieldMoves.GFX_IDS.CUT_TREE } end
  if move == "ROCK_SMASH" then object = { gfx = FieldMoves.GFX_IDS.ROCK_SMASH_ROCK } end
  if move == "FLASH" then mapDef.mapType = 4 end
  if move == "SURF" then water = true end
  if move == "WATERFALL" then P.surfing = true; behavior = 0x13 end
end
for _, row in ipairs(mod.exports.ownedMoves.hm) do session.bag[row.item] = 1 end

-- Test all eight HM selections with the real fromMenu/hasBadge functions.
for i, move in ipairs(badgeMoves) do
  contextFor(move)
  Space.store.flags = {}
  executed, lastMessage = nil, nil
  openMove(move); pressA()
  eq(executed, nil, move .. " blocked without badge")
  eq(lastMessage, FieldMoves.TEXT.BADGE_REQUIRED, move .. " missing badge message")
  top.close()

  -- The wrong Emerald badge must not unlock this move.
  Space.store.flags[badgeRows[i % 8 + 1].flag] = true
  openMove(move); pressA()
  eq(executed, nil, move .. " blocked with wrong badge")
  top.close()

  Space.store.flags = { [tostring(badgeRows[i].flag)] = true }
  lastMessage = nil
  openMove(move); pressA()
  eq(executed and executed.action, actions[move], move .. " executes with correct badge")
  eq(executed and executed.mon, session.party[1], move .. " untrained helper")
  eq(lastMessage, nil, move .. " no error")
  eq(startClosed, true, move .. " closes START silently like native field-move flow")
  eq(#session.party[1].moves, 0, move .. " does not teach/modify moves")
end

-- Contextual script bridge must write the executing VM's special variables.
local vm = { store = { flags = {} }, ctx = { specialVars = {} } }
local function script(move)
  vm.ctx.specialVars = {}
  return wraps["script.command"](function()
    Flags.setVar(vm.store, vm.ctx, 0x800D, 6); return false
  end, { runner = vm }, "checkpartymove", { op = "checkpartymove", FieldMoves.MOVES[move] })
end
for _, move in ipairs(badgeMoves) do
  eq(script(move), false, move .. " script return preserved")
  eq(vm.ctx.specialVars[0x800D], 0, move .. " script helper slot")
  eq(vm.ctx.specialVars[0x8004], 25, move .. " script species")
end
session.bag[339] = nil
script("CUT")
eq(vm.ctx.specialVars[0x800D], 6, "no owned HM stays unavailable")
session.bag[339] = 1
mod.exports.setContextual(false)
script("CUT")
eq(vm.ctx.specialVars[0x800D], 6, "CONTEXT OFF respects learned moves")
mod.exports.setContextual(true)
local party = session.party
session.party = {}
script("CUT")
eq(vm.ctx.specialVars[0x800D], 6, "empty party supplies no invalid script slot")
eq(vm.ctx.specialVars[0x8004], nil, "empty party writes no fake species")
session.party = party

-- Valid location remains mandatory even with all badges.
for _, row in ipairs(badgeRows) do Space.store.flags[row.flag] = true end
local ow = { party = session.party, store = Space.store, session = session,
  facingObject = { gfx = FieldMoves.GFX_IDS.CUT_TREE } }
eq(FieldMoves.tryCutOW(ow).ok, true, "contextual Cut unlocked with HM and badge")
Space.store.flags = {}
eq(FieldMoves.tryCutOW(ow).ok, false, "contextual Cut blocked without badge")
Space.store.flags[badgeRows[1].flag] = true
session.bag[339] = nil
eq(FieldMoves.tryCutOW(ow).ok, false, "contextual Cut blocked without HM")
session.bag[339] = 1
mod.exports.setContextual(false)
eq(FieldMoves.tryCutOW(ow).ok, false, "contextual Cut respects CONTEXT OFF")
mod.exports.setContextual(true)
for _, row in ipairs(badgeRows) do Space.store.flags[row.flag] = true end
contextFor("FLY"); mapDef.mapType = 4
executed = nil; openMove("FLY"); pressA()
eq(executed, nil, "Fly blocked indoors"); top.close()
contextFor("SURF"); water = false
executed = nil; openMove("SURF"); pressA()
eq(executed, nil, "Surf blocked away from water"); top.close()

-- Stale menu selection must recheck actual bag ownership.
contextFor("CUT"); openMove("CUT"); session.bag[339] = nil
executed = nil; pressA()
eq(executed, nil, "removed HM cannot execute from stale menu"); top.close()
print("field-moves-ok: " .. checks .. " assertions (real engine, fixture dependencies)")
