# v2.2.1 verification

## Automated checks performed

- `lua tests/contract.lua` (run here with `luatex --luaonly`): passed.
- `lua tests/field_moves.lua /path/to/engine/field_moves.lua`: 100 assertions passed.
- Baseline v2.2.0 fails the same integration harness with
  `attempt to index a nil value (global 'package')` in START menu injection.
- The new mod chunk runs without a `package` global, as in the current engine sandbox.
- All eight HMs: missing badge and wrong badge rejected; correct Emerald badge
  allows the expected native action with an untrained helper Pokemon.
- Script checks cover actual special-variable storage, preserved return values,
  missing HM, CONTEXT OFF and an empty party.
- Contextual Cut requires both the badge and owned HM and respects CONTEXT OFF.
- Fly indoors, Surf away from water and a removed HM in an already-open menu
  stay blocked.

Engine source used: `bryanthaboi/gen1recomp`, branch `dev`, retrieved 2026-10-04.
The real `src/core/game3/field_moves.lua` is loaded by the integration test;
its ROM, map, flag storage, UI and execution dependencies are fixtures.
The upstream engine is not included in this mod ZIP.
These are code-level tests, not an in-game certification.

## In-game checklist (still requires the user's runtime/save)

- Replace the old mod, restart, and keep a single enabled Emerald copy.
- With Stone Badge and HM01, but no Pokemon knowing Cut, face a cuttable tree:
  test A interaction with CONTEXT ON, then START -> HM -> CUT on another tree.
- Repeat for a breakable rock (Dynamo Badge + HM06) and a shoreline
  (Balance Badge + HM03).
- Test Strength, Flash, Fly, Dive and Waterfall in valid locations with the
  matching HM and badge.
- Verify the submenu and error messages with Modern UI enabled and disabled.
- Verify Dig uses the actual saved escape destination.

## Preserved compatibility checklist

- Manifest ID is `hm_anywhere_gen3_emerald` and `games` contains only `emerald`.
- No Kanto/Sevii Fly destination table remains.
- HM list contains HM01-HM08, including DIVE.
- Field TM list contains TM28 DIG and TM43 SECRET POWER.
- Native RSE Fly selector is reached through `Field.executeFieldMove({action="fly"})`.
- DIVE is delegated to the native Emerald dive engine.
- `FieldMoves.partyMoveUser` fallback activates only on Emerald, with CONTEXT enabled, and only for an owned supported machine.
- `script.command/checkpartymove` fallback changes VAR_RESULT only when vanilla reports slot 6 (not found).
- Normal Emerald START gets HM/TM entries; Safari/Pike/Pyramid/Link special menus are not modified.
- Context OFF restores the vanilla learned-move requirement.
- Modern UI presenter state is saved/restored for both the shared and RSE option-menu state shapes.
