# HM & Field TM Anywhere - Gen 3 (Emerald) v2.2.1

Emerald-only conversion of the Gen 3 HM Anywhere mod. This build targets the Pokémon Emerald / RSE runtime and is intentionally separate from the FireRed/LeafGreen version.

## Features

- `games: ["emerald"]` only.
- Owning an HM is enough to use its supported field action without teaching it to a Pokémon.
- START -> **HM** lists owned Emerald HMs: Cut, Fly, Surf, Strength, Flash, Rock Smash, Waterfall and **Dive (HM08)**.
- START -> **TM** lists supported Emerald field TMs: **TM28 Dig** and **TM43 Secret Power**.
- Badge and location requirements are still enforced by Emerald's native `src.core.game3.field_moves` implementation.
- FLY uses Emerald's native RSE Fly region map and visited Fly destinations instead of the old Kanto/Sevii fallback list.
- DIVE uses Emerald's native dive/emerge warp system.
- CUT uses Emerald grass behavior (tall grass, long grass and ash grass), including the native RSE cut plan.
- FLASH, ROCK SMASH, STRENGTH and WATERFALL use Emerald profile flags, event-object IDs and metatile behavior.
- `CONTEXT: ON/OFF` controls whether normal overworld field-move interactions can substitute an owned machine for a learned move.
- Emerald's script-driven `checkpartymove` path is bridged as well, so contextual Cut/Rock Smash/Strength-style scripts work without teaching the move.
- Modern UI remains optional. The submenu mirrors itself into the active Emerald option presenter while keeping a native fallback renderer.

## Emerald-specific safeguards

The HM/TM entries are injected only into Emerald's normal START menu. They are not forced into Safari, link/Union, Battle Pike, Battle Pyramid, multi-partner or other restricted RSE START-menu variants.

The runtime also checks the active profile before substituting a field-move user, so this Emerald package does not alter FireRed, LeafGreen, Ruby or Sapphire behavior even if loaded incorrectly.

## Compatibility

- Mod ID: `hm_anywhere_gen3_emerald`
- Version: `2.2.1`
- Game: Pokémon Emerald only
- Optional: `gen3_modern_ui`

## v2.2.1 fix and requirements

The mod now uses the permitted `require` API instead of accessing the unavailable
`package.loaded` global. In the current mod sandbox, v2.2.0 could fail before
checking machine ownership or reaching the native badge check.

You need **both the corresponding HM in the Bag and the correct badge**.
A badge alone does not grant an HM. No Pokemon needs to learn the move.
The location must also allow the field action. Keep CONTEXT ON to use normal
map interactions; START -> HM works independently of that setting.

| Emerald badge / gym | Field move |
| --- | --- |
| Stone / Rustboro | Cut |
| Knuckle / Dewford | Flash |
| Dynamo / Mauville | Rock Smash |
| Heat / Lavaridge | Strength |
| Balance / Petalburg | Surf |
| Feather / Fortree | Fly |
| Mind / Mossdeep | Dive |
| Rain / Sootopolis | Waterfall |

### Install / installazione

Replace v2.2.0 with v2.2.1 and restart the game. Keep only one enabled copy
of `hm_anywhere_gen3_emerald`. The mod ID and saved CONTEXT preference are unchanged.

Sostituisci la vecchia versione e riavvia il gioco. Servono sia la MN nella Borsa
sia la medaglia corretta. Per usare la MN interagendo con alberi, rocce o acqua,
controlla che START -> HM -> CONTEXT sia ON.

### Verification

Automated sandbox regression and real field-move engine checks passed.
Map, ROM, UI and execution dependencies in the integration tests are fixtures;
an actual Emerald playthrough, animations and Modern UI rendering were not tested.
See `tests/regression.md` for commands and the remaining in-game checklist.
