# Changelog

## 2.2.1 - Sandbox and field activation fix

- Removed all use of the unavailable `package.loaded` global from mod code; use the permitted module require API.
- Fix applies to runtime lookup, contextual substitution, script bridge, HM/TM menus and option presenter access.
- Preserve native Emerald badge and location checks; recheck machine ownership when using a menu entry.
- Use the executing script VM store/context and avoid writing a fake species for an empty party.
- Pass the actual escape warp for Dig and close START silently as the native party-menu flow does.
- Log context/validation errors instead of losing them behind a generic failure.
- Run the contract under a sandbox without the package global and add integration tests using the real field-move engine.

## 2.2.0 - Emerald conversion

- Converted the FRLG v2.1.4 build to Pokémon Emerald only.
- New mod ID `hm_anywhere_gen3_emerald` so the Emerald and FR/LG packages can coexist without replacing one another.
- Manifest now targets only `emerald`.
- Added HM08 Dive and wired it to Emerald's native Dive/emerge system.
- Added TM43 Secret Power alongside TM28 Dig as an Emerald field TM.
- Replaced the FireRed/LeafGreen custom Fly destination list with Emerald's native RSE Fly region map.
- Reworked field context for Emerald/RSE map types, waterfall behavior, Flash flag, grass cutting and Hyper Cutter handling.
- Added an Emerald `script.command` bridge for the RSE `checkpartymove` opcode, which is required for contextual field scripts that do not call `FieldMoves.partyMoveUser` directly.
- Restricted START menu injection to Emerald's normal field menu so Safari/Link/Battle Pike/Battle Pyramid and other special RSE menus remain native.
- Updated the Modern UI presenter bridge to support the Emerald `src.ui.game3.rse.option_menu` state shape.
- Added explicit Emerald-only runtime guards and exports.

## 2.1.4 - FRLG source release

- FireRed/LeafGreen source version used as the base of this conversion.
