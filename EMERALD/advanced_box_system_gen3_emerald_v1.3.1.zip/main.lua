-- Advanced Box System Gen 3 for Pokemon Recomp / Emerald only
-- v1.3.1
--
-- Emerald PC-first storage workflow with an advanced PARTY <-> BOX browser.
-- The Emerald game owns the PC menu and storage data; the mod replaces only
-- the Pokémon browser for Withdraw / Deposit / Move while preserving native
-- Gen 3 / RSE storage semantics and leaving MOVE ITEMS native.

local VERSION = "1.3.1"
local MOD_ID = "advanced_box_system_gen3_emerald"

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local function req(name)
    local ok, value = pcall(require, name)
    if ok then return value end
    if mod.log and type(mod.log.warn) == "function" then
      mod.log:warn("%s: unable to load %s: %s", MOD_ID, name, tostring(value))
    end
    return nil
  end

  local function readModule(rel)
    local source = mod:read(rel)
    if not source then error("[" .. MOD_ID .. "] missing mod file: " .. rel) end
    return assert(load(source, "@" .. MOD_ID .. "/" .. rel))()
  end

  local Runtime = req("src.core.game3.runtime")
  local Storage = req("src.core.game3.storage")
  local Profile = req("src.core.game3.profile")
  local Screens = req("src.ui.game3.screens")
  local DefaultPcMenu = req("src.ui.game3.pc_menu")
  local NativeBoxUI = req("src.ui.game3.box_storage_ui")
  if not Storage then return end

  local makeUi = readModule("src/advanced_box_ui.lua")
  local BoxUI = makeUi(mod)

  local function isEmeraldSession(session)
    if type(session) ~= "table" then return false end
    if tostring(session.version or ""):lower() == "emerald" then return true end
    if Profile and type(Profile.forSession) == "function" then
      local ok, row = pcall(Profile.forSession, session)
      if ok and type(row) == "table" then
        return tostring(row.id or ""):lower() == "emerald"
      end
    end
    return false
  end

  local function currentSession(game, session)
    local candidates = {}
    if type(session) == "table" then candidates[#candidates + 1] = session end
    if Runtime and type(Runtime.getSession) == "function" then
      local ok, live = pcall(Runtime.getSession)
      if ok and type(live) == "table" then candidates[#candidates + 1] = live end
    end
    if game and type(game.session) == "table" then candidates[#candidates + 1] = game.session end

    for _, live in ipairs(candidates) do
      if isEmeraldSession(live) then return live end
    end
    return nil
  end

  local function pcMenuFor(session)
    if Screens and type(Screens.get) == "function" then
      local ok, menu = pcall(Screens.get, "pc", session)
      if ok and type(menu) == "table" then return menu end
    end
    return DefaultPcMenu
  end

  local function openBox(game, session, mode, onClose)
    local live = currentSession(game, session)
    if not live then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("%s: BOX requested without an active Pokemon Emerald session", MOD_ID)
      end
      return false
    end
    Storage.ensure(live)
    return BoxUI.show(live, { mode = mode or "move", onClose = onClose })
  end

  local function openPc(game, session)
    local live = currentSession(game, session)
    if not live then
      if mod.log and type(mod.log.warn) == "function" then
        mod.log:warn("%s: PC requested without an active Pokemon Emerald session", MOD_ID)
      end
      return false
    end
    Storage.ensure(live)
    local PcMenu = pcMenuFor(live)
    if PcMenu and type(PcMenu.show) == "function" then
      -- The Start-menu PC is a remote storage shortcut, not a physical PC
      -- script.  Calling PcMenu.show() with no startMode enters the shared
      -- root and asks for FRLG-only Text_AccessWhichPC before the RSE skin can
      -- take over.  Emerald does not cache that symbol, so it hard-crashes.
      --
      -- Enter the native Emerald storage submenu directly instead.  All rows
      -- and descriptions used by this state are present in the Emerald ROM
      -- text cache, and closeOnExit makes B / SEE YA! return to the Start Menu
      -- instead of falling back into the shared FRLG root prompt.
      PcMenu.show({
        session = live,
        startMode = "storage",
        closeOnExit = true,
        silentClose = true,
      })
      return true
    end
    return openBox(game, live, "move")
  end

  -- Emerald currently enters the shared Game3 BoxStorageUI from Lanette's PC.
  -- Patch that single entry point, but gate every call by the Emerald profile
  -- so this wrapper can never alter FireRed, LeafGreen, Ruby or Sapphire.
  if NativeBoxUI and type(NativeBoxUI.show) == "function" then
    if type(NativeBoxUI._advancedBoxSystemEmeraldBaseShow) ~= "function" then
      NativeBoxUI._advancedBoxSystemEmeraldBaseShow = NativeBoxUI.show
    end
    local baseShow = NativeBoxUI._advancedBoxSystemEmeraldBaseShow
    NativeBoxUI.show = function(opts)
      opts = opts or {}
      local subMode = tostring(opts.subMode or "move")
      local live = currentSession(nil, opts.session)
      if live and (subMode == "withdraw" or subMode == "deposit" or subMode == "move") then
        Storage.ensure(live)
        return BoxUI.show(live, { mode = subMode, onClose = opts.onClose })
      end
      -- MOVE ITEMS and any non-Emerald session stay completely native.
      return baseShow(opts)
    end
    NativeBoxUI._advancedBoxSystemEmeraldPatchVersion = VERSION
  end

  mod.exports.open = function(game, mode, session)
    if mode == "pc" or mode == nil then return openPc(game, session) end
    return openBox(game, session, mode)
  end
  mod.exports.openRemote = function(game, session)
    return openPc(game, session)
  end
  mod.exports.openBox = function(game, mode, session)
    return openBox(game, session, mode or "move")
  end
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.emeraldOnly = true
  mod.exports.fireRedSupported = false
  mod.exports.leafGreenSupported = false
  mod.exports.rubySupported = false
  mod.exports.sapphireSupported = false
  mod.exports.supportedGames = { "emerald" }
  mod.exports.storageFamily = "rse"
  mod.exports.boxCount = Storage.TOTAL_BOXES_COUNT or 14
  mod.exports.boxCapacity = Storage.IN_BOX_COUNT or 30
  mod.exports.nativeStorage = true
  mod.exports.screenId = BoxUI.SCREEN_ID
  mod.exports.isOpen = BoxUI.isOpen

  -- High-resolution presentation. The logical screen itself lives on the
  -- Game3 UI stack, giving it exclusive input without replacing Emerald save
  -- data, box structures or party structures.
  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result = nextFn(game, viewport)
    if BoxUI.isOpen() then
      local live = currentSession(game, nil)
      if live then
        local ok, err = pcall(BoxUI.drawWindow, viewport)
        if not ok and mod.log and type(mod.log.warn) == "function" then
          mod.log:warn("%s: Advanced Box render failed: %s", MOD_ID, tostring(err))
        end
      end
    end
    return result
  end)

  -- Remote PC shortcut. Only inject it while an Emerald Game3 session exists.
  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then return out end
    if not currentSession(game, nil) then return out end

    for _, entry in ipairs(out) do
      if entry and (entry.absAdvancedBoxEmeraldRemote == true
          or entry.id == "advanced_box_system_gen3_emerald_pc") then
        return out
      end
    end

    local row = {
      id = "advanced_box_system_gen3_emerald_pc",
      label = "PC",
      desc = { "POKéMON STORAGE", "Deposit / Withdraw / Move" },
      absAdvancedBoxEmeraldRemote = true,
      absAdvancedBoxGen3 = true,
      onSelect = function(g, session)
        return openPc(g or game, session)
      end,
    }

    -- Emerald uses id="save" in the Game3 Start Menu. Keep label fallback for
    -- compatibility with older development builds of Pokemon Recomp.
    local insertAt = #out + 1
    for i, entry in ipairs(out) do
      if entry then
        local id = tostring(entry.id or ""):lower()
        local label = tostring(entry.label or ""):upper()
        if id == "save" or label == "SAVE" then
          insertAt = i
          break
        end
      end
    end
    table.insert(out, insertAt, row)
    return out
  end)

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info("%s v%s installed: Emerald-only Lanette PC flow + advanced BOX/PARTY browser", MOD_ID, VERSION)
  end
end
