# Changelog

## 1.3.1 — Emerald Start-menu PC crash fix

- Fixed the crash when selecting **PC** from the Start Menu on Emerald.
- The remote shortcut no longer calls the shared PC root that requests FRLG-only `Text_AccessWhichPC`.
- START -> PC now enters Emerald's native Pokémon Storage submenu with `startMode = "storage"`.
- Added `closeOnExit = true`, so B / SEE YA! returns cleanly to the Start Menu instead of falling into the FRLG root prompt.
- Physical Emerald PCs remain on their native RSE script flow.
- Updated the optional Modern UI dependency id to `gen3_modern_ui_emerald`.

## 1.3.0 — Emerald-only conversion

- Converted the mod from FireRed/LeafGreen to **Pokémon Emerald only**.
- Changed the manifest target to `games: ["emerald"]`.
- Assigned the dedicated id `advanced_box_system_gen3_emerald` so this build does not replace the FR/LG package in the mod library.
- Added runtime validation of the active Emerald profile before opening or rendering the custom storage browser.
- Routed the remote PC shortcut through the profile-aware Game3 PC screen, preserving Emerald/RSE Lanette behavior.
- Limited the `box_storage_ui.show` interception to Emerald sessions and to WITHDRAW / DEPOSIT / MOVE modes.
- Kept MOVE ITEMS native to Emerald.
- Removed the FireRed/LeafGreen HELP-system suppression from the custom browser.
- Updated labels, documentation and exported compatibility metadata for Emerald.

## 1.2.1 — FireRed / LeafGreen build

- Added LeafGreen support to the previous FR/LG package.
- Used the shared Gen 3 storage, PC menu, box UI and HELP-system integration for Kanto Gen 3.
