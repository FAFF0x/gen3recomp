# Changelog

## v1.1.2 — Emerald Poké Mart cursor fix

- Fixed the Emerald BUY list highlight appearing frozen while navigation sounds still played.
- The Modern UI shop presenter now follows Emerald/RSE `scroll + row + 1` instead of the FRLG/root `cursor` field.
- The visible Modern UI list now follows Emerald's eight-row list window and scroll offset.
- Emerald root BUY / SELL / QUIT labels are read from the RSE ROM text path.
- Quantity details use Emerald `_itemId`, `qty`, and `_totalCost` state.
- Decoration marts fail open to the native Emerald renderer because their inventory is not normal item data.

## 1.1.1 — Standalone Emerald package ID
- Changed the Emerald package id from `gen3_modern_ui` to `gen3_modern_ui_emerald`.
- Renamed the package to `Gen3 Modern UI Enhanced — Emerald Standalone`.
- This prevents the Emerald installer entry from colliding with the existing FireRed/LeafGreen mod.
- FireRed/LeafGreen can remain installed under `gen3_modern_ui`; this package still targets only `emerald`.

## 1.1.0 — Emerald-only conversion
- Retargeted the package from FireRed/LeafGreen to `emerald` only in the manifest and mod card.
- Added an Emerald render-time Emerald profile guard so forced loading on another Gen 3 profile exits safely.
- Switched Options and Pokédex routing to Emerald/RSE modules.
- Added Emerald Pokédex list/search-results presentation with native fail-open behavior for complex RSE pages.
- Switched Bag icon rendering to the RSE/Emerald item atlas with a compatibility fallback.
- Added PokéNav and Battle Frontier Start Menu icon handling and changed default Start/Menu identity from Kanto to Hoenn.
- Added a modern presenter for PokéNav main, Condition and Condition Search menus; dedicated PokéNav feature screens still fail open to native Emerald rendering.
- Added Emerald Summary page naming for Battle Moves and Contest Moves.
- Added RSE save phases (`saving_msg`, `save_failed`) to the modern Save presentation.
- Reworked PC presentation around Emerald root rows, Item Storage/Toss, Mailbox and optional bedroom Decoration.
- Updated Trainer Card identity, default colors, exports and documentation for Emerald.
- Preserved native Emerald input/state/callback ownership and native fallback for dedicated PokéNav feature screens, Frontier screens, complex Pokédex pages and unknown RSE layers.

## 1.0.23
- Fixed the compact Electric-type badge color in Party cards.
- Added the `ELECTR` alias to the type-color palette so the shortened label uses the same yellow color as `ELECTRIC`.
- FireRed + LeafGreen compatibility and the existing `gen3_modern_ui` id are preserved.

## 1.0.22
- Fixed type/status badge labels that could wrap or overflow their pill backgrounds in compact layouts.
- Party-screen type pills now compute widths from the rendered label text instead of a rough character estimate.
- Pill text now auto-fits to the available width and remains on a single line when space is tight.
- Status pills reuse the same text-fitting logic for more consistent alignment.
- FireRed + LeafGreen compatibility and the existing `gen3_modern_ui` id are preserved.

## 1.0.21
- Added a global Modern UI presenter for `src.ui.game3.message`.
- NPC dialogue, signs and ordinary script messages no longer rely on the vanilla FRLG textbox presentation.
- Added a global Modern UI presenter for `src.ui.game3.choice`.
- YES/NO prompts and generic multichoice script menus now use Modern UI cards and selection highlighting.
- Native Message/Choice input, typing, paging, callbacks and script result logic remain untouched.
- Global dialogue works even when no supported Game3 Stack menu is open.
- Battle-frame text is intentionally left to Modern Battle UI to avoid overlay conflicts.
- FireRed + LeafGreen support and the existing `gen3_modern_ui` id are preserved.

## 1.0.20
- Added LeafGreen support alongside FireRed.
- Updated `manifest.json` and `mod.card` targets to `firered` + `leafgreen`.
- Replaced the FireRed-only runtime identity with FRLG metadata and explicit `supportedGames`.
- Kept the shared `src.ui.game3.*` / `src.core.game3.*` presenters and native menu ownership unchanged.
- Preserved the existing `gen3_modern_ui` mod id so this version upgrades the installed mod instead of creating a duplicate.

## 1.0.19
- Added icon-led Start Menu navigation with Pokédex, Pokémon, Bag, Trainer, Save, Options and Exit symbols.
- Added generic icon fallback for extra Start Menu entries injected by other mods.
- Added type-aware Party card accents and type badges using FireRed species data.
- Added visible status pills and yellow mid-HP state in Party cards.
- Added Bag pocket tabs and a larger, clearer item detail panel.
- Added icon-led Bag and Party action menus.
- Added subtle screen fade-in and selection pulse, with a UI ANIMATIONS toggle.
- Redesigned Trainer Card with Kanto identity panel, Poké Ball motif and eight badge slots.
- Preserved native FireRed ownership of menu logic, state transitions and callbacks.

## 1.0.18
- Reworked the default theme around recognizable Pokémon colors: Kanto blue, Poké Ball red, logo yellow and white menu cards.
- Added dedicated header/footer colors and stronger selection contrast.
- Removed the narrow Plain Pixel font from the overlay renderer.
- Switched to the readable built-in LÖVE font with smooth filtering.
- Increased minimum font sizes for body, small and hint text.
- Preserved the v1.0.17 layout, menu behavior and FireRed Game3 integration.

## 1.0.17
- Major visual and usability redesign.
- Compact FireRed-oriented layout and palette.
- Plain Pixel font support with fallback.
- Reworked Start, Bag and Party layouts.
- Fixed hidden Party CANCEL cursor.
- Fixed hidden Box special targets.
- Added visible Bag party-target selection.
- Added PC storage submenu presentation.
- Native fallback for PC transfer screens not safely represented by the overlay.

## 1.0.16
- First functional FireRed Game3 port using `src.ui.game3.*` and `render.hud`.
