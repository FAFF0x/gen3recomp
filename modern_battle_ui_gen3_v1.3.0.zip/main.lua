-- MODERN BATTLE UI - GEN 3 (FIRERED) v1.3.0
-- Dedicated to the FireRed runtime used by Gen1Recomp/Gen3.
-- The implementation intentionally mirrors known-working FireRed mods:
--   * manifest games = { "firered" }
--   * engine_internals permission
--   * pcall-guarded src.core.game3 / src.ui.game3 modules
--   * render.hud for the final screen-space presentation pass
return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local VERSION = "1.3.0"
  local MOD_ID = "modern_battle_ui_gen3_firered"

  local function readModule(rel)
    local source = mod:read(rel)
    if not source then error("[" .. MOD_ID .. "] missing mod file: " .. rel) end
    return assert(load(source, "@" .. MOD_ID .. "/" .. rel))()
  end

  local Gen3 = readModule("src/gen3.lua")
  local MoveInfo = readModule("src/move_info.lua")
  local Hud = readModule("src/hud.lua")
  Hud.init(Gen3, MoveInfo)

  mod.options:define({
    { key = "enabled", label = "MODERN BATTLE UI", type = "toggle", default = true },
    { key = "enemy_hp", label = "ENEMY HP NUMBERS", type = "toggle", default = false },
    { key = "move_details", label = "MOVE DETAILS", type = "toggle", default = true },
    { key = "move_info", label = "SELECT MOVE INFO", type = "toggle", default = true },
  })

  -- SELECT opens a read-only move-info panel while the FireRed move grid owns
  -- input.  We inspect the semantic GB-button queue before Input:step promotes
  -- it, so this works with keyboard, gamepad, rebinding and touch alike.
  -- While INFO is open, A/B/START are suppressed to prevent accidental use or
  -- cancellation; directions stay live so the player can inspect all 4 moves.
  mod.hooks:wrap("input.step", function(next, game, dt)
    next(game, dt)
    if mod.options:get("enabled") == false or mod.options:get("move_info") == false then
      Hud.closeMoveInfo()
      return
    end

    local snap = Gen3.snapshot()
    local input = game and game.input
    if not (snap and input and (snap.mode == "moves" or snap.mode == "target")) then
      Hud.closeMoveInfo()
      return
    end

    local q = type(input.pressQueue) == "table" and input.pressQueue or nil
    if not q then return end
    local selectPressed = false
    for _, btn in ipairs(q) do
      if btn == "select" then selectPressed = true break end
    end
    if selectPressed then Hud.toggleMoveInfo() end

    local block = Hud.moveInfoOpen()
    local filtered = {}
    for _, btn in ipairs(q) do
      if btn == "select" then
        -- SELECT belongs to the info overlay while the move grid is open.
      elseif block and (btn == "a" or btn == "b" or btn == "start") then
        -- Keep the detail screen read-only and safe.
      else
        filtered[#filtered + 1] = btn
      end
    end
    input.pressQueue = filtered
    if block and type(input.state) == "table" then
      input.state.a = false
      input.state.b = false
      input.state.start = false
    end
  end)

  -- Same render path used successfully by gen3_dexnav.  The important
  -- difference from v1.0.x is that battle detection comes from the real
  -- FireRed engine module, not from a guessed Game.stack BattleState shape.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    if mod.options:get("enabled") == false then return result end
    local ok, err = pcall(Hud.draw, game, viewport, {
      enemyHp = mod.options:get("enemy_hp") == true,
      moveDetails = mod.options:get("move_details") ~= false,
      moveInfo = mod.options:get("move_info") ~= false,
    })
    if not ok then
      mod.log:warn("%s render failed: %s", MOD_ID, tostring(err))
    end
    return result
  end)

  mod.exports.version = VERSION
  mod.exports.fireRedRuntime = true
  mod.exports.enginePath = "src.core.game3.battle"
  mod.exports.isBattleActive = Gen3.battleActive
end
