local root = assert(os.getenv("MODROOT"), "MODROOT missing")
local source = assert(io.open(root .. "/main.lua", "rb")):read("*a")
local chunk = assert(load(source, "@main.lua"))

local files = {}
for _, rel in ipairs({"src/gen3.lua","src/move_info.lua","src/hud.lua"}) do
  files[rel] = assert(io.open(root .. "/" .. rel, "rb")):read("*a")
end

local wraps = {}
local mod = {
  generation = 3,
  read = function(_, rel) return files[rel] end,
  options = {
    values = {},
    define = function(self, rows) for _, r in ipairs(rows) do self.values[r.key] = r.default end end,
    get = function(self, k) return self.values[k] end,
  },
  hooks = { wrap = function(_, name, fn) wraps[name] = fn end },
  log = { warn = function() end },
  exports = {},
}

package.loaded["src.core.game3.battle"] = {
  _phase = "command",
  isActive = function() return true end,
  getState = function() return { player={mon={hp=20,maxHp=30,level=5}}, enemy={mon={hp=10,maxHp=10,level=4}} } end,
}
package.loaded["src.core.game3.battle.ui"] = { _mode="menu", _menuIndex=2, _moveIndex=1, _active=0 }
package.loaded["src.core.game3.battle.state"] = { displayName=function(b) return b==nil and "POKéMON" or "TESTMON" end }
package.loaded["src.core.game3.battle.moves"] = { get=function() return {type=10,power=40,pp=25,category="special"} end, displayName=function() return "EMBER" end }
package.loaded["src.core.game3.battle.types"] = { name=function() return "FIRE" end, effectiveness=function() return 2 end }
package.loaded["src.core.game3.battle.anim"] = { present=function() return nil end }

chunk()(mod)
assert(wraps["render.hud"], "render.hud not registered")
assert(wraps["input.step"], "input.step not registered")
assert(mod.exports.version == "1.3.0")
assert(mod.exports.fireRedRuntime == true)
assert(mod.exports.enginePath == "src.core.game3.battle")
assert(mod.exports.isBattleActive() == true)
print("contract-ok")
