local root = assert(os.getenv("MODROOT"), "MODROOT missing")

-- Adapter-level tests for live EXP and Pokédex ownership.
local anim = { displayExpRatio = function() return 0.625 end, present = function() return nil end }
package.loaded["src.core.game3.battle.anim"] = anim
package.loaded["src.core.game3.battle.experience"] = { progress = function() return { progressPercent = 0.4 } end }
package.loaded["src.core.game3.runtime"] = { getSession = function() return { dex = { caught = { [25] = true } } } end }
package.loaded["src.core.game3.dex"] = { isCaught = function(dex, species) return dex.caught[species] == true end }

local G = assert(loadfile(root .. "/src/gen3.lua"))()
local battler = { species = 25, mon = { species = 25, level = 20, exp = 1000 } }
assert(math.abs(G.expRatio("player", battler) - 0.625) < 0.0001, "animated EXP ratio must win")
anim.displayExpRatio = nil
assert(math.abs(G.expRatio("player", battler) - 0.4) < 0.0001, "EXP growth fallback")
assert(G.enemyCaught(battler, {}) == true, "caught species should be reported")
assert(G.enemyCaught({species=1, mon={species=1}}, {}) == false, "uncaught species should be reported")
assert(G.enemyCaught(battler, {ghostBattle=true, ghostUnveiled=false}) == nil, "hidden ghost must not leak caught state")

-- Full HUD smoke test: all move cards expose matchup information immediately,
-- and the cards expose EXP / caught-state text during a live battle.
local shown = {}
local fontObj = {
  setFilter=function() end,
  getWidth=function(_, s) return #tostring(s) * 7 end,
  getHeight=function() return 14 end,
}
_G.love = { graphics = {
  newFont=function() return fontObj end,
  getFont=function() return fontObj end,
  setFont=function() end,
  setColor=function() end,
  rectangle=function() end,
  circle=function() end,
  arc=function() end,
  line=function() end,
  setLineWidth=function() end,
  push=function() end,
  pop=function() end,
  setScissor=function() end,
  print=function(v) shown[#shown+1]=tostring(v) end,
  printf=function(v) shown[#shown+1]=tostring(v) end,
} }

local player = { species=4, type1=10, mon={species=4, hp=30, maxHp=40, level=12, moves={1,2,3,4}, pp={10,10,10,10}, maxPp={10,10,10,10}} }
local enemy = { species=25, type1=12, mon={species=25, hp=20, maxHp=35, level=11} }
package.loaded["src.core.game3.battle"] = {
  _phase="command",
  isActive=function() return true end,
  getState=function() return { player=player, enemy=enemy } end,
}
package.loaded["src.core.game3.battle.ui"] = { _mode="moves", _menuIndex=1, _moveIndex=1, _active=0 }
package.loaded["src.core.game3.battle.state"] = { displayName=function(b) return b == player and "CHARMANDER" or "PIKACHU" end }
package.loaded["src.core.game3.battle.moves"] = {
  get=function(id)
    local defs = {
      [1]={type=10,power=40,accuracy=100,pp=25,category="special",effect=4,secondaryChance=10,target=0,priority=0},
      [2]={type=13,power=40,pp=30,category="special"},
      [3]={type=0,power=0,pp=40,accuracy=100,category="status",effect=18,target=8},
      [4]={type=11,power=40,pp=25,category="special"},
    }
    return defs[id]
  end,
  displayName=function(id) return ({[1]="EMBER",[2]="THUNDER",[3]="GROWL",[4]="WATER GUN"})[id] end,
}
package.loaded["src.core.game3.battle.types"] = {
  name=function(id) return ({[0]="NORMAL",[10]="FIRE",[11]="WATER",[12]="GRASS",[13]="ELECTRIC"})[id] or "NORMAL" end,
  effectiveness=function(atk)
    return ({[10]=2,[13]=0,[0]=1,[11]=0.5})[atk] or 1
  end,
}
package.loaded["src.core.game3.battle.anim"] = { present=function() return nil end, displayExpRatio=function() return 0.5 end }
package.loaded["src.core.game3.runtime"] = { getSession=function() return { dex={ caught={ [25]=true } } } end }
package.loaded["src.core.game3.dex"] = { isCaught=function(dex, species) return dex.caught[species] == true end }

local files = {}
for _, rel in ipairs({"src/gen3.lua","src/move_info.lua","src/hud.lua"}) do
  files[rel] = assert(io.open(root .. "/" .. rel, "rb")):read("*a")
end
local wraps = {}
local mod = {
  generation=3,
  read=function(_, rel) return files[rel] end,
  options={ values={}, define=function(self, rows) for _,r in ipairs(rows) do self.values[r.key]=r.default end end, get=function(self,k) return self.values[k] end },
  hooks={ wrap=function(_, name, fn) wraps[name]=fn end },
  log={ warn=function() end }, exports={},
}
assert(load(assert(io.open(root .. "/main.lua","rb")):read("*a"), "@main.lua"))()(mod)
wraps["render.hud"](function() return true end, {}, {gameX=0,gameY=0,gameWidth=960,gameHeight=640})
local all = table.concat(shown, "|")
assert(all:find("×2 SUPER", 1, true), "super-effective badge missing")
assert(all:find("×0 IMMUNE", 1, true), "immune badge missing")
assert(all:find("STATUS", 1, true), "status badge missing")
assert(all:find("×½ RESIST", 1, true), "resisted badge missing")
assert(all:find("EXP", 1, true), "EXP label missing")
assert(all:find("CAUGHT", 1, true), "caught indicator missing")
assert(all:find("SELECT  DETAILS", 1, true), "SELECT details hint missing")

-- MoveInfo must explain status moves from live FireRed effect metadata.
local MI = assert(loadfile(root .. "/src/move_info.lua"))()
local growl = MI.describe({ power=0, category="status", accuracy=100, pp=40, effect=18, target=8, priority=0 })
assert(growl.short:find("Attack", 1, true), "Growl summary must mention Attack")
assert(growl.short:find("1 stage", 1, true), "Growl summary must mention one stage")
assert(growl.target == "Both foes", "Growl target should reflect FireRed target metadata")

-- Open the full panel with SELECT. A/B/START must be consumed while the
-- information screen is open, while directional input remains available.
package.loaded["src.core.game3.battle.ui"]._mode = "moves"
package.loaded["src.core.game3.battle.ui"]._moveIndex = 3
local input = { pressQueue={"select","a","right","b","start"}, state={a=true,b=true,start=true} }
wraps["input.step"](function() end, {input=input}, 1/60)
assert(#input.pressQueue == 1 and input.pressQueue[1] == "right", "info overlay should keep only directional input")
assert(input.state.a == false and input.state.b == false and input.state.start == false, "battle actions must be blocked while info is open")
shown = {}
wraps["render.hud"](function() return true end, {}, {gameX=0,gameY=0,gameWidth=960,gameHeight=640})
all = table.concat(shown, "|")
assert(all:find("MOVE INFO", 1, true), "full move-info overlay missing")
assert(all:find("GROWL", 1, true), "selected move name missing from full info")
assert(all:find("Lowers foe's Attack by 1 stage.", 1, true), "Growl effect explanation missing")
assert(all:find("Both foes", 1, true), "move target detail missing")
assert(all:find("A / B LOCKED", 1, true), "input safety hint missing")

-- SELECT again closes and is consumed instead of leaking to FireRed.
input.pressQueue={"select"}
wraps["input.step"](function() end, {input=input}, 1/60)
assert(#input.pressQueue == 0, "SELECT should be consumed by move-info overlay")
print("features-ok")
