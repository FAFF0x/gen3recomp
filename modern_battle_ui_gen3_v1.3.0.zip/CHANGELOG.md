# Changelog

## 1.3.0
- Added a concise description for the currently highlighted move in the normal move grid.
- Growl and other stat moves now explain the actual stat change instead of only showing STATUS.
- Added a full MOVE INFO overlay toggled with SELECT.
- Full info shows type, category, power, accuracy, PP, priority, target, current matchup, secondary chance and a detailed effect explanation.
- D-pad remains available while MOVE INFO is open so the player can inspect all four moves.
- A, B and START are suppressed while the info overlay is open to prevent accidental battle actions.
- Move explanations are generated from FireRed's live effect metadata, including stat changes, status effects, recoil, draining, multi-hit, weather, screens, priority and special move behaviors.
- No battle calculations or move definitions are modified.

## 1.2.0
- Added effectiveness badges to every move card so matchup information is visible before selecting a move.
- Added distinct SUPER, NORMAL, RESIST and IMMUNE states, including ×4/×2/×1/×1/2/×1/4/×0 multipliers.
- Status moves now show STATUS rather than a damage-effectiveness badge.
- Added a live EXP progress bar directly below the active Pokémon name.
- EXP rendering follows the native animated battle ratio when available and falls back to the Gen 3 experience growth curve.
- Added Pokédex caught-state information to the opponent card using the active FireRed session's `session.dex` and `Dex.isCaught`.
- Added CAUGHT / NOT CAUGHT Poké Ball badges without changing capture logic.
- Hidden ghost encounters do not reveal Pokédex ownership before the species is revealed.
- Battle logic and the v1.1.1 visual language remain unchanged.

## 1.1.1
- Reworked the battle presentation around the visual language of Modern UI Gen3 v1.0.19.
- Replaced the dark low-contrast palette with Kanto blue, white, Poké Ball red and Pokémon yellow.
- Fixed blurry/illegible text by drawing typography directly in final window space instead of rasterizing 5–8 px fonts and scaling them up.
- Generated fonts now use a 12 px minimum and linear filtering, matching Modern UI's readability strategy.
- Increased contrast and hierarchy for Pokémon names, levels, HP values, command labels, move labels and move details.
- Selected command/move cards now use a yellow raised surface plus a red selection rail.
- HP bars now use the same green / amber / red thresholds as Modern UI Gen3.
- Battle logic, FireRed runtime adapter, input ownership and native animations remain unchanged from v1.1.0.

## 1.1.0
- Rebuilt the port against FireRed's actual `src.core.game3.battle` runtime.
- Target changed to the real FireRed game id.
- Replaced command/move chrome and singles health boxes through `render.hud` while preserving native battle logic.
