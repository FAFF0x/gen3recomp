-- FireRed engine adapter.  Pattern intentionally follows gen3_dexnav 0.1.4.
local Gen3 = {}
local cache = {}

local function try(name)
  local hit = cache[name]
  if hit ~= nil then return hit or nil end
  local ok, module = pcall(require, name)
  cache[name] = ok and module or false
  return ok and module or nil
end
Gen3.try = try

function Gen3.battle() return try("src.core.game3.battle") end
function Gen3.ui() return try("src.core.game3.battle.ui") end
function Gen3.state() return try("src.core.game3.battle.state") end
function Gen3.moves() return try("src.core.game3.battle.moves") end
function Gen3.types() return try("src.core.game3.battle.types") end
function Gen3.anim() return try("src.core.game3.battle.anim") end
function Gen3.summaryData() return try("src.core.game3.summary_data") end
function Gen3.experience() return try("src.core.game3.battle.experience") end
function Gen3.runtime() return try("src.core.game3.runtime") end
function Gen3.dex() return try("src.core.game3.dex") end

function Gen3.battleActive()
  local B = Gen3.battle()
  if not (B and B.isActive) then return false end
  local ok, active = pcall(B.isActive)
  return ok and active == true
end

function Gen3.snapshot()
  local B = Gen3.battle()
  local U = Gen3.ui()
  if not (B and U and B.isActive and B.getState) then return nil end
  local okActive, active = pcall(B.isActive)
  if not okActive or not active then return nil end
  local okState, st = pcall(B.getState)
  if not okState or type(st) ~= "table" then return nil end
  return {
    battle = B,
    state = st,
    ui = U,
    phase = B._phase,
    mode = U._mode or "none",
    menuIndex = tonumber(U._menuIndex) or 1,
    moveIndex = tonumber(U._moveIndex) or 1,
    active = tonumber(U._active) or 0,
  }
end

function Gen3.displayName(battler)
  local S = Gen3.state()
  if S and S.displayName then
    local ok, name = pcall(S.displayName, battler)
    if ok and name then return tostring(name) end
  end
  local mon = battler and battler.mon
  return tostring((mon and (mon.nickname or mon.name)) or "POKéMON")
end

function Gen3.typeName(id)
  local T = Gen3.types()
  if T then
    local f = T.name or T.get
    if f then
      local ok, name = pcall(f, id)
      if ok and name then return tostring(name) end
    end
  end
  return "NORMAL"
end

function Gen3.moveDef(id)
  local M = Gen3.moves()
  if not (M and M.get) then return nil end
  local ok, def = pcall(M.get, id)
  return ok and def or nil
end

function Gen3.moveName(id)
  local M = Gen3.moves()
  if M and M.displayName then
    local ok, name = pcall(M.displayName, id)
    if ok and name then return tostring(name) end
  end
  return tostring(id or "-")
end

function Gen3.effectiveness(moveType, enemy)
  local T = Gen3.types()
  if not (T and T.effectiveness and enemy) then return 1 end
  local ok, mult = pcall(T.effectiveness, moveType, enemy.type1, enemy.type2)
  if ok and type(mult) == "number" then return mult end
  return 1
end

function Gen3.displayHp(side, battler)
  local mon = battler and battler.mon or {}
  local hp = tonumber(mon.hp) or 0
  local maxHp = tonumber(mon.maxHp) or math.max(hp, 1)
  local A = Gen3.anim()
  if A and A.present then
    local ok, p = pcall(A.present, side)
    if ok and type(p) == "table" then
      hp = tonumber(p.displayHp) or hp
      maxHp = tonumber(p.displayMaxHp) or maxHp
    end
  end
  return hp, math.max(1, maxHp)
end

function Gen3.expRatio(side, battler)
  if not (battler and battler.mon) then return nil end
  local A = Gen3.anim()
  if A and A.displayExpRatio then
    local ok, ratio = pcall(A.displayExpRatio, side, battler)
    if ok and type(ratio) == "number" then
      return math.max(0, math.min(1, ratio))
    end
  end
  local E = Gen3.experience()
  if E and E.progress then
    local ok, prog = pcall(E.progress, battler.mon)
    if ok and type(prog) == "table" then
      local ratio = tonumber(prog.progressPercent)
      if ratio then return math.max(0, math.min(1, ratio)) end
    end
  end
  return nil
end

function Gen3.enemyCaught(battler, battleState)
  if not battler then return nil end
  if battleState and battleState.ghostBattle and not battleState.ghostUnveiled then return nil end
  local species = tonumber(battler.species or (battler.mon and (battler.mon.species or battler.mon.speciesId)))
  if not species then return nil end
  local R = Gen3.runtime()
  local session
  if R and R.getSession then
    local ok, value = pcall(R.getSession)
    if ok then session = value end
  end
  local dex = session and (session.dex or session.pokedex)
  if not dex then return nil end
  local D = Gen3.dex()
  if D and D.isCaught then
    local ok, value = pcall(D.isCaught, dex, species)
    if ok then return value == true end
  end
  local side = dex.caught or dex.owned
  if type(side) == "table" then
    return side[species] == true or side[tostring(species)] == true
  end
  return false
end

function Gen3.statusLabel(battler)
  if not battler then return nil end
  local raw = battler.status or (battler.mon and (battler.mon.status or battler.mon.status1))
  if raw == nil or raw == 0 or raw == "" then return nil end
  if type(raw) == "string" then
    local s = raw:upper()
    if s:find("SLEEP", 1, true) or s == "SLP" then return "SLP" end
    if s:find("POISON", 1, true) or s == "PSN" or s == "TOX" then return "PSN" end
    if s:find("BURN", 1, true) or s == "BRN" then return "BRN" end
    if s:find("FREEZE", 1, true) or s == "FRZ" then return "FRZ" end
    if s:find("PAR", 1, true) then return "PAR" end
    return s:sub(1, 3)
  end
  local SD = Gen3.summaryData()
  if SD and SD.statusAilment then
    local ok, n = pcall(SD.statusAilment, { status = raw, hp = battler.mon and battler.mon.hp })
    if ok then
      return ({ [1] = "SLP", [2] = "PSN", [3] = "BRN", [4] = "FRZ", [5] = "PAR", [6] = "PSN" })[n]
    end
  end
  return "STS"
end

return Gen3
