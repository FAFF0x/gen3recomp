-- Modern Battle UI - FireRed move information helper.
-- Descriptions are generated from the live FireRed move definition so the UI
-- remains useful for the full Gen 3 move table without modifying battle logic.
local MoveInfo = {}

local STAT = {
  attack = "Attack", defense = "Defense", speed = "Speed",
  spAtk = "Sp. Atk", spDef = "Sp. Def", accuracy = "Accuracy", evasion = "Evasion",
}

local DIRECT_STAT = {
  [10]={who="user",stat="Attack",n=1}, [11]={who="user",stat="Defense",n=1},
  [12]={who="user",stat="Speed",n=1}, [13]={who="user",stat="Sp. Atk",n=1},
  [14]={who="user",stat="Sp. Def",n=1}, [15]={who="user",stat="Accuracy",n=1},
  [16]={who="user",stat="Evasion",n=1}, [18]={who="target",stat="Attack",n=-1},
  [19]={who="target",stat="Defense",n=-1}, [20]={who="target",stat="Speed",n=-1},
  [21]={who="target",stat="Sp. Atk",n=-1}, [22]={who="target",stat="Sp. Def",n=-1},
  [23]={who="target",stat="Accuracy",n=-1}, [24]={who="target",stat="Evasion",n=-1},
  [50]={who="user",stat="Attack",n=2}, [51]={who="user",stat="Defense",n=2},
  [52]={who="user",stat="Speed",n=2}, [53]={who="user",stat="Sp. Atk",n=2},
  [54]={who="user",stat="Sp. Def",n=2}, [55]={who="user",stat="Accuracy",n=2},
  [56]={who="user",stat="Evasion",n=2}, [58]={who="target",stat="Attack",n=-2},
  [59]={who="target",stat="Defense",n=-2}, [60]={who="target",stat="Speed",n=-2},
  [61]={who="target",stat="Sp. Atk",n=-2}, [62]={who="target",stat="Sp. Def",n=-2},
  [63]={who="target",stat="Accuracy",n=-2}, [64]={who="target",stat="Evasion",n=-2},
}

local EFFECT = {
  [0]   = {"Deals damage.", "Deals direct damage with no additional effect."},
  [1]   = {"Puts the foe to sleep.", "Inflicts sleep on the target if the move connects."},
  [2]   = {"May poison the foe.", "Deals damage and may poison the target."},
  [3]   = {"Drains HP from the foe.", "Deals damage and restores the user's HP based on damage dealt."},
  [4]   = {"May burn the foe.", "Deals damage and may inflict a burn."},
  [5]   = {"May freeze the foe.", "Deals damage and may freeze the target."},
  [6]   = {"May paralyze the foe.", "Deals damage and may paralyze the target."},
  [7]   = {"User faints after attacking.", "A very strong attack that causes the user to faint after use."},
  [8]   = {"Drains a sleeping foe's HP.", "Works on a sleeping target and restores the user's HP from the damage dealt."},
  [9]   = {"Copies the foe's last move.", "Uses the last move used by the opposing Pokémon when possible."},
  [17]  = {"Cannot miss normally.", "Ignores the usual accuracy check under normal battle conditions."},
  [25]  = {"Resets stat changes.", "Returns battlers' temporary stat-stage changes to normal."},
  [26]  = {"Stores damage, then strikes back.", "Endures attacks for multiple turns, then returns amplified damage."},
  [27]  = {"Attacks repeatedly, then confuses user.", "Locks the user into repeated attacks for several turns and may leave it confused afterward."},
  [28]  = {"Forces the foe to switch.", "Forces the target out when switching is possible; special rules apply to wild battles."},
  [29]  = {"Hits 2–5 times.", "Strikes the target multiple times in one use."},
  [30]  = {"Changes the user's type.", "Changes the user's type according to the move's conversion rules."},
  [31]  = {"May make the foe flinch.", "Deals damage and may cause the target to flinch."},
  [32]  = {"Restores the user's HP.", "Restores a portion of the user's maximum HP."},
  [33]  = {"Badly poisons the foe.", "Inflicts toxic poison, whose damage increases as turns pass."},
  [34]  = {"Scatters coins while attacking.", "Deals damage and may increase prize money after the battle."},
  [35]  = {"Weakens special attacks.", "Sets Light Screen on the user's side for several turns."},
  [36]  = {"May inflict a status condition.", "Deals damage and can inflict burn, freeze, or paralysis."},
  [37]  = {"Fully heals, then sleeps.", "Restores HP and cures status, then puts the user to sleep."},
  [38]  = {"Can knock out in one hit.", "If it connects and the level rules allow it, the target faints immediately."},
  [39]  = {"Charges before attacking.", "Uses a preparation turn before the damaging strike."},
  [40]  = {"Cuts the foe's HP in half.", "Deals damage equal to roughly half of the target's current HP."},
  [41]  = {"Always deals 40 HP damage.", "Inflicts a fixed 40 HP of damage when it hits."},
  [42]  = {"Traps and damages for several turns.", "Prevents escape while dealing residual trapping damage for several turns."},
  [43]  = {"High critical-hit ratio.", "Has an increased chance to score a critical hit."},
  [44]  = {"Hits twice.", "Strikes the target two times in one use."},
  [45]  = {"User is hurt if it misses.", "If the attack misses, the user takes recoil damage."},
  [46]  = {"Prevents stat reductions.", "Protects the user's side from opposing stat-lowering effects for several turns."},
  [47]  = {"Raises critical-hit chance.", "Raises the user's critical-hit stage."},
  [48]  = {"Deals recoil damage to the user.", "The user takes recoil after successfully dealing damage."},
  [49]  = {"Confuses the foe.", "Inflicts confusion on the target."},
  [57]  = {"Transforms into the foe.", "Copies the target's form, moves, stats and other battle properties allowed by Transform."},
  [65]  = {"Weakens physical attacks.", "Sets Reflect on the user's side for several turns."},
  [66]  = {"Poisons the foe.", "Inflicts regular poison on the target."},
  [67]  = {"Paralyzes the foe.", "Inflicts paralysis on the target."},
  [75]  = {"Charges, then attacks with high crit rate.", "Uses a charging turn, then attacks with an increased critical-hit chance."},
  [76]  = {"May confuse the foe.", "Deals damage and may confuse the target."},
  [77]  = {"Hits twice and may poison.", "Strikes twice and may poison the target."},
  [78]  = {"Moves after the foe but cannot miss normally.", "Uses negative priority and normally bypasses accuracy checks."},
  [79]  = {"Creates a Substitute.", "Uses some of the user's HP to create a decoy that absorbs attacks and effects."},
  [80]  = {"Requires a recharge turn.", "After attacking, the user normally must spend the next turn recharging."},
  [81]  = {"Gets stronger after being hit.", "Raises the user's Attack after it takes damage while Rage remains active."},
  [82]  = {"Copies one of the foe's moves.", "Replaces Mimic temporarily with a move known by the target."},
  [83]  = {"Uses a random move.", "Calls a randomly selected move."},
  [84]  = {"Seeds the foe and drains HP.", "Plants a seed that drains HP from the target each turn and heals the user's side."},
  [85]  = {"Has no battle effect.", "This move intentionally has no direct battle effect."},
  [86]  = {"Disables the foe's recent move.", "Temporarily prevents the target from using one of its moves."},
  [87]  = {"Damage equals the user's level.", "Deals fixed damage equal to the user's current level."},
  [88]  = {"Deals variable fixed damage.", "Deals damage based on the user's level with Psywave's random variation."},
  [89]  = {"Returns physical damage.", "Returns amplified physical damage from an eligible attack used against the user."},
  [90]  = {"Forces the foe to repeat a move.", "Makes the target repeat its last usable move for several turns."},
  [91]  = {"Averages both battlers' HP.", "Adds the user's and target's current HP together and splits the total between them."},
  [92]  = {"Works while the user is asleep.", "Can be used while asleep and may cause flinching."},
  [93]  = {"Changes type to resist the foe.", "Changes the user's type based on a move type known by the target."},
  [94]  = {"Makes the next attack hit.", "Locks onto the target so the user's next eligible attack bypasses normal accuracy checks."},
  [95]  = {"Permanently copies a move.", "Copies the target's last move into the user's moveset when allowed."},
  [97]  = {"Uses another move while asleep.", "Can be selected while asleep and calls another move the user knows."},
  [98]  = {"Takes the attacker down if user faints.", "If the user faints to an opponent's attack before its next action, that attacker also faints."},
  [99]  = {"Stronger when the user's HP is low.", "Power increases as the user's remaining HP decreases."},
  [100] = {"Reduces PP of the foe's last move.", "Lowers the PP of the target's most recently used move."},
  [101] = {"Leaves the foe with at least 1 HP.", "Deals damage but cannot reduce the target below 1 HP."},
  [102] = {"Cures the party's status conditions.", "Removes major status conditions from the user's party."},
  [103] = {"Usually moves first.", "Uses increased priority so it generally acts before normal-priority moves."},
  [104] = {"Kicks three times, increasing power.", "Hits three times with later kicks becoming stronger if the sequence continues."},
  [105] = {"May steal the foe's held item.", "Deals damage and can take the target's held item when battle rules allow it."},
  [106] = {"Prevents the foe from escaping.", "Traps the target so it cannot switch or flee normally."},
  [107] = {"Damages a sleeping foe each turn.", "Places a nightmare on a sleeping target, causing recurring HP loss."},
  [108] = {"Raises the user's Evasion.", "Raises the user's Evasion and activates Minimize-specific interactions."},
  [109] = {"Effect depends on the user's type.", "Curse has different effects for Ghost-type and non-Ghost users."},
  [111] = {"Protects the user for one turn.", "Blocks many incoming moves for the turn; repeated use becomes less reliable."},
  [112] = {"Sets entry hazards.", "Places Spikes on the opponent's side, damaging grounded Pokémon when they switch in."},
  [113] = {"Negates foe's evasion advantages.", "Marks the target so certain accuracy and Ghost-immunity interactions are bypassed."},
  [114] = {"Both battlers faint after a countdown.", "Starts a perish count on affected Pokémon; they faint when the count reaches zero unless they switch out."},
  [115] = {"Starts a sandstorm.", "Changes the weather to sandstorm for several turns."},
  [116] = {"Survives the turn with at least 1 HP.", "Prevents the user from being knocked out by most direct attacks that turn; repeated use may fail."},
  [117] = {"Power rises on consecutive turns.", "Locks the user into Rollout and increases power with each successful consecutive hit."},
  [118] = {"Raises foe ATK but confuses it.", "Raises the target's Attack sharply and then confuses it."},
  [119] = {"Power rises with consecutive hits.", "Power increases when Fury Cutter is used successfully on consecutive turns."},
  [120] = {"May infatuate the foe.", "Infatuates a compatible target, which may prevent it from acting."},
  [121] = {"Power depends on friendship.", "Deals more damage when the user's friendship is higher."},
  [122] = {"May heal or damage unpredictably.", "Present randomly produces different damage values or may heal the target."},
  [123] = {"Power rises as friendship falls.", "Deals more damage when the user's friendship is lower."},
  [124] = {"Protects the party from status.", "Prevents many major status conditions from affecting the user's side for several turns."},
  [125] = {"Can thaw a frozen target.", "Deals damage and has the move-specific interaction that can thaw a frozen target."},
  [126] = {"Power varies randomly.", "Chooses a Magnitude level that determines the move's power."},
  [127] = {"Switches out and passes stat changes.", "The user switches out while passing eligible stat stages and effects to the replacement."},
  [128] = {"Hits harder if the foe switches.", "Power is increased when it catches the target switching out."},
  [129] = {"Removes trapping and hazards.", "Deals damage and clears several trapping effects and entry hazards from the user's side."},
  [130] = {"Always deals 20 HP damage.", "Inflicts a fixed 20 HP of damage when it hits."},
  [132] = {"Restores HP; amount depends on weather.", "Restores the user's HP, with the amount modified by the current weather."},
  [133] = {"Restores HP; amount depends on weather.", "Restores the user's HP, with the amount modified by the current weather."},
  [134] = {"Restores HP; amount depends on weather.", "Restores the user's HP, with the amount modified by the current weather."},
  [135] = {"Type and power depend on the user.", "Hidden Power's type and power are derived from the user's individual values."},
  [136] = {"Starts rain.", "Changes the weather to rain for several turns."},
  [137] = {"Starts harsh sunlight.", "Changes the weather to harsh sunlight for several turns."},
  [142] = {"Maximizes ATK at the cost of HP.", "Consumes a large amount of the user's HP to maximize its Attack stage when possible."},
  [143] = {"Copies the foe's stat changes.", "Copies the target's current stat-stage changes onto the user."},
  [144] = {"Returns special damage.", "Returns amplified special damage from an eligible attack used against the user."},
  [145] = {"Raises Defense, then attacks.", "Uses a charging turn that raises Defense before the damaging strike."},
  [146] = {"May flinch; stronger vs airborne foes.", "Deals damage, may cause flinching, and has special interactions with airborne targets."},
  [147] = {"Can hit underground targets harder.", "Deals damage with a special interaction against targets using Dig."},
  [148] = {"Hits after a delay.", "Schedules damage to strike the target after a delay rather than immediately."},
  [149] = {"Can hit airborne targets harder.", "Deals damage with a special interaction against targets using Fly or Bounce-like states."},
  [150] = {"May flinch; strong vs minimized foes.", "Deals damage, may flinch, and has a special interaction with minimized targets."},
  [151] = {"Charges, then attacks.", "Normally stores sunlight for one turn before attacking; weather can alter the behavior."},
  [152] = {"May paralyze; weather affects accuracy.", "Deals damage, may paralyze, and its accuracy has weather-specific behavior."},
  [153] = {"Escapes or switches the user out.", "Ends a wild battle or switches the user when the battle rules permit it."},
  [154] = {"Party members attack in sequence.", "Uses eligible party members to contribute hits to a multi-hit attack."},
  [155] = {"Becomes hard to hit before striking.", "Uses a semi-invulnerable preparation turn before attacking."},
  [156] = {"Raises Defense.", "Raises the user's Defense and activates Defense Curl interactions."},
  [157] = {"Restores HP.", "Restores the user's HP; field-use behavior is handled separately."},
  [158] = {"Moves first and flinches on first turn out.", "Has high priority and can flinch the target, but only works on the user's first active turn."},
  [159] = {"Locks user into an uproar.", "Forces repeated attacks for several turns and prevents sleep while the uproar is active."},
  [160] = {"Stores energy for later moves.", "Adds a Stockpile count used by Spit Up and Swallow."},
  [161] = {"Uses stored energy to attack.", "Consumes Stockpile levels to determine the attack's power."},
  [162] = {"Uses stored energy to heal.", "Consumes Stockpile levels to restore HP."},
  [164] = {"Starts hail.", "Changes the weather to hail for several turns."},
  [165] = {"Prevents repeated use of the same move.", "Torments the target so it cannot select the same move on consecutive turns."},
  [166] = {"Raises Sp. Atk and confuses the foe.", "Raises the target's Special Attack and then confuses it."},
  [167] = {"Burns the foe.", "Inflicts a burn on the target."},
  [168] = {"Sharply lowers foe's offenses, then user faints.", "Greatly lowers the target's Attack and Special Attack, then causes the user to faint."},
  [169] = {"Stronger when user has a status condition.", "Power is increased when the user is burned, poisoned, or paralyzed."},
  [170] = {"Fails if user is hit before attacking.", "Prepares first; if the user takes eligible damage before its action, the move fails."},
  [171] = {"Extra damage to paralyzed foes; cures paralysis.", "Deals increased damage to a paralyzed target and removes that paralysis afterward."},
  [172] = {"Redirects attacks toward the user.", "Makes opposing single-target moves prefer the user for the turn."},
  [173] = {"Becomes a move based on terrain.", "Calls a different move according to the current battle terrain."},
  [174] = {"Boosts the next Electric attack.", "Charges power and raises Special Defense according to Gen 3 rules."},
  [175] = {"Stops the foe using status moves.", "Taunts the target, temporarily limiting it to damaging moves."},
  [176] = {"Boosts an ally's next attack.", "Raises the power of an ally's move for the turn in double battles."},
  [177] = {"Swaps held items.", "Exchanges the user's and target's held items when both items can be moved."},
  [178] = {"Copies the foe's Ability.", "Changes the user's Ability to match the target's when allowed."},
  [179] = {"Heals later.", "Creates a delayed healing effect that restores HP at the end of a future turn."},
  [180] = {"Uses a random party move.", "Calls a move chosen from eligible moves known by the user's party."},
  [181] = {"Roots user and restores HP each turn.", "Prevents switching and restores some HP each turn while active."},
  [182] = {"Lowers user's ATK and DEF after hitting.", "Deals damage, then lowers the user's Attack and Defense."},
  [183] = {"Reflects certain status moves.", "Returns compatible status moves to their source during the turn."},
  [184] = {"Recovers a consumed held item.", "Restores an eligible item the user previously consumed or lost."},
  [185] = {"Stronger if the user was hit first.", "Power increases when the user takes damage before it attacks that turn."},
  [186] = {"Breaks Reflect and Light Screen.", "Deals damage and removes Reflect or Light Screen from the target's side."},
  [187] = {"Makes the foe drowsy, then sleep.", "The target becomes drowsy and falls asleep at the end of the following turn if still eligible."},
  [188] = {"Removes the foe's held item.", "Deals damage and knocks off the target's held item when allowed."},
  [189] = {"Tries to match the foe's HP.", "Deals damage equal to the difference between the target's and user's current HP when positive."},
  [190] = {"Power falls as user's HP falls.", "Power is greatest at high HP and decreases as the user's HP is reduced."},
  [191] = {"Swaps Abilities.", "Exchanges the user's and target's Abilities when the battle rules permit it."},
  [192] = {"Blocks moves also known by the user.", "Prevents opponents from using moves that the user also knows while Imprison is active."},
  [193] = {"Cures poison, paralysis, or burn.", "Removes several common major status conditions from the user."},
  [194] = {"Drains PP if the user faints.", "If the user faints from an opposing move, that move can lose all remaining PP."},
  [195] = {"Steals certain support-move effects.", "Intercepts compatible moves that would otherwise benefit their user."},
  [196] = {"Power rises against heavier foes.", "Power is determined by the target's weight."},
  [197] = {"May cause an effect based on terrain.", "Deals damage and may inflict a secondary effect determined by the battle terrain."},
  [198] = {"Strong attack with recoil.", "Deals heavy damage and also hurts the user with recoil."},
  [199] = {"Confuses all nearby Pokémon.", "Confuses multiple battlers in range in a double battle."},
  [200] = {"High crit rate and may burn.", "Has an increased critical-hit chance and may inflict a burn."},
  [201] = {"Weakens Electric-type moves.", "Creates a field effect that reduces Electric-type move power."},
  [202] = {"May badly poison the foe.", "Deals damage and may inflict toxic poison."},
  [203] = {"Type and power change with weather.", "Changes type and may change power according to the current weather."},
  [204] = {"Sharply lowers user's Sp. Atk after hitting.", "Deals damage, then sharply lowers the user's Special Attack."},
  [205] = {"Lowers foe ATK and DEF.", "Lowers the target's Attack and Defense by one stage each."},
  [206] = {"Raises user's DEF and Sp. Def.", "Raises the user's Defense and Special Defense by one stage each."},
  [207] = {"Can hit foes during Fly-like moves.", "Deals damage and can strike targets in certain airborne semi-invulnerable states."},
  [208] = {"Raises user's ATK and DEF.", "Raises the user's Attack and Defense by one stage each."},
  [209] = {"High crit rate and may poison.", "Has an increased critical-hit chance and may poison the target."},
  [210] = {"Weakens Fire-type moves.", "Creates a field effect that reduces Fire-type move power."},
  [211] = {"Raises user's Sp. Atk and Sp. Def.", "Raises the user's Special Attack and Special Defense by one stage each."},
  [212] = {"Raises user's ATK and Speed.", "Raises the user's Attack and Speed by one stage each."},
  [213] = {"Changes user's type by terrain.", "Changes the user's type according to the current battle terrain."},
}

local SECONDARY = {
  [2]="poison", [4]="burn", [5]="freeze", [6]="paralyze", [31]="flinch",
  [68]="lower Attack", [69]="lower Defense", [70]="lower Speed",
  [71]="lower Sp. Atk", [72]="lower Sp. Def", [73]="lower Accuracy",
  [74]="lower Evasion", [76]="confuse", [146]="flinch", [150]="flinch",
  [152]="paralyze", [200]="burn", [202]="badly poison", [209]="poison",
}

local function stageText(spec)
  if not spec then return nil end
  local verb = spec.n > 0 and "Raises" or "Lowers"
  local who = spec.who == "user" and "user's" or "foe's"
  local n = math.abs(spec.n)
  local amount = n == 1 and "by 1 stage" or "by 2 stages"
  return string.format("%s %s %s %s.", verb, who, spec.stat, amount)
end

local function targetLabel(target)
  target = tonumber(target) or 0
  if target == 0 then return "Selected foe" end
  if target == 1 then return "Depends on move" end
  if target == 2 then return "User or selected battler" end
  if target == 4 then return "Random foe" end
  if target == 8 then return "Both foes" end
  if target == 16 then return "User" end
  if target == 32 then return "All other battlers" end
  if target == 64 then return "Opponent's field" end
  return "Battle-specific"
end

local function statEffect(def)
  local e = tonumber(def and def.effect)
  local spec = DIRECT_STAT[e]
  if not spec then return nil end
  local sentence = stageText(spec)
  return sentence, sentence
end

local function baseEffect(def)
  if not def then return "No move data.", "No move definition is available from the FireRed runtime." end

  local statShort, statLong = statEffect(def)
  if statShort then return statShort, statLong end

  local e = tonumber(def.effect)
  local row = e and EFFECT[e] or nil
  local short = row and row[1] or nil
  local long = row and row[2] or nil

  -- Curated runtime metadata can be more specific than the numeric effect.
  if def.hits then
    local lo, hi = tonumber(def.hits[1]) or 2, tonumber(def.hits[2]) or tonumber(def.hits[1]) or 2
    short = lo == hi and ("Hits " .. lo .. " times.") or string.format("Hits %d–%d times.", lo, hi)
    long = "Strikes the target multiple times during one move use."
  end
  if def.afterHit and def.afterHit.kind == "recoil" then
    local pct = math.floor((tonumber(def.afterHit.fraction) or 0.25) * 100 + 0.5)
    short = string.format("User takes %d%% recoil.", pct)
    long = string.format("After dealing damage, the user loses HP equal to about %d%% of the damage dealt.", pct)
  end

  if not short then
    if (tonumber(def.power) or 0) > 0 then
      short = "Deals damage."
      long = "Deals direct damage; no additional effect is exposed by the current FireRed move definition."
    else
      short = "Status move."
      long = "Applies a non-damaging battle effect defined by FireRed."
    end
  end

  local chance = tonumber(def.secondaryChance)
  local sec = e and SECONDARY[e] or nil
  if chance and chance > 0 and chance < 100 and sec then
    short = string.format("%d%% chance to %s.", chance, sec)
    long = string.format("Deals damage and has a %d%% chance to %s the target.", chance, sec)
  end

  return short, long
end

function MoveInfo.describe(def)
  local short, long = baseEffect(def)
  local accuracy = tonumber(def and def.accuracy)
  local power = tonumber(def and def.power) or 0
  local priority = tonumber(def and def.priority) or 0
  return {
    short = short,
    long = long,
    target = targetLabel(def and def.target),
    priority = priority,
    accuracy = accuracy,
    power = power,
    secondaryChance = tonumber(def and def.secondaryChance) or 0,
  }
end

return MoveInfo
