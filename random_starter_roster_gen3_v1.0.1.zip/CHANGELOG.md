# Changelog

## 1.0.1
- Added LeafGreen support alongside FireRed.
- Updated manifest game targets to `firered` and `leafgreen`.
- Added explicit runtime `supportedGames` metadata for both FRLG games.
- Added `LG_OAKS_LAB` as an accepted Oak's Lab map id.
- Kept the existing starter-slot, evolution-pool, rival-line and text-patching logic unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.0
- Initial FireRed-only release.
- Random stable roster of three base-stage Pokémon from three-stage families.
- Oak starter Poké Ball species replacement.
- Rival counter-choice and later evolution-line continuity.
- Save-persistent roster.
