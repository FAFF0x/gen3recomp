-- Trade Evolution Fix - Gen 3 / FireRed
-- v1.2.1
--
-- Replaces FireRed's vanilla EVO_TRADE / EVO_TRADE_ITEM rows with real
-- EVO_LEVEL rows so single-player level-up evolution, Pokédex viewers and
-- other data-driven UI mods all see the solo path directly.
--
-- FireRed's evolution row stores only one parameter.  An EVO_LEVEL row cannot
-- also encode a held-item id, so item requirements for converted trade-item
-- rows are enforced through the public evolution.check hook.  The item is
-- consumed only after pokemon.evolved fires.

local LEVEL_METHOD = "EVO_LEVEL"
local TRADE_METHOD = "EVO_TRADE"
local TRADE_ITEM_METHOD = "EVO_TRADE_ITEM"

-- FireRed item ids (pret include/constants/items.h).  String keys are kept too
-- so the mod works with both numeric opaque mons and string-shaped fixtures.
local ITEM_NUM = {
  KINGS_ROCK = 187,
  DEEP_SEA_TOOTH = 192,
  DEEP_SEA_SCALE = 193,
  METAL_COAT = 199,
  DRAGON_SCALE = 201,
  UP_GRADE = 218,
}

-- All vanilla trade evolutions present in FireRed's evolution table.
local TARGETS = {
  { source = "KADABRA",  into = "ALAKAZAM", level = 40 },
  { source = "MACHOKE",  into = "MACHAMP",  level = 40 },
  { source = "GRAVELER", into = "GOLEM",    level = 40 },
  { source = "HAUNTER",  into = "GENGAR",   level = 40 },

  { source = "POLIWHIRL", into = "POLITOED", level = 40, item = "KINGS_ROCK" },
  { source = "SLOWPOKE",  into = "SLOWKING", level = 37, item = "KINGS_ROCK", first = true },
  { source = "ONIX",      into = "STEELIX",  level = 40, item = "METAL_COAT" },
  { source = "SCYTHER",   into = "SCIZOR",   level = 40, item = "METAL_COAT" },
  { source = "SEADRA",    into = "KINGDRA",  level = 40, item = "DRAGON_SCALE" },
  { source = "PORYGON",   into = "PORYGON2", level = 40, item = "UP_GRADE" },
  { source = "CLAMPERL",  into = "HUNTAIL",  level = 40, item = "DEEP_SEA_TOOTH" },
  { source = "CLAMPERL",  into = "GOREBYSS", level = 40, item = "DEEP_SEA_SCALE" },
}

local function copyTable(row)
  local out = {}
  for k, v in pairs(row or {}) do out[k] = v end
  return out
end

local function normalizeItemKey(value)
  if value == nil then return nil end
  if type(value) ~= "string" then return nil end
  local s = value:upper()
  s = s:gsub("^ITEM_", "")
  s = s:gsub("'", "")
  s = s:gsub("[^A-Z0-9]+", "_")
  s = s:gsub("^_+", ""):gsub("_+$", "")
  return s
end

local function heldMatches(mon, itemKey, itemNum)
  if not mon or not itemKey then return true end
  local candidates = { mon.item, mon.heldItem }
  for _, held in ipairs(candidates) do
    if held ~= nil then
      local n = tonumber(held)
      if n and itemNum and n == itemNum then return true end
      local k = normalizeItemKey(held)
      if k and k == itemKey then return true end
    end
  end
  return false
end

local function clearHeldItem(mon)
  if not mon then return end
  -- Game3 uses 0 as the canonical no-item value.  Keep both aliases in sync.
  mon.item = 0
  mon.heldItem = 0
end

local function pairKey(sourceId, targetId)
  return tostring(sourceId) .. ">" .. tostring(targetId)
end

local function rowTarget(row)
  return row and (row.species or row.into or row.target)
end

return function(mod)
  local convertedPairs = {}
  local converted = 0
  local alreadyFixed = 0
  local missing = 0

  for _, spec in ipairs(TARGETS) do
    local species = mod.content.pokemon:get(spec.source)
    local target = mod.content.pokemon:get(spec.into)

    if not species or type(species.evolutions) ~= "table" or not target then
      missing = missing + 1
      mod.log:warn("No FireRed evolution data found for %s -> %s", spec.source, spec.into)
    else
      local tradeRow, existingLevelRow
      for _, evo in ipairs(species.evolutions) do
        if rowTarget(evo) == spec.into then
          if evo.method == TRADE_METHOD or evo.method == TRADE_ITEM_METHOD then
            tradeRow = evo
          elseif evo.method == LEVEL_METHOD then
            existingLevelRow = evo
          end
        end
      end

      if existingLevelRow then
        -- Another compatible mod already supplied a solo level path.  Do not
        -- overwrite it or add a duplicate row.
        alreadyFixed = alreadyFixed + 1
      elseif not tradeRow then
        missing = missing + 1
        mod.log:warn(
          "Vanilla FireRed trade evolution %s -> %s was not found; leaving it untouched",
          spec.source, spec.into
        )
      else
        local itemKey = normalizeItemKey(tradeRow.item) or spec.item
        if itemKey then itemKey = normalizeItemKey(itemKey) end
        local itemNum = itemKey and ITEM_NUM[itemKey] or nil

        local levelRow = copyTable(tradeRow)
        levelRow.method = LEVEL_METHOD
        levelRow.level = spec.level
        levelRow.species = spec.into
        -- Critical for Gen3: item and level share the same encoded parameter.
        -- Never leave item/param on an EVO_LEVEL row.
        levelRow.item = nil
        levelRow.param = nil
        levelRow.into = nil
        levelRow.target = nil

        local evolutions = {}
        if spec.first then
          -- Slowpoke: King's Rock path must be considered before Slowbro at 37.
          evolutions[#evolutions + 1] = levelRow
          for _, evo in ipairs(species.evolutions) do
            if evo ~= tradeRow then evolutions[#evolutions + 1] = copyTable(evo) end
          end
        else
          for _, evo in ipairs(species.evolutions) do
            if evo == tradeRow then
              evolutions[#evolutions + 1] = levelRow
            else
              evolutions[#evolutions + 1] = copyTable(evo)
            end
          end
        end

        mod.content.pokemon:patch(spec.source, { evolutions = evolutions })

        local sourceId = tonumber(species.index)
        local targetId = tonumber(target.index)
        if sourceId and targetId then
          convertedPairs[pairKey(sourceId, targetId)] = {
            source = spec.source,
            target = spec.into,
            level = spec.level,
            itemKey = itemKey,
            itemNum = itemNum,
          }
        end
        converted = converted + 1
      end
    end
  end

  -- Enforce held-item requirements on only the EVO_LEVEL rows this mod made.
  mod.hooks:wrap("evolution.check", function(nextFn, game, mon, evo, trigger)
    local sourceId = tonumber(mon and (mon.speciesId or mon.species))
    local targetId = tonumber(evo and evo.speciesId)
    local ours = sourceId and targetId and convertedPairs[pairKey(sourceId, targetId)] or nil

    if ours
      and evo
      and (evo.method == LEVEL_METHOD or tonumber(evo.methodId) == 4)
      and tonumber(evo.level or evo.param) == tonumber(ours.level)
    then
      if not trigger or trigger.kind ~= "levelup" then return false end
      if (tonumber(mon.level) or 1) < ours.level then return false end
      if ours.itemKey and not heldMatches(mon, ours.itemKey, ours.itemNum) then return false end
      return true
    end

    return nextFn(game, mon, evo, trigger)
  end, 500)

  -- Consume a required held item only after the evolution commits.  A canceled
  -- evolution never emits pokemon.evolved, so the item is retained.
  mod.events:on("pokemon.evolved", function(ev)
    if not ev or not ev.mon then return end
    if ev.via and ev.via ~= "level" and ev.via ~= LEVEL_METHOD then return end

    local sourceId = tonumber(ev.fromSpeciesId)
    local targetId = tonumber(ev.toSpeciesId)
    local ours = sourceId and targetId and convertedPairs[pairKey(sourceId, targetId)] or nil
    if not ours or not ours.itemKey then return end

    if heldMatches(ev.mon, ours.itemKey, ours.itemNum) then
      clearHeldItem(ev.mon)
    end
  end)

  mod.exports = mod.exports or {}
  mod.exports.version = "1.2.1"
  mod.exports.converted = converted

  mod.log:info(
    "Gen 3 Trade Evolution Fix replaced %d trade evolution(s); %d already fixed, %d missing",
    converted, alreadyFixed, missing
  )
end
