# Changelog

## 1.0.19
- Added icon-led Start Menu navigation with Pokédex, Pokémon, Bag, Trainer, Save, Options and Exit symbols.
- Added generic icon fallback for extra Start Menu entries injected by other mods.
- Added type-aware Party card accents and type badges using FireRed species data.
- Added visible status pills and yellow mid-HP state in Party cards.
- Added Bag pocket tabs and a larger, clearer item detail panel.
- Added icon-led Bag and Party action menus.
- Added subtle screen fade-in and selection pulse, with a UI ANIMATIONS toggle.
- Redesigned Trainer Card with Kanto identity panel, Poké Ball motif and eight badge slots.
- Preserved native FireRed ownership of menu logic, state transitions and callbacks.

## 1.0.18
- Reworked the default theme around recognizable Pokémon colors: Kanto blue, Poké Ball red, logo yellow and white menu cards.
- Added dedicated header/footer colors and stronger selection contrast.
- Removed the narrow Plain Pixel font from the overlay renderer.
- Switched to the readable built-in LÖVE font with smooth filtering.
- Increased minimum font sizes for body, small and hint text.
- Preserved the v1.0.17 layout, menu behavior and FireRed Game3 integration.

## 1.0.17
- Major visual and usability redesign.
- Compact FireRed-oriented layout and palette.
- Plain Pixel font support with fallback.
- Reworked Start, Bag and Party layouts.
- Fixed hidden Party CANCEL cursor.
- Fixed hidden Box special targets.
- Added visible Bag party-target selection.
- Added PC storage submenu presentation.
- Native fallback for PC transfer screens not safely represented by the overlay.

## 1.0.16
- First functional FireRed Game3 port using `src.ui.game3.*` and `render.hud`.
