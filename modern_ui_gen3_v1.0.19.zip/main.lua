-- Gen3 Modern UI Enhanced v1.0.19
-- FireRed-only port of the Gen2 Modern UI presentation model.
--
-- IMPORTANT: FireRed is not src.ui.gen3.*.  The current runtime exposes the
-- real game-specific modules under src.ui.game3.*.  This mod deliberately
-- leaves those modules in control of input, state transitions and callbacks,
-- and paints the modern presentation at render.hud, after the completed
-- 240x160 FireRed frame has already been composited.

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local MOD_ID = "gen3_modern_ui"

  local function req(name)
    local ok, value = pcall(require, name)
    if ok then return value end
    return nil
  end

  local Stack = req("src.ui.game3.stack")
  if not Stack then
    if mod.log and mod.log.warn then
      mod.log:warn("[%s] src.ui.game3.stack is unavailable; FireRed UI overlay disabled", MOD_ID)
    end
    return
  end

  local Pokemon = req("src.core.game3.pokemon")
  local ItemsData = req("src.core.game3.items_data")
  local Bag = req("src.core.game3.bag")
  local Storage = req("src.core.game3.storage")
  local Dex = req("src.core.game3.dex")
  local PokedexData = req("src.core.game3.pokedex_data")
  local Types = req("src.core.game3.battle.types")
  local BagChrome = req("src.ui.game3.bag_chrome")

  local StartMenu = req("src.ui.game3.start_menu")
  local BagMenu = req("src.ui.game3.bag_menu")
  local PartyMenu = req("src.ui.game3.party_menu")
  local SummaryMenu = req("src.ui.game3.summary_menu")
  local Pokedex = req("src.ui.game3.pokedex")
  local TrainerCard = req("src.ui.game3.trainer_card")
  local SaveMenu = req("src.ui.game3.save_menu")
  local OptionMenu = req("src.ui.game3.option_menu")
  local ShopMenu = req("src.ui.game3.shop_menu")
  local PcMenu = req("src.ui.game3.pc_menu")
  local BoxStorageUI = req("src.ui.game3.box_storage_ui")

  -- ---------------- options

  mod.options:define({
    {
      key = "theme", label = "UI THEME", type = "choice", default = "modern",
      choices = {
        { "POKéMON CLASSIC", "modern" },
        { "CLASSIC MONO", "classic" },
        { "POCKET GREEN", "green" },
        { "MIDNIGHT", "midnight" },
        { "FROST", "frost" },
        { "LIGHT", "light" },
        { "DARK", "dark" },
      },
    },
    {
      key = "ui_scale", label = "UI SCALE", type = "choice", default = "100",
      choices = {
        { "85%", "85" }, { "100%", "100" }, { "115%", "115" },
        { "130%", "130" }, { "150%", "150" },
      },
    },
    { key = "dim_world", label = "DIM BACKGROUND", type = "toggle", default = true },
    { key = "hints", label = "CONTROL HINTS", type = "toggle", default = true },
    { key = "animations", label = "UI ANIMATIONS", type = "toggle", default = true },
  })

  local THEMES = {
    modern = {
      -- Pokémon-inspired palette: Kanto blue, Poké Ball red and logo yellow.
      bg = { 0.075, 0.285, 0.565, 0.985 }, surface = { 0.975, 0.990, 1.000, 1 },
      raised = { 1.000, 0.965, 0.745, 1 }, selected = { 1.000, 0.820, 0.250, 1 },
      accent = { 0.900, 0.175, 0.175, 1 }, secondary = { 1.000, 0.790, 0.030, 1 },
      text = { 0.055, 0.180, 0.315, 1 }, muted = { 0.285, 0.405, 0.510, 1 },
      divider = { 0.510, 0.720, 0.900, 1 }, header = { 0.090, 0.330, 0.650, 1 },
      headerText = { 1.000, 1.000, 1.000, 1 }, footer = { 0.045, 0.145, 0.270, 1 },
      footerText = { 0.960, 0.985, 1.000, 1 }, hp = { 0.180, 0.690, 0.305, 1 },
      hpMid = { 0.975, 0.650, 0.090, 1 }, hpLow = { 0.860, 0.180, 0.150, 1 },
    },
    classic = {
      bg = { 0.035, 0.035, 0.030, 0.96 }, surface = { 0.96, 0.95, 0.89, 1 },
      raised = { 0.86, 0.85, 0.78, 1 }, selected = { 0.72, 0.77, 0.72, 1 },
      accent = { 0.06, 0.09, 0.12, 1 }, text = { 0.035, 0.045, 0.055, 1 },
      muted = { 0.25, 0.30, 0.36, 1 }, divider = { 0.34, 0.40, 0.47, 0.94 },
      hp = { 0.02, 0.34, 0.48, 1 }, hpLow = { 0.74, 0.16, 0.03, 1 },
    },
    green = {
      bg = { 0.035, 0.075, 0.040, 0.96 }, surface = { 0.84, 0.88, 0.70, 1 },
      raised = { 0.73, 0.80, 0.58, 1 }, selected = { 0.62, 0.73, 0.46, 1 },
      accent = { 0.07, 0.20, 0.14, 1 }, text = { 0.045, 0.095, 0.065, 1 },
      muted = { 0.18, 0.27, 0.19, 1 }, divider = { 0.27, 0.38, 0.24, 0.96 },
      hp = { 0.02, 0.34, 0.48, 1 }, hpLow = { 0.74, 0.16, 0.03, 1 },
    },
    midnight = {
      bg = { 0.018, 0.022, 0.040, 0.98 }, surface = { 0.035, 0.045, 0.075, 0.99 },
      raised = { 0.075, 0.090, 0.150, 1 }, selected = { 0.24, 0.18, 0.48, 1 },
      accent = { 0.70, 0.58, 1.00, 1 }, text = { 0.96, 0.95, 1.00, 1 },
      muted = { 0.74, 0.76, 0.89, 1 }, divider = { 0.34, 0.38, 0.54, 0.96 },
      hp = { 0.14, 0.78, 0.74, 1 }, hpLow = { 1.00, 0.48, 0.18, 1 },
    },
    frost = {
      bg = { 0.055, 0.090, 0.140, 0.96 }, surface = { 0.96, 0.98, 1.00, 1 },
      raised = { 0.88, 0.93, 0.98, 1 }, selected = { 0.38, 0.63, 0.88, 1 },
      accent = { 0.04, 0.38, 0.66, 1 }, text = { 0.055, 0.095, 0.160, 1 },
      muted = { 0.24, 0.32, 0.43, 1 }, divider = { 0.36, 0.49, 0.63, 0.96 },
      hp = { 0.02, 0.34, 0.48, 1 }, hpLow = { 0.74, 0.16, 0.03, 1 },
    },
    light = {
      bg = { 0.78, 0.80, 0.84, 0.97 }, surface = { 0.98, 0.98, 0.96, 1 },
      raised = { 0.89, 0.90, 0.88, 1 }, selected = { 0.40, 0.63, 0.88, 1 },
      accent = { 0.07, 0.24, 0.46, 1 }, text = { 0.035, 0.050, 0.085, 1 },
      muted = { 0.24, 0.29, 0.36, 1 }, divider = { 0.36, 0.43, 0.52, 1 },
      hp = { 0.02, 0.34, 0.48, 1 }, hpLow = { 0.74, 0.16, 0.03, 1 },
    },
    dark = {
      bg = { 0.012, 0.016, 0.024, 0.99 }, surface = { 0.055, 0.065, 0.085, 1 },
      raised = { 0.105, 0.125, 0.155, 1 }, selected = { 0.25, 0.52, 0.78, 1 },
      accent = { 0.52, 0.85, 1.00, 1 }, text = { 0.96, 0.98, 1.00, 1 },
      muted = { 0.73, 0.78, 0.88, 1 }, divider = { 0.34, 0.44, 0.56, 1 },
      hp = { 0.14, 0.78, 0.74, 1 }, hpLow = { 1.00, 0.48, 0.18, 1 },
    },
  }

  local fonts = {}
  local function font(size)
    -- Use LÖVE's highly readable built-in font instead of the narrow pixel font.
    -- The overlay is drawn in window space, so smooth filtering is preferable.
    size = math.max(12, math.floor(size + 0.5))
    local key = tostring(size)
    if fonts[key] then return fonts[key] end
    local ok, f = pcall(love.graphics.newFont, size)
    if not ok or not f then f = love.graphics.getFont() end
    if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    fonts[key] = f
    return f
  end

  local UI_ALPHA = 1
  local ANIM = { screen = nil, openedAt = 0 }

  local fallbackClock = 0
  local function nowTime()
    if love and love.timer and love.timer.getTime then
      local ok, v = pcall(love.timer.getTime)
      if ok and tonumber(v) then return tonumber(v) end
    end
    fallbackClock = fallbackClock + (1 / 60)
    return fallbackClock
  end

  local function easeOutCubic(v)
    v = math.max(0, math.min(1, tonumber(v) or 0))
    local q = 1 - v
    return 1 - q * q * q
  end

  local function color(c, alphaMul)
    alphaMul = alphaMul or 1
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * alphaMul * UI_ALPHA)
  end

  local function safe(v)
    if v == nil then return "" end
    local s = tostring(v)
    s = s:gsub("<PK><MN>", "POKéMON")
    s = s:gsub("<PKMN>", "POKéMON")
    s = s:gsub("<LV>", "Lv")
    return s
  end

  local function activeTheme()
    return THEMES[mod.options:get("theme") or "modern"] or THEMES.modern
  end

  local function getUiScale()
    return (tonumber(mod.options:get("ui_scale")) or 100) / 100
  end

  local function roundRect(mode, x, y, w, h, r)
    if love.graphics.rectangle then love.graphics.rectangle(mode, x, y, w, h, r, r) end
  end

  local function text(t, value, x, y, size, c, align, width)
    local f = font(size)
    love.graphics.setFont(f)
    color(c or t.text)
    if width then
      love.graphics.printf(safe(value), x, y, width, align or "left")
    else
      love.graphics.print(safe(value), x, y)
    end
  end

  local function panel(t, x, y, w, h, selected)
    local radius = math.min(8, h * 0.10)
    color(selected and t.raised or t.surface)
    roundRect("fill", x, y, w, h, radius)
    color(selected and t.accent or t.divider, selected and 0.72 or 0.46)
    love.graphics.setLineWidth(1)
    roundRect("line", x, y, w, h, radius)
  end

  local function selectedBand(t, x, y, w, h)
    local nudge = 0
    local glow = 0.94
    if mod.options:get("animations") ~= false then
      local pulse = math.sin(nowTime() * 5.2)
      nudge = pulse * math.min(1.4, h * 0.025)
      glow = 0.92 + (pulse + 1) * 0.025
    end
    x = x + nudge
    color(t.selected, glow)
    roundRect("fill", x, y, w, h, math.min(7, h * 0.20))
    color(t.accent)
    love.graphics.rectangle("fill", x, y, math.max(3, w * 0.008), h)
  end

  local function divider(t, x1, y1, x2, y2)
    color(t.divider, 0.72)
    love.graphics.setLineWidth(1)
    love.graphics.line(x1, y1, x2, y2)
  end

  local function hint(t, L, value)
    if mod.options:get("hints") == false then return end
    local fy = L.y + L.h - L.footerH
    color(t.footer or t.surface)
    love.graphics.rectangle("fill", L.x, fy, L.w, L.footerH)
    color(t.secondary or t.divider, 0.95)
    love.graphics.rectangle("fill", L.x, fy, L.w, math.max(2, 3 * L.s))
    text(t, value, L.x + L.pad, fy + math.max(6, L.footerH * 0.28),
      L.tiny, t.footerText or t.muted, "left", L.w - L.pad * 2)
  end

  local function header(t, L, title, subtitle)
    local ty = L.y + math.max(6, L.pad * 0.50)
    text(t, title, L.x + L.pad, ty, L.title, t.headerText or t.text)
    if subtitle and subtitle ~= "" then
      text(t, subtitle, L.x + L.w * 0.52, ty + L.title * 0.18,
        L.small, t.secondary or t.accent, "right", L.w * 0.48 - L.pad)
    end
    return L.contentY
  end

  local function layout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
    local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
    local base = math.max(0.64, math.min(w / 720, h / 480)) * getUiScale()
    local pad = math.max(9, 13 * base)
    local headerH = math.max(42, 49 * base)
    local footerH = math.max(27, 30 * base)
    return {
      x = x, y = y, w = w, h = h, s = base,
      pad = pad, gap = math.max(6, 9 * base),
      title = math.max(20, 24 * base), body = math.max(15, 17 * base),
      small = math.max(13, 14 * base), tiny = math.max(12, 12 * base),
      row = math.max(30, 35 * base), headerH = headerH, footerH = footerH,
      contentY = y + headerH, contentH = h - headerH - footerH,
    }
  end

  local function backdrop(t, L)
    love.graphics.setScissor(L.x, L.y, L.w, L.h)
    color(t.bg, mod.options:get("dim_world") == false and 0.92 or 1)
    love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    color(t.header or t.surface)
    love.graphics.rectangle("fill", L.x, L.y, L.w, L.headerH)
    -- Poké Ball red cap + Pokémon yellow separator make the default theme
    -- immediately recognizable without sacrificing contrast.
    color(t.accent, 0.98)
    love.graphics.rectangle("fill", L.x, L.y, L.w, math.max(3, 4 * L.s))
    color(t.secondary or t.divider, 0.96)
    love.graphics.rectangle("fill", L.x, L.contentY - math.max(2, 3 * L.s), L.w, math.max(2, 3 * L.s))
  end

  local function speciesOf(mon)
    if not mon then return nil end
    if Pokemon and Pokemon.speciesOf then
      local ok, sp = pcall(Pokemon.speciesOf, mon)
      if ok and sp then return sp end
    end
    return tonumber(mon.species or mon.speciesId or mon.id)
  end

  local function speciesName(monOrSpecies)
    local mon = type(monOrSpecies) == "table" and monOrSpecies or nil
    local sp = mon and speciesOf(mon) or tonumber(monOrSpecies)
    if mon then
      local nick = mon.nickname or mon.nick or mon.name
      if nick and tostring(nick) ~= "" then return tostring(nick) end
    end
    if Pokemon and Pokemon.name and sp then
      local ok, name = pcall(Pokemon.name, sp)
      if ok and name then return name end
    end
    return sp and ("POKéMON " .. tostring(sp)) or "POKéMON"
  end

  local function drawIcon(monOrSpecies, x, y, size)
    if not (Pokemon and Pokemon.icon and love and love.graphics) then return false end
    local sp = type(monOrSpecies) == "table" and speciesOf(monOrSpecies) or tonumber(monOrSpecies)
    if not sp then return false end
    local ok, icon = pcall(Pokemon.icon, sp)
    if not ok or not (icon and icon.image) then return false end
    local q = icon.quads and (icon.quads[0] or icon.quads[1])
    if not q then return false end
    local iw = tonumber(icon.w) or 32
    local ih = tonumber(icon.h) or 32
    color({1,1,1,1})
    love.graphics.draw(icon.image, q, x, y, 0, size / iw, size / ih)
    return true
  end

  local function hpValues(mon)
    local hp = tonumber(mon and (mon.hp or mon.currentHp or mon.currentHP)) or 0
    local max = tonumber(mon and (mon.maxHp or mon.maxhp or mon.maxHP)) or 1
    if max < 1 then max = 1 end
    return hp, max
  end

  local function hpBar(t, x, y, w, h, hp, max)
    local ratio = math.max(0, math.min(1, (tonumber(hp) or 0) / math.max(1, tonumber(max) or 1)))
    color(t.divider, 0.32)
    roundRect("fill", x, y, w, h, h / 2)
    local fill = ratio <= 0.25 and t.hpLow or (ratio <= 0.50 and (t.hpMid or t.selected) or t.hp)
    color(fill)
    roundRect("fill", x, y, w * ratio, h, h / 2)
  end

  local function drawRows(t, L, x, y, w, rows, cursor, opts)
    opts = opts or {}
    local rowH = opts.rowH or L.row
    local bottom = L.y + L.h - (L.footerH or L.pad) - L.pad
    local maxRows = opts.maxRows or math.max(1, math.floor((bottom - y) / rowH))
    local total = #rows
    local first = opts.first or 1
    if cursor and cursor >= first + maxRows then first = cursor - maxRows + 1 end
    if cursor and cursor < first then first = cursor end
    first = math.max(1, math.min(first, math.max(1, total - maxRows + 1)))
    for vis = 0, maxRows - 1 do
      local idx = first + vis
      local row = rows[idx]
      if not row then break end
      local yy = y + vis * rowH
      if idx == cursor then selectedBand(t, x, yy + 1, w, rowH - 2) end
      if vis > 0 and opts.separators ~= false then divider(t, x + 5, yy, x + w - 5, yy) end
      local iconSpace = 0
      if row.icon then
        local isz = math.min(rowH - 8, opts.iconSize or rowH - 10)
        pcall(row.icon, x + 8, yy + (rowH - isz) / 2, isz)
        iconSpace = isz + 8
      end
      local left = x + 10 + iconSpace
      local valueW = row.value ~= nil and math.min(w * 0.36, 170 * L.s) or 0
      text(t, row.label or row.name or row[1] or "", left,
        yy + rowH * (row.sub and 0.13 or 0.25), L.body, t.text, "left",
        math.max(20, w - (left - x) - valueW - 12))
      if row.value ~= nil and safe(row.value) ~= "" then
        text(t, row.value, x + w - valueW - 9, yy + rowH * 0.29,
          L.small, idx == cursor and t.text or t.muted, "right", valueW)
      end
      if opts.sub and row.sub and safe(row.sub) ~= "" then
        text(t, row.sub, left, yy + rowH * 0.57, L.tiny, t.muted, "left",
          math.max(20, w - (left - x) - 12))
      end
    end
    return first
  end

  local function modal(t, L, title, rows, cursor, message)
    local w = math.min(L.w * 0.52, 420 * L.s)
    local h = math.min(L.h * 0.62, (80 + #rows * 44) * L.s)
    local x = L.x + (L.w - w) / 2
    local y = L.y + (L.h - h) / 2
    color({0,0,0,0.58})
    love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    panel(t, x, y, w, h, true)
    text(t, title or "", x + L.pad, y + L.pad, L.title * 0.78, t.text)
    local yy = y + L.pad + L.title
    if message and message ~= "" then
      text(t, message, x + L.pad, yy, L.small, t.muted, "left", w - L.pad * 2)
      yy = yy + L.small * 2.5
    end
    drawRows(t, L, x + L.pad, yy, w - L.pad * 2, rows, cursor,
      { rowH = math.max(26, L.row * 0.86), maxRows = #rows })
  end

  local function drawItemIcon(id, x, y, size)
    if not (BagChrome and BagChrome.drawItemIcon and id) then return false end
    local ok, result = pcall(BagChrome.drawItemIcon, id, x, y, size / 24)
    return ok and result ~= false
  end

  local TYPE_NAMES = {
    [0] = "NORMAL", [1] = "FIGHT", [2] = "FLYING", [3] = "POISON",
    [4] = "GROUND", [5] = "ROCK", [6] = "BUG", [7] = "GHOST",
    [8] = "STEEL", [9] = "MYSTERY", [10] = "FIRE", [11] = "WATER",
    [12] = "GRASS", [13] = "ELECTRIC", [14] = "PSYCHIC", [15] = "ICE",
    [16] = "DRAGON", [17] = "DARK",
  }
  local TYPE_COLORS = {
    NORMAL = { 0.64, 0.62, 0.47, 1 }, FIGHT = { 0.75, 0.16, 0.12, 1 },
    FIGHTING = { 0.75, 0.16, 0.12, 1 }, FLYING = { 0.49, 0.62, 0.91, 1 },
    POISON = { 0.59, 0.27, 0.65, 1 }, GROUND = { 0.78, 0.62, 0.29, 1 },
    ROCK = { 0.65, 0.56, 0.22, 1 }, BUG = { 0.59, 0.68, 0.10, 1 },
    GHOST = { 0.42, 0.34, 0.65, 1 }, STEEL = { 0.58, 0.61, 0.68, 1 },
    FIRE = { 0.91, 0.32, 0.17, 1 }, WATER = { 0.22, 0.48, 0.86, 1 },
    GRASS = { 0.29, 0.68, 0.25, 1 }, ELECTRIC = { 0.94, 0.75, 0.08, 1 },
    PSYCHIC = { 0.90, 0.30, 0.52, 1 }, ICE = { 0.43, 0.78, 0.84, 1 },
    DRAGON = { 0.42, 0.20, 0.89, 1 }, DARK = { 0.34, 0.28, 0.24, 1 },
    MYSTERY = { 0.40, 0.68, 0.60, 1 },
  }

  local function monTypeNames(mon)
    local out = {}
    if not (Pokemon and Pokemon.types) then return out end
    local sp = speciesOf(mon)
    if not sp then return out end
    local ok, values = pcall(Pokemon.types, sp)
    if not ok or type(values) ~= "table" then return out end
    for i = 1, 2 do
      local raw = values[i]
      if raw ~= nil then
        local name = nil
        if Types and Types.name then
          local okN, n = pcall(Types.name, raw)
          if okN and n then name = tostring(n):upper() end
        end
        name = name or TYPE_NAMES[tonumber(raw)] or tostring(raw):upper()
        if i == 1 or name ~= out[1] then out[#out + 1] = name end
      end
    end
    return out
  end

  local function typeColor(name, fallback)
    return TYPE_COLORS[tostring(name or ""):upper()] or fallback
  end

  local function statusName(mon)
    local st = mon and (mon.status or mon.status1 or mon.condition)
    if st == nil or st == false or st == 0 or st == "" then return nil end
    if type(st) == "string" then
      local u = st:upper()
      if u == "OK" or u == "NONE" then return nil end
      if u:find("POI", 1, true) or u:find("PSN", 1, true) then return "PSN" end
      if u:find("BRN", 1, true) or u:find("BURN", 1, true) then return "BRN" end
      if u:find("PAR", 1, true) then return "PAR" end
      if u:find("SLP", 1, true) or u:find("SLEEP", 1, true) then return "SLP" end
      if u:find("FRZ", 1, true) or u:find("FREEZE", 1, true) then return "FRZ" end
      return u:sub(1, 4)
    end
    local n = tonumber(st) or 0
    if n % 8 ~= 0 then return "SLP" end
    if math.floor(n / 0x80) % 2 == 1 then return "PSN" end
    if math.floor(n / 0x40) % 2 == 1 then return "PAR" end
    if math.floor(n / 0x20) % 2 == 1 then return "FRZ" end
    if math.floor(n / 0x10) % 2 == 1 then return "BRN" end
    if math.floor(n / 0x08) % 2 == 1 then return "PSN" end
    return nil
  end

  local function drawPill(t, value, x, y, w, h, fill)
    color(fill or t.accent, 0.94)
    roundRect("fill", x, y, w, h, h / 2)
    text(t, value, x, y + math.max(1, h * 0.13), math.max(11, h * 0.58),
      { 1, 1, 1, 1 }, "center", w)
  end

  local function drawPokeball(t, x, y, size, alpha)
    alpha = alpha or 0.16
    local r = size / 2
    color(t.accent, alpha)
    love.graphics.circle("fill", x + r, y + r, r)
    color(t.surface, alpha * 1.20)
    love.graphics.rectangle("fill", x, y + r - math.max(2, size * 0.045), size, math.max(4, size * 0.09))
    color(t.surface, alpha * 1.20)
    love.graphics.circle("fill", x + r, y + r, size * 0.16)
    color(t.accent, alpha)
    love.graphics.circle("line", x + r, y + r, size * 0.16)
  end

  local function drawMenuIcon(t, id, x, y, size, selected)
    local c = selected and t.accent or (t.header or t.accent)
    local fg = selected and t.accent or t.text
    color(c, selected and 0.18 or 0.11)
    love.graphics.circle("fill", x + size / 2, y + size / 2, size / 2)
    color(fg, 0.98)
    love.graphics.setLineWidth(math.max(1.5, size * 0.07))
    local cx, cy = x + size / 2, y + size / 2
    id = tostring(id or ""):lower()
    if id == "pokemon" then
      love.graphics.circle("line", cx, cy, size * 0.30)
      love.graphics.line(x + size * 0.20, cy, x + size * 0.80, cy)
      love.graphics.circle("fill", cx, cy, size * 0.08)
    elseif id == "pokedex" then
      roundRect("line", x + size * 0.20, y + size * 0.19, size * 0.60, size * 0.62, size * 0.08)
      love.graphics.circle("line", x + size * 0.38, y + size * 0.36, size * 0.09)
      love.graphics.line(x + size * 0.29, y + size * 0.61, x + size * 0.70, y + size * 0.61)
    elseif id == "bag" then
      roundRect("line", x + size * 0.22, y + size * 0.35, size * 0.56, size * 0.43, size * 0.10)
      love.graphics.line(x + size * 0.34, y + size * 0.37, x + size * 0.34, y + size * 0.28, x + size * 0.66, y + size * 0.28, x + size * 0.66, y + size * 0.37)
    elseif id == "trainer" then
      love.graphics.circle("line", cx, y + size * 0.34, size * 0.13)
      roundRect("line", x + size * 0.25, y + size * 0.54, size * 0.50, size * 0.25, size * 0.10)
    elseif id == "save" then
      roundRect("line", x + size * 0.23, y + size * 0.20, size * 0.54, size * 0.60, size * 0.06)
      love.graphics.rectangle("line", x + size * 0.34, y + size * 0.24, size * 0.25, size * 0.18)
      love.graphics.rectangle("line", x + size * 0.34, y + size * 0.55, size * 0.31, size * 0.16)
    elseif id == "option" or id == "options" then
      love.graphics.circle("line", cx, cy, size * 0.14)
      for i = 0, 7 do
        local a = i * math.pi / 4
        local x1, y1 = cx + math.cos(a) * size * 0.23, cy + math.sin(a) * size * 0.23
        local x2, y2 = cx + math.cos(a) * size * 0.34, cy + math.sin(a) * size * 0.34
        love.graphics.line(x1, y1, x2, y2)
      end
    elseif id == "exit" then
      love.graphics.rectangle("line", x + size * 0.22, y + size * 0.20, size * 0.34, size * 0.60)
      love.graphics.line(x + size * 0.44, cy, x + size * 0.80, cy)
      love.graphics.line(x + size * 0.67, cy - size * 0.12, x + size * 0.80, cy)
      love.graphics.line(x + size * 0.67, cy + size * 0.12, x + size * 0.80, cy)
    else
      love.graphics.circle("line", cx, cy, size * 0.24)
    end
    love.graphics.setLineWidth(1)
  end

  local function drawActionIcon(t, label, x, y, size)
    local token = tostring(label or "?"):upper():sub(1, 1)
    color(t.accent, 0.13)
    love.graphics.circle("fill", x + size / 2, y + size / 2, size / 2)
    text(t, token, x, y + size * 0.13, math.max(11, size * 0.55), t.accent, "center", size)
  end

  local function quickBadgeCount(session)
    session = session or {}
    local b = session.badges
    local n = 0
    if type(b) == "table" then
      for i = 1, 8 do if b[i] == true or (tonumber(b[i]) or 0) > 0 then n = n + 1 end end
    elseif type(b) == "number" then
      for i = 0, 7 do if math.floor(b / (2 ^ i)) % 2 == 1 then n = n + 1 end end
    else
      for i = 1, 8 do if session["badge" .. i] then n = n + 1 end end
    end
    return n
  end

  -- ---------------- screen presenters

  local function drawStart(t, L, m)
    backdrop(t, L)
    local session = m._session or {}
    local name = tostring(session.name or session.playerName or "RED")
    local map = safe(session.mapName or session.map or "KANTO"):gsub("^FR_", ""):gsub("_", " ")
    local contentY = header(t, L, "PAUSE MENU", name:upper())
    local x = L.x + L.pad
    local y = contentY + L.gap
    local w = L.w - L.pad * 2
    local h = L.contentH - L.gap * 2
    local infoW = math.min(w * 0.33, 230 * L.s)
    local menuX = x + infoW + L.gap
    local menuW = w - infoW - L.gap

    panel(t, x, y, infoW, h, false)
    drawPokeball(t, x + infoW * 0.34, y + h * 0.47, infoW * 0.58, 0.12)
    text(t, "TRAINER", x + L.pad, y + L.pad, L.tiny, t.muted)
    text(t, name, x + L.pad, y + L.pad + L.tiny * 1.25, L.title * 0.88, t.text)
    text(t, map, x + L.pad, y + L.pad + L.tiny * 1.35 + L.title,
      L.small, t.muted, "left", infoW - L.pad * 2)
    divider(t, x + L.pad, y + h * 0.39, x + infoW - L.pad, y + h * 0.39)
    local infoRows = {
      { label = "BADGES", value = tostring(quickBadgeCount(session)) .. "/8" },
      { label = "PARTY", value = tostring(#(session.party or {})) .. "/6" },
      { label = "MONEY", value = "¥" .. tostring(math.floor(tonumber(session.money) or 0)) },
    }
    drawRows(t, L, x + L.pad, y + h * 0.42, infoW - L.pad * 2, infoRows, nil,
      { maxRows = 3, rowH = math.max(26, L.row * 0.80), separators = false })
    text(t, "KANTO JOURNEY", x + L.pad, y + h - L.pad - L.small,
      L.small, t.accent)

    panel(t, menuX, y, menuW, h, false)
    local rows = {}
    for i, e in ipairs(m.ENTRIES or {}) do
      local id = e.id or "menu"
      local active = i == (m.cursor or 1)
      rows[i] = {
        label = e.label or id or ("ITEM " .. i),
        icon = function(ix, iy, isz) drawMenuIcon(t, id, ix, iy, isz, active) end,
      }
    end
    local rowH = math.min(L.row * 1.07, (h - L.gap * 2) / math.max(1, #rows))
    drawRows(t, L, menuX + L.gap, y + L.gap, menuW - L.gap * 2,
      rows, m.cursor, { maxRows = #rows, rowH = rowH, iconSize = rowH * 0.68 })
    hint(t, L, "↑↓ SELECT    A OPEN    B / START CLOSE")
    if m._confirmExit then
      modal(t, L, "RETURN TO MAIN MENU?", { { label = "YES" }, { label = "NO" } }, m._confirmCursor or 2)
    end
  end

  local function itemName(id)
    if ItemsData and ItemsData.displayName then
      local ok, n = pcall(ItemsData.displayName, id)
      if ok and n then return n end
    end
    return tostring(id or "ITEM")
  end

  local function itemDesc(id, info)
    if type(info) == "table" and info.description then return info.description end
    if ItemsData and ItemsData.description and id then
      local ok, d = pcall(ItemsData.description, id)
      if ok and d then return d end
    end
    return ""
  end

  local function drawBag(t, L, m)
    backdrop(t, L)
    local pocket = m.currentPocket and m.currentPocket() or "ITEMS"
    local pocketLabel = safe(pocket):gsub("_", " ")
    local contentY = header(t, L, "BAG", pocketLabel)
    local x = L.x + L.pad
    local y = contentY + L.gap
    local w = L.w - L.pad * 2
    local h = L.contentH - L.gap * 2
    local listW = math.min(w * 0.62, 450 * L.s)
    local detailX = x + listW + L.gap
    local detailW = w - listW - L.gap
    panel(t, x, y, listW, h, false)
    panel(t, detailX, y, detailW, h, false)

    local raw = {}
    if m.list then
      local ok, found = pcall(m.list, pocket)
      if ok and type(found) == "table" then raw = found end
    end
    local sel = raw[m.cursor or 1]

    local tabsH = math.max(25, 29 * L.s)
    if m.mode ~= "party" then
      local order = (ItemsData and (ItemsData.BAG_POCKET_ORDER or ItemsData.POCKET_ORDER))
        or { "ITEMS", "KEY_ITEMS", "POKE_BALLS", "TM_CASE", "BERRY_POUCH" }
      local short = { ITEMS = "ITEMS", KEY_ITEMS = "KEY", POKE_BALLS = "BALLS", TM_CASE = "TM", BERRY_POUCH = "BERRIES" }
      local count = math.max(1, #order)
      local tabW = (listW - L.gap * 2) / count
      for i, key in ipairs(order) do
        local tx = x + L.gap + (i - 1) * tabW
        local active = i == (m.pocketIdx or 1)
        if active then selectedBand(t, tx + 1, y + 3, tabW - 2, tabsH - 5) end
        text(t, short[key] or safe(key):gsub("_", " "), tx, y + tabsH * 0.28,
          L.tiny, active and t.text or t.muted, "center", tabW)
      end
      divider(t, x + L.gap, y + tabsH, x + listW - L.gap, y + tabsH)
    end

    local listY = y + (m.mode == "party" and L.gap or tabsH + L.gap * 0.55)
    if m.mode == "party" then
      local party = (m._session and m._session.party) or {}
      local rows = {}
      for i, mon in ipairs(party) do
        local hp, max = hpValues(mon)
        rows[i] = {
          label = speciesName(mon), value = "Lv " .. tostring(mon.level or "?"),
          sub = tostring(hp) .. "/" .. tostring(max) .. " HP",
          icon = function(ix, iy, isz) drawIcon(mon, ix, iy, isz) end,
        }
      end
      rows[#rows + 1] = { label = "CANCEL" }
      drawRows(t, L, x + L.gap, listY, listW - L.gap * 2,
        rows, m.partyCursor or 1, { maxRows = 7, rowH = math.max(38, L.row), sub = true })
      text(t, "CHOOSE A POKéMON", detailX + L.pad, y + L.pad, L.body, t.text)
      text(t, "Select the target for this item.", detailX + L.pad,
        y + L.pad + L.body * 1.7, L.small, t.muted, "left", detailW - L.pad * 2)
      drawPokeball(t, detailX + detailW * 0.18, y + h * 0.54, detailW * 0.62, 0.08)
    else
      local rows = {}
      for _, r in ipairs(raw) do
        rows[#rows + 1] = { label = itemName(r.id), value = (tonumber(r.qty) or 1) > 1 and ("×" .. tostring(r.qty)) or "" }
      end
      rows[#rows + 1] = { label = "CLOSE BAG" }
      drawRows(t, L, x + L.gap, listY, listW - L.gap * 2,
        rows, m.cursor, { maxRows = 6, rowH = math.max(33, L.row * 0.93) })
      if sel then
        local iconSize = math.min(detailW * 0.42, 80 * L.s)
        local iconX = detailX + (detailW - iconSize) / 2
        local iconY = y + L.pad
        color(t.raised, 0.72)
        love.graphics.circle("fill", iconX + iconSize / 2, iconY + iconSize / 2, iconSize * 0.55)
        drawItemIcon(sel.id, iconX, iconY, iconSize)
        text(t, itemName(sel.id), detailX + L.pad, iconY + iconSize + L.gap,
          L.body, t.text, "center", detailW - L.pad * 2)
        local qtyW = math.min(detailW * 0.50, 100 * L.s)
        drawPill(t, "IN BAG ×" .. tostring(tonumber(sel.qty) or 1),
          detailX + (detailW - qtyW) / 2, iconY + iconSize + L.gap + L.body * 1.55,
          qtyW, math.max(22, 24 * L.s), t.accent)
        divider(t, detailX + L.pad, y + h * 0.58, detailX + detailW - L.pad, y + h * 0.58)
        text(t, itemDesc(sel.id, sel.info), detailX + L.pad, y + h * 0.62,
          L.small, t.muted, "left", detailW - L.pad * 2)
      else
        text(t, "NO ITEM", detailX + L.pad, y + h * 0.44, L.body, t.muted)
      end
    end
    hint(t, L, m.mode == "party" and "↑↓ POKéMON    A CONFIRM    B BACK"
      or "←→ POCKET    ↑↓ ITEM    A ACTION    B CLOSE")

    if m.mode == "action" then
      local acts = {}
      for i, a in ipairs(m.ACTIONS or {}) do
        local label = a
        acts[i] = { label = label, icon = function(ix, iy, isz) drawActionIcon(t, label, ix, iy, isz) end }
      end
      modal(t, L, itemName(sel and sel.id), acts, m.actionCursor or 1, itemDesc(sel and sel.id, sel and sel.info))
    elseif m.mode == "toss" then
      modal(t, L, "TOSS ITEM", {
        { label = itemName(sel and sel.id), value = "×" .. tostring(m.tossQty or 1) },
        { label = "A CONFIRM   B CANCEL" },
      }, 1)
    elseif m.mode == "message" and m.messageText then
      modal(t, L, "BAG", { { label = "OK" } }, 1, m.messageText)
    end
  end

  local function drawParty(t, L, m)
    if m.mode == "forget" or m.mode == "stat_growth" then return false end
    backdrop(t, L)
    local party = m._party or {}
    local contentY = header(t, L, "POKéMON", tostring(#party) .. "/6 PARTY")
    local x = L.x + L.pad
    local y = contentY + L.gap
    local w = L.w - L.pad * 2
    local h = L.contentH - L.gap * 2
    local cellW = (w - L.gap) / 2
    local cellH = (h - L.gap * 2) / 3
    for i = 1, 6 do
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local cx = x + col * (cellW + L.gap)
      local cy = y + row * (cellH + L.gap)
      local mon = party[i]
      local selected = i == (m.cursor or 1) or i == m.switchFrom
      panel(t, cx, cy, cellW, cellH, selected)
      if selected then selectedBand(t, cx + 1, cy + 1, cellW - 2, cellH - 2) end
      if mon then
        local types = monTypeNames(mon)
        local typeAccent = typeColor(types[1], t.accent)
        color(typeAccent, selected and 1 or 0.82)
        roundRect("fill", cx + 2, cy + 2, math.max(4, 5 * L.s), cellH - 4, 3)

        local iconSize = math.min(cellH - 10, 56 * L.s)
        drawIcon(mon, cx + 9, cy + (cellH - iconSize) / 2, iconSize)
        local tx = cx + iconSize + 19
        text(t, speciesName(mon), tx, cy + 5, L.body, t.text, "left", cellW - (tx - cx) - 9)
        text(t, "Lv " .. tostring(mon.level or "?"), tx, cy + 6 + L.body * 1.05, L.tiny, t.muted)

        local pillY = cy + 7 + L.body * 2.02
        local px = tx
        for ti = 1, math.min(2, #types) do
          local name = types[ti]
          local pw = math.max(42, math.min(66, (#name * 7 + 16) * L.s))
          drawPill(t, name, px, pillY, pw, math.max(18, 19 * L.s), typeColor(name, t.accent))
          px = px + pw + 5 * L.s
        end
        local st = statusName(mon)
        if st then
          local sw = math.max(38, 44 * L.s)
          drawPill(t, st, cx + cellW - sw - 8, cy + 7 + L.body * 1.02,
            sw, math.max(18, 19 * L.s), t.hpLow)
        end

        local hp, max = hpValues(mon)
        local by = cy + cellH - math.max(11, 12 * L.s)
        local barW = math.max(32, cellW - (tx - cx) - 10)
        hpBar(t, tx, by, barW, math.max(6, 7 * L.s), hp, max)
        text(t, tostring(hp) .. "/" .. tostring(max), tx, by - L.tiny * 1.10, L.tiny, t.muted)
      else
        text(t, "EMPTY", cx + 12, cy + cellH * 0.36, L.small, t.muted)
      end
    end
    local cancelW = math.min(120 * L.s, w * 0.24)
    local cancelX = L.x + L.w - L.pad - cancelW
    local cancelY = L.y + L.h - L.footerH + 3
    if (m.cursor or 1) == 7 then selectedBand(t, cancelX, cancelY, cancelW, L.footerH - 6) end
    text(t, "CANCEL", cancelX, cancelY + 4, L.tiny,
      (m.cursor or 1) == 7 and t.text or t.muted, "center", cancelW)
    hint(t, L, "D-PAD SELECT    A ACTION    B CLOSE")

    if m.mode == "action" then
      local acts = {}
      for i, a in ipairs(m.ACTIONS or {}) do
        local label = a
        acts[i] = { label = label, icon = function(ix, iy, isz) drawActionIcon(t, label, ix, iy, isz) end }
      end
      modal(t, L, speciesName(party[m.cursor or 1]), acts, m.actionCursor or 1)
    elseif m.mode == "item_action" then
      local acts = {}
      for i, a in ipairs(m.ITEM_ACTIONS or {}) do
        local label = a
        acts[i] = { label = label, icon = function(ix, iy, isz) drawActionIcon(t, label, ix, iy, isz) end }
      end
      modal(t, L, "HELD ITEM", acts, m.itemActionCursor or 1)
    elseif m.mode == "message" and m._messageText then
      modal(t, L, "POKéMON", { { label = "OK" } }, 1, m._messageText)
    elseif m.mode == "yesno" and m._yesNoPrompt then
      modal(t, L, m._yesNoPrompt, { { label = "YES" }, { label = "NO" } }, m._yesNoCursor or 1)
    end
  end

  local function movesFor(mon)
    local out = {}
    if not mon then return out end
    for i = 1, 4 do
      local mv = mon.moves and mon.moves[i]
      local id = type(mv) == "table" and (mv.id or mv.move or mv.moveId or mv.num or mv.name or mv[1]) or mv
      if id and id ~= 0 and id ~= "" then
        local name = nil
        if Pokemon and Pokemon.moveName then
          local ok, n = pcall(Pokemon.moveName, id)
          if ok then name = n end
        end
        out[#out + 1] = name or tostring(id)
      end
    end
    return out
  end

  local function drawSummary(t, L, m)
    backdrop(t, L)
    local party = m._party or {}
    local mon = party[m._cursor or 1]
    local page = tonumber(m._page) or 0
    local pageName = ({ [0] = "INFO", [1] = "SKILLS", [2] = "MOVES", [3] = "MOVE INFO", [4] = "EGG" })[page] or "SUMMARY"
    local contentY = header(t, L, "SUMMARY", pageName .. "  •  " .. speciesName(mon))
    local leftW = math.min(L.w * 0.33, 340 * L.s)
    local rightX = L.x + L.pad + leftW + L.gap
    local rightW = L.x + L.w - L.pad - rightX
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, L.x + L.pad, contentY, leftW, h, false)
    local iconSize = math.min(leftW * 0.58, h * 0.42)
    drawIcon(mon, L.x + L.pad + (leftW - iconSize) / 2, contentY + L.pad, iconSize)
    text(t, speciesName(mon), L.x + L.pad * 2, contentY + L.pad + iconSize + L.gap,
      L.body, t.text)
    text(t, "Lv " .. tostring(mon and mon.level or "?"), L.x + L.pad * 2,
      contentY + L.pad + iconSize + L.gap + L.body * 1.4, L.small, t.muted)

    panel(t, rightX, contentY, rightW, h, false)
    if page == 2 or page == 3 then
      local rows = {}
      local moves = movesFor(mon)
      for i, mv in ipairs(moves) do rows[i] = { label = mv, value = "MOVE " .. i } end
      if #rows == 0 then rows[1] = { label = "NO MOVES" } end
      drawRows(t, L, rightX + L.gap, contentY + L.gap, rightW - L.gap * 2,
        rows, m._moveCursor or 1, { maxRows = 5 })
    elseif page == 1 then
      local hp, max = hpValues(mon)
      local rows = {
        { label = "HP", value = tostring(hp) .. "/" .. tostring(max) },
        { label = "ATTACK", value = tostring(mon and (mon.attack or mon.atk) or "—") },
        { label = "DEFENSE", value = tostring(mon and (mon.defense or mon.def) or "—") },
        { label = "SP. ATK", value = tostring(mon and (mon.spAtk or mon.spa or mon.spatk) or "—") },
        { label = "SP. DEF", value = tostring(mon and (mon.spDef or mon.spd or mon.spdef) or "—") },
        { label = "SPEED", value = tostring(mon and (mon.speed or mon.spe) or "—") },
      }
      drawRows(t, L, rightX + L.gap, contentY + L.gap, rightW - L.gap * 2,
        rows, nil, { maxRows = #rows })
    else
      local rows = {
        { label = "SPECIES", value = speciesName(speciesOf(mon)) },
        { label = "LEVEL", value = tostring(mon and mon.level or "—") },
        { label = "EXP.", value = tostring(mon and (mon.exp or mon.experience) or "—") },
        { label = "HELD ITEM", value = itemName(mon and mon.heldItem) },
        { label = "STATUS", value = tostring(mon and (mon.status or "OK") or "—") },
      }
      drawRows(t, L, rightX + L.gap, contentY + L.gap, rightW - L.gap * 2,
        rows, nil, { maxRows = #rows })
    end
    hint(t, L, "←→ PAGE   ↑↓ POKéMON / MOVE   A SELECT   B BACK")
  end

  local function dexCount(side)
    local n = 0
    for _, on in pairs(side or {}) do if on then n = n + 1 end end
    return n
  end

  local function dexSeen(dex, sp)
    if Dex and Dex.isSeen then
      local ok, v = pcall(Dex.isSeen, dex, sp)
      if ok then return v == true end
    end
    return dex and dex.seen and (dex.seen[sp] or dex.seen[tostring(sp)]) == true
  end

  local function dexCaught(dex, sp)
    if Dex and Dex.isCaught then
      local ok, v = pcall(Dex.isCaught, dex, sp)
      if ok then return v == true end
    end
    local side = dex and (dex.caught or dex.owned)
    return side and (side[sp] or side[tostring(sp)]) == true
  end

  local function drawPokedex(t, L, m)
    local screen = m.screen or "mode_select"
    if screen == "category_grid" or screen == "action_popup" or screen == "area" or screen == "size" then
      return false
    end
    backdrop(t, L)
    local dex = m._dex or {}
    local contentY = header(t, L, "POKéDEX", string.upper(screen:gsub("_", " ")))
    local h = L.y + L.h - L.footerH - L.pad - contentY
    local leftW = math.min(L.w * 0.28, 300 * L.s)
    panel(t, L.x + L.pad, contentY, leftW, h, false)
    text(t, "SEEN", L.x + L.pad * 2, contentY + L.pad, L.small, t.muted)
    text(t, tostring(dexCount(dex.seen)), L.x + L.pad * 2,
      contentY + L.pad + L.small * 1.4, L.title, t.accent)
    text(t, "CAUGHT", L.x + L.pad * 2,
      contentY + L.pad + L.small * 1.4 + L.title * 1.35, L.small, t.muted)
    text(t, tostring(dexCount(dex.caught or dex.owned)), L.x + L.pad * 2,
      contentY + L.pad + L.small * 2.8 + L.title * 1.35, L.title, t.accent)
    local rightX = L.x + L.pad + leftW + L.gap
    local rightW = L.x + L.w - L.pad - rightX
    panel(t, rightX, contentY, rightW, h, false)

    if screen == "mode_select" then
      local rows = {}
      for i, e in ipairs(m.MODES or {}) do
        rows[i] = { label = e.label or e.id or "", value = e.unlocked == false and "LOCKED" or "" }
      end
      drawRows(t, L, rightX + L.gap, contentY + L.gap, rightW - L.gap * 2,
        rows, m.modeCursor or 1, { maxRows = 9, rowH = math.max(24, L.row * 0.8) })
    elseif screen == "ordered_list" and PokedexData and PokedexData.getOrderList then
      local ok, list = pcall(PokedexData.getOrderList, m.currentOrder, dex)
      list = ok and list or {}
      local rows = {}
      local first = math.max(1, (m.listScroll or 0) + 1)
      for idx = first, math.min(#list, first + 8) do
        local sp = list[idx]
        rows[#rows + 1] = {
          label = dexSeen(dex, sp) and speciesName(sp) or "-----",
          value = string.format("№%03d%s", tonumber(sp) or 0, dexCaught(dex, sp) and " ●" or ""),
          _idx = idx,
          icon = dexSeen(dex, sp) and function(ix, iy, isz) drawIcon(sp, ix, iy, isz) end or nil,
        }
      end
      local visibleCursor = (m.listCursor or 1) - first + 1
      drawRows(t, L, rightX + L.gap, contentY + L.gap, rightW - L.gap * 2,
        rows, visibleCursor, { maxRows = 9, rowH = math.max(24, L.row * 0.8) })
    else
      local sp = m._regSpecies or m.selectedSpecies
      local iconSize = math.min(rightW * 0.26, h * 0.42)
      drawIcon(sp, rightX + L.gap, contentY + L.gap, iconSize)
      text(t, speciesName(sp), rightX + L.gap + iconSize + L.gap,
        contentY + L.gap, L.title * 0.85, t.text)
      text(t, string.format("№%03d", tonumber(sp) or 0),
        rightX + L.gap + iconSize + L.gap,
        contentY + L.gap + L.title, L.body, t.accent)
      text(t, dexCaught(dex, sp) and "CAUGHT" or (dexSeen(dex, sp) and "SEEN" or "UNKNOWN"),
        rightX + L.gap + iconSize + L.gap,
        contentY + L.gap + L.title + L.body * 1.5, L.small, t.muted)
    end
    hint(t, L, "D-PAD NAVIGATE   A OPEN   SELECT CRY   B BACK")
  end

  local function countBadges(session)
    session = session or {}
    local b = session.badges
    local n = 0
    if type(b) == "table" then
      for i = 1, 8 do
        if b[i] == true or (tonumber(b[i]) or 0) > 0 then n = n + 1 end
      end
    elseif type(b) == "number" then
      for i = 0, 7 do
        local p = 2 ^ i
        if math.floor(b / p) % 2 == 1 then n = n + 1 end
      end
    else
      for i = 1, 8 do if session["badge" .. i] then n = n + 1 end end
    end
    return n
  end

  local function drawTrainer(t, L, m)
    backdrop(t, L)
    local s = m._session or {}
    local contentY = header(t, L, "TRAINER CARD", "KANTO LEAGUE")
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, x, contentY, w, h, false)

    local identityW = math.min(w * 0.37, 330 * L.s)
    color(t.accent, 0.96)
    roundRect("fill", x + 1, contentY + 1, identityW, h - 2, 7)
    drawPokeball(t, x + identityW * 0.23, contentY + h * 0.45,
      identityW * 0.72, 0.20)

    local name = tostring(s.name or s.playerName or "RED")
    local tid = tonumber(s.trainerId or s.trainerID or s.id) or 0
    local monogramSize = math.min(identityW * 0.34, h * 0.30)
    local mx = x + (identityW - monogramSize) / 2
    local my = contentY + L.pad
    color({1,1,1,1}, 0.96)
    love.graphics.circle("fill", mx + monogramSize / 2, my + monogramSize / 2, monogramSize / 2)
    text(t, name:sub(1, 1):upper(), mx, my + monogramSize * 0.19,
      monogramSize * 0.48, t.accent, "center", monogramSize)
    text(t, name, x + L.pad, my + monogramSize + L.gap,
      L.title * 0.82, {1,1,1,1}, "center", identityW - L.pad * 2)
    text(t, "ID No. " .. string.format("%05d", tid % 100000), x + L.pad,
      my + monogramSize + L.gap + L.title * 0.95, L.small,
      {1,1,1,0.88}, "center", identityW - L.pad * 2)
    text(t, "KANTO TRAINER", x + L.pad, contentY + h - L.pad - L.small,
      L.small, {1,1,1,0.90}, "center", identityW - L.pad * 2)

    local rx = x + identityW + L.gap
    local rw = w - identityW - L.gap - L.pad
    local rows = {
      { label = "MONEY", value = "¥" .. tostring(math.floor(tonumber(s.money) or 0)) },
      { label = "POKéDEX", value = tostring(dexCount(s.dex and (s.dex.caught or s.dex.owned))) },
      { label = "BADGES", value = tostring(countBadges(s)) .. "/8" },
      { label = "PLAY TIME", value = string.format("%02d:%02d", tonumber(s.playTimeHours or s.hours) or 0, tonumber(s.playTimeMinutes or s.minutes) or 0) },
    }
    drawRows(t, L, rx, contentY + L.pad, rw, rows, nil,
      { maxRows = #rows, rowH = math.max(28, L.row * 0.88) })
    divider(t, rx, contentY + h * 0.48, rx + rw, contentY + h * 0.48)
    text(t, "GYM BADGES", rx, contentY + h * 0.53, L.body, t.text)
    local badge = countBadges(s)
    local badgeGap = math.max(7, 9 * L.s)
    local size = math.min((rw - badgeGap * 3) / 4, math.max(26, 38 * L.s))
    for i = 1, 8 do
      local col = (i - 1) % 4
      local row = math.floor((i - 1) / 4)
      local px = rx + col * (size + badgeGap)
      local py = contentY + h * 0.61 + row * (size + badgeGap)
      color(i <= badge and (t.secondary or t.accent) or t.divider, i <= badge and 1 or 0.30)
      love.graphics.circle("fill", px + size / 2, py + size / 2, size / 2)
      color(i <= badge and t.accent or t.surface, i <= badge and 0.92 or 0.50)
      love.graphics.circle("fill", px + size / 2, py + size / 2, size * 0.31)
      text(t, tostring(i), px, py + size * 0.20, math.max(11, size * 0.34),
        i <= badge and {1,1,1,1} or t.muted, "center", size)
    end
    hint(t, L, "A / B / START CLOSE")
  end

  local function drawSave(t, L, m)
    backdrop(t, L)
    local s = m._session or {}
    local phase = m._phase or "confirm"
    local contentY = header(t, L, "SAVE", string.upper(phase))
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, x, contentY, w, h, false)
    local rows = {
      { label = "PLAYER", value = tostring(s.name or s.playerName or "RED") },
      { label = "LOCATION", value = safe(s.mapName or s.map or "KANTO"):gsub("^FR_", ""):gsub("_", " ") },
      { label = "BADGES", value = tostring(countBadges(s)) },
      { label = "POKéDEX", value = tostring(dexCount(s.dex and (s.dex.caught or s.dex.owned))) },
      { label = "TIME", value = string.format("%02d:%02d", tonumber(s.playTimeHours or s.hours) or 0, tonumber(s.playTimeMinutes or s.minutes) or 0) },
    }
    drawRows(t, L, x + L.pad, contentY + L.pad, w * 0.62, rows, nil,
      { maxRows = #rows, rowH = math.max(30, L.row) })
    local msg
    if phase == "confirm" then msg = "Would you like to save the game?"
    elseif phase == "overwrite" then msg = "There is already a save file. Overwrite it?"
    elseif phase == "saving" then msg = "SAVING... DO NOT TURN OFF THE POWER."
    else msg = tostring(s.name or "PLAYER") .. " saved the game." end
    text(t, msg, x + w * 0.64, contentY + L.pad, L.body, t.text, "left", w * 0.32)
    if phase == "confirm" or phase == "overwrite" then
      local opts = { { label = "YES" }, { label = "NO" } }
      drawRows(t, L, x + w * 0.64, contentY + h * 0.48, w * 0.30, opts, m.cursor or 1,
        { maxRows = 2, rowH = math.max(32, L.row) })
    end
    hint(t, L, "A CONFIRM   B CANCEL")
  end

  local function drawOptions(t, L, m)
    backdrop(t, L)
    local pages = m._pages or {}
    local p = pages[#pages]
    local contentY = header(t, L, p and p.title or "OPTION", "GAME SETTINGS")
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, x, contentY, w, h, false)
    local rows = {}
    if p then
      local first = math.max(1, (p.scroll or 0) + 1)
      for idx = first, math.min(#p.rows, first + 6) do
        local r = p.rows[idx]
        local value = ""
        if r and type(r.value) == "function" then
          local ok, v = pcall(r.value, m._ctx)
          if ok and v ~= nil then value = v end
        end
        rows[#rows + 1] = { label = r and (r.label or r.id) or "OPTION", value = value, _idx = idx }
      end
      rows[#rows + 1] = { label = "CANCEL" }
      local cursor = (p.index or 1) - first + 1
      if (p.index or 1) > #p.rows then cursor = #rows end
      drawRows(t, L, x + L.gap, contentY + L.gap, w - L.gap * 2,
        rows, cursor, { maxRows = 7, rowH = math.max(28, L.row * 0.88) })
    end
    hint(t, L, "↑↓ PICK   ←→ CHANGE   A SELECT   B BACK")
  end

  local function stockRows(m, sell)
    local rows = {}
    if sell and Bag and m._session and m._session.bag then
      local pockets = ItemsData and (ItemsData.POCKET_ORDER or ItemsData.BAG_POCKET_ORDER) or {}
      for _, pocket in ipairs(pockets or {}) do
        local ok, list = pcall(Bag.listPocket, m._session.bag, pocket)
        if ok then
          for _, slot in ipairs(list or {}) do
            local info = ItemsData and ItemsData.info and ItemsData.info(slot.id)
            local price = math.floor((tonumber(info and info.price) or 0) / 2)
            if price > 0 then rows[#rows + 1] = { id = slot.id, qty = slot.qty, price = price } end
          end
        end
      end
    else
      for _, id in ipairs(m._items or {}) do
        local info = ItemsData and ItemsData.info and ItemsData.info(id)
        rows[#rows + 1] = { id = id, price = tonumber(info and info.price) or 0 }
      end
    end
    return rows
  end

  local function drawShop(t, L, m)
    backdrop(t, L)
    local mode = m.mode or "root"
    local contentY = header(t, L, "POKé MART", string.upper(mode:gsub("_", " ")))
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, x, contentY, w, h, false)
    local money = tonumber(m._session and m._session.money) or 0
    text(t, "MONEY  ¥" .. tostring(math.floor(money)), x + L.pad, contentY + L.pad,
      L.body, t.accent)
    if mode == "root" then
      local rows = {}
      for i, e in ipairs(m.ROOT or {}) do rows[i] = { label = e.label or e.id } end
      drawRows(t, L, x + w * 0.46, contentY + L.pad, w * 0.48, rows, m.cursor or 1,
        { maxRows = #rows, rowH = math.max(34, L.row * 1.05) })
      text(t, m._status or "Welcome!", x + L.pad, contentY + h * 0.56,
        L.body, t.text, "left", w * 0.38)
    else
      local sell = mode:sub(1, 4) == "sell"
      local raw = stockRows(m, sell)
      local rows = {}
      for i, r in ipairs(raw) do
        rows[#rows + 1] = {
          label = itemName(r.id),
          value = "¥" .. tostring(r.price or 0) .. ((r.qty and r.qty > 1) and ("  ×" .. r.qty) or ""),
        }
      end
      rows[#rows + 1] = { label = "CANCEL" }
      drawRows(t, L, x + w * 0.34, contentY + L.pad, w * 0.60, rows, m.cursor or 1,
        { maxRows = 7, rowH = math.max(28, L.row * 0.86) })
      local p = m._pending
      if p then
        text(t, itemName(p.id), x + L.pad, contentY + L.pad + L.body * 2, L.body, t.text)
        text(t, "QTY ×" .. tostring(m.qty or 1), x + L.pad,
          contentY + L.pad + L.body * 3.4, L.body, t.accent)
      end
      if m._status then text(t, m._status, x + L.pad, contentY + h * 0.70,
        L.small, t.muted, "left", w * 0.29) end
    end
    hint(t, L, "↑↓ SELECT   A CONFIRM   B BACK")
  end

  local function drawPc(t, L, m)
    local mode = m.mode or "root"
    local supported = mode == "root" or mode == "storage_menu" or mode == "player_pc"
      or mode == "item_storage" or mode == "msg"
    if not supported then return false end
    backdrop(t, L)
    local contentY = header(t, L, "PC", string.upper(mode:gsub("_", " ")))
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    panel(t, x, contentY, w, h, false)
    local s = m._session or {}
    local rows = {}
    local cursor = m.cursor or 1
    if mode == "root" then
      local player = tostring(s.name or s.playerName or "RED")
      rows = {
        { label = "POKéMON STORAGE" },
        { label = player .. "'s PC" },
        { label = "PROF. OAK'S PC" },
        { label = "HALL OF FAME" },
        { label = "LOG OFF" },
      }
    elseif mode == "player_pc" then
      for i, e in ipairs(m.TOP_ACTIONS or {}) do rows[i] = { label = e.label or e.id } end
    elseif mode == "item_storage" then
      for i, e in ipairs(m.ITEM_STORAGE_ACTIONS or {}) do rows[i] = { label = e.label or e.id } end
    elseif mode == "storage_menu" then
      rows = {
        { label = "WITHDRAW POKéMON" }, { label = "DEPOSIT POKéMON" },
        { label = "MOVE POKéMON" }, { label = "MOVE ITEMS" }, { label = "SEE YA!" },
      }
    elseif mode == "msg" then
      rows = { { label = "A / B  CONTINUE" } }
      cursor = 1
    else
      return false
    end
    drawRows(t, L, x + w * 0.43, contentY + L.pad, w * 0.51, rows, cursor,
      { maxRows = math.min(7, #rows), rowH = math.max(30, L.row * 0.95) })
    text(t, m._status or "", x + L.pad, contentY + L.pad + L.body,
      L.body, t.text, "left", w * 0.35)
    hint(t, L, "↑↓ SELECT   A CONFIRM   B BACK")
  end

  local function currentStorage(m)
    if not (Storage and Storage.ensure and m._session) then return nil end
    local ok, st = pcall(Storage.ensure, m._session)
    return ok and st or nil
  end

  local function drawBox(t, L, m)
    backdrop(t, L)
    local st = currentStorage(m)
    local boxId = st and (st.currentBox or 1) or 1
    local box = st and st.boxes and st.boxes[boxId]
    local contentY = header(t, L, "POKéMON STORAGE", (box and box.name) or ("BOX " .. tostring(boxId)))
    local x = L.x + L.pad
    local w = L.w - L.pad * 2
    local h = L.y + L.h - L.footerH - L.pad - contentY
    local infoW = math.min(w * 0.28, 300 * L.s)
    panel(t, x, contentY, infoW, h, false)
    panel(t, x + infoW + L.gap, contentY, w - infoW - L.gap, h, false)
    local gridX = x + infoW + L.gap * 2
    local gridY = contentY + L.gap
    local gridW = w - infoW - L.gap * 3
    local topH = math.max(24, 28 * L.s)
    local btnW = gridW / 3
    local special = { {"PARTY", -10}, { (box and box.name) or ("BOX " .. tostring(boxId)), 0 }, {"CLOSE", -20} }
    for i, e in ipairs(special) do
      local bx = gridX + (i - 1) * btnW
      if (m.cursorSlot or 1) == e[2] then selectedBand(t, bx + 1, gridY, btnW - 2, topH) end
      text(t, e[1], bx, gridY + topH * 0.23, L.tiny,
        (m.cursorSlot or 1) == e[2] and t.text or t.muted, "center", btnW)
    end
    gridY = gridY + topH + L.gap * 0.5
    local cellW = gridW / 6
    local cellH = math.min((h - L.gap * 2 - topH) / 5, cellW * 0.82)
    local mons = box and box.mons or {}
    for slot = 1, 30 do
      local col = (slot - 1) % 6
      local row = math.floor((slot - 1) / 6)
      local cx = gridX + col * cellW
      local cy = gridY + row * cellH
      if slot == (m.cursorSlot or 1) and m.mode ~= "party_drawer" then
        selectedBand(t, cx + 2, cy + 2, cellW - 4, cellH - 4)
      end
      local mon = mons and mons[slot]
      if mon then
        drawIcon(mon, cx + cellW * 0.18, cy + cellH * 0.08, math.min(cellW * 0.64, cellH * 0.70))
      end
    end
    if (m.mode == "party_drawer" or m.drawerOpen) and m._session and m._session.party then
      local party = m._session.party
      local stripH = math.max(34, 40 * L.s)
      local py = contentY + h - stripH - L.gap
      local cell = gridW / 7
      color(t.bg, 0.86)
      roundRect("fill", gridX, py, gridW, stripH, 6)
      for i = 1, 6 do
        local px = gridX + (i - 1) * cell
        if (m.partyCursor or 1) == i then selectedBand(t, px + 1, py + 1, cell - 2, stripH - 2) end
        if party[i] then drawIcon(party[i], px + cell * 0.20, py + 3, math.min(cell * 0.60, stripH - 6)) end
      end
      local cx = gridX + 6 * cell
      if (m.partyCursor or 1) == 7 then selectedBand(t, cx + 1, py + 1, cell - 2, stripH - 2) end
      text(t, "X", cx, py + stripH * 0.25, L.small, t.muted, "center", cell)
    end
    local selected = nil
    if (m.cursorSlot or 1) >= 1 and (m.cursorSlot or 1) <= 30 then selected = mons and mons[m.cursorSlot] end
    if m.mode == "party_drawer" and m._session and m._session.party then selected = m._session.party[m.partyCursor or 1] end
    if selected then
      drawIcon(selected, x + L.pad, contentY + L.pad, math.min(infoW * 0.48, h * 0.28))
      text(t, speciesName(selected), x + L.pad, contentY + h * 0.38, L.body, t.text)
      text(t, "Lv " .. tostring(selected.level or "?"), x + L.pad, contentY + h * 0.38 + L.body * 1.5,
        L.small, t.muted)
      local hp, max = hpValues(selected)
      hpBar(t, x + L.pad, contentY + h * 0.57, infoW - L.pad * 2, math.max(6, 8 * L.s), hp, max)
      text(t, tostring(hp) .. "/" .. tostring(max), x + L.pad, contentY + h * 0.57 + L.small,
        L.small, t.muted)
    else
      text(t, "EMPTY SLOT", x + L.pad, contentY + h * 0.43, L.body, t.muted)
    end
    hint(t, L, "D-PAD MOVE   A ACTION   B BACK")
    if m.mode == "action_menu" then
      local rows = {}
      for i, a in ipairs(m._activeActions or {}) do rows[i] = { label = a } end
      modal(t, L, speciesName(selected), rows, m.actionCursor or 1)
    elseif m.mode == "box_menu" then
      modal(t, L, (box and box.name) or ("BOX " .. tostring(boxId)),
        { { label = "SWITCH BOX" }, { label = "WALLPAPER" }, { label = "CANCEL" } },
        m.boxMenuCursor or 1)
    elseif m.mode == "pick_box" then
      modal(t, L, "SWITCH BOX", { { label = (box and box.name) or ("BOX " .. tostring(boxId)), value = tostring(boxId) .. "/14" } }, 1,
        "↑ / ↓ choose a box.  A or B closes.")
    elseif m.mode == "pick_wallpaper" then
      modal(t, L, "WALLPAPER", { { label = "STYLE", value = tostring(m.wallpaperCursor or 1) .. "/16" } }, 1,
        "↑ / ↓ choose a wallpaper.  A applies, B cancels.")
    elseif m.mode == "message" and m._status then
      modal(t, L, "STORAGE", { { label = "OK" } }, 1, m._status)
    end
  end

  local PRESENTERS = {
    start = function(t, L, top) if StartMenu then drawStart(t, L, StartMenu) end end,
    bag = function(t, L, top) if BagMenu then drawBag(t, L, BagMenu) end end,
    party = function(t, L, top) if PartyMenu then return drawParty(t, L, PartyMenu) end end,
    summary = function(t, L, top) if SummaryMenu then drawSummary(t, L, SummaryMenu) end end,
    pokedex = function(t, L, top) if Pokedex then return drawPokedex(t, L, Pokedex) end end,
    trainer = function(t, L, top) if TrainerCard then drawTrainer(t, L, TrainerCard) end end,
    save = function(t, L, top) if SaveMenu then drawSave(t, L, SaveMenu) end end,
    option = function(t, L, top) if OptionMenu then drawOptions(t, L, OptionMenu) end end,
    shop = function(t, L, top) if ShopMenu then drawShop(t, L, ShopMenu) end end,
    pc_menu = function(t, L, top) if PcMenu then return drawPc(t, L, PcMenu) end end,
    box_storage = function(t, L, top) if BoxStorageUI then drawBox(t, L, BoxStorageUI) end end,
  }

  local function draw(game, viewport)
    if not (love and love.graphics and viewport) then return end
    local top = Stack.top and Stack.top() or nil
    if not (top and top.id and PRESENTERS[top.id]) then return end
    local t = activeTheme()
    local L = layout(viewport)
    local now = nowTime()
    if ANIM.screen ~= top.id then
      ANIM.screen = top.id
      ANIM.openedAt = now
    end
    if mod.options:get("animations") == false then
      UI_ALPHA = 1
    else
      UI_ALPHA = easeOutCubic((now - (ANIM.openedAt or now)) / 0.12)
      UI_ALPHA = math.max(0.12, UI_ALPHA)
    end
    love.graphics.push("all")
    local ok, err = pcall(PRESENTERS[top.id], t, L, top)
    love.graphics.setScissor()
    love.graphics.pop()
    UI_ALPHA = 1
    if not ok and mod.log and mod.log.warn then
      mod.log:warn("[%s] presenter %s failed: %s", MOD_ID, tostring(top.id), tostring(err))
    end
  end

  -- FireRed's render.hud is explicitly window-space and runs after the
  -- finished game frame.  This lets us cover the native 240x160 menu without
  -- touching its input/state owner underneath.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    draw(game, viewport)
    return result
  end)

  if mod.exports then
    mod.exports.generation = 3
    mod.exports.game = "firered"
    mod.exports.version = "1.0.19"
    mod.exports.isActive = function()
      local top = Stack.top and Stack.top() or nil
      return top and PRESENTERS[top.id] ~= nil or false
    end
  end

  if mod.log and mod.log.info then
    mod.log:info("[%s] v1.0.19 installed on FireRed Game3 UI stack", MOD_ID)
  end
end
