# Changelog

## 1.0.2

- FireRed-only Gen 3 port.
- Reimplemented stable held navigation against the native FireRed Bag and Help systems.
- Bag cadence preserved at 40-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Help cadence preserved at 20-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Edge presses remain immediate.
- Other FireRed menus remain edge-only and are not modified.
- Added generation-specific duplicate-patch guard.
- Added unique Gen 3 mod ID and FireRed-only manifest target.
- Does not patch the shared legacy `MenuRepeat` helper.
