# FireRed real-time repeat regression checklist

## Bag

- initial Up/Down press moves immediately;
- first held repeat occurs about 40/60 = 0.667 s later;
- subsequent held repeats occur about 5/60 = 0.0833 s apart;
- result is independent of GAME SPEED;
- multiple fixed updates at the same wall-clock timestamp do not produce multiple cursor moves;
- action/toss/submenu modes remain edge-only.

## Help

- initial direction press moves immediately;
- first held repeat occurs about 20/60 = 0.333 s later;
- subsequent held repeats occur about 5/60 = 0.0833 s apart;
- L/R open/close behavior and Help eligibility rules remain native.

## Scope

- no Gen1/Gen2 shared MenuRepeat patch;
- no overworld movement changes;
- no battle-input changes;
- FireRed-only manifest target.
