-- Stable Menu Navigation - Gen 3 / FireRed
-- v1.0.2
--
-- FireRed's Bag and Help screens implement GBA-style held-direction repeat
-- with logic-frame counters. GAME SPEED can execute multiple fixed updates per
-- rendered frame, which makes those counters advance faster than real time.
--
-- This mod keeps the native cadence but measures it in wall-clock time:
--   Bag:  40 frames initial delay, then every 5 frames
--   Help: 20 frames initial delay, then every 5 frames
-- at the native 60 Hz cadence. Physical edge presses remain immediate.

local VERSION = "1.0.2"
local MOD_ID = "pokemonmod_gen3_stable_menu_navigation"
local PATCH_KEY = "__pokemonmod_gen3_stable_menu_navigation_v1"
local LOGIC_HZ = 60
local DIRS = { "up", "down", "left", "right" }

local BAG_DELAY_FRAMES = 40
local HELP_DELAY_FRAMES = 20
local REPEAT_RATE_FRAMES = 5

local function wallTime()
  if love and love.timer and type(love.timer.getTime) == "function" then
    local ok, value = pcall(love.timer.getTime)
    if ok and type(value) == "number" then return value end
  end
  if os and type(os.clock) == "function" then return os.clock() end
  return 0
end

local function sec(frames)
  return math.max(0, tonumber(frames) or 0) / LOGIC_HZ
end

local function clearState(state)
  state.dir = nil
  state.nextAt = nil
end

local function pressed(input, key)
  return input and type(input.wasPressed) == "function" and input:wasPressed(key) == true
end

local function down(input, key)
  return input and type(input.isDown) == "function" and input:isDown(key) == true
end

local function firstPressedDir(input)
  for _, key in ipairs(DIRS) do
    if pressed(input, key) then return key end
  end
  return nil
end

local function firstHeldDir(input)
  for _, key in ipairs(DIRS) do
    if down(input, key) then return key end
  end
  return nil
end

-- Returns one synthetic direction at most once per wall-clock deadline.
-- Edge presses are not synthesized here; callers continue to see the original
-- physical wasPressed edge directly.
local function realtimeRepeat(state, input, delayFrames, rateFrames)
  local now = wallTime()
  local edge = firstPressedDir(input)
  local held = firstHeldDir(input)

  if edge then
    state.dir = edge
    state.nextAt = now + sec(delayFrames)
    return nil
  end

  if held ~= state.dir then
    state.dir = held
    state.nextAt = held and (now + sec(delayFrames)) or nil
    return nil
  end

  if not held then
    clearState(state)
    return nil
  end

  if type(state.nextAt) ~= "number" then
    state.nextAt = now + sec(delayFrames)
    return nil
  end

  if now >= state.nextAt then
    -- Schedule from NOW instead of an old deadline. Fast-forward may call the
    -- handler several times in one rendered frame; this prevents a burst.
    state.nextAt = now + math.max(0.001, sec(rateFrames))
    return held
  end

  return nil
end

local function makeBagInputProxy(input, synthetic)
  return setmetatable({
    wasPressed = function(_, key)
      if (key == "up" or key == "down") and synthetic == key then
        return true
      end
      return pressed(input, key)
    end,
    isDown = function(_, key)
      -- Disable BagMenu's private logic-frame repeat counter. We re-inject the
      -- same directional repeat through wasPressed at real-time deadlines.
      if key == "up" or key == "down" then return false end
      return down(input, key)
    end,
  }, { __index = input })
end

local function makeHelpInputProxy(input, synthetic)
  return {
    wasPressed = function(_, key)
      if synthetic == key then return true end
      return pressed(input, key)
    end,
  }
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local okBag, BagMenu = pcall(require, "src.ui.game3.bag_menu")
  local okHelp, Help = pcall(require, "src.ui.game3.help_system")

  if not okBag or type(BagMenu) ~= "table" or type(BagMenu.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation could not access FireRed BagMenu")
    mod.exports.active = false
    mod.exports.reason = "FireRed BagMenu unavailable"
    return
  end
  if not okHelp or type(Help) ~= "table" or type(Help.update) ~= "function"
      or type(Help.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation could not access FireRed Help system")
    mod.exports.active = false
    mod.exports.reason = "FireRed Help system unavailable"
    return
  end

  local installed = rawget(_G, PATCH_KEY)
  if type(installed) == "table" and installed.active == true then
    -- An equivalent Gen 3 copy already owns the real-time gates. Do not layer
    -- another timing wrapper on top of it.
    mod.exports.active = true
    mod.exports.shared = true
    mod.exports.mode = "firered_realtime_repeat"
    mod.exports.version = VERSION
    return
  end

  local bagState = {}
  local helpState = {}

  local baseBagHandleInput = BagMenu.handleInput
  local baseBagShow = BagMenu.show
  local baseHelpUpdate = Help.update
  local baseHelpShow = Help.show

  if type(baseBagShow) == "function" then
    BagMenu.show = function(...)
      clearState(bagState)
      return baseBagShow(...)
    end
  end

  BagMenu.handleInput = function(input)
    -- Only the Bag's normal list has native held up/down repeat. Other modes
    -- deliberately remain edge-only, matching FireRed.
    local synthetic = nil
    if BagMenu.mode == "list" then
      synthetic = realtimeRepeat(
        bagState, input, BAG_DELAY_FRAMES, REPEAT_RATE_FRAMES
      )
    else
      -- Track release/change so returning to the list never inherits a stale
      -- deadline from a previous list interaction.
      clearState(bagState)
    end

    return baseBagHandleInput(makeBagInputProxy(input, synthetic))
  end

  if type(baseHelpShow) == "function" then
    Help.show = function(...)
      clearState(helpState)
      return baseHelpShow(...)
    end
  end

  Help.update = function(game)
    -- Closed Help keeps its exact native open/eligibility behavior (L/R,
    -- button mode, fades, context checks). Only the already-open navigation
    -- repeat is replaced.
    if not Help.open then
      clearState(helpState)
      return baseHelpUpdate(game)
    end

    local input = game and game.input
    if not input then return true end
    local synthetic = realtimeRepeat(
      helpState, input, HELP_DELAY_FRAMES, REPEAT_RATE_FRAMES
    )
    Help.handleInput(makeHelpInputProxy(input, synthetic))
    return true
  end

  rawset(_G, PATCH_KEY, {
    active = true,
    owner = MOD_ID,
    version = VERSION,
    bag = BagMenu,
    help = Help,
    bagHandleInput = BagMenu.handleInput,
    helpUpdate = Help.update,
  })

  mod.exports.active = true
  mod.exports.shared = false
  mod.exports.mode = "firered_realtime_repeat"
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.fireRedOnly = true
  mod.exports.logicHz = LOGIC_HZ
  mod.exports.bagInitialDelaySeconds = sec(BAG_DELAY_FRAMES)
  mod.exports.helpInitialDelaySeconds = sec(HELP_DELAY_FRAMES)
  mod.exports.repeatRateSeconds = sec(REPEAT_RATE_FRAMES)
  mod.exports.targets = { bag = true, help = true }

  mod.log:info(
    "Stable Menu Navigation Gen 3 enabled: FireRed Bag/Help held navigation uses real-time timing"
  )
end
