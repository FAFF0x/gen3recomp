-- Pokecenter Max Happiness Gen 3 v1.0.3
-- FireRed-only port of pokecenter_max_happiness_gen2.
--
-- FireRed's Pokemon Center nurse script executes special HealPlayerParty
-- (special id 0). We hook the composable script.command seam instead of
-- replacing Party.healAll globally, so whiteout / rival / other engine heals
-- remain untouched.

local HEAL_PLAYER_PARTY = 0x00
local MAX_FRIENDSHIP = 255

local function mapIdFromContext(ctx)
  if type(ctx) ~= "table" then return nil end

  local ow = ctx.overworld
  local map = ow and ow.map
  if type(map) == "table" and map.id then
    return tostring(map.id)
  end

  local session = ctx.session or ctx.save
  if type(session) == "table" and session.map then
    return tostring(session.map)
  end

  return nil
end

local function isPokemonCenter(ctx)
  local id = mapIdFromContext(ctx)
  if not id then return false end
  id = id:upper()

  -- FireRed map ids use e.g. FR_VIRIDIAN_CITY_POKEMON_CENTER_1F.
  -- Restricting to 1F avoids unrelated upstairs / network rooms.
  return id:find("POKEMON_CENTER_1F", 1, true) ~= nil
end

local function isEgg(mon)
  if type(mon) ~= "table" then return false end
  if mon.isEgg == true or mon.egg == true then return true end
  -- Runtime uses species 412 as the opaque Egg placeholder in several Game3
  -- party paths; keep it excluded just like the original Gen2 mod.
  local species = tonumber(mon.species or mon.speciesId) or 0
  return species == 412
end

local function maximizeParty(session)
  local changed = 0
  local party = type(session) == "table" and session.party or nil
  if type(party) ~= "table" then return changed end

  for _, mon in ipairs(party) do
    if type(mon) == "table" and not isEgg(mon) then
      local old = tonumber(mon.friendship or mon.happiness)
      if old ~= MAX_FRIENDSHIP then changed = changed + 1 end
      -- Game3-created mons carry both aliases and different engine paths read
      -- either one (e.g. Return accepts friendship or happiness).
      mon.friendship = MAX_FRIENDSHIP
      mon.happiness = MAX_FRIENDSHIP
    end
  end

  return changed
end

return function(mod)
  if not mod or not mod.hooks or type(mod.hooks.wrap) ~= "function" then
    error("Pokecenter Max Happiness Gen 3 requires Mod API hook support")
  end

  mod.hooks:wrap("script.command", function(next, ctx, op, row)
    -- Preserve the native FireRed command first. HealPlayerParty may yield while
    -- the nurse animation runs, but friendship is independent of HP/status/PP,
    -- so applying it immediately after dispatch is safe and deterministic.
    local result = next(ctx, op, row)

    local specialId = type(row) == "table" and tonumber(row.id or row[1]) or nil
    if op == "special" and specialId == HEAL_PLAYER_PARTY and isPokemonCenter(ctx) then
      local session = ctx and (ctx.session or ctx.save)
      local changed = maximizeParty(session)
      if mod.log and mod.log.info then
        mod.log:info(
          "Pokemon Center heal on %s: friendship set to 255 (%d changed)",
          tostring(mapIdFromContext(ctx) or "?"), changed
        )
      end
    end

    return result
  end, 0)

  mod.exports.maximizePartyHappiness = function(session)
    local target = session
    if target == nil and mod.game then
      target = mod.game.session or mod.game.save
    end
    return maximizeParty(target)
  end

  mod.exports.maximizePartyFriendship = mod.exports.maximizePartyHappiness

  if mod.log and mod.log.info then
    mod.log:info("Installed FireRed Pokemon Center heal -> max friendship hook")
  end
end
