# Changelog

## 1.0.3
- Ported the mod from Gen 2 to FireRed / Gen 3 only.
- Changed target to `games: ["firered"]`.
- Changed mod id to `pokecenter_max_happiness_gen3` to avoid collisions with the Gen2 build.
- Replaced the Gen2 `World:healParty()` patch with FireRed's real `special HealPlayerParty` script path.
- Uses the composable `script.command` hook instead of globally replacing `Party.healAll`.
- Sets both Gen3 friendship aliases (`friendship` and `happiness`) to 255.
- Applies only inside Pokemon Center 1F maps.
- Eggs remain excluded.
- Other Game3 healing paths stay vanilla.
