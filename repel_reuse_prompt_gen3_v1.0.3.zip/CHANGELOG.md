# Changelog

## 1.0.3
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Added explicit FRLG runtime metadata with `game = "frlg"` and `supportedGames`.
- Kept the shared Game3 Repel counter, `StepEvents.onRepelStep`, `ItemUse.useField`, Choice and Message logic unchanged.
- Preserved the existing `pokemonmod_gen3_repel_reuse_prompt` id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.2

- Ported the mod from Gen 2 to FireRed / Gen 3.
- Switched from Gen 2 `World:repelWoreOff` / `World:useRepel` to native Gen 3
  `StepEvents`, `Bag`, and `ItemUse` APIs.
- Preserves FireRed's native wear-off message, then opens a YES/NO reuse prompt.
- Remembers the last Repel type used through the public `item.use` hook.
- Added MAX REPEL -> SUPER REPEL -> REPEL fallback when the preferred type is out.
- Added Gen 3-specific id and FireRed-only manifest targeting.
- Avoids rebuilding the Repel counter or unrelated step-event logic.
