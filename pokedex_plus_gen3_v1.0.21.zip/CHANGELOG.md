# Changelog

## 1.0.21
- Restored the proven v1.0.8 render split.
- Added the DEX ENTRY page.
- Fixed the actual stack/invisible regression: removed `debug.traceback` from draw cleanup because `debug` is not guaranteed inside the mod sandbox.
- Uses one guarded `push("all")` / `pop()` pair with `pcall`, so cleanup always happens after renderer errors.
- Modern UI ON uses only the Modern renderer; Modern UI OFF uses only the FireRed vanilla renderer.

# Changelog

## 1.0.21
- Rebuilt directly from the user-confirmed working v1.0.8 source.
- Added DEX ENTRY as a sixth Pokémon detail tab.
- Added FireRed/LeafGreen category, height, weight and flavor-text display from Game3 Pokédex data.
- Up/Down switches FireRed/LeafGreen text when the two entries differ.
- Preserved v1.0.8 list/detail input routing, Search & Filter Lab and Modern UI behavior.
- Hardened the vanilla 240×160 draw path with guaranteed graphics-state cleanup.
- Keeps the native renderer below the Modern UI overlay so the screen remains visible if the overlay fails.

## 1.0.8
- Rebuilt search and filtering as a dedicated Search & Filter Lab.
- Added integrated controller keyboard and direct PC keyboard name search.
- Added combined NAME / TYPE / STATUS / SORT filtering with live result count and preview.
- Added visual type/status/sort option palettes under Modern UI.
- Added RESET/APPLY workflow and matching native FireRed fallback layout.
- Kept the cached/event-driven result model to avoid per-frame full-Dex scans.
- Preserved Modern UI integration and Trade Evolution Fix requirement display from 1.0.7.

## 1.0.7
- Evolution info now recognizes `pokemonmod_gen3_trade_evolution_fix`.
- Shows solo level/item requirements instead of stale vanilla TRADE text.
- Added compatibility for all 12 converted FireRed trade evolutions.
- No evolution mechanics were changed.

## 1.0.6
- Added adaptive `gen3_modern_ui` presentation for the custom Pokédex Plus stack.
- Preserved v1.0.5 cached list/data model and native FireRed fallback renderer.
- Added modern list sidebar, Pokémon detail identity card, stat bars and modern data panels.
- Modern overlay is window-space and runs after the base Modern UI HUD pass.


## 1.0.5
- Rebuilt the UI at FireRed's native 240×160 coordinate space.
- Removed oversized viewport-dependent scaling.
- Cached species/filter results to remove per-frame full Pokédex scans and stalls.
- Fixed ANY/type cycling by removing the leading-nil Lua array bug.
- Lazy-loads large front sprites only inside the detail Overview page.
- Retains Stats, Evolutions, Level Moves, Habitat and native AREA integration.

## 1.0.4
- Initial FireRed port.
