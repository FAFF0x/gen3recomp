-- HM & Field TM Anywhere - Gen 3 / FireRed v2.1.3
-- Native Game3 port of hm_anywhere_gen2_v2.1.0.

local HM_ROWS = {
  { item = 339, move = "CUT",        label = "CUT" },
  { item = 340, move = "FLY",        label = "FLY" },
  { item = 341, move = "SURF",       label = "SURF" },
  { item = 342, move = "STRENGTH",   label = "STRENGTH" },
  { item = 343, move = "FLASH",      label = "FLASH" },
  { item = 344, move = "ROCK_SMASH", label = "ROCK SMASH" },
  { item = 345, move = "WATERFALL",  label = "WATERFALL" },
}

-- In FireRed, of the Gen2 v2.1.0 field-TM set only DIG remains a TM with a
-- supported overworld handler. ROCK SMASH moved to HM06; HEADBUTT and SWEET
-- SCENT are not FireRed TMs.
local TM_ROWS = {
  { item = 316, move = "DIG", label = "DIG" }, -- TM28
}

local DEVICE_MON = {
  nickname = "FIELD DEVICE",
  name = "FIELD DEVICE",
  species = 25,
  speciesId = 25,
  level = 5,
  hp = 1,
  maxHp = 1,
  moves = {},
}

local DESTINATIONS = {
  { key="PALLET_TOWN",      label="PALLET TOWN",      heal=1 },
  { key="VIRIDIAN_CITY",    label="VIRIDIAN CITY",    heal=2 },
  { key="PEWTER_CITY",      label="PEWTER CITY",      heal=3 },
  { key="CERULEAN_CITY",    label="CERULEAN CITY",    heal=4 },
  { key="LAVENDER_TOWN",    label="LAVENDER TOWN",    heal=5 },
  { key="VERMILION_CITY",   label="VERMILION CITY",   heal=6 },
  { key="CELADON_CITY",     label="CELADON CITY",     heal=7 },
  { key="FUCHSIA_CITY",     label="FUCHSIA CITY",     heal=8 },
  { key="CINNABAR_ISLAND",  label="CINNABAR ISLAND",  heal=9 },
  { key="INDIGO_PLATEAU",   label="INDIGO PLATEAU",   heal=10 },
  { key="SAFFRON_CITY",     label="SAFFRON CITY",     heal=11 },
  { key="ONE_ISLAND",       label="ONE ISLAND",       heal=14 },
  { key="TWO_ISLAND",       label="TWO ISLAND",       heal=15 },
  { key="THREE_ISLAND",     label="THREE ISLAND",     heal=16 },
  { key="FOUR_ISLAND",      label="FOUR ISLAND",      heal=17 },
  { key="FIVE_ISLAND",      label="FIVE ISLAND",      heal=18 },
  { key="SIX_ISLAND",       label="SIX ISLAND",       heal=20 },
  { key="SEVEN_ISLAND",     label="SEVEN ISLAND",     heal=19 },
}

local function runtimeSession()
  local Runtime = package.loaded["src.core.game3.runtime"]
  if not Runtime then
    local ok, r = pcall(require, "src.core.game3.runtime")
    if ok then Runtime = r end
  end
  return Runtime and Runtime.getSession and Runtime.getSession() or nil
end

local function runtimeGame()
  local Runtime = package.loaded["src.core.game3.runtime"]
  return Runtime and Runtime._game or nil
end

local function contextualEnabled(mod)
  return mod.save:get("contextualActions", true) ~= false
end

local function setContextual(mod, enabled)
  mod.save:set("contextualActions", enabled and true or false)
end

local function bagHas(session, itemId)
  if not (session and session.bag) then return false end
  local ok, Bag = pcall(require, "src.core.game3.bag")
  return ok and Bag and Bag.has and Bag.has(session.bag, itemId, 1) == true
end

local function rowForMove(move)
  local FieldMoves = require("src.core.game3.field_moves")
  local target = FieldMoves.normalizeMoveId(move)
  for _, row in ipairs(HM_ROWS) do
    if FieldMoves.normalizeMoveId(row.move) == target then return row, "hm" end
  end
  for _, row in ipairs(TM_ROWS) do
    if FieldMoves.normalizeMoveId(row.move) == target then return row, "tm" end
  end
  return nil
end

local function ownsMove(session, move)
  local row = rowForMove(move)
  return row and bagHas(session, row.item) or false
end

local function helperMon(party)
  for i, mon in ipairs(party or {}) do
    if type(mon) == "table" and not mon.isEgg and not mon.egg then
      return mon, i - 1
    end
  end
  return DEVICE_MON, 6
end

local function currentMapId(session)
  local Map = package.loaded["src.core.game3.map"]
  return tostring((session and session.map) or (Map and Map.current) or "")
end

local function isCaveMap(mapId, mapDef)
  local u = tostring(mapId or ""):upper()
  local mt = mapDef and tonumber(mapDef.type)
  if mt == 4 then return true end -- MAP_TYPE_UNDERGROUND
  return u:find("CAVE", 1, true) ~= nil
      or u:find("TUNNEL", 1, true) ~= nil
      or u:find("MT_MOON", 1, true) ~= nil
      or u:find("VICTORY_ROAD", 1, true) ~= nil
      or u:find("SEAFOAM", 1, true) ~= nil
end

local function buildContext(session, mon)
  local P = require("src.core.game3.player")
  local C = require("src.core.game3.collision")
  local Objects = require("src.core.game3.objects")
  local Map = require("src.core.game3.map")
  local Space = package.loaded["src.core.game3.scripting.space"]
  local d = ({ up={0,-1}, down={0,1}, left={-1,0}, right={1,0} })[P.facing or "down"] or {0,1}
  local fx, fy = (P.cellX or 0) + d[1], (P.cellY or 0) + d[2]
  local mapDef = Map.currentDef and Map.currentDef() or nil
  local mapId = currentMapId(session)
  local beh = C.behavior and C.behavior(fx, fy) or nil
  local isWaterfall = beh == 0x13 or beh == 0x21
  local cave = isCaveMap(mapId, mapDef)
  return {
    party = session and session.party or {},
    mon = mon,
    store = Space and Space.store,
    session = session,
    facingObject = Objects.at and Objects.at(fx, fy) or nil,
    isFacingWater = C.isWater and C.isWater(fx, fy) or false,
    isSurfing = P.surfing == true,
    hasCuttableGrass = C.isGrass and (C.isGrass(fx, fy) or C.isGrass(P.cellX or 0, P.cellY or 0)) or false,
    mapType = mapDef and mapDef.type,
    isCave = cave,
    isDarkCave = cave,
    isFlashActive = false,
    canEscapeRope = cave,
    escapeWarp = true,
    isFacingWaterfall = isWaterfall,
    facing = P.facing or "down",
  }
end

local function visitedTable(mod)
  local t = mod.save:get("flyVisited", {})
  if type(t) ~= "table" then t = {} end
  return t
end

local function markVisited(mod, mapId)
  local u = tostring(mapId or ""):upper()
  if u == "" then return end
  local t = visitedTable(mod)
  local changed = false
  for _, d in ipairs(DESTINATIONS) do
    if u:find(d.key, 1, true) and not t[d.key] then
      t[d.key] = true
      changed = true
    end
  end
  if changed then mod.save:set("flyVisited", t) end
end

local function markHealVisited(mod, session)
  local hm = tostring(session and session.healMap or ""):upper()
  if hm ~= "" then markVisited(mod, hm) end
end

local Menu = {
  open = false,
  kind = "hm",
  mode = "list",
  cursor = 1,
  scroll = 0,
  rows = {},
  items = {},
  title = "HM ANYWHERE",
  footer = "A USE  B BACK",
  screenId = "HmAnywhereGen3",
  message = nil,
}

-- Present the custom HM/TM controller through the native Game3 `option`
-- surface.  Modern UI Gen3 already owns a presenter for that surface, while
-- the Stack still dispatches input/draw/update to `Menu` itself.  This keeps
-- the working HM logic independent from Modern UI and gives us a native
-- fallback when Modern UI is not installed.
local function menuLayerId()
  return "option"
end

local function optionMenuModule()
  local m = package.loaded["src.ui.game3.option_menu"]
  if m then return m end
  local ok, mod = pcall(require, "src.ui.game3.option_menu")
  return ok and mod or nil
end

local function saveOptionPresenterState()
  local O = optionMenuModule()
  if not O or Menu._optionPresenterSaved then return end
  Menu._optionPresenterSaved = {
    open = O.open, cursor = O.cursor, pages = O._pages, ctx = O._ctx,
    flat = O._flat, session = O._session, game = O._game, onClose = O._onClose,
  }
end

local function restoreOptionPresenterState()
  local O = optionMenuModule()
  local s = Menu._optionPresenterSaved
  if not (O and s) then Menu._optionPresenterSaved = nil; return end
  O.open, O.cursor, O._pages, O._ctx = s.open, s.cursor, s.pages, s.ctx
  O._flat, O._session, O._game, O._onClose = s.flat, s.session, s.game, s.onClose
  Menu._optionPresenterSaved = nil
end

local function syncOptionPresenter()
  local O = optionMenuModule()
  if not O or not Menu.open then return end
  local pageRows = {}
  local count = math.max(0, #Menu.rows - 1) -- Modern UI adds its own CANCEL row.
  for i = 1, count do
    local src = Menu.rows[i]
    local value = ""
    if src.id == "CONTEXT" then
      value = contextualEnabled(Menu.mod) and "ON" or "OFF"
    elseif src.disabled then
      value = ""
    elseif Menu.mode == "fly" then
      value = "FLY"
    elseif src.move then
      value = "USE"
    end
    local shown = tostring(src.label or src.id or "OPTION")
    if src.id == "CONTEXT" then shown = "CONTEXT ACTIONS" end
    pageRows[#pageRows + 1] = {
      id = src.id, label = shown,
      value = function() return value end,
    }
  end
  local scroll = Menu.scroll or 0
  O.open = true
  O.cursor = Menu.cursor or 1
  O._session = Menu.session
  O._game = Menu.game
  O._ctx = { session = Menu.session, game = Menu.game, options = {} }
  O._pages = {{
    title = Menu.title or "HM ANYWHERE", rows = pageRows,
    index = Menu.cursor or 1, scroll = scroll,
  }}
end

local function rebuildRows(mod)
  local session = Menu.session or runtimeSession()
  local src = Menu.kind == "tm" and TM_ROWS or HM_ROWS
  local rows = {}
  for _, row in ipairs(src) do
    if bagHas(session, row.item) then
      rows[#rows + 1] = { id=row.move, move=row.move, label=row.label, item=row.item }
    end
  end
  if #rows == 0 then
    rows[#rows + 1] = {
      id = "EMPTY",
      label = Menu.kind == "tm" and "NO OWNED FIELD TM" or "NO OWNED HM",
      disabled = true,
    }
  end
  rows[#rows + 1] = {
    id="CONTEXT",
    label=contextualEnabled(mod) and "CONTEXT: ON" or "CONTEXT: OFF",
  }
  rows[#rows + 1] = { id="CANCEL", label="CANCEL" }
  Menu.rows, Menu.items = rows, rows
  if Menu.cursor < 1 then Menu.cursor = 1 end
  if Menu.cursor > #rows then Menu.cursor = #rows end
  syncOptionPresenter()
end

local function flyRows(mod)
  local seen = visitedTable(mod)
  local out = {}
  for _, d in ipairs(DESTINATIONS) do
    if seen[d.key] then out[#out + 1] = d end
  end
  out[#out + 1] = { key="CANCEL", label="CANCEL" }
  return out
end

function Menu.show(kind, game, session, mod)
  Menu.open = true
  Menu.kind = kind == "tm" and "tm" or "hm"
  Menu.mode = "list"
  Menu.cursor = 1
  Menu.scroll = 0
  Menu.game = game or runtimeGame()
  Menu.session = session or runtimeSession()
  Menu.mod = mod
  Menu.message = nil
  Menu.title = Menu.kind == "tm" and "TM ANYWHERE" or "HM ANYWHERE"
  Menu.screenId = Menu.kind == "tm" and "TmAnywhereGen3" or "HmAnywhereGen3"
  markVisited(mod, currentMapId(Menu.session))
  markHealVisited(mod, Menu.session)
  saveOptionPresenterState()
  rebuildRows(mod)
  local Stack = require("src.ui.game3.stack")
  Stack.push(menuLayerId(), Menu, { hideBelow=true })
  syncOptionPresenter()
end

function Menu.close()
  if not Menu.open then return end
  local Stack = require("src.ui.game3.stack")
  Stack.pop(menuLayerId())
  Menu.open = false
  Menu.mode = "list"
  Menu.message = nil
  restoreOptionPresenterState()
end

local function closeToField()
  Menu.close()
  local StartMenu = package.loaded["src.ui.game3.start_menu"]
  if StartMenu and StartMenu.isOpen and StartMenu.isOpen() then StartMenu.close() end
end

local function setMessage(text)
  text = tostring(text or "Can't use that here.")
  local ok, Message = pcall(require, "src.ui.game3.message")
  if ok and Message and Message.show then
    Message.show(text, function()
      if Message.close then Message.close() end
      syncOptionPresenter()
    end)
    return
  end
  Menu.message = text
end

local function beginFly(mod, res)
  local FieldMoves = require("src.core.game3.field_moves")
  if not (res and res.ok and res.action == "fly") then
    setMessage((res and res.text) or FieldMoves.TEXT.CANT_USE_HERE)
    return
  end
  local rows = flyRows(mod)
  if #rows <= 1 then
    setMessage("No visited FLY destination\nis available yet.")
    return
  end
  Menu.mode = "fly"
  Menu.title = "FLY DESTINATION"
  Menu.rows, Menu.items = rows, rows
  Menu.cursor, Menu.scroll = 1, 0
  syncOptionPresenter()
end

local function chooseFly(row)
  if not row or row.key == "CANCEL" then
    Menu.mode = "list"
    Menu.title = "HM ANYWHERE"
    Menu.cursor = 1
    rebuildRows(Menu.mod)
    syncOptionPresenter()
    return
  end
  local HealLocations = require("src.core.game3.heal_locations")
  local loc = HealLocations.get(row.heal)
  if not loc then setMessage("That FLY point is unavailable."); return end
  local game = Menu.game or runtimeGame()
  if not game then setMessage("FLY is unavailable right now."); return end
  closeToField()
  local Warp = require("src.core.game3.warp")
  local ok, err = Warp.request(Menu.mod, game, loc.map, loc.x, loc.y, "down", { fade=true })
  if not ok then
    local Message = require("src.ui.game3.message")
    Message.show(tostring(err or "FLY failed."))
  end
end

local function useMove(row)
  if not row or not row.move then return end
  local session = Menu.session or runtimeSession()
  if not session then setMessage("Field data is unavailable."); return end
  local FieldMoves = require("src.core.game3.field_moves")
  local mon = helperMon(session.party)
  local ctx = buildContext(session, mon)
  local ok, res = pcall(FieldMoves.fromMenu, row.move, ctx)
  if not ok then setMessage("Field move failed."); return end
  if row.move == "FLY" then
    beginFly(Menu.mod, res)
    return
  end
  if not (res and res.ok) then
    setMessage((res and res.text) or FieldMoves.TEXT.CANT_USE_HERE)
    return
  end
  closeToField()
  local Field = require("src.core.game3.field")
  if Field.executeFieldMove then Field.executeFieldMove(res) end
end

function Menu.handleInput(input)
  if not Menu.open or not input then return end
  if Menu.message then
    if input:wasPressed("a") or input:wasPressed("b") or input:wasPressed("start") then
      Menu.message = nil
    end
    return
  end
  local n = #Menu.rows
  if n < 1 then return end
  if input:wasPressed("up") then
    Menu.cursor = ((Menu.cursor - 2) % n) + 1
  elseif input:wasPressed("down") then
    Menu.cursor = (Menu.cursor % n) + 1
  elseif input:wasPressed("b") then
    if Menu.mode == "fly" then
      Menu.mode = "list"
      Menu.title = "HM ANYWHERE"
      rebuildRows(Menu.mod)
      Menu.cursor = 1
    else
      Menu.close()
    end
  elseif input:wasPressed("a") or input:wasPressed("start") then
    local row = Menu.rows[Menu.cursor]
    if Menu.mode == "fly" then
      chooseFly(row)
    elseif row and row.id == "CANCEL" then
      Menu.close()
    elseif row and row.id == "CONTEXT" then
      setContextual(Menu.mod, not contextualEnabled(Menu.mod))
      rebuildRows(Menu.mod)
    else
      useMove(row)
    end
  end
  if Menu.open then syncOptionPresenter() end
end

function Menu.update()
  if Menu.open then syncOptionPresenter() end
end

local function clampScroll()
  local visible = 7
  local n = #Menu.rows
  if n <= visible then Menu.scroll = 0; return end
  if Menu.cursor - 1 < Menu.scroll then Menu.scroll = Menu.cursor - 1 end
  if Menu.cursor > Menu.scroll + visible then Menu.scroll = Menu.cursor - visible end
  if Menu.scroll < 0 then Menu.scroll = 0 end
  if Menu.scroll > n - visible then Menu.scroll = n - visible end
end

function Menu.draw()
  if not Menu.open then return end
  local Window = require("src.ui.game3.window")
  local FrlgFont = require("src.ui.game3.frlg_font")
  local Chrome = require("src.ui.game3.chrome")
  clampScroll()
  love.graphics.setColor(0.10, 0.31, 0.54, 1)
  love.graphics.rectangle("fill", 0, 0, 240, 160)
  love.graphics.setColor(1,1,1,1)
  Chrome.fixedStdFrame(2, 1, 26, 2)
  Window.printPx(Menu.title, 24, 10, { colors=FrlgFont.COLOR.NORMAL })
  Window.stdFrame(Window.template(4, 5, 22, 12))
  local visible = 7
  for slot=1, visible do
    local idx = Menu.scroll + slot
    local row = Menu.rows[idx]
    if not row then break end
    local y = 44 + (slot-1)*14
    if idx == Menu.cursor then Window.cursorPx(36, y) end
    Window.printPx(row.label or row.id or "?", 48, y, { colors=FrlgFont.COLOR.NORMAL })
  end
  FrlgFont.draw(Menu.mode == "fly" and "A FLY   B BACK" or "A USE   B BACK", 48, 145, {
    colors=FrlgFont.COLOR.WHITE,
  })
  if Menu.message then
    Chrome.dialogueFrame()
    FrlgFont.draw(FrlgFont.wrap(Menu.message, 200), 20, 122, {
      maxWidth=200, linePitch=14, colors=FrlgFont.COLOR.NORMAL,
    })
  end
end

return function(mod)
  -- FireRed owns these exact modules; do not load or probe Gen2 facades.
  local FieldMoves = require("src.core.game3.field_moves")

  -- One patch owner per runtime. If an equivalent Gen3 mod patched the same
  -- seam first, do not stack a second ownership substitution.
  if not FieldMoves.__hmAnywhereGen3OriginalPartyMoveUser then
    local original = FieldMoves.partyMoveUser
    FieldMoves.__hmAnywhereGen3OriginalPartyMoveUser = original
    FieldMoves.__hmAnywhereGen3Owner = mod.id
    FieldMoves.partyMoveUser = function(party, moveIdentifier)
      local mon, slot = original(party, moveIdentifier)
      if mon then return mon, slot end
      if not contextualEnabled(mod) then return nil, 6 end
      local session = runtimeSession()
      if not ownsMove(session, moveIdentifier) then return nil, 6 end
      return helperMon(party)
    end
  elseif FieldMoves.__hmAnywhereGen3Owner ~= mod.id then
    mod.log:warn("Another Gen3 HM Anywhere implementation already owns field-move substitution; contextual patch not duplicated.")
  end

  mod.hooks:wrap("ui.start_menu.items", function(next_, game, items)
    local out = next_(game, items)
    if type(out) ~= "table" then return out end
    local session = (game and game.session) or runtimeSession()
    local function hasEntry(id, label)
      for _, e in ipairs(out) do
        if e.id == id or tostring(e.label or ""):upper() == label then return true end
      end
      return false
    end
    local function insertBeforeSave(entry)
      local at = #out + 1
      for i,e in ipairs(out) do
        if e.id == "save" or tostring(e.label or ""):upper() == "SAVE" then at=i; break end
      end
      table.insert(out, at, entry)
    end
    -- Keep both entries visible at all times.  Ownership is evaluated only
    -- after opening the corresponding screen.  This avoids a timing problem
    -- during StartMenu.show where the FireRed session/TM Case may not yet be
    -- observable to a mod even though it is present in the live save.
    if not hasEntry("hm_anywhere_gen3_hm", "HM") then
      insertBeforeSave({
        id="hm_anywhere_gen3_hm", label="HM",
        desc={ "Use owned HMs", "without teaching" },
        onSelect=function(selectedGame, selectedSession)
          Menu.show("hm", selectedGame or game, selectedSession or session or runtimeSession(), mod)
        end,
      })
    end
    if not hasEntry("hm_anywhere_gen3_tm", "TM") then
      insertBeforeSave({
        id="hm_anywhere_gen3_tm", label="TM",
        desc={ "Use field TMs", "without teaching" },
        onSelect=function(selectedGame, selectedSession)
          Menu.show("tm", selectedGame or game, selectedSession or session or runtimeSession(), mod)
        end,
      })
    end
    return out
  end, 0, "hm_anywhere_gen3_start")

  mod.events:on("game.ready", function(event)
    local session = runtimeSession()
    markVisited(mod, currentMapId(session))
    markHealVisited(mod, session)
    mod.log:info("HM & Field TM Anywhere Gen3 v2.1.3 ready on FireRed; contextual actions %s",
      contextualEnabled(mod) and "ON" or "OFF")
  end)

  mod.events:on("map.entered", function(event)
    local session = runtimeSession()
    markVisited(mod, (event and (event.mapId or event.map)) or currentMapId(session))
    markHealVisited(mod, session)
  end)

  mod.exports.ownedHM = function(move)
    local row, kind = rowForMove(move)
    return kind == "hm" and row and bagHas(runtimeSession(), row.item) or false
  end
  mod.exports.ownedTM = function(move)
    local row, kind = rowForMove(move)
    return kind == "tm" and row and bagHas(runtimeSession(), row.item) or false
  end
  mod.exports.contextualEnabled = function() return contextualEnabled(mod) end
  mod.exports.setContextual = function(v) setContextual(mod, v) end
  mod.exports.version = "2.1.3"
end
