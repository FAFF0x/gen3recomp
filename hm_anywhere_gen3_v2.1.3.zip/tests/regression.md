# v2.1.1 regression checklist

- Manifest targets only `firered`.
- No executable references to Gen2 modules.
- HM entry appears only when a supported HM is owned.
- TM entry appears only when TM28 is owned.
- Contextual OFF restores normal learned-move requirement.
- Contextual ON lets native `FieldMoves.partyMoveUser` fall back to machine ownership only after the vanilla lookup fails.
- Duplicate patch sentinel prevents two HM Anywhere implementations from stacking the same replacement.
- Custom menu follows the Game3 static stack contract: `handleInput(input)`, `update()`, `draw()`.
- B returns to START; successful field move exits menus before calling `Field.executeFieldMove`.
