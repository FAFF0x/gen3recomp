# v2.1.2

- Fixed HM/TM entries not appearing in FireRed START.
- HM and TM are now always injected through `ui.start_menu.items`.
- Ownership is evaluated inside the opened menu, not while START is being built.
- Added explicit empty-state rows when no supported HM/TM is owned.
- Preserved duplicate-entry guards and Gen3-only target.

# Changelog

## 2.1.1

- Ported from Gen2 to native FireRed/Game3 modules.
- Target changed to FireRed only.
- New ID `hm_anywhere_gen3` avoids collision with the Gen2 package.
- Replaced Gen2 inventory/machine detection with native Game3 Bag + TM Case item IDs.
- Added native Game3 START -> HM and START -> TM menus.
- Added contextual ownership substitution through `src.core.game3.field_moves.partyMoveUser` with a duplicate-patch sentinel.
- Adapted machine set to FireRed: Rock Smash is HM06; the supported field TM is TM28 Dig.
- Added persisted contextual ON/OFF toggle.
- Added a FireRed Fly fallback using visited destinations and native Warp.request because the current Game3 region-map module exposes no Fly destination selection seam.

## 2.1.3

- Fixed HM/TM submenus falling back to the vanilla renderer when Modern UI Gen3 is active.
- The custom controller is now exposed through the native Game3 `option` stack surface while open.
- Added a synthetic OptionMenu page so Modern UI renders HM/TM rows, cursor, context state, Fly destinations and CANCEL with its normal modern layout.
- Preserves and restores the real OptionMenu state on entry/exit, avoiding collisions with normal game options.
- Invalid field-move messages now use the native Game3 message overlay so they remain visible above the modern presenter.
- No changes to the working HM/TM ownership or field-action logic from v2.1.2.
