-- SUMMON - Gen 3 / FireRed
-- v1.0.3
--
-- Adds SUMMON to FireRed's Start menu. The entered National Pokédex number is
-- resolved through the live Gen 3 Pokémon dataset, then a normal wild battle is
-- started through the native FireRed WorldAPI/BattleBridge path.

local VERSION = "1.0.3"
local MOD_ID = "pokemonmod_gen3_summon"
local SCREEN_ID = "pokemonmod_gen3_summon_screen"
local HOOK_PRIORITY = 1000

local GRID = {
  { "1", "2", "3" },
  { "4", "5", "6" },
  { "7", "8", "9" },
  { "DEL", "0", "OK" },
  { "CANCEL" },
}

local function normalizeLabel(label)
  return tostring(label or ""):upper():gsub("[^A-Z0-9]", "")
end

local function hasSummonRow(items)
  for _, item in ipairs(items or {}) do
    if normalizeLabel(item and item.label) == "SUMMON" then return true end
    if item and item.pokemonmodGen3Summon then return true end
  end
  return false
end

local function moveGrid(state, direction)
  local current = GRID[state.row]
  if direction == "up" then
    state.row = state.row > 1 and state.row - 1 or #GRID
    state.col = math.min(state.col, #GRID[state.row])
  elseif direction == "down" then
    state.row = state.row < #GRID and state.row + 1 or 1
    state.col = math.min(state.col, #GRID[state.row])
  elseif direction == "left" then
    state.col = state.col > 1 and state.col - 1 or #current
  elseif direction == "right" then
    state.col = state.col < #current and state.col + 1 or 1
  end
end

local function runtimeSession()
  local ok, Runtime = pcall(require, "src.core.game3.runtime")
  if ok and Runtime and Runtime.getSession then return Runtime.getSession() end
  return nil
end

local function hasHealthyParty(session)
  for _, mon in ipairs(session and session.party or {}) do
    if not (mon.isEgg or mon.egg == true) and (tonumber(mon.hp) or 0) > 0 then
      return true
    end
  end
  return false
end

local function summonLevel(session)
  for _, mon in ipairs(session and session.party or {}) do
    if not (mon.isEgg or mon.egg == true) and (tonumber(mon.hp) or 0) > 0 then
      local lv = math.floor(tonumber(mon.level or mon.lvl) or 1)
      if lv < 1 then lv = 1 elseif lv > 100 then lv = 100 end
      return lv
    end
  end
  return nil
end

local function buildDexIndex()
  local Pokemon = require("src.core.game3.pokemon")
  if not Pokemon._names then Pokemon.install(nil) end

  local byDex, maxDex = {}, 0
  local national = Pokemon._national and Pokemon._national.toSpecies

  if type(national) == "table" then
    for nat, species in pairs(national) do
      nat, species = tonumber(nat), tonumber(species)
      if nat and species and nat >= 1 and nat % 1 == 0 then
        local key = Pokemon.keyName(species)
        if key then
          nat = math.floor(nat)
          if not byDex[nat] then
            byDex[nat] = {
              dex = nat,
              species = species,
              name = Pokemon.name(species),
            }
          end
          if nat > maxDex then maxDex = nat end
        end
      end
    end
  end

  -- Safe fallback for a partially hydrated dataset. FireRed's National Dex
  -- covers 1..386; speciesFromNational also handles the internal Gen 3 gaps.
  if maxDex == 0 then
    for nat = 1, 386 do
      local species = Pokemon.speciesFromNational(nat)
      if species and Pokemon.keyName(species) then
        byDex[nat] = { dex = nat, species = species, name = Pokemon.name(species) }
        maxDex = nat
      end
    end
  end

  return byDex, maxDex
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local Stack = require("src.ui.game3.stack")
  local Window = require("src.ui.game3.window")
  local FrlgFont = require("src.ui.game3.frlg_font")
  local StartMenu = require("src.ui.game3.start_menu")
  local WorldAPI = require("src.world.game3.WorldAPI")

  local UI = {
    open = false,
    game = nil,
    byDex = {},
    maxDex = 386,
    digits = "",
    row = 1,
    col = 1,
    message = "",
  }

  local function se(id)
    pcall(function() require("src.core.game3.audio").playSe(id) end)
  end

  local function selectedNumber()
    if UI.digits == "" then return nil end
    return tonumber(UI.digits)
  end

  local function selectedSpecies()
    local n = selectedNumber()
    return n and UI.byDex[n] or nil
  end

  local function syncMessage()
    UI.message = ""
  end

  local function appendDigit(digit)
    if not UI.open then return end
    local maxLen = math.max(3, #tostring(math.max(1, UI.maxDex or 386)))
    if #UI.digits >= maxLen then return end
    if digit == "0" and UI.digits == "" then return end
    UI.digits = UI.digits .. tostring(digit)
    syncMessage()
    se(5)
  end

  local function deleteDigit()
    if not UI.open then return end
    if #UI.digits > 0 then
      UI.digits = UI.digits:sub(1, -2)
      syncMessage()
      se(5)
    end
  end

  local function clearDigits()
    UI.digits = ""
    syncMessage()
    se(5)
  end

  local function closeScreen()
    if not UI.open then return end
    UI.open = false
    Stack.pop(SCREEN_ID)
    se(9)
  end

  local function showFailure(game, text)
    local ok, Hud = pcall(require, "src.ui.game3.hud")
    if ok and Hud and Hud.openMessage then
      Hud.openMessage(game, text or "SUMMON failed.")
    end
  end

  local function submit()
    if not UI.open then return end
    local number = selectedNumber()
    if not number then
      UI.message = "ENTER A NUMBER"
      se(9)
      return
    end

    local row = UI.byDex[number]
    if not row then
      UI.message = string.format("No.%03d NOT FOUND", number)
      se(9)
      return
    end

    local session = runtimeSession()
    local level = summonLevel(session)
    if not level then
      UI.message = "NO HEALTHY POKéMON"
      se(9)
      return
    end

    local game = UI.game
    -- Remove our layer first and then the actual FireRed Start menu. This keeps
    -- the battle transition from returning to a stale modal menu afterwards.
    closeScreen()
    if StartMenu.isOpen and StartMenu.isOpen() then StartMenu.close() end

    local world = WorldAPI.new(game, MOD_ID)
    local ok, err = world:startWildBattle(row.species, level)
    if not ok then
      mod.log:warn("SUMMON failed for %s (National Dex %d, species %d): %s",
        tostring(row.name), row.dex, row.species, tostring(err))
      showFailure(game, "SUMMON failed.\n" .. tostring(err or "Try again."))
    end
  end

  local function activate(label)
    if tostring(label):match("^%d$") then
      appendDigit(label)
    elseif label == "DEL" then
      deleteDigit()
    elseif label == "OK" then
      submit()
    elseif label == "CANCEL" then
      closeScreen()
    end
  end

  function UI.show(game)
    UI.game = game
    UI.byDex, UI.maxDex = buildDexIndex()
    UI.digits = ""
    UI.row = 1
    UI.col = 1
    UI.message = hasHealthyParty(runtimeSession()) and "" or "NO HEALTHY POKéMON"
    UI.open = true
    Stack.push(SCREEN_ID, UI, { hideBelow = true })
    se(6)
    return true
  end

  function UI.handleInput(input)
    if not UI.open or not input then return end
    local current = GRID[UI.row]
    if input:wasPressed("up") then
      moveGrid(UI, "up"); se(5)
    elseif input:wasPressed("down") then
      moveGrid(UI, "down"); se(5)
    elseif input:wasPressed("left") then
      moveGrid(UI, "left"); se(5)
    elseif input:wasPressed("right") then
      moveGrid(UI, "right"); se(5)
    elseif input:wasPressed("select") then
      clearDigits()
    elseif input:wasPressed("start") then
      submit()
    elseif input:wasPressed("b") then
      closeScreen()
    elseif input:wasPressed("a") then
      activate(current[UI.col])
    end
  end

  local function textWidth(s)
    local ok, w = pcall(FrlgFont.measure, tostring(s or ""), { small = false })
    if ok and tonumber(w) then return w end
    return #tostring(s or "") * 8
  end

  local function centered(s, cx)
    return math.floor(cx - textWidth(s) / 2)
  end

  local MODERN = {
    bg = { 0.075, 0.285, 0.565, 0.995 },
    surface = { 0.975, 0.990, 1.000, 1 },
    raised = { 1.000, 0.965, 0.745, 1 },
    selected = { 1.000, 0.820, 0.250, 1 },
    accent = { 0.900, 0.175, 0.175, 1 },
    secondary = { 1.000, 0.790, 0.030, 1 },
    text = { 0.055, 0.180, 0.315, 1 },
    muted = { 0.285, 0.405, 0.510, 1 },
    divider = { 0.510, 0.720, 0.900, 1 },
    header = { 0.090, 0.330, 0.650, 1 },
    headerText = { 1.000, 1.000, 1.000, 1 },
    footer = { 0.045, 0.145, 0.270, 1 },
    footerText = { 0.960, 0.985, 1.000, 1 },
    ok = { 0.180, 0.690, 0.305, 1 },
    warn = { 0.920, 0.480, 0.160, 1 },
  }

  local FONT_CACHE = {}
  local function mfont(size)
    local lg = love and love.graphics
    if not (lg and lg.newFont) then return nil end
    size = math.max(8, math.floor(size or 12))
    if FONT_CACHE[size] then return FONT_CACHE[size] end
    local ok, f = pcall(lg.newFont, size)
    if ok and f then
      if f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
      FONT_CACHE[size] = f
      return f
    end
    return lg.getFont and lg.getFont() or nil
  end

  local function mcolor(c)
    local lg = love and love.graphics
    if lg and lg.setColor and c then lg.setColor(c[1], c[2], c[3], c[4] or 1) end
  end

  local function mrect(mode, x, y, w, h, r)
    local lg = love and love.graphics
    if lg and lg.rectangle then lg.rectangle(mode, x, y, w, h, r or 0, r or 0) end
  end

  local function mtext(text, x, y, size, color, align, width)
    local lg = love and love.graphics
    if not (lg and lg.print and lg.printf) then return end
    local prev = lg.getFont and lg.getFont() or nil
    local f = mfont(size)
    if f and lg.setFont then lg.setFont(f) end
    mcolor(color or MODERN.text)
    text = tostring(text or "")
    if align and width then
      lg.printf(text, x, y, width, align)
    else
      lg.print(text, x, y)
    end
    if prev and lg.setFont then lg.setFont(prev) end
  end

  local function drawPanel(x, y, w, h, tone)
    mcolor(tone or MODERN.surface)
    mrect("fill", x, y, w, h, 10)
    mcolor(MODERN.divider)
    mrect("fill", x + 1, y + 1, w - 2, h - 2, 10)
    mcolor({ 1, 1, 1, 0.06 })
    mrect("line", x, y, w, h, 10)
  end

  local function buttonRect(r, c)
    local gap = 3
    local bw = 62
    local bh = 12
    local startX = 17
    local startY = 68
    local row = GRID[r]
    if #row == 1 then
      return 17, startY + (r - 1) * (bh + gap), 206, bh
    end
    return startX + (c - 1) * (bw + gap), startY + (r - 1) * (bh + gap), bw, bh
  end

  local function drawKeyButton(r, c, label, selected)
    local x, y, w, h = buttonRect(r, c)
    drawPanel(x, y, w, h, selected and MODERN.raised or MODERN.surface)
    if selected then
      mcolor(MODERN.accent)
      mrect("fill", x, y, 4, h, 10)
      mcolor({ 1, 1, 1, 0.08 })
      mrect("fill", x + 4, y, w - 4, h, 10)
    end
    local color = MODERN.text
    if label == "CANCEL" then color = MODERN.accent end
    if label == "OK" then color = MODERN.ok end
    mtext(label, x, y + 1, 10, color, "center", w)
  end

  function UI.draw()
    if not UI.open then return end
    local lg = love and love.graphics
    if not lg then return end

    mcolor(MODERN.bg)
    mrect("fill", 0, 0, 240, 160, 0)

    -- Header
    drawPanel(8, 6, 224, 18, MODERN.header)
    mtext("SUMMON", 16, 9, 12, MODERN.headerText)
    mtext("MODERN UI - FIRE RED", 98, 10, 8, MODERN.secondary)

    -- Selection / details panel
    drawPanel(8, 28, 224, 32, MODERN.surface)
    local number = selectedNumber()
    local row = selectedSpecies()
    local display = number and string.format("No.%03d", number) or "No.---"
    mtext(display, 18, 37, 16, MODERN.accent)
    if row then
      mtext(tostring(row.name), 92, 36, 14, MODERN.text)
      mtext(string.format("Lv.%d", summonLevel(runtimeSession()) or 0), 180, 38, 11, MODERN.ok)
      mtext("National Dex", 92, 49, 8, MODERN.muted)
    else
      mtext("ENTER A NATIONAL DEX NUMBER", 92, 38, 10, MODERN.text)
      mtext(string.format("Valid range: 1-%d", UI.maxDex or 386), 92, 50, 8, MODERN.muted)
    end

    -- Keypad panel
    drawPanel(8, 64, 224, 80, MODERN.surface)
    for r, gridRow in ipairs(GRID) do
      for c, label in ipairs(gridRow) do
        drawKeyButton(r, c, label, r == UI.row and c == UI.col)
      end
    end

    -- Footer / help
    if UI.message ~= "" then
      mtext(UI.message, 12, 147, 9, MODERN.accent, "center", 216)
    else
      mtext("A SELECT   B BACK   START OK   SELECT CLEAR", 10, 147, 8, MODERN.muted, "center", 220)
    end
  end

  -- High-resolution Modern UI presenter. The native 240x160 layer remains
  -- underneath only to own input/state. This overlay is painted in window
  -- space after the game canvas, so text is never upscaled from GBA resolution.
  local function modernLayout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth)
      or (love.graphics.getWidth and love.graphics.getWidth()) or 720
    local h = tonumber(viewport and viewport.gameHeight)
      or (love.graphics.getHeight and love.graphics.getHeight()) or 480
    local s = math.max(0.64, math.min(w / 720, h / 480))
    local pad = math.max(10, 14 * s)
    local gap = math.max(7, 10 * s)
    local headerH = math.max(44, 52 * s)
    local footerH = math.max(28, 32 * s)
    return {
      x=x, y=y, w=w, h=h, s=s, pad=pad, gap=gap,
      headerH=headerH, footerH=footerH,
      contentY=y+headerH,
      contentH=h-headerH-footerH,
      title=math.max(21,25*s), body=math.max(16,18*s),
      small=math.max(13,15*s), tiny=math.max(12,13*s),
    }
  end

  local function modernBackdrop(L)
    love.graphics.setScissor(L.x, L.y, L.w, L.h)
    mcolor(MODERN.bg)
    love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    mcolor(MODERN.header)
    love.graphics.rectangle("fill", L.x, L.y, L.w, L.headerH)
    mcolor(MODERN.accent)
    love.graphics.rectangle("fill", L.x, L.y, L.w, math.max(3, 4 * L.s))
    mcolor(MODERN.secondary)
    love.graphics.rectangle("fill", L.x, L.contentY - math.max(2, 3 * L.s), L.w, math.max(2, 3 * L.s))
    mtext("SUMMON", L.x + L.pad, L.y + math.max(8, L.pad * 0.58), L.title, MODERN.headerText)
    mtext("FIRE RED  /  NATIONAL DEX", L.x + L.w * 0.48,
      L.y + math.max(11, L.pad * 0.78), L.small, MODERN.secondary,
      "right", L.w * 0.52 - L.pad)
  end

  local function modernPanel(x, y, w, h, selected)
    mcolor(selected and MODERN.raised or MODERN.surface)
    mrect("fill", x, y, w, h, math.min(10, h * 0.16))
    mcolor(selected and MODERN.accent or MODERN.divider)
    love.graphics.setLineWidth(math.max(1, 1.2))
    mrect("line", x, y, w, h, math.min(10, h * 0.16))
  end

  local function modernSelection(x, y, w, h)
    mcolor(MODERN.selected)
    mrect("fill", x, y, w, h, math.min(9, h * 0.22))
    mcolor(MODERN.accent)
    love.graphics.rectangle("fill", x, y, math.max(4, w * 0.012), h)
  end

  local function modernFooter(L, msg, warning)
    local y = L.y + L.h - L.footerH
    mcolor(MODERN.footer)
    love.graphics.rectangle("fill", L.x, y, L.w, L.footerH)
    mcolor(MODERN.secondary)
    love.graphics.rectangle("fill", L.x, y, L.w, math.max(2, 3 * L.s))
    mtext(msg or "", L.x + L.pad, y + math.max(6, L.footerH * 0.28),
      L.tiny, warning and MODERN.secondary or MODERN.footerText,
      "center", L.w - L.pad * 2)
  end

  local function drawModernInfo(L, x, y, w, h)
    modernPanel(x, y, w, h, false)
    local number = selectedNumber()
    local row = selectedSpecies()
    local display = number and string.format("No.%03d", number) or "No.---"

    mtext("NATIONAL DEX", x + L.pad, y + L.pad, L.tiny, MODERN.muted)
    mtext(display, x + L.pad, y + L.pad + L.tiny * 1.45,
      math.max(30, 38 * L.s), MODERN.header)

    local splitY = y + h * 0.49
    mcolor(MODERN.divider)
    love.graphics.rectangle("fill", x + L.pad, splitY, w - L.pad * 2, math.max(1, 2 * L.s))

    if row then
      mtext(tostring(row.name), x + L.pad, splitY + L.gap,
        math.max(20, 24 * L.s), MODERN.text, "left", w - L.pad * 2)
      mtext("Wild encounter level", x + L.pad, splitY + L.gap + L.body * 1.75,
        L.tiny, MODERN.muted)
      local lv = summonLevel(runtimeSession()) or 0
      local pillW, pillH = math.max(86, 100 * L.s), math.max(28, 32 * L.s)
      local px = x + L.pad
      local py = splitY + L.gap + L.body * 3.0
      mcolor(MODERN.ok)
      mrect("fill", px, py, pillW, pillH, pillH / 2)
      mtext("Lv. " .. tostring(lv), px, py + math.max(4, pillH * 0.19),
        L.small, MODERN.headerText, "center", pillW)
    else
      mtext("Enter a National Dex number", x + L.pad, splitY + L.gap,
        L.body, MODERN.text, "left", w - L.pad * 2)
      mtext("Valid range: 1-" .. tostring(UI.maxDex or 386),
        x + L.pad, splitY + L.gap + L.body * 1.8,
        L.small, MODERN.muted, "left", w - L.pad * 2)
    end
  end

  local function drawModernKeypad(L, x, y, w, h)
    modernPanel(x, y, w, h, false)
    local innerX, innerY = x + L.gap, y + L.gap
    local innerW, innerH = w - L.gap * 2, h - L.gap * 2
    local rows = #GRID
    local rowGap = L.gap * 0.65
    local rowH = (innerH - rowGap * (rows - 1)) / rows

    for r, gridRow in ipairs(GRID) do
      local cols = #gridRow
      local colGap = L.gap * 0.65
      local cellW = (innerW - colGap * (cols - 1)) / cols
      for c, label in ipairs(gridRow) do
        local bx = innerX + (c - 1) * (cellW + colGap)
        local by = innerY + (r - 1) * (rowH + rowGap)
        local selected = r == UI.row and c == UI.col
        modernPanel(bx, by, cellW, rowH, selected)
        if selected then modernSelection(bx + 1, by + 1, cellW - 2, rowH - 2) end
        local fg = MODERN.text
        if label == "OK" then fg = MODERN.ok end
        if label == "CANCEL" then fg = MODERN.accent end
        mtext(label, bx, by + math.max(5, rowH * 0.23),
          L.body, fg, "center", cellW)
      end
    end
  end

  local function drawModernOverlay(game, viewport)
    if not UI.open or not (love and love.graphics and viewport) then return end
    local top = Stack.top and Stack.top() or nil
    if not (top and top.id == SCREEN_ID) then return end

    local L = modernLayout(viewport)
    love.graphics.push("all")
    local ok, err = pcall(function()
      if love.graphics.origin then love.graphics.origin() end
      modernBackdrop(L)

      local x = L.x + L.pad
      local y = L.contentY + L.pad
      local h = L.contentH - L.pad * 2
      local infoW = math.max(210 * L.s, L.w * 0.34)
      local keypadX = x + infoW + L.gap
      local keypadW = L.x + L.w - L.pad - keypadX

      drawModernInfo(L, x, y, infoW, h)
      drawModernKeypad(L, keypadX, y, keypadW, h)

      if UI.message ~= "" then
        modernFooter(L, UI.message, true)
      else
        modernFooter(L, "A SELECT   B BACK   START OK   SELECT CLEAR")
      end
    end)
    love.graphics.setScissor()
    love.graphics.pop()
    if not ok and mod.log and mod.log.warn then
      mod.log:warn("%s modern presenter failed: %s", MOD_ID, tostring(err))
    end
  end

  -- Raw keyboard entry for 0-9 / numpad, DEL, Enter and Escape. Other keys
  -- continue down the normal FireRed input chain so D-pad/A/B still work.
  mod.hooks:wrap("input.key", function(nextFn, game, ev)
    if UI.open and ev and ev.phase == "pressed" then
      local key = tostring(ev.key or "")
      local digit = key:match("^([0-9])$") or key:match("^kp([0-9])$")
      if digit then appendDigit(digit); return end
      if key == "backspace" or key == "delete" then deleteDigit(); return end
      if key == "return" or key == "kpenter" then submit(); return end
      if key == "escape" then closeScreen(); return end
    end
    return nextFn(game, ev)
  end, HOOK_PRIORITY)

  -- Paint the custom SUMMON screen in window space after the native GBA frame.
  -- This is the same presentation path used by Gen3 Modern UI and avoids
  -- rasterizing modern fonts into the 240x160 canvas.
  mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
    local result = nextFn(game, viewport)
    drawModernOverlay(game, viewport)
    return result
  end, HOOK_PRIORITY)

  mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
    local out = nextFn(game, items)
    if type(out) ~= "table" then out = items end
    if hasSummonRow(out) then return out end

    return mod.ui.insertBefore(out, "SAVE", {
      id = "pokemonmod_gen3_summon",
      label = "SUMMON",
      desc = { "Choose a wild", "POKéMON" },
      pokemonmodGen3Summon = true,
      onSelect = function(liveGame)
        UI.show(liveGame or game)
      end,
    })
  end, HOOK_PRIORITY)

  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.fireRedOnly = true
  mod.exports.buildDexIndex = buildDexIndex
  mod.exports.summonLevel = function(session) return summonLevel(session or runtimeSession()) end
  mod.exports.open = function(game) return UI.show(game) end
  mod.exports.isOpen = function() return UI.open end

  if mod.log and mod.log.info then
    mod.log:info("Summon - Gen 3 v%s loaded (FireRed only)", VERSION)
  end
end
