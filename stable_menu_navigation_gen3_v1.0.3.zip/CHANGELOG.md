# Changelog

## 1.0.3
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Replaced the FireRed-only runtime export with FRLG `game` and `supportedGames` metadata.
- Updated the shared-owner fast path so it also reports FireRed + LeafGreen compatibility.
- Kept the Game3 Bag/Help real-time repeat logic unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.2

- FireRed-only Gen 3 port.
- Reimplemented stable held navigation against the native FireRed Bag and Help systems.
- Bag cadence preserved at 40-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Help cadence preserved at 20-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Edge presses remain immediate.
- Other FireRed menus remain edge-only and are not modified.
- Added generation-specific duplicate-patch guard.
- Added unique Gen 3 mod ID and FireRed-only manifest target.
- Does not patch the shared legacy `MenuRepeat` helper.
