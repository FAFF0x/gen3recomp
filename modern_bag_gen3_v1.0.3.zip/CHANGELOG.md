# Changelog

## 1.0.3

- Replaced the generic TM/HM Bag presentation with a dedicated full-area two-pane catalogue.
- Added a six-row move list on the left and an always-visible technical move card on the right.
- Move rows now show machine number, move name, type, class and power without opening another screen.
- The detail card now keeps type, class, Power, Accuracy, PP and the wrapped move effect visible at all times.
- Completely redesigned the START filter panel into a navigation column plus contextual visual selector.
- TYPE displays all available type chips at once; CLASS and SORT display their full option sets simultaneously.
- Left/Right now changes TYPE, CLASS and SORT directly; Up/Down changes filter section.
- NAME search remains A-to-edit and combines with all other filters.
- Redesigned Y/I Move Information as a spacious two-column technical sheet.
- Added responsive scaling, clipping and ellipsis handling to prevent labels from leaving their cards.
- Dedicated TM/HM overlays now render only when the Game3 Bag layer is topmost, preventing overlap with Party/Naming submenus.

## 1.0.2

- Rebuilt the FireRed TM/HM view around move data instead of generic item data.
- TM/HM rows now show machine number plus move name (for example `TM24 THUNDERBOLT`).
- The side detail panel now exposes type, class, power, accuracy, PP and a compact move effect.
- START now opens the dedicated NAME / TYPE / CLASS / SORT panel, matching the Gen2 feature set.
- NAME search now filters by the move name and combines with TYPE and CLASS filters.
- Added raw Keyboard `I` / Controller `Y` move-information shortcuts through the supported input hooks.
- Added a dedicated Move Information overlay with machine number, move name, type, class, power, accuracy, PP and move effect.
- Added a dedicated high-resolution filter overlay and widened the native fallback panel so long labels stay inside their boxes.
- Added numeric FireRed move-type decoding for correct type labels and Gen3 physical/special classification.

## 1.0.1

- Ported Modern Bag from Gen2 to native FireRed/Game3.
- Added FireRed-only manifest target and unique `pokemonmod_gen3_modern_bag` identity.
- Replaced the Gen2 PackMenu renderer patch with a Game3 `BagMenu` logical-view adapter.
- Added eight FireRed-aware logical categories: Favorites, Medicine, Balls, TM/HM, Berries, Battle, Key Items and Other.
- Preserved native FireRed USE/GIVE/TOSS/REGISTER/TM teach behavior by leaving items in their real Game3 pockets.
- Added persistent favorites and pins.
- Added Game3 naming-screen search.
- Added TM/HM filters for kind, type and damage class plus number/name/power sorting and move details.
- Expanded Game3 pocket/stack capacity while retaining native Bag mutation functions.
- Added automatic compatibility with `gen3_modern_ui` through the live BagMenu model.
- Added equivalent-mod deferral and runtime patch sentinels to prevent double installation.
