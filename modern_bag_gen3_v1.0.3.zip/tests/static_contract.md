# Static contract — Modern Bag Gen3 v1.0.3

- Manifest id: `pokemonmod_gen3_modern_bag`.
- Manifest target: `games: ["firered"]` only.
- No Game2/Gen2 runtime requires.
- Uses `src.core.game3.bag`, `src.ui.game3.bag_menu`, Game3 TM/berry pockets and Game3 naming.
- Logical categories do not relocate physical inventory slots.
- Native Game3 Bag owns USE/GIVE/TOSS/REGISTER/teach actions.
- TM/HM browsing uses a dedicated two-pane catalogue: six-row machine list + persistent move detail card.
- TM/HM rows expose machine number, move name, type/class and power at a glance.
- Persistent detail exposes type, class, power, accuracy, PP and wrapped move effect.
- START opens the redesigned NAME / TYPE / CLASS / SORT filter centre.
- TYPE / CLASS / SORT change directly with Left/Right; all choices remain visible in the panel.
- NAME search matches the move name and combines with TYPE and CLASS.
- Keyboard `I` and controller `Y` open a dedicated expanded Move Information overlay.
- All high-resolution TM/HM panels are responsive and clip/ellipsize/wrap text within their regions.
- The dedicated TM/HM renderer runs only while the Game3 `bag` layer is topmost, so Party/Naming submenus are never covered.
- Equivalent IDs are detected before patch install.
- `BagMenu` uses a module sentinel to prevent double wrapping.
