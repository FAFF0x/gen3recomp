-- Modern Bag - Gen 3 / FireRed (Pokemon MOD)
-- Port of modern_bag_gen2_v1.0.0 to the native Game3 inventory model.
--
-- FireRed physically stores items in ITEMS / KEY_ITEMS / POKE_BALLS plus the
-- TM CASE and BERRY POUCH.  This mod never moves an item between those real
-- pockets.  It only exposes eight logical views over the same live Bag data,
-- so native use/give/toss/register/teach behavior remains authoritative.

local MOD_ID = "pokemonmod_gen3_modern_bag"
local MOD_VERSION = "1.0.3"
local EQUIVALENT_IDS = { "modern_bag_gen3", "modern_bag" }

local PATCH_KEY = "__pokemonmodModernBagGen3DispatchV1"
local CAPACITY_KEY = "__pokemonmodModernBagGen3CapacityV1"
local UNLIMITED_QTY = 999999

local CATEGORIES = {
  { id = "favorites", key = "FAV", label = "FAVORITES" },
  { id = "medicine",  key = "MEDICINE", label = "MEDICINE", actionPocket = "ITEMS" },
  { id = "balls",     key = "POKE_BALLS", label = "BALLS", actionPocket = "POKE_BALLS" },
  { id = "machines",  key = "TM_CASE", label = "TM / HM", actionPocket = "TM_CASE" },
  { id = "berries",   key = "BERRY_POUCH", label = "BERRIES", actionPocket = "BERRY_POUCH" },
  { id = "battle",    key = "BATTLE", label = "BATTLE", actionPocket = "ITEMS" },
  { id = "key",       key = "KEY_ITEMS", label = "KEY ITEMS", actionPocket = "KEY_ITEMS" },
  { id = "other",     key = "OTHER", label = "OTHER", actionPocket = "ITEMS" },
}

local KEY_TO_CATEGORY, ID_TO_INDEX = {}, {}
for i, c in ipairs(CATEGORIES) do
  KEY_TO_CATEGORY[c.key] = c
  ID_TO_INDEX[c.id] = i
end

local PHYSICAL_TYPES = {
  NORMAL=true, FIGHTING=true, FLYING=true, POISON=true, GROUND=true,
  ROCK=true, BUG=true, GHOST=true, STEEL=true,
}

local MOVE_TYPE_NAMES = {
  [0]="NORMAL", [1]="FIGHTING", [2]="FLYING", [3]="POISON",
  [4]="GROUND", [5]="ROCK", [6]="BUG", [7]="GHOST", [8]="STEEL",
  [9]="MYSTERY", [10]="FIRE", [11]="WATER", [12]="GRASS",
  [13]="ELECTRIC", [14]="PSYCHIC", [15]="ICE", [16]="DRAGON", [17]="DARK",
}

local SORT_MODES = { "NUMBER", "NAME", "POWER HIGH", "POWER LOW" }
local CLASS_MODES = { "ANY", "PHYSICAL", "SPECIAL", "STATUS" }
local TYPE_FILTER_MODES = {
  "ANY","NORMAL","FIGHTING","FLYING","POISON","GROUND","ROCK","BUG","GHOST","STEEL",
  "FIRE","WATER","GRASS","ELECTRIC","PSYCHIC","ICE","DRAGON","DARK",
}
local KIND_MODES = { "ALL", "TM", "HM" }

local function optionValue(mod, key, default)
  if mod and mod.options and type(mod.options.get) == "function" then
    local ok, v = pcall(mod.options.get, mod.options, key)
    if ok and v ~= nil then return v end
  end
  return default
end

local function canon(ItemsData, id)
  local n = ItemsData.toNumericId and ItemsData.toNumericId(id) or tonumber(id)
  return tostring(n or id or "")
end

local function upper(s) return tostring(s or ""):upper() end
local function moveTypeLabel(raw)
  local n = tonumber(raw)
  if n ~= nil and MOVE_TYPE_NAMES[n] then return MOVE_TYPE_NAMES[n] end
  return upper(raw or "NORMAL")
end
local function norm(s)
  s = upper(s):gsub("É", "E")
  return s:gsub("[^A-Z0-9]", "")
end

local function cleanSavedArray(value)
  local out, seen = {}, {}
  if type(value) ~= "table" then return out end
  for _, v in ipairs(value) do
    local k = tostring(v or "")
    if k ~= "" and not seen[k] then seen[k] = true; out[#out+1] = k end
  end
  return out
end

local function indexArray(t)
  local out = {}
  for i, v in ipairs(t or {}) do out[tostring(v)] = i end
  return out
end

local function loadPrefs(mod)
  local fav = cleanSavedArray(mod.save:get("favorite_items", {}))
  local pin = cleanSavedArray(mod.save:get("pinned_items", {}))
  local sort = upper(mod.save:get("machine_sort", "NUMBER"))
  local valid = false
  for _, v in ipairs(SORT_MODES) do if sort == v then valid = true break end end
  if not valid then sort = "NUMBER" end
  return {
    favoriteOrder = fav, favoriteSet = indexArray(fav),
    pinnedOrder = pin, pinnedSet = indexArray(pin),
    machineSort = sort,
  }
end

local function savePrefs(mod, st)
  mod.save:set("favorite_items", cleanSavedArray(st.favoriteOrder))
  mod.save:set("pinned_items", cleanSavedArray(st.pinnedOrder))
  mod.save:set("machine_sort", st.machineSort or "NUMBER")
end

local function toggleOrdered(list, key)
  for i, v in ipairs(list) do
    if v == key then table.remove(list, i); return false end
  end
  list[#list+1] = key
  return true
end

local function rebuildPrefIndexes(st)
  st.favoriteOrder = cleanSavedArray(st.favoriteOrder)
  st.pinnedOrder = cleanSavedArray(st.pinnedOrder)
  st.favoriteSet = indexArray(st.favoriteOrder)
  st.pinnedSet = indexArray(st.pinnedOrder)
end

local function cycle(values, current)
  for i, v in ipairs(values) do
    if v == current then return values[(i % #values) + 1] end
  end
  return values[1]
end

local function cycleDir(values, current, delta)
  if type(values) ~= "table" or #values < 1 then return current end
  local idx = 1
  for i, v in ipairs(values) do
    if v == current then idx = i break end
  end
  idx = ((idx - 1 + (tonumber(delta) or 1)) % #values) + 1
  return values[idx]
end

local function moveClass(move)
  move = move or {}
  local power = math.floor(tonumber(move.power) or 0)
  if power <= 0 then return "STATUS" end
  return PHYSICAL_TYPES[moveTypeLabel(move.type)] and "PHYSICAL" or "SPECIAL"
end

local function machineInfo(Pokemon, ItemsData, SummaryData, id)
  if not (ItemsData.isTm and ItemsData.isTm(id)) then return nil end
  local moveId = Pokemon.moveFromTmItem(id)
  if not moveId then return nil end
  local move = Pokemon.battleMove(moveId) or {}
  local hm = ItemsData.isHm and ItemsData.isHm(id) or false
  local number = ItemsData.tmNumber and ItemsData.tmNumber(id) or nil
  if not number then
    local num = ItemsData.toNumericId(id) or tonumber(id)
    if num then number = hm and (num - (ItemsData.FIRST_HM or 339) + 1)
      or (num - (ItemsData.FIRST_TM or 289) + 1) end
  end
  number = tonumber(number) or 999
  local code = (hm and "HM" or "TM") .. string.format("%02d", number)
  local name = Pokemon.moveName(moveId) or "MOVE"
  local acc = tonumber(move.accuracy)
  if acc and acc <= 0 then acc = nil end
  local desc = SummaryData and SummaryData.moveDescription
    and SummaryData.moveDescription(moveId, name) or nil
  return {
    id=id, moveId=moveId, code=code, kind=hm and "HM" or "TM", number=number,
    name=name, nameKey=norm(name), type=moveTypeLabel(move.type),
    class=moveClass(move), power=math.floor(tonumber(move.power) or 0),
    accuracy=acc, pp=math.floor(tonumber(move.pp) or 0),
    effect=desc or "", effectId=move.effect,
    effectChance=math.floor(tonumber(move.secondaryEffectChance or move.effectChance) or 0),
    description=desc or "",
  }
end

local function install(mod)
  local deferredTo
  if type(mod.find) == "function" then
    for _, id in ipairs(EQUIVALENT_IDS) do
      local ok, h = pcall(mod.find, id)
      if ok and type(h) == "table" then deferredTo = id; break end
    end
  end

  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  mod.exports.modId = MOD_ID
  mod.exports.version = MOD_VERSION
  if deferredTo then
    if mod.log then mod.log:warn("Modern Bag Gen3 deferred to active equivalent: " .. deferredTo) end
    return
  end

  local ItemsData = require("src.core.game3.items_data")
  local Items = require("src.core.game3.items")
  local Bag = require("src.core.game3.bag")
  local BagMenu = require("src.ui.game3.bag_menu")
  local Pokemon = require("src.core.game3.pokemon")
  local SummaryData = require("src.core.game3.summary_data")
  local BattleItems = require("src.core.game3.battle.items")
  local Stack = require("src.ui.game3.stack")
  local BagChrome = require("src.ui.game3.bag_chrome")

  if mod.options and type(mod.options.define) == "function" then
    mod.options:define({
      {
        key="opening_pocket", type="choice", label="Opening Pocket", default="medicine",
        choices={
          {"Favorites","favorites"},{"Medicine","medicine"},{"Balls","balls"},
          {"TM / HM","machines"},{"Berries","berries"},{"Battle","battle"},
          {"Key Items","key"},{"Other","other"},{"Last Used","last"},
        },
      },
      {
        key="hold_scroll_speed", type="choice", label="Hold Scroll Speed", default="fast",
        choices={{"Off","off"},{"Normal","normal"},{"Fast","fast"},{"Very Fast","very_fast"}},
      },
    })
  end

  -- One technical mutex on the live Game3 BagMenu prevents two equivalent
  -- implementations from both replacing the same singleton methods.
  local existing = rawget(BagMenu, PATCH_KEY)
  if existing and existing.owner ~= MOD_ID then
    mod.exports.active = false
    mod.exports.deferredTo = existing.owner or "equivalent_modern_bag"
    if mod.log then mod.log:warn("Modern Bag Gen3 runtime patch already owned by " .. tostring(mod.exports.deferredTo)) end
    return
  end
  if existing and existing.owner == MOD_ID then return end

  local nativeOrder = {}
  for i, p in ipairs(ItemsData.BAG_POCKET_ORDER or {}) do nativeOrder[i] = p end
  local physicalOrder = {}
  for i, p in ipairs(ItemsData.POCKET_ORDER or {"ITEMS","KEY_ITEMS","POKE_BALLS","TM_CASE","BERRY_POUCH"}) do physicalOrder[i] = p end
  local logicalOrder = {}
  for i, c in ipairs(CATEGORIES) do logicalOrder[i] = c.key end

  local nativeLabels = {}
  for _, c in ipairs(CATEGORIES) do nativeLabels[c.key] = ItemsData.POCKET_LABEL[c.key] end
  local function setOrder(src)
    local t = ItemsData.BAG_POCKET_ORDER
    for i=#t,1,-1 do t[i] = nil end
    for i,v in ipairs(src) do t[i] = v end
  end
  local function activateOrder()
    setOrder(logicalOrder)
    for _, c in ipairs(CATEGORIES) do ItemsData.POCKET_LABEL[c.key] = c.label end
  end
  local function restoreOrder()
    setOrder(nativeOrder)
    for _, c in ipairs(CATEGORIES) do ItemsData.POCKET_LABEL[c.key] = nativeLabels[c.key] end
  end

  -- Preserve the Gen2 mod's expanded-capacity behavior on Game3 without
  -- replacing Bag.add/remove.  The native functions still own all mutations.
  if not rawget(Bag, CAPACITY_KEY) then
    rawset(Bag, CAPACITY_KEY, { owner=MOD_ID, oldMax=Items.GAME3_MAX_QTY })
    for k in pairs(ItemsData.CAPACITY or {}) do ItemsData.CAPACITY[k] = UNLIMITED_QTY end
    Items.GAME3_MAX_QTY = UNLIMITED_QTY
  end

  local state = {
    active=false, mod=mod,
    prefs=loadPrefs(mod),
    query="",
    filters={ kind="ALL", type="ANY", class="ANY" },
    custom=nil,
    repeatKey=nil, repeatFrames=0,
  }

  local function categoryAt(idx)
    return CATEGORIES[tonumber(idx) or 1] or CATEGORIES[1]
  end

  local baseDisplayName = ItemsData.displayName
  local baseDescription = ItemsData.description

  local function isMachineView()
    return state.active and not BagMenu._battle
      and categoryAt(BagMenu.pocketIdx).id == "machines"
  end

  local function machineListLabel(mi)
    if not mi then return nil end
    return mi.code .. "  " .. mi.name
  end

  local function machineCompactDescription(mi)
    if not mi then return "" end
    local pow = mi.power > 0 and tostring(mi.power) or "--"
    local acc = mi.accuracy and (tostring(mi.accuracy) .. "%") or "--"
    local effect = tostring(mi.effect or "")
    if #effect > 150 then effect = effect:sub(1, 147) .. "..." end
    return string.format("%s  /  %s\nPOWER %s   ACC %s   PP %d\n%s",
      mi.type, mi.class, pow, acc, mi.pp, effect)
  end

  ItemsData.displayName = function(id)
    if isMachineView() and ItemsData.isTm and ItemsData.isTm(id) then
      local mi = machineInfo(Pokemon, ItemsData, SummaryData, id)
      if mi then return machineListLabel(mi) end
    end
    if baseDisplayName then return baseDisplayName(id) end
    return tostring(id or "ITEM")
  end

  ItemsData.description = function(id)
    if isMachineView() and ItemsData.isTm and ItemsData.isTm(id) then
      local mi = machineInfo(Pokemon, ItemsData, SummaryData, id)
      if mi then return machineCompactDescription(mi) end
    end
    if baseDescription then return baseDescription(id) end
    return ""
  end

  local function categoryForRow(row)
    local id = row and row.id
    if id == nil then return "other" end
    local pocket = ItemsData.pocketOf(id)
    if pocket == "POKE_BALLS" then return "balls" end
    if pocket == "TM_CASE" then return "machines" end
    if pocket == "BERRY_POUCH" then return "berries" end
    if pocket == "KEY_ITEMS" then
      local n = ItemsData.toNumericId(id) or tonumber(id)
      if n == ItemsData.ITEM_TM_CASE or n == ItemsData.ITEM_BERRY_POUCH then return "hidden" end
      return "key"
    end
    local use = ItemsData.fieldUseKind and ItemsData.fieldUseKind(id) or nil
    if use == "heal" or use == "status" or use == "revive" or use == "pp"
        or use == "level" or use == "vitamin" then return "medicine" end
    local battle = false
    if BattleItems and BattleItems.isBattleUsable then
      local ok, v = pcall(BattleItems.isBattleUsable, id)
      battle = ok and v == true
    end
    if battle then return "battle" end
    return "other"
  end

  local function physicalRows()
    local out, source = {}, 0
    for _, pocket in ipairs(physicalOrder) do
      for _, row in ipairs(Bag.listPocket(BagMenu._bag, pocket) or {}) do
        source = source + 1
        row._modernSource = source
        out[#out+1] = row
      end
    end
    return out
  end

  local function rowHaystack(row, mi)
    return norm((row.name or ItemsData.displayName(row.id) or "") .. " " .. tostring(row.id)
      .. " " .. (mi and (mi.code .. " " .. mi.name .. " " .. mi.type .. " " .. mi.class) or ""))
  end

  local function machinePass(mi)
    local f = state.filters
    if not mi then return false end
    if f.kind ~= "ALL" and mi.kind ~= f.kind then return false end
    if f.type ~= "ANY" and mi.type ~= f.type then return false end
    if f.class ~= "ANY" and mi.class ~= f.class then return false end
    return true
  end

  local function machineLess(a, b)
    local ma, mb = a._modernMachine, b._modernMachine
    local sort = state.prefs.machineSort
    if sort == "NAME" then
      if ma.nameKey ~= mb.nameKey then return ma.nameKey < mb.nameKey end
    elseif sort == "POWER HIGH" then
      if ma.power ~= mb.power then return ma.power > mb.power end
    elseif sort == "POWER LOW" then
      if ma.power ~= mb.power then return ma.power < mb.power end
    else
      local ka = (ma.kind == "HM" and 0 or 1) * 1000 + ma.number
      local kb = (mb.kind == "HM" and 0 or 1) * 1000 + mb.number
      if ka ~= kb then return ka < kb end
    end
    return ma.nameKey < mb.nameKey
  end

  local function logicalRows(key)
    if not state.active or BagMenu._battle then return nil end
    local cat = KEY_TO_CATEGORY[key] or categoryAt(BagMenu.pocketIdx)
    local wanted = norm(state.query)
    local out = {}
    for _, row in ipairs(physicalRows()) do
      local k = canon(ItemsData, row.id)
      local actual = categoryForRow(row)
      local favorite = state.prefs.favoriteSet[k] ~= nil
      local include = cat.id == "favorites" and favorite or actual == cat.id
      if include then
        local mi = actual == "machines" and machineInfo(Pokemon, ItemsData, SummaryData, row.id) or nil
        local searchMatch
        if wanted == "" then
          searchMatch = true
        elseif cat.id == "machines" then
          searchMatch = mi and mi.nameKey:find(wanted, 1, true) ~= nil
        else
          searchMatch = rowHaystack(row, mi):find(wanted, 1, true) ~= nil
        end
        if (cat.id ~= "machines" or machinePass(mi)) and searchMatch then
          if mi then
            row.name = machineListLabel(mi)
            row.description = machineCompactDescription(mi)
          end
          row._modernKey = k
          row._modernFavorite = favorite
          row._modernPinned = state.prefs.pinnedSet[k] ~= nil
          row._modernPinRank = state.prefs.pinnedSet[k]
          row._modernFavRank = state.prefs.favoriteSet[k]
          row._modernMachine = mi
          out[#out+1] = row
        end
      end
    end
    table.sort(out, function(a,b)
      if a._modernPinned ~= b._modernPinned then return a._modernPinned end
      if a._modernPinned and a._modernPinRank ~= b._modernPinRank then return a._modernPinRank < b._modernPinRank end
      if cat.id == "favorites" and a._modernFavRank ~= b._modernFavRank then return a._modernFavRank < b._modernFavRank end
      if cat.id == "machines" and a._modernMachine and b._modernMachine then return machineLess(a,b) end
      return (a._modernSource or 0) < (b._modernSource or 0)
    end)
    return out
  end

  local function selectedRow()
    local rows = logicalRows(categoryAt(BagMenu.pocketIdx).key) or {}
    return rows[BagMenu.cursor]
  end

  local function refreshCursor(preserveId)
    local rows = logicalRows(categoryAt(BagMenu.pocketIdx).key) or {}
    local idx
    if preserveId ~= nil then
      local wanted = canon(ItemsData, preserveId)
      for i,r in ipairs(rows) do if canon(ItemsData, r.id) == wanted then idx=i break end end
    end
    BagMenu.cursor = idx or math.max(1, math.min(BagMenu.cursor or 1, #rows + 1))
    local maxScroll = math.max(0, (#rows + 1) - 6)
    BagMenu.scroll = math.max(0, math.min(BagMenu.scroll or 0, maxScroll))
    if BagMenu.cursor <= BagMenu.scroll then BagMenu.scroll = BagMenu.cursor - 1 end
    if BagMenu.cursor > BagMenu.scroll + 6 then BagMenu.scroll = BagMenu.cursor - 6 end
  end

  local function rememberPocket()
    local c = categoryAt(BagMenu.pocketIdx)
    if c then mod.save:set("last_pocket", c.id) end
  end

  local function openingIndex()
    local wanted = tostring(optionValue(mod, "opening_pocket", "medicine") or "medicine")
    if wanted == "last" then wanted = tostring(mod.save:get("last_pocket", "medicine") or "medicine") end
    return ID_TO_INDEX[wanted] or ID_TO_INDEX.medicine
  end

  local function semanticPocket()
    local c = categoryAt(BagMenu.pocketIdx)
    if BagMenu.mode == "list" or state.custom then return c.key end
    if c.id == "favorites" then
      local row = selectedRow()
      return row and ItemsData.pocketOf(row.id) or "ITEMS"
    end
    return c.actionPocket or c.key
  end

  local base = {
    show=BagMenu.show, close=BagMenu.close, currentPocket=BagMenu.currentPocket,
    list=BagMenu.list, handleInput=BagMenu.handleInput, draw=BagMenu.draw,
  }
  local dispatch = { owner=MOD_ID, base=base, state=state }
  rawset(BagMenu, PATCH_KEY, dispatch)

  BagMenu.currentPocket = function()
    if state.active and not BagMenu._battle then return semanticPocket() end
    return base.currentPocket()
  end

  BagMenu.list = function(pocket)
    if state.active and not BagMenu._battle then
      local key = pocket or categoryAt(BagMenu.pocketIdx).key
      local rows = logicalRows(key)
      if rows then return rows end
    end
    return base.list(pocket)
  end

  BagMenu.show = function(sessionBag, opts)
    opts = opts or {}
    local battle = opts.battle == true
    if battle then
      if state.active then state.active=false; restoreOrder() end
      return base.show(sessionBag, opts)
    end
    state.active = true
    state.custom = nil
    state.query = ""
    activateOrder()
    local copy = {}
    for k,v in pairs(opts) do copy[k]=v end
    copy.pocket = nil
    copy.pocketIdx = openingIndex()
    local result = base.show(sessionBag, copy)
    BagMenu.pocketIdx = copy.pocketIdx
    refreshCursor()
    return result
  end

  BagMenu.close = function(...)
    if state.active then
      rememberPocket()
      state.active=false
      state.custom=nil
      restoreOrder()
    end
    return base.close(...)
  end

  local function persistPrefs()
    rebuildPrefIndexes(state.prefs)
    savePrefs(mod, state.prefs)
  end

  local function itemTools()
    local row = selectedRow()
    if not row then return end
    local k = canon(ItemsData, row.id)
    local acts = {}
    acts[#acts+1] = state.prefs.favoriteSet[k] and "REMOVE FAVORITE" or "ADD FAVORITE"
    acts[#acts+1] = state.prefs.pinnedSet[k] and "UNPIN ITEM" or "PIN ITEM"
    local info = row.info or ItemsData.info(row.id)
    local pocket = ItemsData.pocketOf(row.id)
    if pocket == "KEY_ITEMS" and info and (tonumber(info.registrability) or 0) > 0 then
      acts[#acts+1] = (BagMenu._session and BagMenu._session.registeredItem == row.id) and "UNREGISTER" or "REGISTER"
    end
    if ItemsData.isTm(row.id) then acts[#acts+1] = "MOVE INFO" end
    acts[#acts+1] = "SORT BAG"
    if state.query ~= "" then acts[#acts+1] = "CLEAR SEARCH" end
    acts[#acts+1] = "CANCEL"
    state.custom = { kind="tools", actions=acts, cursor=1, itemId=row.id }
    BagMenu.ACTIONS = acts
    BagMenu.actionCursor = 1
    BagMenu.mode = "action"
  end

  local function availableMachineTypes()
    local out={}
    for i,v in ipairs(TYPE_FILTER_MODES) do out[i]=v end
    return out
  end

  local FILTER_ROWS = { "NAME", "TYPE", "CLASS", "SORT", "RESET", "DONE" }

  local function filterActions()
    local out = {}
    for i, v in ipairs(FILTER_ROWS) do out[i] = v end
    return out
  end

  local function openFilters()
    state.custom = { kind="filters", actions=filterActions(), cursor=1 }
    BagMenu.ACTIONS = state.custom.actions
    BagMenu.actionCursor = 1
    BagMenu.mode = "action"
  end

  local function showMoveInfo(row)
    local mi = row and machineInfo(Pokemon, ItemsData, SummaryData, row.id)
    if not mi then
      BagMenu.mode="message"; BagMenu.messageText="No move data available."; return false
    end
    state.custom = { kind="move_info", info=mi, itemId=row.id }
    BagMenu.mode = "list"
    return true
  end

  local function sortPhysicalBag()
    local pin = state.prefs.pinnedSet
    for _, pocket in ipairs(physicalOrder) do
      local slots = BagMenu._bag and BagMenu._bag.pockets and BagMenu._bag.pockets[pocket]
      if type(slots)=="table" then
        table.sort(slots, function(a,b)
          local ka,kb=canon(ItemsData,a.id),canon(ItemsData,b.id)
          local pa,pb=pin[ka],pin[kb]
          if (pa~=nil) ~= (pb~=nil) then return pa~=nil end
          if pa and pb and pa~=pb then return pa<pb end
          return norm(ItemsData.displayName(a.id)) < norm(ItemsData.displayName(b.id))
        end)
      end
    end
  end

  local function openSearch(title, onDone)
    local okN, Naming = pcall(require, "src.ui.game3.naming")
    if not (okN and Naming and Naming.open) then return false end
    Naming.open({ title=title or "SEARCH ITEMS", template="BOX", maxLen=12, seed=state.query or "",
      onDone=function(value)
        state.query = norm(value or "")
        refreshCursor()
        if onDone then onDone() end
      end,
    })
    return true
  end

  local function changeFilterValue(which, delta)
    delta = tonumber(delta) or 1
    if which == "TYPE" then
      state.filters.type = cycleDir(availableMachineTypes(), state.filters.type, delta)
    elseif which == "CLASS" then
      state.filters.class = cycleDir(CLASS_MODES, state.filters.class, delta)
    elseif which == "SORT" then
      state.prefs.machineSort = cycleDir(SORT_MODES, state.prefs.machineSort, delta)
      savePrefs(mod, state.prefs)
    else
      return false
    end
    refreshCursor()
    return true
  end

  local function handleCustom(input)
    local c = state.custom
    if not c then return false end

    if c.kind == "move_info" then
      if input:wasPressed("a") or input:wasPressed("b") or input:wasPressed("start") then
        state.custom = nil
        BagMenu.mode = "list"
      end
      return true
    end

    if c.kind == "filters" then
      local acts = c.actions or FILTER_ROWS
      if input:wasPressed("up") then
        c.cursor=((c.cursor-2)%#acts)+1; BagMenu.actionCursor=c.cursor; return true
      elseif input:wasPressed("down") then
        c.cursor=(c.cursor%#acts)+1; BagMenu.actionCursor=c.cursor; return true
      elseif input:wasPressed("left") then
        changeFilterValue(acts[c.cursor], -1); return true
      elseif input:wasPressed("right") then
        changeFilterValue(acts[c.cursor], 1); return true
      elseif input:wasPressed("b") or input:wasPressed("start") then
        state.custom=nil; BagMenu.mode="list"; refreshCursor(); return true
      elseif not input:wasPressed("a") then
        return true
      end

      local act=acts[c.cursor]
      if act=="NAME" then
        openSearch("MOVE NAME SEARCH", function()
          if state.custom and state.custom.kind=="filters" then
            state.custom.actions=filterActions(); BagMenu.ACTIONS=state.custom.actions
          end
        end)
        return true
      elseif act=="TYPE" or act=="CLASS" or act=="SORT" then
        changeFilterValue(act, 1)
      elseif act=="RESET" then
        state.filters={kind="ALL",type="ANY",class="ANY"}; state.query=""
        state.prefs.machineSort="NUMBER"; savePrefs(mod,state.prefs); refreshCursor()
      elseif act=="DONE" then
        state.custom=nil; BagMenu.mode="list"; refreshCursor(); return true
      end
      return true
    end

    local acts = c.actions or {}
    if input:wasPressed("up") then
      c.cursor=((c.cursor-2)%#acts)+1; BagMenu.actionCursor=c.cursor; return true
    elseif input:wasPressed("down") then
      c.cursor=(c.cursor%#acts)+1; BagMenu.actionCursor=c.cursor; return true
    elseif input:wasPressed("b") then
      state.custom=nil; BagMenu.mode="list"; refreshCursor(c.itemId); return true
    elseif not input:wasPressed("a") then return true end

    local act=acts[c.cursor]
    if c.kind=="tools" then
      local row=selectedRow(); local id=(row and row.id) or c.itemId
      local k=canon(ItemsData,id)
      if act=="ADD FAVORITE" or act=="REMOVE FAVORITE" then
        toggleOrdered(state.prefs.favoriteOrder,k); persistPrefs()
      elseif act=="PIN ITEM" or act=="UNPIN ITEM" then
        toggleOrdered(state.prefs.pinnedOrder,k); persistPrefs()
      elseif act=="REGISTER" or act=="UNREGISTER" then
        if BagMenu._session then
          BagMenu._session.registeredItem=(act=="REGISTER") and id or nil
        end
      elseif act=="MOVE INFO" then
        state.custom=nil; showMoveInfo(row); return true
      elseif act=="SORT BAG" then
        sortPhysicalBag()
      elseif act=="CLEAR SEARCH" then
        state.query=""
      end
      state.custom=nil; BagMenu.mode="list"; refreshCursor(id); return true
    end
    return true
  end

  local REPEAT = {
    off={enabled=false,delay=999999,rate=999999},
    normal={enabled=true,delay=16,rate=4}, fast={enabled=true,delay=10,rate=2},
    very_fast={enabled=true,delay=6,rate=1},
  }

  local function inputProxy(input)
    if not (state.active and BagMenu.mode=="list" and input and input.isDown) then return input end
    local speed=tostring(optionValue(mod,"hold_scroll_speed","fast"))
    local cfg=REPEAT[speed] or REPEAT.fast
    local key
    if input:isDown("up") then key="up" elseif input:isDown("down") then key="down" end
    local pressed=key and input:wasPressed(key)
    if key~=state.repeatKey or pressed then state.repeatKey=key; state.repeatFrames=0
    elseif key then state.repeatFrames=state.repeatFrames+1 else state.repeatKey=nil; state.repeatFrames=0 end
    local synth=cfg.enabled and key and state.repeatFrames>=cfg.delay and ((state.repeatFrames-cfg.delay)%cfg.rate==0) and key or nil
    return {
      wasPressed=function(_,k) return input:wasPressed(k) or synth==k end,
      isDown=function(_,k)
        if k=="up" or k=="down" then return false end
        return input:isDown(k)
      end,
    }
  end

  local function drawNativeCustomMenu()
    if not state.custom then return end
    local okW, Window = pcall(require, "src.ui.game3.window")
    local okF, FrlgFont = pcall(require, "src.ui.game3.frlg_font")
    if not (okW and okF and Window and FrlgFont) then return end
    local acts=state.custom.actions or {}
    local popW=26
    local popH=math.min(14, math.max(4, #acts*2))
    local popX=3
    local popY=math.max(1, 19-popH)
    Window.stdFrame(Window.template(popX,popY,popW,popH))
    for i,act in ipairs(acts) do
      local y=popY*8+(i-1)*16+2
      if i==(state.custom.cursor or 1) then Window.cursorPx(popX*8+1,y) end
      FrlgFont.draw(act,popX*8+9,y,{colors=FrlgFont.COLOR.NORMAL,maxWidth=popW*8-14,small=true})
    end
  end

  if type(base.draw)=="function" then
    BagMenu.draw=function(...)
      if state.active and state.custom then
        local mode=BagMenu.mode
        BagMenu.mode="list"
        local ok,a,b,c=pcall(base.draw,...)
        BagMenu.mode=mode
        if not ok then error(a) end
        drawNativeCustomMenu()
        return a,b,c
      end
      return base.draw(...)
    end
  end

  local function selectedMachineRow()
    if not isMachineView() or BagMenu.mode ~= "list" then return nil end
    return selectedRow()
  end

  local function closeMoveInfo()
    if state.custom and state.custom.kind == "move_info" then
      state.custom = nil
      BagMenu.mode = "list"
      return true
    end
    return false
  end

  local function triggerMoveInfoHotkey()
    if not (state.active and BagMenu.open and not BagMenu._battle) then return false end
    if state.custom and state.custom.kind == "move_info" then return closeMoveInfo() end
    if state.custom or BagMenu.mode ~= "list" or categoryAt(BagMenu.pocketIdx).id ~= "machines" then return false end
    local row = selectedMachineRow()
    if not row then return false end
    return showMoveInfo(row)
  end

  if mod.hooks and mod.hooks.wrap then
    mod.hooks:wrap("input.key", function(next, game, ev)
      if ev and ev.phase == "pressed" and tostring(ev.key or ""):lower() == "i"
          and triggerMoveInfoHotkey() then
        return true
      end
      return next(game, ev)
    end, 900)
    mod.hooks:wrap("input.gamepad", function(next, game, ev)
      if ev and ev.phase == "pressed" and tostring(ev.button or ""):lower() == "y"
          and triggerMoveInfoHotkey() then
        return true
      end
      return next(game, ev)
    end, 900)
  end

  local overlayFonts = {}
  local function overlayFont(size)
    size = math.max(7, math.floor(size + 0.5))
    if not overlayFonts[size] and love and love.graphics and love.graphics.newFont then
      local ok, f = pcall(love.graphics.newFont, size)
      if ok then overlayFonts[size] = f end
    end
    return overlayFonts[size] or (love and love.graphics and love.graphics.getFont and love.graphics.getFont())
  end

  local TYPE_COLORS = {
    NORMAL={0.55,0.55,0.48}, FIGHTING={0.73,0.22,0.18}, FLYING={0.48,0.58,0.84},
    POISON={0.58,0.30,0.64}, GROUND={0.73,0.58,0.32}, ROCK={0.64,0.55,0.25},
    BUG={0.57,0.64,0.15}, GHOST={0.40,0.34,0.60}, STEEL={0.55,0.58,0.66},
    FIRE={0.88,0.32,0.18}, WATER={0.25,0.48,0.84}, GRASS={0.30,0.65,0.26},
    ELECTRIC={0.90,0.72,0.10}, PSYCHIC={0.86,0.31,0.52}, ICE={0.42,0.72,0.80},
    DRAGON={0.42,0.24,0.80}, DARK={0.33,0.29,0.26}, MYSTERY={0.38,0.62,0.56},
  }

  local function fillRect(x,y,w,h,r,g,b,a,rad)
    love.graphics.setColor(r,g,b,a or 1)
    local rr=rad or math.min(12,math.max(2,h*0.18))
    love.graphics.rectangle("fill",x,y,w,h,rr,rr)
  end

  local function outlineRect(x,y,w,h,r,g,b,a,rad,lw)
    love.graphics.setLineWidth(lw or 1)
    love.graphics.setColor(r,g,b,a or 1)
    local rr=rad or math.min(12,math.max(2,h*0.18))
    love.graphics.rectangle("line",x,y,w,h,rr,rr)
    love.graphics.setLineWidth(1)
  end

  local function put(text,x,y,w,size,color,align)
    love.graphics.setFont(overlayFont(size))
    love.graphics.setColor((color and color[1]) or 1,(color and color[2]) or 1,(color and color[3]) or 1,(color and color[4]) or 1)
    love.graphics.printf(tostring(text or ""),x,y,math.max(1,w),align or "left")
  end

  local function ellipsize(text, size, maxW)
    text=tostring(text or "")
    local f=overlayFont(size)
    if not (f and f.getWidth) or f:getWidth(text)<=maxW then return text end
    local tail="..."
    while #text>1 and f:getWidth(text..tail)>maxW do text=text:sub(1,-2) end
    return text..tail
  end

  local function putLine(text,x,y,w,h,size,color,align)
    love.graphics.setScissor(x,y,math.max(1,w),math.max(1,h))
    put(ellipsize(text,size,w),x,y,w,size,color,align)
    love.graphics.setScissor()
  end

  local function viewportBox(viewport)
    local x=tonumber(viewport and viewport.gameX) or 0
    local y=tonumber(viewport and viewport.gameY) or 0
    local w=tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
    local h=tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
    local scl=math.max(0.34,math.min(1.60,w/720,h/480))
    return x,y,w,h,scl
  end

  local function prettySort(v)
    if v == "NAME" then return "Move Name" end
    if v == "POWER HIGH" then return "Power High -> Low" end
    if v == "POWER LOW" then return "Power Low -> High" end
    return "Machine Number"
  end

  local function filteredMachineCount()
    return #(logicalRows("TM_CASE") or {})
  end

  local function topIsBag()
    local top=Stack and Stack.top and Stack.top()
    return top and top.id=="bag" and top.mod==BagMenu
  end

  local function typeColor(t)
    return TYPE_COLORS[t] or {0.42,0.48,0.58}
  end

  local function classShort(c)
    if c=="PHYSICAL" then return "PHYSICAL" end
    if c=="SPECIAL" then return "SPECIAL" end
    return "STATUS"
  end

  local function statText(v, suffix)
    if v==nil or tonumber(v)==nil or tonumber(v)<=0 then return "--" end
    return tostring(math.floor(tonumber(v))) .. (suffix or "")
  end

  local function drawBadge(text,x,y,w,h,bg,scl)
    fillRect(x,y,w,h,bg[1],bg[2],bg[3],1,7*scl)
    putLine(text,x+5*scl,y+h*0.20,w-10*scl,h*0.70,11*scl,{1,1,1,1},"center")
  end

  local function filterValue(name)
    if name=="NAME" then return state.query~="" and state.query or "ANY" end
    if name=="TYPE" then return state.filters.type end
    if name=="CLASS" then return state.filters.class end
    if name=="SORT" then return prettySort(state.prefs.machineSort) end
    return ""
  end

  local function drawFilterChips(vx, y, vw, scl)
    local pad=12*scl
    local gap=7*scl
    local labels={
      {"NAME",state.query~="" and state.query or "ANY"},
      {"TYPE",state.filters.type},
      {"CLASS",state.filters.class},
      {"SORT",prettySort(state.prefs.machineSort)},
    }
    local cw=(vw-pad*2-gap*3)/4
    for i,row in ipairs(labels) do
      local x=vx+pad+(i-1)*(cw+gap)
      fillRect(x,y,cw,32*scl,0.075,0.095,0.13,1,7*scl)
      putLine(row[1],x+7*scl,y+4*scl,cw-14*scl,11*scl,9*scl,{0.52,0.62,0.75,1})
      putLine(row[2],x+7*scl,y+16*scl,cw-14*scl,14*scl,10*scl,{0.94,0.96,1,1})
    end
  end

  local function drawMachineCatalogue(viewport)
    if not (love and love.graphics) then return end
    local vx,vy,vw,vh,scl=viewportBox(viewport)
    love.graphics.setScissor(vx,vy,vw,vh)
    love.graphics.setColor(0.028,0.043,0.065,1); love.graphics.rectangle("fill",vx,vy,vw,vh)

    local headerH=54*scl
    fillRect(vx,vy,vw,headerH,0.055,0.09,0.145,1,0)
    putLine("TM / HM CASE",vx+16*scl,vy+12*scl,vw*0.55,30*scl,21*scl,{1,1,1,1})
    putLine(tostring(filteredMachineCount()).." MOVES",vx+vw*0.60,vy+15*scl,vw*0.36-16*scl,25*scl,12*scl,{0.68,0.80,0.96,1},"right")

    local chipY=vy+headerH+8*scl
    drawFilterChips(vx,chipY,vw,scl)

    local footerH=34*scl
    local contentY=chipY+39*scl
    local contentH=vy+vh-footerH-contentY-8*scl
    local gap=10*scl
    local pad=12*scl
    local leftW=vw*0.56
    local rightX=vx+leftW+gap
    local rightW=vw-leftW-gap-pad

    fillRect(vx+pad,contentY,leftW-pad,contentH,0.045,0.060,0.085,1,10*scl)
    fillRect(rightX,contentY,rightW,contentH,0.045,0.060,0.085,1,10*scl)

    local rows=logicalRows("TM_CASE") or {}
    local total=#rows+1
    local visible=6
    local listX=vx+pad+8*scl
    local listW=leftW-pad-16*scl
    local rowGap=5*scl
    local rowH=(contentH-16*scl-rowGap*(visible-1))/visible
    for i=1,visible do
      local idx=(BagMenu.scroll or 0)+i
      if idx>total then break end
      local y=contentY+8*scl+(i-1)*(rowH+rowGap)
      local selected=idx==(BagMenu.cursor or 1)
      if selected then
        fillRect(listX,y,listW,rowH,0.12,0.24,0.39,1,8*scl)
        outlineRect(listX,y,listW,rowH,0.34,0.58,0.90,1,8*scl,2*scl)
      else
        fillRect(listX,y,listW,rowH,0.075,0.092,0.12,1,8*scl)
      end
      local row=rows[idx]
      if row then
        local mi=row._modernMachine or machineInfo(Pokemon,ItemsData,SummaryData,row.id)
        if mi then
          local codeW=58*scl
          putLine(mi.code,listX+10*scl,y+8*scl,codeW,rowH-10*scl,12*scl,{0.66,0.80,1,1})
          local typeW=72*scl
          local tc=typeColor(mi.type)
          drawBadge(mi.type,listX+listW-typeW-9*scl,y+8*scl,typeW,rowH-16*scl,tc,scl)
          local nameX=listX+10*scl+codeW
          local nameW=listW-codeW-typeW-32*scl
          putLine(mi.name,nameX,y+6*scl,nameW,18*scl,13*scl,{1,1,1,1})
          local sub=classShort(mi.class).."  /  PWR "..statText(mi.power)
          putLine(sub,nameX,y+24*scl,nameW,15*scl,9*scl,{0.62,0.70,0.80,1})
        end
      else
        putLine("CLOSE BAG",listX+12*scl,y+12*scl,listW-24*scl,rowH-16*scl,12*scl,{0.82,0.86,0.92,1})
      end
    end

    local sel=rows[BagMenu.cursor or 1]
    local info=sel and (sel._modernMachine or machineInfo(Pokemon,ItemsData,SummaryData,sel.id)) or nil
    local rx=rightX+12*scl
    local rw=rightW-24*scl
    if info then
      local iconSize=math.max(1.0,1.65*scl)
      if BagChrome and BagChrome.drawItemIcon then pcall(BagChrome.drawItemIcon,info.id,rx,contentY+14*scl,iconSize) end
      local titleX=rx+48*scl
      putLine(info.name,titleX,contentY+12*scl,rw-48*scl,24*scl,18*scl,{1,1,1,1})
      local qty=tonumber(sel.qty) or 1
      putLine(info.code.."   /   OWNED x"..tostring(qty),titleX,contentY+38*scl,rw-48*scl,18*scl,10*scl,{0.62,0.72,0.86,1})

      local badgeY=contentY+66*scl
      local badgeH=27*scl
      local tc=typeColor(info.type)
      drawBadge(info.type,rx,badgeY,rw*0.48,badgeH,tc,scl)
      drawBadge(info.class,rx+rw*0.52,badgeY,rw*0.48,badgeH,{0.24,0.29,0.38},scl)

      local statY=badgeY+37*scl
      local statGap=6*scl
      local sw=(rw-statGap*2)/3
      local stats={{"POWER",statText(info.power)},{"ACCURACY",statText(info.accuracy,"%")},{"PP",statText(info.pp)}}
      for i,st in ipairs(stats) do
        local sx=rx+(i-1)*(sw+statGap)
        fillRect(sx,statY,sw,53*scl,0.075,0.095,0.13,1,7*scl)
        putLine(st[1],sx+5*scl,statY+7*scl,sw-10*scl,13*scl,8*scl,{0.55,0.65,0.78,1},"center")
        putLine(st[2],sx+5*scl,statY+24*scl,sw-10*scl,22*scl,15*scl,{1,1,1,1},"center")
      end

      local effY=statY+63*scl
      local effH=contentY+contentH-12*scl-effY
      fillRect(rx,effY,rw,effH,0.065,0.080,0.105,1,8*scl)
      putLine("MOVE EFFECT",rx+10*scl,effY+9*scl,rw-20*scl,16*scl,10*scl,{0.58,0.70,0.86,1})
      local effect=tostring(info.effect or info.description or "No description available.")
      love.graphics.setScissor(rx+10*scl,effY+28*scl,rw-20*scl,math.max(1,effH-38*scl))
      put(effect,rx+10*scl,effY+28*scl,rw-20*scl,11*scl,{0.92,0.94,0.98,1})
      love.graphics.setScissor(vx,vy,vw,vh)
      if info.effectChance and info.effectChance>0 then
        putLine("Secondary chance: "..tostring(info.effectChance).."%",rx+10*scl,effY+effH-19*scl,rw-20*scl,13*scl,9*scl,{0.70,0.78,0.90,1},"right")
      end
    else
      putLine("CLOSE BAG",rx,contentY+contentH*0.37,rw,34*scl,22*scl,{1,1,1,1},"center")
      putLine("Press A to close the Bag.",rx,contentY+contentH*0.50,rw,20*scl,11*scl,{0.65,0.72,0.82,1},"center")
    end

    fillRect(vx,vy+vh-footerH,vw,footerH,0.042,0.065,0.10,1,0)
    putLine("A USE   /   SELECT TOOLS   /   START FILTERS   /   Y / I DETAILS   /   B BACK",
      vx+12*scl,vy+vh-footerH+10*scl,vw-24*scl,18*scl,10*scl,{0.86,0.91,0.98,1},"center")
    love.graphics.setScissor()
  end

  local function drawChoiceModal(viewport,title,actions,cursor)
    if not actions or #actions<1 then return end
    local vx,vy,vw,vh,scl=viewportBox(viewport)
    love.graphics.setColor(0,0,0,0.46); love.graphics.rectangle("fill",vx,vy,vw,vh)
    local pw=math.min(vw*0.42,330*scl)
    local rowH=37*scl
    local ph=46*scl+#actions*rowH+12*scl
    local px=vx+(vw-pw)/2
    local py=vy+(vh-ph)/2
    fillRect(px,py,pw,ph,0.055,0.072,0.10,0.99,10*scl)
    outlineRect(px,py,pw,ph,0.28,0.48,0.74,1,10*scl,2*scl)
    putLine(title,px+12*scl,py+12*scl,pw-24*scl,23*scl,14*scl,{1,1,1,1},"center")
    for i,act in ipairs(actions) do
      local y=py+42*scl+(i-1)*rowH
      if i==(cursor or 1) then fillRect(px+10*scl,y,pw-20*scl,rowH-5*scl,0.13,0.27,0.43,1,7*scl) end
      putLine(act,px+20*scl,y+9*scl,pw-40*scl,rowH-12*scl,11*scl,{0.94,0.96,1,1})
    end
  end

  local function drawMoveInfoOverlay(viewport, info)
    if not (love and love.graphics and info) then return end
    local vx,vy,vw,vh,scl=viewportBox(viewport)
    love.graphics.setScissor(vx,vy,vw,vh)
    love.graphics.setColor(0,0,0,0.70); love.graphics.rectangle("fill",vx,vy,vw,vh)
    local pw=math.min(vw*0.88,850*scl)
    local ph=math.min(vh*0.84,455*scl)
    local px=vx+(vw-pw)/2
    local py=vy+(vh-ph)/2
    fillRect(px,py,pw,ph,0.045,0.060,0.085,0.995,12*scl)
    outlineRect(px,py,pw,ph,0.32,0.53,0.82,1,12*scl,2*scl)
    local headerH=58*scl
    fillRect(px,py,pw,headerH,0.07,0.12,0.19,1,12*scl)
    putLine("MOVE INFORMATION",px+18*scl,py+10*scl,pw*0.33,22*scl,12*scl,{0.63,0.76,0.94,1})
    putLine(info.code.."   "..info.name,px+18*scl,py+29*scl,pw-36*scl,27*scl,19*scl,{1,1,1,1})

    local bodyY=py+headerH+14*scl
    local footerH=32*scl
    local bodyH=py+ph-footerH-bodyY-10*scl
    local gap=12*scl
    local leftW=pw*0.34
    local lx=px+14*scl
    local rx=lx+leftW+gap
    local rw=px+pw-14*scl-rx
    fillRect(lx,bodyY,leftW,bodyH,0.065,0.082,0.11,1,9*scl)
    fillRect(rx,bodyY,rw,bodyH,0.065,0.082,0.11,1,9*scl)

    local iconScale=math.max(1.1,2.0*scl)
    if BagChrome and BagChrome.drawItemIcon then pcall(BagChrome.drawItemIcon,info.id,lx+14*scl,bodyY+16*scl,iconScale) end
    putLine(info.name,lx+66*scl,bodyY+17*scl,leftW-80*scl,23*scl,15*scl,{1,1,1,1})
    putLine(info.code,lx+66*scl,bodyY+40*scl,leftW-80*scl,18*scl,10*scl,{0.62,0.72,0.86,1})
    local badgeY=bodyY+75*scl
    local bw=(leftW-38*scl)/2
    drawBadge(info.type,lx+12*scl,badgeY,bw,27*scl,typeColor(info.type),scl)
    drawBadge(info.class,lx+22*scl+bw,badgeY,bw,27*scl,{0.24,0.29,0.38},scl)
    local statY=badgeY+42*scl
    local stats={{"POWER",statText(info.power)},{"ACCURACY",statText(info.accuracy,"%")},{"PP",statText(info.pp)}}
    for i,st in ipairs(stats) do
      local y=statY+(i-1)*55*scl
      fillRect(lx+12*scl,y,leftW-24*scl,45*scl,0.085,0.105,0.14,1,7*scl)
      putLine(st[1],lx+22*scl,y+7*scl,(leftW-44*scl)*0.55,18*scl,9*scl,{0.58,0.68,0.82,1})
      putLine(st[2],lx+leftW*0.56,y+6*scl,leftW*0.36,24*scl,16*scl,{1,1,1,1},"right")
    end

    putLine("MOVE EFFECT",rx+14*scl,bodyY+14*scl,rw-28*scl,20*scl,12*scl,{0.62,0.75,0.92,1})
    if info.effectChance and info.effectChance>0 then
      putLine("Secondary chance  "..tostring(info.effectChance).."%",rx+14*scl,bodyY+14*scl,rw-28*scl,20*scl,9*scl,{0.72,0.80,0.90,1},"right")
    end
    love.graphics.setScissor(rx+14*scl,bodyY+42*scl,rw-28*scl,math.max(1,bodyH-56*scl))
    put(tostring(info.effect or info.description or "No description available."),rx+14*scl,bodyY+42*scl,rw-28*scl,13*scl,{0.93,0.95,0.99,1})
    love.graphics.setScissor(vx,vy,vw,vh)
    putLine("Y / I   or   A / B   BACK",px+18*scl,py+ph-footerH+8*scl,pw-36*scl,18*scl,10*scl,{0.68,0.76,0.87,1},"center")
    love.graphics.setScissor()
  end

  local function drawFilterOverlay(viewport)
    if not (love and love.graphics and state.custom and state.custom.kind=="filters") then return end
    local vx,vy,vw,vh,scl=viewportBox(viewport)
    love.graphics.setScissor(vx,vy,vw,vh)
    love.graphics.setColor(0,0,0,0.70); love.graphics.rectangle("fill",vx,vy,vw,vh)
    local pw=math.min(vw*0.90,900*scl)
    local ph=math.min(vh*0.86,460*scl)
    local px=vx+(vw-pw)/2
    local py=vy+(vh-ph)/2
    fillRect(px,py,pw,ph,0.045,0.060,0.085,0.995,12*scl)
    outlineRect(px,py,pw,ph,0.31,0.52,0.82,1,12*scl,2*scl)
    local pad=15*scl
    putLine("TM/HM FILTERS",px+pad,py+12*scl,pw*0.42,26*scl,18*scl,{1,1,1,1})
    putLine(tostring(filteredMachineCount()).." result(s)",px+pw*0.62,py+15*scl,pw*0.34-pad,20*scl,11*scl,{0.66,0.78,0.94,1},"right")
    drawFilterChips(px,py+45*scl,pw,scl)

    local bodyY=py+84*scl
    local footerH=34*scl
    local bodyH=py+ph-footerH-bodyY-10*scl
    local navW=pw*0.28
    local navX=px+pad
    local contentX=navX+navW+12*scl
    local contentW=px+pw-pad-contentX
    fillRect(navX,bodyY,navW,bodyH,0.060,0.078,0.105,1,9*scl)
    fillRect(contentX,bodyY,contentW,bodyH,0.060,0.078,0.105,1,9*scl)

    local cur=state.custom.cursor or 1
    local navRows=FILTER_ROWS
    local navGap=5*scl
    local navH=(bodyH-16*scl-navGap*(#navRows-1))/#navRows
    for i,name in ipairs(navRows) do
      local y=bodyY+8*scl+(i-1)*(navH+navGap)
      if i==cur then
        fillRect(navX+7*scl,y,navW-14*scl,navH,0.13,0.27,0.43,1,7*scl)
        outlineRect(navX+7*scl,y,navW-14*scl,navH,0.33,0.57,0.90,1,7*scl,1.5*scl)
      end
      putLine(name,navX+16*scl,y+8*scl,navW-32*scl,16*scl,11*scl,{1,1,1,1})
      local val=filterValue(name)
      if val~="" then putLine(val,navX+16*scl,y+23*scl,navW-32*scl,14*scl,9*scl,{0.61,0.72,0.87,1}) end
    end

    local active=navRows[cur]
    local cx=contentX+14*scl
    local cw=contentW-28*scl
    putLine(active=="RESET" and "RESET FILTERS" or active=="DONE" and "APPLY & CLOSE" or (active.." FILTER"),
      cx,bodyY+12*scl,cw,25*scl,15*scl,{1,1,1,1})

    if active=="NAME" then
      putLine("Search by the move name, not the machine number.",cx,bodyY+44*scl,cw,36*scl,10*scl,{0.66,0.74,0.84,1})
      fillRect(cx,bodyY+92*scl,cw,54*scl,0.085,0.11,0.15,1,8*scl)
      putLine(state.query~="" and state.query or "ANY MOVE NAME",cx+14*scl,bodyY+108*scl,cw-28*scl,24*scl,15*scl,{1,1,1,1})
      putLine("Press A to edit",cx,bodyY+160*scl,cw,18*scl,10*scl,{0.60,0.72,0.88,1},"center")
    elseif active=="TYPE" then
      putLine("← / → changes the selected type. All types stay visible for reference.",cx,bodyY+42*scl,cw,34*scl,9*scl,{0.66,0.74,0.84,1})
      local types=availableMachineTypes()
      local cols=4
      local gap=6*scl
      local tw=(cw-gap*(cols-1))/cols
      local th=28*scl
      local y0=bodyY+82*scl
      for i,t in ipairs(types) do
        local col=(i-1)%cols; local row=math.floor((i-1)/cols)
        local x=cx+col*(tw+gap); local y=y0+row*(th+gap)
        local tc=t=="ANY" and {0.23,0.29,0.38} or typeColor(t)
        local selected=t==state.filters.type
        fillRect(x,y,tw,th,tc[1],tc[2],tc[3],selected and 1 or 0.42,6*scl)
        if selected then outlineRect(x,y,tw,th,0.95,0.98,1,1,6*scl,2*scl) end
        putLine(t,x+4*scl,y+7*scl,tw-8*scl,14*scl,9*scl,{1,1,1,1},"center")
      end
    elseif active=="CLASS" then
      putLine("Gen III class is derived from move type; status moves remain STATUS.",cx,bodyY+42*scl,cw,34*scl,9*scl,{0.66,0.74,0.84,1})
      local vals=CLASS_MODES
      local gap=8*scl
      local cardW=(cw-gap)/2
      local cardH=58*scl
      local y0=bodyY+92*scl
      for i,v in ipairs(vals) do
        local col=(i-1)%2; local row=math.floor((i-1)/2)
        local x=cx+col*(cardW+gap); local y=y0+row*(cardH+gap)
        local selected=v==state.filters.class
        fillRect(x,y,cardW,cardH,selected and 0.13 or 0.08,selected and 0.27 or 0.10,selected and 0.43 or 0.14,1,8*scl)
        if selected then outlineRect(x,y,cardW,cardH,0.36,0.62,0.94,1,8*scl,2*scl) end
        putLine(v,x+8*scl,y+20*scl,cardW-16*scl,20*scl,11*scl,{1,1,1,1},"center")
      end
    elseif active=="SORT" then
      putLine("Choose how the filtered result list is ordered.",cx,bodyY+42*scl,cw,24*scl,9*scl,{0.66,0.74,0.84,1})
      local vals={{"NUMBER","MACHINE NUMBER"},{"NAME","MOVE NAME"},{"POWER HIGH","POWER HIGH -> LOW"},{"POWER LOW","POWER LOW -> HIGH"}}
      local gap=8*scl
      local cardW=(cw-gap)/2
      local cardH=58*scl
      local y0=bodyY+86*scl
      for i,v in ipairs(vals) do
        local col=(i-1)%2; local row=math.floor((i-1)/2)
        local x=cx+col*(cardW+gap); local y=y0+row*(cardH+gap)
        local selected=v[1]==state.prefs.machineSort
        fillRect(x,y,cardW,cardH,selected and 0.13 or 0.08,selected and 0.27 or 0.10,selected and 0.43 or 0.14,1,8*scl)
        if selected then outlineRect(x,y,cardW,cardH,0.36,0.62,0.94,1,8*scl,2*scl) end
        putLine(v[2],x+8*scl,y+20*scl,cardW-16*scl,20*scl,10*scl,{1,1,1,1},"center")
      end
    elseif active=="RESET" then
      putLine("Clear NAME, TYPE and CLASS, and restore Machine Number sorting.",cx,bodyY+55*scl,cw,48*scl,12*scl,{0.78,0.84,0.92,1},"center")
      fillRect(cx+cw*0.18,bodyY+125*scl,cw*0.64,50*scl,0.34,0.13,0.13,1,8*scl)
      putLine("A  RESET ALL",cx+cw*0.18,bodyY+141*scl,cw*0.64,20*scl,12*scl,{1,1,1,1},"center")
    elseif active=="DONE" then
      putLine("Filters are applied live. Close this panel to return to the move list.",cx,bodyY+52*scl,cw,48*scl,11*scl,{0.78,0.84,0.92,1},"center")
      fillRect(cx+cw*0.18,bodyY+125*scl,cw*0.64,50*scl,0.12,0.28,0.22,1,8*scl)
      putLine("A  DONE",cx+cw*0.18,bodyY+141*scl,cw*0.64,20*scl,12*scl,{1,1,1,1},"center")
    end

    fillRect(px,py+ph-footerH,pw,footerH,0.042,0.065,0.10,1,0)
    putLine("UP/DOWN SECTION   /   LEFT/RIGHT CHANGE   /   A EDIT/APPLY   /   B or START DONE",
      px+12*scl,py+ph-footerH+10*scl,pw-24*scl,18*scl,9*scl,{0.78,0.85,0.94,1},"center")
    love.graphics.setScissor()
  end

  if mod.hooks and mod.hooks.wrap then
    mod.hooks:wrap("render.hud", function(next, game, viewport)
      local result=next(game,viewport)
      if state.active and BagMenu.open and not BagMenu._battle and topIsBag() and isMachineView() then
        drawMachineCatalogue(viewport)
        if state.custom and state.custom.kind=="move_info" then
          drawMoveInfoOverlay(viewport,state.custom.info)
        elseif state.custom and state.custom.kind=="filters" then
          drawFilterOverlay(viewport)
        elseif state.custom and state.custom.kind=="tools" then
          drawChoiceModal(viewport,"ITEM TOOLS",state.custom.actions,state.custom.cursor)
        elseif BagMenu.mode=="action" then
          drawChoiceModal(viewport,"TM / HM ACTION",BagMenu.ACTIONS,BagMenu.actionCursor)
        end
      end
      return result
    end, 950)
  end

  BagMenu.handleInput = function(input)
    if not (state.active and not BagMenu._battle) then return base.handleInput(input) end
    if state.custom then return handleCustom(input) end

    local free = BagMenu.mode=="list" and not BagMenu._open and not BagMenu._exit and not BagMenu._switch
    if free and input:wasPressed("select") then itemTools(); return end
    if free and input:wasPressed("start") then
      if categoryAt(BagMenu.pocketIdx).id=="machines" then openFilters()
      else openSearch("SEARCH " .. categoryAt(BagMenu.pocketIdx).label) end
      return
    end

    local before=BagMenu.pocketIdx
    local result=base.handleInput(inputProxy(input))
    if state.active and BagMenu.pocketIdx~=before then rememberPocket(); state.query="" end
    return result
  end

  -- Modern UI reads BagMenu and ItemsData dynamically, so no renderer fork is
  -- needed: exposing the logical order/list here automatically gives the same
  -- high-resolution Gen3 Modern UI Bag with the extra categories.
  mod.exports.categories=function()
    local out={}; for i,c in ipairs(CATEGORIES) do out[i]={id=c.id,key=c.key,label=c.label} end; return out
  end
  mod.exports.categoryForItem=function(id)
    return categoryForRow({id=id,info=ItemsData.info(id),name=ItemsData.displayName(id)})
  end
  mod.exports.machineInfo=function(id) return machineInfo(Pokemon,ItemsData,SummaryData,id) end
  mod.exports.moveDamageClass=moveClass
  mod.exports.isFavorite=function(id) return state.prefs.favoriteSet[canon(ItemsData,id)]~=nil end
  mod.exports.isPinned=function(id) return state.prefs.pinnedSet[canon(ItemsData,id)]~=nil end
  mod.exports.openingPocketIndex=openingIndex
  mod.exports.isMoveInfoOpen=function()
    return state.custom ~= nil and state.custom.kind == "move_info"
  end
  mod.exports.machineFilters=function()
    return { query=state.query, type=state.filters.type, class=state.filters.class, sort=state.prefs.machineSort }
  end

  if mod.log then
    mod.log:info("Modern Bag Gen3 installed: FireRed logical bag views + native Game3 actions")
  end
end

return install
