# Changelog

## 1.1.0
- Changed starter randomization from a save-derived deterministic seed to per-application-launch entropy.
- Oak now receives a fresh random roster after closing and reopening the game, as long as the starter has not yet been chosen.
- The three choices remain distinct base-stage Pokémon from genuine three-stage evolution families.
- The previous launch's three species are excluded from the next launch when the candidate pool permits it.
- The roster is committed only when the starter is actually given, preserving Blue/rival starter consistency after the adventure begins.
- Added migration behavior so the old v1.0.x saved `roster` is not reused as the next pre-choice roster.
- FireRed + LeafGreen support is preserved.

## 1.0.1
- Added LeafGreen support alongside FireRed.
- Updated manifest game targets to `firered` and `leafgreen`.
- Added explicit runtime `supportedGames` metadata for both FRLG games.
- Added `LG_OAKS_LAB` as an accepted Oak's Lab map id.
- Kept the existing starter-slot, evolution-pool, rival-line and text-patching logic unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.0
- Initial FireRed-only release.
- Random stable roster of three base-stage Pokémon from three-stage families.
- Oak starter Poké Ball species replacement.
- Rival counter-choice and later evolution-line continuity.
- Save-persistent roster.
