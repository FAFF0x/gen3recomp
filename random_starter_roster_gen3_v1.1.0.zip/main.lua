-- Random Starter Roster - Gen 3 v1.1.0
-- FireRed + LeafGreen. Keeps Oak's three physical ball slots / VAR_STARTER_MON semantics,
-- but generates a fresh random trio on every application launch until the starter is chosen.

return function(mod)
  local Pokemon = require("src.core.game3.pokemon")

  local VAR_PLAYER_STARTER_NUM     = 0x4001 -- VAR_TEMP_1
  local VAR_PLAYER_STARTER_SPECIES = 0x4002 -- VAR_TEMP_2
  local VAR_RIVAL_STARTER_SPECIES  = 0x4003 -- VAR_TEMP_3
  local FLAG_SYS_POKEMON_GET       = 0x828
  local SPECIES_LAST               = 411

  -- Physical Oak-ball slots in vanilla FRLG:
  -- 1 = Bulbasaur ball, 2 = Squirtle ball, 3 = Charmander ball.
  local VANILLA_SLOT = { [1] = 1, [7] = 2, [4] = 3 }
  local VANILLA_FAMILY_STAGE = {
    BULBASAUR=1, IVYSAUR=2, VENUSAUR=3,
    SQUIRTLE=1, WARTORTLE=2, BLASTOISE=3,
    CHARMANDER=1, CHARMELEON=2, CHARIZARD=3,
  }

  -- Every rival/champion trainer whose starter family is encoded in its trainer id.
  local RIVAL_SLOT_BY_TRAINER = {
    [326]=2, [329]=2, [332]=2, [426]=2, [429]=2, [432]=2, [435]=2, [438]=2, [739]=2,
    [327]=1, [330]=1, [333]=1, [427]=1, [430]=1, [433]=1, [436]=1, [439]=1, [740]=1,
    [328]=3, [331]=3, [334]=3, [428]=3, [431]=3, [434]=3, [437]=3, [440]=3, [741]=3,
  }

  local poolCache
  local pathCache = {}
  local activeRoster
  local currentPlayerSlot
  local patchedConfirmations = 0

  local function copyTable(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
  end

  local function evoTarget(row)
    if type(row) ~= "table" then return nil end
    local n = tonumber(row.target or row.species or row.into or row[3])
    if n and n > 0 then return n end
    return nil
  end

  local function validSpecies(sp)
    sp = tonumber(sp)
    if not sp or sp < 1 or sp > SPECIES_LAST then return false end
    local nat = Pokemon.national(sp)
    if not nat or nat < 1 or nat > 386 then return false end
    local key = Pokemon.keyName and Pokemon.keyName(sp)
    return type(key) == "string" and key ~= "" and key ~= "EGG"
  end

  -- Returns one complete base -> middle -> final path, if one exists.
  local function threeStagePath(base)
    base = tonumber(base)
    if not base then return nil end
    local cached = pathCache[base]
    if cached ~= nil then return cached or nil end
    for _, first in ipairs(Pokemon.evolutions(base) or {}) do
      local mid = evoTarget(first)
      if mid and validSpecies(mid) then
        for _, second in ipairs(Pokemon.evolutions(mid) or {}) do
          local final = evoTarget(second)
          if final and validSpecies(final) then
            local path = { base, mid, final }
            pathCache[base] = path
            return path
          end
        end
      end
    end
    pathCache[base] = false
    return nil
  end

  local function candidatePool()
    if poolCache then return poolCache end
    -- Force evolution/national tables to be available before scanning.
    Pokemon.evolutions(1)
    local hasPre = {}
    for sp = 1, SPECIES_LAST do
      if validSpecies(sp) then
        for _, row in ipairs(Pokemon.evolutions(sp) or {}) do
          local target = evoTarget(row)
          if target and validSpecies(target) then hasPre[target] = true end
        end
      end
    end
    local pool = {}
    for sp = 1, SPECIES_LAST do
      if validSpecies(sp) and not hasPre[sp] and threeStagePath(sp) then
        pool[#pool + 1] = sp
      end
    end
    table.sort(pool, function(a, b)
      return (Pokemon.national(a) or 9999) < (Pokemon.national(b) or 9999)
    end)
    poolCache = pool
    return pool
  end

  local MODULUS = 2147483647

  -- Use process/startup entropy rather than Trainer ID / save identity.
  -- This keeps the three balls stable for the current run, but changes the
  -- roster after closing and reopening the game.
  local function launchSeed()
    local state = 104729

    local function mix(value)
      local n = tonumber(value) or 0
      n = math.floor(math.abs(n)) % MODULUS
      state = (state * 48271 + n + 1) % MODULUS
      if state <= 0 then state = 1 end
    end

    if os and os.time then mix(os.time()) end
    if os and os.clock then mix(os.clock() * 1000000) end

    if love and love.timer and love.timer.getTime then
      local ok, t = pcall(love.timer.getTime)
      if ok then mix((tonumber(t) or 0) * 1000000) end
    end

    -- Lua normally includes an address-like identity in tostring(table).
    -- It is process-local and gives us extra entropy without touching the
    -- global math.random state used by the game or other mods.
    local token = tostring({})
    local hex = token:match("0x(%x+)")
    if hex then mix(tonumber(hex, 16) or 0) end

    return state
  end

  local launchState = launchSeed()

  local function nextRand(state)
    state = (state * 48271) % MODULUS
    if state <= 0 then state = 1 end
    return state, state
  end

  local function rosterValid(roster)
    if type(roster) ~= "table" or #roster ~= 3 then return false end
    local allowed, seen = {}, {}
    for _, sp in ipairs(candidatePool()) do allowed[sp] = true end
    for i = 1, 3 do
      local sp = tonumber(roster[i])
      if not sp or not allowed[sp] or seen[sp] then return false end
      seen[sp] = true
    end
    return true
  end

  local function generateRoster(excludeRoster)
    local pool = candidatePool()
    assert(#pool >= 3, "Random Starter Roster: fewer than three eligible species")

    local excluded = {}
    if rosterValid(excludeRoster) then
      for i = 1, 3 do excluded[tonumber(excludeRoster[i])] = true end
    end

    -- Prefer a completely different trio from the immediately previous launch.
    -- If a custom data set ever exposes fewer than six eligible bases, fall back
    -- to the full pool rather than failing.
    local bag = {}
    for _, sp in ipairs(pool) do
      if not excluded[sp] then bag[#bag + 1] = sp end
    end
    if #bag < 3 then
      bag = {}
      for _, sp in ipairs(pool) do bag[#bag + 1] = sp end
    end

    -- Advance the process-local state before each roster generation.
    launchState = (launchState + 104729) % MODULUS
    if launchState <= 0 then launchState = 1 end
    local state = launchState

    for i = #bag, 2, -1 do
      local r
      state, r = nextRand(state)
      local j = (r % i) + 1
      bag[i], bag[j] = bag[j], bag[i]
    end
    launchState = state

    return { bag[1], bag[2], bag[3] }
  end

  local function sessionFrom(ctx)
    if ctx and ctx.save then
      local ok, s = pcall(function() return ctx.save.gen3 end)
      if ok and type(s) == "table" then return s end
      if type(ctx.save) == "table" then return ctx.save end
    end
    local Runtime = package.loaded["src.core.game3.runtime"]
      or require("src.core.game3.runtime")
    return Runtime and Runtime.getSession and Runtime.getSession() or nil
  end

  local function copyRoster(roster)
    return { tonumber(roster[1]), tonumber(roster[2]), tonumber(roster[3]) }
  end

  local function logRoster(prefix, roster)
    if not (mod.log and mod.log.info and rosterValid(roster)) then return end
    local names = {}
    for i = 1, 3 do
      names[i] = Pokemon.name(roster[i]) or Pokemon.keyName(roster[i]) or tostring(roster[i])
    end
    mod.log:info("%s: %s / %s / %s", prefix, names[1], names[2], names[3])
  end

  -- Preview roster: process-local only. It is deliberately NOT restored from
  -- the previous launch, so reopening the game rerolls Oak's three choices.
  local function ensureLaunchRoster(ctx)
    if rosterValid(activeRoster) then return activeRoster end

    local previous = mod.save:get("lastLaunchRoster")
    if not rosterValid(previous) then
      -- v1.0.x stored its preview directly as "roster"; use it only as an
      -- exclusion source during migration, never as the current launch roster.
      previous = mod.save:get("roster")
    end

    activeRoster = generateRoster(previous)
    mod.save:set("lastLaunchRoster", copyRoster(activeRoster))
    logRoster("Random starter launch roster", activeRoster)
    return activeRoster
  end

  -- Once the player actually receives a starter, freeze the current trio for
  -- future rival teams. This prevents Blue's starter family from changing on
  -- later application launches after the adventure has already begun.
  local function commitRoster(roster)
    if not rosterValid(roster) then return end
    local committed = copyRoster(roster)
    mod.save:set("committedRoster", committed)
    -- Keep the legacy key populated for compatibility with v1.0.x and tools.
    mod.save:set("roster", committed)
    logRoster("Committed starter roster", committed)
  end

  local function ensureCommittedRoster(ctx)
    if rosterValid(activeRoster) then return activeRoster end

    local saved = mod.save:get("committedRoster")
    if not rosterValid(saved) then saved = mod.save:get("roster") end
    if rosterValid(saved) then
      activeRoster = copyRoster(saved)
      return activeRoster
    end

    -- Defensive fallback for unusual scripts/mods that request the rival team
    -- without going through Oak's normal gift event.
    activeRoster = generateRoster(mod.save:get("lastLaunchRoster"))
    commitRoster(activeRoster)
    return activeRoster
  end

  local function oakLab(ctx)
    local map = ctx and ctx.overworld and ctx.overworld.map
    local id = map and map.id
    return id == "OAKS_LAB" or id == "FR_OAKS_LAB" or id == "LG_OAKS_LAB" or id == "PalletTown_ProfessorOaksLab"
  end

  local function firstStarterScene(ctx)
    if not oakLab(ctx) then return false end
    local session = sessionFrom(ctx)
    if session and type(session.party) == "table" and #session.party > 0 then return false end
    local okS, Space = pcall(require, "src.core.game3.scripting.space")
    local okF, Flags = pcall(require, "src.core.game3.scripting.flags")
    if okS and okF and Space and Space.store and Flags and Flags.getFlag then
      if Flags.getFlag(Space.store, nil, FLAG_SYS_POKEMON_GET) then return false end
    end
    return true
  end

  local function setStringVar1(ctx, species)
    local vm = ctx and (ctx.vm or ctx.runner)
    local raw = vm and vm.ctx
    if type(raw) == "table" then
      raw.stringVars = raw.stringVars or {}
      raw.stringVars[1] = Pokemon.name(species) or Pokemon.keyName(species) or tostring(species)
    end
  end

  -- Preserve the real FRLG TextIR control tokens but replace the fixed species
  -- words in the three starter confirmations with STR_VAR_1.
  local function replaceSpeciesText(ir, fixedName)
    local out = {}
    for _, seg in ipairs(ir or {}) do
      if type(seg) == "table" and seg.t == "text" and type(seg.s) == "string" then
        local s = seg.s
        s = s:gsub("GRASS POKéMON ", "POKéMON ")
             :gsub("WATER POKéMON ", "POKéMON ")
             :gsub("FIRE POKéMON ", "POKéMON ")
        local pos = 1
        while true do
          local a, b = s:find(fixedName, pos, true)
          if not a then
            if pos <= #s then out[#out + 1] = { t = "text", s = s:sub(pos) } end
            break
          end
          if a > pos then out[#out + 1] = { t = "text", s = s:sub(pos, a - 1) } end
          out[#out + 1] = { t = "strvar", n = 1 }
          pos = b + 1
        end
      else
        local c = {}
        if type(seg) == "table" then for k, v in pairs(seg) do c[k] = v end else c = seg end
        out[#out + 1] = c
      end
    end
    return out
  end

  local function patchConfirmationText()
    local targets = {
      { phrase = "BULBASAUR is your choice", name = "BULBASAUR" },
      { phrase = "SQUIRTLE is your choice", name = "SQUIRTLE" },
      { phrase = "CHARMANDER is your choice", name = "CHARMANDER" },
    }
    local patches = {}
    for id, ir in mod.content.text:each() do
      if type(ir) == "table" then
        local flat = {}
        for _, seg in ipairs(ir) do
          if type(seg) == "table" and type(seg.s) == "string" then flat[#flat + 1] = seg.s end
        end
        local joined = table.concat(flat)
        for _, target in ipairs(targets) do
          if joined:find(target.phrase, 1, true) then
            patches[#patches + 1] = { id = id, ir = replaceSpeciesText(ir, target.name) }
            break
          end
        end
      end
    end
    for _, p in ipairs(patches) do
      mod.content.text:override(p.id, p.ir)
      patchedConfirmations = patchedConfirmations + 1
    end
  end

  patchConfirmationText()

  mod.hooks:wrap("script.command", function(nextFn, ctx, op, row)
    if not firstStarterScene(ctx) then return nextFn(ctx, op, row) end
    local roster = ensureLaunchRoster(ctx)
    if op == "setvar" then
      local var = tonumber(row.var or row[1])
      local value = tonumber(row.value or row[2])
      if var == VAR_PLAYER_STARTER_NUM and value and value >= 0 and value <= 2 then
        currentPlayerSlot = value + 1
      elseif var == VAR_PLAYER_STARTER_SPECIES then
        local slot = VANILLA_SLOT[value]
        if slot and roster[slot] then
          currentPlayerSlot = slot
          setStringVar1(ctx, roster[slot])
          local copy = copyTable(row)
          copy.value, copy[2] = roster[slot], roster[slot]
          return nextFn(ctx, op, copy)
        end
      elseif var == VAR_RIVAL_STARTER_SPECIES then
        local slot = VANILLA_SLOT[value]
        if slot and roster[slot] then
          local copy = copyTable(row)
          copy.value, copy[2] = roster[slot], roster[slot]
          return nextFn(ctx, op, copy)
        end
      end
    end
    return nextFn(ctx, op, row)
  end, 420)

  -- Safety seam: if another script/gift path still presents a vanilla starter,
  -- replace only the first Oak's Lab gift. Other gifts are untouched.
  mod.events:on("pokemon.before_give", function(gift)
    if not gift or not firstStarterScene(gift.ctx) then return end
    local roster = ensureLaunchRoster(gift.ctx)
    local slot = VANILLA_SLOT[tonumber(gift.speciesId)]
      or VANILLA_SLOT[Pokemon.speciesFromName(gift.species)]
      or currentPlayerSlot
    if slot and roster[slot] then
      gift.species = Pokemon.keyName(roster[slot]) or roster[slot]
      gift.speciesId = roster[slot]
      gift.level = 5
      commitRoster(roster)
    end
  end)

  -- Keep Blue on the same random starter family all game. The vanilla FRLG trainer
  -- id tells us which of the three physical Oak-ball slots his starter came from.
  mod.hooks:wrap("trainer.party", function(nextFn, trainerClass, trainerId, party)
    local base = nextFn(trainerClass, trainerId, party) or party
    local slot = RIVAL_SLOT_BY_TRAINER[tonumber(trainerId)]
    if not slot or type(base) ~= "table" then return base end
    local roster = ensureCommittedRoster(nil)
    local path = threeStagePath(roster[slot])
    if not path then return base end
    local out = {}
    for i, mon in ipairs(base) do
      local row = copyTable(mon)
      local key = type(row.species) == "string" and row.species or Pokemon.keyName(tonumber(row.speciesId or row.species))
      local stage = key and VANILLA_FAMILY_STAGE[key]
      if stage then
        local repl = path[stage] or path[#path]
        row.species = Pokemon.keyName(repl) or repl
        row.speciesId = repl
        -- Rival parties sometimes carry explicit starter moves. Recompute a
        -- legal level-up moveset for the substituted species at this battle's
        -- level instead of inheriting Bulbasaur/Squirtle/Charmander-only moves.
        local G3 = require("src.mods.Gen3Compat")
        local learned = Pokemon.movesAtLevel(repl, tonumber(row.level or row.lvl) or 5) or {}
        local namedMoves = {}
        for _, moveId in ipairs(learned) do
          local moveName = G3.moveName and G3.moveName(moveId) or nil
          if moveName then namedMoves[#namedMoves + 1] = moveName end
        end
        row.moves = (#namedMoves > 0) and namedMoves or nil
        row.moveIds = nil
      end
      out[i] = row
    end
    return out
  end, 420)

  mod.exports.version = "1.1.0"
  mod.exports.supportedGames = { "firered", "leafgreen" }
  mod.exports.rerollsEveryLaunch = true
  mod.exports.commitAfterStarterChoice = true
  mod.exports.eligibleSpecies = function()
    local out = {}
    for i, sp in ipairs(candidatePool()) do out[i] = Pokemon.keyName(sp) or sp end
    return out
  end
  mod.exports.currentRoster = function()
    local roster = ensureCommittedRoster(nil)
    local out = {}
    for i = 1, 3 do out[i] = Pokemon.keyName(roster[i]) or roster[i] end
    return out
  end
  mod.exports.confirmationTextPatches = function() return patchedConfirmations end
end
