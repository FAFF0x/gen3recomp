# Changelog

## 1.1.4
- Replaced generic Modern UI Poké Mart mirroring with a dedicated modern TM/HM catalogue renderer.
- Added persistent readable move details beside the list.
- Added colored move-type badges with vector type icons.
- Added Physical / Special / Status category icon.
- Added Machine, Type and Category filters.
- Added live filtered result count and active-filter chips.
- Kept v1.1.2 static Game3 stack adapter fix and all purchase behavior.
- Uses a unique catalogue stack id so Modern UI does not overwrite the specialized layout.

## 1.1.3
- Integrated catalogue with Modern UI via generic shop presenter.

## 1.1.2
- Fixed Game3 modal-stack callback freeze.
