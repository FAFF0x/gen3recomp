-- Universal Free TM/HM Shop Gen 3 v1.1.4
-- FireRed-only port of all_tm_shop_gen2.
-- Dedicated modern catalogue with filters + readable move details.

return function(mod)
  local VERSION = "1.1.4"
  local MOD_ID = "all_tm_shop_gen3"
  local ROOT_ID = "all_tm_shop_gen3_catalogue"
  local STACK_ID = "all_tm_shop_gen3_catalogue"

  local Bag = require("src.core.game3.bag")
  local ItemsData = require("src.core.game3.items_data")
  local Pokemon = require("src.core.game3.pokemon")
  local Moves = require("src.core.game3.battle.moves")
  local Types = require("src.core.game3.battle.types")
  local EffectIds = require("src.core.game3.battle.effect_ids")
  local SummaryData = require("src.core.game3.summary_data")
  local SummaryChrome = require("src.ui.game3.summary_chrome")
  local Stack = require("src.ui.game3.stack")
  local Window = require("src.ui.game3.window")
  local FrlgFont = require("src.ui.game3.frlg_font")
  local ShopMenu = require("src.ui.game3.shop_menu")

  local NUM_TMS = 50
  local NUM_HMS = 8
  local NUM_MACHINES = 58
  local FIRST_TM, LAST_TM = 289, 338
  local FIRST_HM, LAST_HM = 339, 346
  local VISIBLE_ROWS = 8

  local function copyTable(src)
    local out = {}
    for k, v in pairs(src or {}) do out[k] = v end
    return out
  end

  local function copyList(src)
    local out = {}
    for i, v in ipairs(src or {}) do out[i] = v end
    return out
  end

  local function numeric(id)
    if ItemsData.toNumericId then
      local ok, n = pcall(ItemsData.toNumericId, id)
      if ok and n then return tonumber(n) end
    end
    return tonumber(id)
  end

  local function normalized(value)
    return tostring(value or ""):upper():gsub("[^A-Z0-9]", "")
  end

  local function isMachine(id)
    local n = numeric(id)
    return n and n >= FIRST_TM and n <= LAST_HM or false
  end

  local function machineInfo(id)
    local n = numeric(id)
    if not n then return nil end
    if n >= FIRST_TM and n <= LAST_TM then
      local number = n - FIRST_TM + 1
      return "TM", number, number, n
    elseif n >= FIRST_HM and n <= LAST_HM then
      local number = n - FIRST_HM + 1
      return "HM", number, NUM_TMS + number, n
    end
    return nil
  end

  local function typeName(value)
    if value == nil then return "NORMAL" end
    if type(value) == "number" and Types.name then
      local ok, name = pcall(Types.name, value)
      if ok and name then return tostring(name):upper() end
    end
    local s = tostring(value):upper()
    if s == "FIGHT" then return "FIGHTING" end
    return s
  end

  local EFFECT_NAME = {}
  for k, v in pairs(EffectIds or {}) do
    if type(k) == "string" and type(v) == "number" and EFFECT_NAME[v] == nil then
      EFFECT_NAME[v] = k
    end
  end

  local function effectName(value)
    if value == nil then return "STANDARD DAMAGE" end
    local n = tonumber(value)
    local s = n and EFFECT_NAME[n] or tostring(value)
    if not s or s == "" or s == "HIT" or s == "0" then return "STANDARD DAMAGE" end
    s = tostring(s):gsub("_", " ")
    return s
  end

  local function moveRow(itemId)
    local moveId = Pokemon.moveFromTmItem(itemId)
    if not moveId then return nil end
    local move = Moves.get(moveId) or Pokemon.battleMove(moveId) or {}
    local name = Pokemon.moveName(moveId) or move.name or ("MOVE " .. tostring(moveId))
    local kind, number, order, numericId = machineInfo(itemId)
    if not kind then return nil end
    local cat = tostring(move.category or ((tonumber(move.power) or 0) == 0 and "status" or "physical")):upper()
    return {
      id = numericId,
      kind = kind,
      number = number,
      order = order,
      itemName = string.format("%s%02d", kind, number),
      moveId = moveId,
      moveName = name,
      type = typeName(move.type),
      category = cat,
      power = tonumber(move.power) or 0,
      accuracy = tonumber(move.accuracy) or 0,
      pp = tonumber(move.pp) or 0,
      effect = effectName(move.effect),
      chance = tonumber(move.secondaryChance) or 0,
      description = SummaryData.moveDescription(moveId, name) or ItemsData.description(numericId) or "",
    }
  end

  local machinesCache = nil
  local function discoverMachines()
    if machinesCache then return machinesCache end
    local rows = {}
    for id = FIRST_TM, LAST_HM do
      local row = moveRow(id)
      if row then rows[#rows + 1] = row end
    end
    table.sort(rows, function(a, b) return a.order < b.order end)
    machinesCache = rows
    return machinesCache
  end

  local function discoverTMs()
    local out = {}
    for _, row in ipairs(discoverMachines()) do if row.kind == "TM" then out[#out + 1] = row end end
    return out
  end

  local function discoverHMs()
    local out = {}
    for _, row in ipairs(discoverMachines()) do if row.kind == "HM" then out[#out + 1] = row end end
    return out
  end

  local function normalStock(stock)
    local out, seen = {}, {}
    for _, id in ipairs(stock or {}) do
      local n = numeric(id) or id
      local key = tostring(n)
      if not isMachine(n) and not seen[key] then
        seen[key] = true
        out[#out + 1] = n
      end
    end
    return out
  end

  local function se(id)
    pcall(function() require("src.core.game3.audio").playSe(id) end)
  end

  -- Every machine is free. Native shop selling logic therefore also rejects it,
  -- avoiding a free-money loop.
  if not ItemsData.__allTmShopGen3PricePatched then
    local previousInfo = ItemsData.info
    ItemsData.info = function(id)
      local row = previousInfo(id)
      if type(row) ~= "table" or not isMachine(id) then return row end
      local patched = copyTable(row)
      patched.price = 0
      return patched
    end
    ItemsData.__allTmShopGen3PricePatched = MOD_ID
  end

  local TYPE_ORDER = {
    "ALL", "NORMAL", "FIGHTING", "FLYING", "POISON", "GROUND", "ROCK", "BUG",
    "GHOST", "STEEL", "FIRE", "WATER", "GRASS", "ELECTRIC", "PSYCHIC", "ICE",
    "DRAGON", "DARK",
  }
  local KIND_ORDER = { "ALL", "TM", "HM" }
  local CATEGORY_ORDER = { "ALL", "PHYSICAL", "SPECIAL", "STATUS" }

  local function cycle(list, current, delta)
    local at = 1
    for i, v in ipairs(list) do if v == current then at = i break end end
    at = ((at - 1 + delta) % #list) + 1
    return list[at]
  end

  -- ==================================================================
  -- Dedicated TM/HM catalogue controller.
  -- ==================================================================
  local FreeTMShop = {}
  FreeTMShop.__index = FreeTMShop

  function FreeTMShop.new(session)
    local self = setmetatable({}, FreeTMShop)
    self.open = true
    self.session = session
    self.allRows = discoverMachines()
    self.rows = {}
    self.index = 1
    self.scroll = 0
    self.mode = "list" -- list | filters | quantity | confirm | details | message
    self.qty = 1
    self.qtyMax = 1
    self.choice = 1
    self.message = nil
    self.filterCursor = 1
    self.filters = { kind = "ALL", type = "ALL", category = "ALL" }
    self:applyFilters()
    return self
  end

  function FreeTMShop:applyFilters(preferId)
    local old = preferId or (self.rows[self.index] and self.rows[self.index].id)
    local rows = {}
    for _, row in ipairs(self.allRows or {}) do
      local f = self.filters
      if (f.kind == "ALL" or row.kind == f.kind)
          and (f.type == "ALL" or row.type == f.type)
          and (f.category == "ALL" or row.category == f.category) then
        rows[#rows + 1] = row
      end
    end
    self.rows = rows
    self.index = #rows > 0 and 1 or 0
    if old then
      for i, row in ipairs(rows) do if row.id == old then self.index = i break end end
    end
    self.scroll = 0
    self:ensureVisible()
  end

  function FreeTMShop:selected()
    return self.index > 0 and self.rows[self.index] or nil
  end

  function FreeTMShop:bag()
    if not self.session then return nil end
    if not self.session.bag then self.session.bag = Bag.new() end
    return self.session.bag
  end

  function FreeTMShop:owned(row)
    local bag = self:bag()
    if not bag or not row then return 0 end
    return tonumber(Bag.get(bag, row.id)) or 0
  end

  function FreeTMShop:ensureVisible()
    if #self.rows < 1 then self.scroll = 0 return end
    if self.index <= self.scroll then self.scroll = self.index - 1
    elseif self.index > self.scroll + VISIBLE_ROWS then self.scroll = self.index - VISIBLE_ROWS end
    self.scroll = math.max(0, math.min(self.scroll, math.max(0, #self.rows - VISIBLE_ROWS)))
  end

  function FreeTMShop:step(delta)
    local n = #self.rows
    if n < 1 then return end
    self.index = ((self.index - 1 + delta) % n) + 1
    self:ensureVisible()
    se(5)
  end

  function FreeTMShop:page(delta)
    if #self.rows < 1 then return end
    self.index = math.max(1, math.min(#self.rows, self.index + delta * VISIBLE_ROWS))
    self:ensureVisible()
    se(5)
  end

  function FreeTMShop:filterStep(delta)
    local f = self.filters
    if self.filterCursor == 1 then f.kind = cycle(KIND_ORDER, f.kind, delta)
    elseif self.filterCursor == 2 then f.type = cycle(TYPE_ORDER, f.type, delta)
    elseif self.filterCursor == 3 then f.category = cycle(CATEGORY_ORDER, f.category, delta)
    else return end
    self:applyFilters()
    se(5)
  end

  function FreeTMShop:resetFilters()
    self.filters.kind, self.filters.type, self.filters.category = "ALL", "ALL", "ALL"
    self:applyFilters()
    se(5)
  end

  function FreeTMShop:beginPurchase()
    local row = self:selected()
    if not row then
      self.message = "No machines match the active filters."
      self.mode = "message"
      se(9)
      return
    end
    local owned = self:owned(row)
    if row.kind == "HM" then
      if owned >= 1 then
        self.message = "You already have this HM."
        self.mode = "message"
        se(9)
        return
      end
      self.qty, self.qtyMax = 1, 1
    else
      if owned >= 99 then
        self.message = "You already have 99 of this TM."
        self.mode = "message"
        se(9)
        return
      end
      self.qty, self.qtyMax = 1, 99 - owned
    end
    self.choice = 1
    self.mode = "quantity"
    se(5)
  end

  function FreeTMShop:quantityStep(delta)
    local n = self.qty + delta
    if math.abs(delta) == 1 then
      if n > self.qtyMax then n = 1 end
      if n < 1 then n = self.qtyMax end
    else
      n = math.max(1, math.min(self.qtyMax, n))
    end
    self.qty = n
    se(5)
  end

  function FreeTMShop:finishPurchase()
    local row = self:selected()
    local bag = self:bag()
    if not row or not bag then self.mode = "list" return end
    if not Bag.canAdd(bag, row.id, self.qty) or not Bag.add(bag, row.id, self.qty) then
      self.message = "There is no room in your TM CASE."
      self.mode = "message"
      se(9)
      return
    end
    pcall(function()
      local Q = require("src.core.game3.quest_log_recorder")
      local Runtime = package.loaded["src.core.game3.runtime"]
      Q.event(self.session, self.qty == 1 and "BoughtItem" or "BoughtItemsIncludingItem", {
        D0 = Q.location(Runtime and Runtime._game, self.session), D1 = row.itemName, D2 = 0,
      })
    end)
    self.message = string.format("Added %s x%d to the TM CASE.", row.itemName, self.qty)
    self.mode = "message"
    se(246)
  end

  function FreeTMShop:close()
    self.open = false
    Stack.pop(STACK_ID)
    se(9)
  end

  function FreeTMShop:handleInput(input)
    if not self.open or not input then return end

    if self.mode == "message" then
      if input:wasPressed("a") or input:wasPressed("b") then
        self.message = nil; self.mode = "list"; se(5)
      end
      return
    end

    if self.mode == "filters" then
      if input:wasPressed("up") then
        self.filterCursor = ((self.filterCursor - 2) % 4) + 1; se(5)
      elseif input:wasPressed("down") then
        self.filterCursor = (self.filterCursor % 4) + 1; se(5)
      elseif input:wasPressed("left") then
        if self.filterCursor <= 3 then self:filterStep(-1) end
      elseif input:wasPressed("right") then
        if self.filterCursor <= 3 then self:filterStep(1) end
      elseif input:wasPressed("a") then
        if self.filterCursor == 4 then self:resetFilters() else self.mode = "list"; se(5) end
      elseif input:wasPressed("select") or input:wasPressed("start") or input:wasPressed("b") then
        self.mode = "list"; se(5)
      end
      return
    end

    if self.mode == "details" then
      if input:wasPressed("select") or input:wasPressed("a") or input:wasPressed("b") then
        self.mode = "list"; se(5)
      elseif input:wasPressed("up") then self:step(-1)
      elseif input:wasPressed("down") then self:step(1)
      elseif input:wasPressed("left") then self:page(-1)
      elseif input:wasPressed("right") then self:page(1)
      elseif input:wasPressed("start") then self.mode = "filters"; se(5)
      end
      return
    end

    if self.mode == "quantity" then
      if input:wasPressed("up") then self:quantityStep(1)
      elseif input:wasPressed("down") then self:quantityStep(-1)
      elseif input:wasPressed("right") then self:quantityStep(10)
      elseif input:wasPressed("left") then self:quantityStep(-10)
      elseif input:wasPressed("a") then self.choice = 1; self.mode = "confirm"; se(5)
      elseif input:wasPressed("b") then self.mode = "list"; se(9) end
      return
    end

    if self.mode == "confirm" then
      if input:wasPressed("up") or input:wasPressed("down") then
        self.choice = self.choice == 1 and 2 or 1; se(5)
      elseif input:wasPressed("b") then self.mode = "list"; se(9)
      elseif input:wasPressed("a") then
        if self.choice == 1 then self:finishPurchase() else self.mode = "list"; se(9) end
      end
      return
    end

    if input:wasPressed("up") then self:step(-1)
    elseif input:wasPressed("down") then self:step(1)
    elseif input:wasPressed("left") then self:page(-1)
    elseif input:wasPressed("right") then self:page(1)
    elseif input:wasPressed("a") then self:beginPurchase()
    elseif input:wasPressed("select") then self.mode = "details"; se(5)
    elseif input:wasPressed("start") then self.mode = "filters"; se(5)
    elseif input:wasPressed("b") then self:close() end
  end

  -- Native 240x160 fallback. The high-resolution render.hud view below covers
  -- this in normal Game3 rendering, but keeping a native fallback makes the
  -- catalogue robust if screen-space rendering is unavailable.
  local function statValue(n, dashZero, suffix)
    n = tonumber(n)
    if n == nil or (dashZero and n <= 0) then return "---" end
    return tostring(math.floor(n)) .. (suffix or "")
  end

  local function drawNativeStats(row, x, y)
    if not row then return end
    local ok = pcall(SummaryChrome.drawTypeBadge, row.type, x, y)
    if not ok then FrlgFont.draw(row.type, x, y, { colors = FrlgFont.COLOR.NORMAL }) end
    FrlgFont.draw(row.category, x, y + 16, { maxWidth = 72, colors = FrlgFont.COLOR.NORMAL })
    FrlgFont.draw("POW " .. statValue(row.power, true), x, y + 31, { colors = FrlgFont.COLOR.DARK_GRAY })
    FrlgFont.draw("ACC " .. statValue(row.accuracy, true, "%"), x, y + 45, { colors = FrlgFont.COLOR.DARK_GRAY })
    FrlgFont.draw("PP  " .. statValue(row.pp, false), x, y + 59, { colors = FrlgFont.COLOR.DARK_GRAY })
  end

  function FreeTMShop:draw()
    if not self.open then return end
    love.graphics.setColor(0.07, 0.28, 0.56, 1)
    love.graphics.rectangle("fill", 0, 0, 240, 160)
    love.graphics.setColor(1, 1, 1, 1)
    Window.stdFrame(Window.template(1, 1, 16, 17))
    Window.stdFrame(Window.template(18, 1, 11, 17))
    FrlgFont.draw("TM/HM SHOP", 12, 9, { colors = FrlgFont.COLOR.NORMAL })
    FrlgFont.draw(string.format("%d/%d", #self.rows, #self.allRows), 113, 9, { colors = FrlgFont.COLOR.DARK_GRAY })
    for vis = 1, 7 do
      local idx = self.scroll + vis
      local r = self.rows[idx]
      if not r then break end
      local y = 27 + (vis - 1) * 17
      if idx == self.index and self.mode ~= "filters" then Window.cursorPx(10, y) end
      FrlgFont.draw(r.itemName, 20, y, { colors = FrlgFont.COLOR.DARK_GRAY })
      FrlgFont.draw(r.moveName, 54, y, { maxWidth = 73, colors = FrlgFont.COLOR.NORMAL })
    end
    local row = self:selected()
    if row then
      FrlgFont.draw(row.moveName, 150, 12, { maxWidth = 76, colors = FrlgFont.COLOR.NORMAL })
      drawNativeStats(row, 150, 34)
      FrlgFont.draw("OWN " .. tostring(self:owned(row)), 150, 111, { colors = FrlgFont.COLOR.DARK_GRAY })
    end
    FrlgFont.draw("START FILTER", 150, 134, { colors = FrlgFont.COLOR.DARK_GRAY })
    if self.mode == "filters" then
      Window.stdFrame(Window.template(4, 4, 22, 11))
      local vals = {
        "MACHINE  " .. self.filters.kind,
        "TYPE     " .. self.filters.type,
        "CLASS    " .. self.filters.category,
        "RESET FILTERS",
      }
      for i, s in ipairs(vals) do
        local y = 39 + (i - 1) * 20
        if i == self.filterCursor then Window.cursorPx(38, y) end
        FrlgFont.draw(s, 48, y, { maxWidth = 150, colors = FrlgFont.COLOR.NORMAL })
      end
    end
  end

  local activeCatalogue = nil

  -- Game3 Stack calls menu callbacks with dot syntax.
  local CatalogueLayer = {}
  function CatalogueLayer.handleInput(input)
    local child = activeCatalogue
    if child and child.open then
      child:handleInput(input)
      if not child.open then activeCatalogue = nil end
    end
  end
  function CatalogueLayer.draw()
    local child = activeCatalogue
    if child and child.open then return child:draw() end
  end
  function CatalogueLayer.update(dt)
    local child = activeCatalogue
    if child and child.open and child.update then child:update(dt) end
  end
  function CatalogueLayer.isOpen()
    return activeCatalogue ~= nil and activeCatalogue.open == true
  end

  local function openCatalogue()
    activeCatalogue = FreeTMShop.new(ShopMenu._session)
    Stack.push(STACK_ID, CatalogueLayer, { hideBelow = true })
    se(5)
    return activeCatalogue
  end

  -- ==================================================================
  -- High-resolution Modern-UI-style renderer.
  -- This intentionally uses a unique stack id, so gen3_modern_ui does not
  -- compress the catalogue through its generic Poké Mart presenter.
  -- ==================================================================
  local fonts = {}
  local function font(size)
    size = math.max(12, math.floor(size + 0.5))
    local key = tostring(size)
    if fonts[key] then return fonts[key] end
    local ok, f = pcall(love.graphics.newFont, size)
    if not ok or not f then f = love.graphics.getFont() end
    if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    fonts[key] = f
    return f
  end

  local C = {
    bg = {0.075, 0.285, 0.565, 0.985}, header = {0.090, 0.330, 0.650, 1},
    surface = {0.975, 0.990, 1.000, 1}, raised = {1.000, 0.965, 0.745, 1},
    selected = {1.000, 0.820, 0.250, 1}, red = {0.900, 0.175, 0.175, 1},
    yellow = {1.000, 0.790, 0.030, 1}, text = {0.055, 0.180, 0.315, 1},
    muted = {0.285, 0.405, 0.510, 1}, divider = {0.510, 0.720, 0.900, 1},
    footer = {0.045, 0.145, 0.270, 1}, white = {1,1,1,1}, green = {0.18,0.69,0.305,1},
  }

  local TYPE_COLORS = {
    NORMAL={0.64,0.62,0.47,1}, FIGHTING={0.75,0.16,0.12,1}, FLYING={0.49,0.62,0.91,1},
    POISON={0.59,0.27,0.65,1}, GROUND={0.78,0.62,0.29,1}, ROCK={0.65,0.56,0.22,1},
    BUG={0.59,0.68,0.10,1}, GHOST={0.42,0.34,0.65,1}, STEEL={0.58,0.61,0.68,1},
    FIRE={0.91,0.32,0.17,1}, WATER={0.22,0.48,0.86,1}, GRASS={0.29,0.68,0.25,1},
    ELECTRIC={0.94,0.75,0.08,1}, PSYCHIC={0.90,0.30,0.52,1}, ICE={0.43,0.78,0.84,1},
    DRAGON={0.42,0.20,0.89,1}, DARK={0.34,0.28,0.24,1},
  }

  local function setColor(c, a)
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * (a or 1))
  end
  local function rr(mode, x, y, w, h, r)
    love.graphics.rectangle(mode, x, y, w, h, r, r)
  end
  local function txt(value, x, y, size, color, align, width)
    love.graphics.setFont(font(size))
    setColor(color or C.text)
    if width then love.graphics.printf(tostring(value or ""), x, y, width, align or "left")
    else love.graphics.print(tostring(value or ""), x, y) end
  end
  local function panel(x, y, w, h, raised)
    setColor(raised and C.raised or C.surface)
    rr("fill", x, y, w, h, math.min(10, h * 0.08))
    setColor(C.divider, 0.55)
    love.graphics.setLineWidth(1)
    rr("line", x, y, w, h, math.min(10, h * 0.08))
  end
  local function line(x1,y1,x2,y2)
    setColor(C.divider,0.65); love.graphics.setLineWidth(1); love.graphics.line(x1,y1,x2,y2)
  end

  local function layout(viewport)
    local x = tonumber(viewport.gameX) or 0
    local y = tonumber(viewport.gameY) or 0
    local w = tonumber(viewport.gameWidth) or love.graphics.getWidth()
    local h = tonumber(viewport.gameHeight) or love.graphics.getHeight()
    local s = math.max(0.64, math.min(w / 720, h / 480))
    local pad = math.max(9, 13 * s)
    local headerH = math.max(46, 52 * s)
    local footerH = math.max(29, 32 * s)
    return {x=x,y=y,w=w,h=h,s=s,pad=pad,gap=math.max(7,9*s),headerH=headerH,footerH=footerH,
      title=math.max(21,24*s),body=math.max(15,17*s),small=math.max(13,14*s),tiny=math.max(12,12*s)}
  end

  local function typeIconShape(kind, x, y, sz)
    setColor(C.white)
    local k = tostring(kind or "NORMAL")
    local cx, cy = x + sz/2, y + sz/2
    love.graphics.setLineWidth(math.max(1, sz*0.08))
    if k == "FIRE" then
      love.graphics.polygon("fill", cx, y+sz*0.12, x+sz*0.72, y+sz*0.55, cx, y+sz*0.88, x+sz*0.30, y+sz*0.58)
    elseif k == "WATER" then
      love.graphics.polygon("fill", cx, y+sz*0.10, x+sz*0.72, y+sz*0.57, cx, y+sz*0.88, x+sz*0.28, y+sz*0.57)
    elseif k == "ELECTRIC" then
      love.graphics.polygon("fill", x+sz*0.57,y+sz*0.08, x+sz*0.28,y+sz*0.53, x+sz*0.50,y+sz*0.53, x+sz*0.38,y+sz*0.92, x+sz*0.75,y+sz*0.42, x+sz*0.53,y+sz*0.42)
    elseif k == "GRASS" then
      love.graphics.ellipse("fill", cx, cy, sz*0.23, sz*0.35, 20)
      setColor(TYPE_COLORS.GRASS); love.graphics.line(cx-sz*0.08,cy+sz*0.20,cx+sz*0.11,cy-sz*0.18)
    elseif k == "ICE" then
      for a=0,2 do local ang=a*math.pi/3; love.graphics.line(cx-math.cos(ang)*sz*.30,cy-math.sin(ang)*sz*.30,cx+math.cos(ang)*sz*.30,cy+math.sin(ang)*sz*.30) end
    elseif k == "POISON" then
      love.graphics.circle("fill",cx,cy-sz*.08,sz*.20); love.graphics.circle("fill",x+sz*.32,y+sz*.70,sz*.08); love.graphics.circle("fill",x+sz*.66,y+sz*.72,sz*.07)
    elseif k == "GROUND" or k == "ROCK" then
      love.graphics.polygon("fill",x+sz*.17,y+sz*.75,x+sz*.42,y+sz*.30,x+sz*.56,y+sz*.52,x+sz*.72,y+sz*.22,x+sz*.88,y+sz*.75)
    elseif k == "FLYING" then
      love.graphics.arc("line","open",cx,cy,sz*.30,math.pi*1.05,math.pi*1.90,20); love.graphics.arc("line","open",cx+sz*.12,cy+sz*.08,sz*.20,math.pi*1.05,math.pi*1.90,20)
    elseif k == "BUG" then
      love.graphics.circle("fill",cx,cy+sz*.08,sz*.20); love.graphics.circle("fill",cx,cy-sz*.20,sz*.12); love.graphics.line(cx-sz*.18,cy,x+sz*.16,cy-sz*.10); love.graphics.line(cx+sz*.18,cy,x+sz*.84,cy-sz*.10)
    elseif k == "GHOST" then
      love.graphics.arc("fill","closed",cx,cy,sz*.28,math.pi,math.pi*2,20); love.graphics.rectangle("fill",cx-sz*.28,cy,sz*.56,sz*.24)
      setColor(TYPE_COLORS.GHOST); love.graphics.circle("fill",cx-sz*.09,cy-sz*.02,sz*.04); love.graphics.circle("fill",cx+sz*.09,cy-sz*.02,sz*.04)
    elseif k == "STEEL" then
      love.graphics.polygon("fill",cx,y+sz*.16,x+sz*.78,y+sz*.32,x+sz*.78,y+sz*.68,cx,y+sz*.84,x+sz*.22,y+sz*.68,x+sz*.22,y+sz*.32); setColor(TYPE_COLORS.STEEL); love.graphics.circle("fill",cx,cy,sz*.12)
    elseif k == "PSYCHIC" then
      love.graphics.circle("line",cx,cy,sz*.27); love.graphics.circle("line",cx,cy,sz*.14); love.graphics.circle("fill",cx,cy,sz*.04)
    elseif k == "DRAGON" then
      love.graphics.polygon("fill",cx,y+sz*.12,x+sz*.77,cy,x+sz*.55,y+sz*.88,x+sz*.35,y+sz*.62,x+sz*.22,cy)
    elseif k == "DARK" then
      love.graphics.circle("fill",cx,cy,sz*.29); setColor(TYPE_COLORS.DARK); love.graphics.circle("fill",cx+sz*.12,cy-sz*.06,sz*.24)
    elseif k == "FIGHTING" then
      love.graphics.rectangle("fill",x+sz*.24,y+sz*.34,sz*.52,sz*.42,sz*.08,sz*.08); love.graphics.rectangle("fill",x+sz*.34,y+sz*.18,sz*.12,sz*.26)
    else
      love.graphics.circle("line",cx,cy,sz*.27); love.graphics.circle("fill",cx,cy,sz*.08)
    end
  end

  local function typeBadge(rowType, x, y, w, h, showText)
    local c = TYPE_COLORS[rowType] or C.muted
    setColor(c); rr("fill",x,y,w,h,h/2)
    local iconSz = math.min(h*0.72, w*0.25)
    typeIconShape(rowType, x+h*0.14, y+(h-iconSz)/2, iconSz)
    if showText ~= false then txt(rowType, x+h*0.95, y+h*0.19, math.max(11,h*0.43), C.white,"left",w-h*1.05) end
  end

  local function categoryIcon(category, x, y, sz, color)
    setColor(color or C.text)
    local cx,cy=x+sz/2,y+sz/2
    love.graphics.setLineWidth(math.max(1,sz*.07))
    if category == "PHYSICAL" then
      love.graphics.line(cx-sz*.28,cy,cx+sz*.28,cy); love.graphics.line(cx,cy-sz*.28,cx,cy+sz*.28); love.graphics.line(cx-sz*.20,cy-sz*.20,cx+sz*.20,cy+sz*.20); love.graphics.line(cx+sz*.20,cy-sz*.20,cx-sz*.20,cy+sz*.20)
    elseif category == "SPECIAL" then
      love.graphics.circle("line",cx,cy,sz*.27); love.graphics.circle("fill",cx,cy,sz*.08)
    else
      rr("line",x+sz*.22,y+sz*.22,sz*.56,sz*.56,sz*.12); love.graphics.line(cx-sz*.14,cy,cx+sz*.14,cy); love.graphics.line(cx,cy-sz*.14,cx,cy+sz*.14)
    end
  end

  local function chip(label, value, x, y, w, h, active)
    setColor(active and C.raised or C.surface)
    rr("fill",x,y,w,h,h/2)
    setColor(active and C.red or C.divider, active and 0.85 or 0.55)
    rr("line",x,y,w,h,h/2)
    txt(label .. "  " .. value, x+h*.35, y+h*.20, math.max(11,h*.42), active and C.text or C.muted,"left",w-h*.6)
  end

  local function statCard(label, value, x, y, w, h)
    setColor(C.raised); rr("fill",x,y,w,h,math.min(8,h*.18))
    txt(label,x+w*.08,y+h*.16,math.max(11,h*.25),C.muted,"left",w*.84)
    txt(value,x+w*.08,y+h*.44,math.max(15,h*.36),C.text,"left",w*.84)
  end

  local function drawFilterModal(ui, L)
    local f = ui.filters
    setColor({0,0,0,1},0.55); love.graphics.rectangle("fill",L.x,L.y,L.w,L.h)
    local w = math.min(L.w*.62, 480*L.s); local h = math.min(L.h*.62, 300*L.s)
    local x=L.x+(L.w-w)/2; local y=L.y+(L.h-h)/2
    panel(x,y,w,h,false)
    txt("FILTERS",x+L.pad,y+L.pad,L.title*.82,C.text)
    txt("← / → changes the selected filter",x+L.pad,y+L.pad+L.title*.90,L.small,C.muted)
    local rows={
      {"MACHINE",f.kind},{"TYPE",f.type},{"CATEGORY",f.category},{"RESET","CLEAR ALL"},
    }
    local rowY=y+L.pad+L.title*2.05; local rh=(h-(rowY-y)-L.pad)/4
    for i,r in ipairs(rows) do
      local yy=rowY+(i-1)*rh
      if i==ui.filterCursor then setColor(C.selected,0.78); rr("fill",x+L.pad,yy,w-L.pad*2,rh-4,7); setColor(C.red); love.graphics.rectangle("fill",x+L.pad,yy,4,rh-4) end
      txt(r[1],x+L.pad*1.7,yy+rh*.23,L.body,C.text)
      txt(r[2],x+w*.48,yy+rh*.26,L.small,i==ui.filterCursor and C.text or C.muted,"right",w*.42-L.pad)
    end
  end

  local function drawModal(ui, L, title, message, rows, cursor)
    setColor({0,0,0,1},0.50); love.graphics.rectangle("fill",L.x,L.y,L.w,L.h)
    local w=math.min(L.w*.55,430*L.s); local h=math.min(L.h*.50,230*L.s)
    local x=L.x+(L.w-w)/2; local y=L.y+(L.h-h)/2
    panel(x,y,w,h,false)
    txt(title,x+L.pad,y+L.pad,L.title*.78,C.text)
    if message then txt(message,x+L.pad,y+L.pad+L.title,L.small,C.muted,"left",w-L.pad*2) end
    if rows then
      local yy=y+h-L.pad-(#rows*math.max(34,L.body*2.15)); local rh=math.max(34,L.body*2.15)
      for i,r in ipairs(rows) do
        local ry=yy+(i-1)*rh
        if i==cursor then setColor(C.selected,0.82); rr("fill",x+L.pad,ry,w-L.pad*2,rh-4,7) end
        txt(r,x+L.pad*1.6,ry+rh*.22,L.body,C.text)
      end
    end
  end

  local function drawModernCatalogue(viewport)
    local ui=activeCatalogue
    if not (ui and ui.open and love and love.graphics and viewport) then return end
    local top=Stack.top and Stack.top() or nil
    if not (top and top.id==STACK_ID) then return end
    local L=layout(viewport)
    love.graphics.push("all")
    love.graphics.setScissor(L.x,L.y,L.w,L.h)
    setColor(C.bg); love.graphics.rectangle("fill",L.x,L.y,L.w,L.h)
    setColor(C.header); love.graphics.rectangle("fill",L.x,L.y,L.w,L.headerH)
    setColor(C.red); love.graphics.rectangle("fill",L.x,L.y,L.w,math.max(3,4*L.s))
    setColor(C.yellow); love.graphics.rectangle("fill",L.x,L.y+L.headerH-math.max(2,3*L.s),L.w,math.max(2,3*L.s))
    txt("TM / HM SHOP",L.x+L.pad,L.y+L.pad*.55,L.title,C.white)
    txt(string.format("%d / %d MACHINES  •  FREE",#ui.rows,#ui.allRows),L.x+L.w*.52,L.y+L.pad*.72,L.small,C.yellow,"right",L.w*.48-L.pad)

    local filterY=L.y+L.headerH+L.gap*.70
    local chipH=math.max(26,29*L.s); local available=L.w-L.pad*2; local chipGap=L.gap*.55
    local chipW=(available-chipGap*3)/4
    chip("MACHINE",ui.filters.kind,L.x+L.pad,filterY,chipW,chipH,ui.filters.kind~="ALL")
    chip("TYPE",ui.filters.type,L.x+L.pad+(chipW+chipGap),filterY,chipW,chipH,ui.filters.type~="ALL")
    chip("CLASS",ui.filters.category,L.x+L.pad+2*(chipW+chipGap),filterY,chipW,chipH,ui.filters.category~="ALL")
    chip("START","FILTERS",L.x+L.pad+3*(chipW+chipGap),filterY,chipW,chipH,false)

    local contentY=filterY+chipH+L.gap*.70
    local footerH=L.footerH
    local contentH=L.y+L.h-footerH-L.gap-contentY
    local leftW=L.w*.54-L.pad-L.gap*.5
    local rightX=L.x+L.pad+leftW+L.gap
    local rightW=L.x+L.w-L.pad-rightX
    panel(L.x+L.pad,contentY,leftW,contentH,false)
    panel(rightX,contentY,rightW,contentH,false)

    -- list
    local listX=L.x+L.pad+L.gap; local listW=leftW-L.gap*2
    local rowH=contentH/VISIBLE_ROWS
    if #ui.rows==0 then
      txt("NO RESULTS",listX,contentY+contentH*.36,L.title*.85,C.muted,"center",listW)
      txt("Change or reset the filters.",listX,contentY+contentH*.52,L.small,C.muted,"center",listW)
    else
      for vis=1,VISIBLE_ROWS do
        local idx=ui.scroll+vis; local row=ui.rows[idx]; if not row then break end
        local yy=contentY+(vis-1)*rowH
        if idx==ui.index and ui.mode~="filters" then
          setColor(C.selected,0.78); rr("fill",L.x+L.pad+4,yy+3,leftW-8,rowH-6,7)
          setColor(C.red); love.graphics.rectangle("fill",L.x+L.pad+4,yy+3,4,rowH-6)
        elseif vis>1 then line(listX,yy,listX+listW,yy) end
        local labelW=math.max(48,58*L.s)
        txt(row.itemName,listX+5,yy+rowH*.25,L.small,C.muted,"left",labelW)
        txt(row.moveName,listX+labelW,yy+rowH*.20,L.body,C.text,"left",listW-labelW-115*L.s)
        local badgeW=math.max(72,82*L.s); local badgeH=math.max(20,22*L.s)
        typeBadge(row.type,listX+listW-badgeW-4,yy+(rowH-badgeH)/2,badgeW,badgeH,true)
      end
    end

    -- detail pane
    local row=ui:selected(); local dx=rightX+L.gap; local dw=rightW-L.gap*2
    if row then
      txt(row.moveName,dx,contentY+L.gap,L.title*.82,C.text,"left",dw)
      txt(row.itemName .. "   •   OWNED ×" .. tostring(ui:owned(row)),dx,contentY+L.gap+L.title*.90,L.small,C.muted,"left",dw)
      local badgeY=contentY+L.gap+L.title*1.75; local badgeH=math.max(34,38*L.s)
      typeBadge(row.type,dx,badgeY,dw*.58,badgeH,true)
      local catX=dx+dw*.62; local iconSz=badgeH*.70
      categoryIcon(row.category,catX,badgeY+(badgeH-iconSz)/2,iconSz,C.text)
      txt(row.category,catX+iconSz+6,badgeY+badgeH*.25,L.small,C.text,"left",dw*.38-iconSz-6)

      local statsY=badgeY+badgeH+L.gap*.8; local statGap=L.gap*.55; local sw=(dw-statGap*2)/3; local sh=math.max(52,57*L.s)
      statCard("POWER",row.power>0 and tostring(row.power) or "---",dx,statsY,sw,sh)
      statCard("ACCURACY",row.accuracy>0 and (tostring(row.accuracy).."%") or "---",dx+sw+statGap,statsY,sw,sh)
      statCard("PP",tostring(row.pp),dx+(sw+statGap)*2,statsY,sw,sh)

      local descY=statsY+sh+L.gap*.9
      txt("MOVE DESCRIPTION",dx,descY,L.tiny,C.muted)
      local desc=row.description; if not desc or desc=="" or desc=="---" then desc="No description available." end
      txt(desc,dx,descY+L.tiny*1.45,L.small,C.text,"left",dw)
      local effY=contentY+contentH-math.max(62,70*L.s)
      line(dx,effY-L.gap*.45,dx+dw,effY-L.gap*.45)
      txt("EFFECT",dx,effY,L.tiny,C.muted)
      txt(row.effect,dx,effY+L.tiny*1.35,L.small,C.text,"left",dw*.72)
      local chance=row.chance>0 and (tostring(row.chance).."%") or "—"
      txt("CHANCE  "..chance,dx+dw*.72,effY+L.tiny*1.35,L.small,C.muted,"right",dw*.28)
    else
      txt("NO MOVE SELECTED",dx,contentY+contentH*.42,L.body,C.muted,"center",dw)
    end

    -- footer
    local fy=L.y+L.h-footerH
    setColor(C.footer); love.graphics.rectangle("fill",L.x,fy,L.w,footerH)
    setColor(C.yellow); love.graphics.rectangle("fill",L.x,fy,L.w,math.max(2,3*L.s))
    local hint="↑↓ SELECT   ←→ PAGE   A TAKE   SELECT DETAILS   START FILTERS   B BACK"
    if ui.mode=="details" then hint="↑↓ MOVE   ←→ PAGE   SELECT / A / B BACK   START FILTERS"
    elseif ui.mode=="filters" then hint="↑↓ FILTER   ←→ CHANGE   A APPLY / RESET   B CLOSE"
    elseif ui.mode=="quantity" then hint="↑↓ ±1   ←→ ±10   A CONFIRM   B CANCEL"
    elseif ui.mode=="confirm" then hint="↑↓ YES / NO   A CONFIRM   B CANCEL" end
    txt(hint,L.x+L.pad,fy+footerH*.30,L.tiny,C.white,"left",L.w-L.pad*2)

    if ui.mode=="filters" then drawFilterModal(ui,L)
    elseif ui.mode=="quantity" and row then
      drawModal(ui,L,"QUANTITY",string.format("%s — %s\nFREE • OWNED ×%d",row.itemName,row.moveName,ui:owned(row)),{"×"..tostring(ui.qty).." / "..tostring(ui.qtyMax)},1)
    elseif ui.mode=="confirm" and row then
      drawModal(ui,L,"CONFIRM",string.format("Take %s ×%d for FREE?",row.itemName,ui.qty),{"YES","NO"},ui.choice)
    elseif ui.mode=="message" and ui.message then drawModal(ui,L,"TM / HM SHOP",ui.message,{"OK"},1)
    elseif ui.mode=="details" and row then
      -- Details mode deliberately keeps the full two-pane layout; the selected
      -- move remains visible while the footer changes to navigation controls.
    end

    love.graphics.setScissor(); love.graphics.pop()
  end

  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    local ok, err = pcall(drawModernCatalogue, viewport)
    if not ok and mod.log and mod.log.warn then mod.log:warn("[%s] TM/HM renderer failed: %s",MOD_ID,tostring(err)) end
    return result
  end)

  -- ------------------------------------------------------------------
  -- Add one composable TM/HM SHOP row. Equivalent rows suppress ours.
  -- ------------------------------------------------------------------
  local function hasEquivalentRoot()
    for _, row in ipairs(ShopMenu.ROOT or {}) do
      local id=normalized(row and row.id); local label=normalized(row and row.label)
      if id==normalized(ROOT_ID) or label=="TMHMSHOP"
          or (label:find("TM",1,true) and label:find("HM",1,true) and label:find("SHOP",1,true)) then return true end
    end
    return false
  end

  local ownsRoot=false
  if not hasEquivalentRoot() then
    ShopMenu.ROOT=ShopMenu.ROOT or {}
    local insertAt=#ShopMenu.ROOT+1
    for i,row in ipairs(ShopMenu.ROOT) do if row and row.id=="quit" then insertAt=i break end end
    table.insert(ShopMenu.ROOT,insertAt,{id=ROOT_ID,label="TM/HM SHOP"})
    ownsRoot=true
  else
    mod.log:info("An equivalent TM/HM SHOP entry is already present; duplicate row suppressed")
  end

  if not ShopMenu.__allTmShopGen3ShowPatched then
    local previousShow=ShopMenu.show
    ShopMenu.show=function(opts)
      opts=opts or {}; local patched=copyTable(opts); patched.items=normalStock(opts.items or {})
      return previousShow(patched)
    end
    ShopMenu.__allTmShopGen3ShowPatched=MOD_ID
  end

  if ownsRoot and not ShopMenu.__allTmShopGen3InputPatched then
    local previousHandleInput=ShopMenu.handleInput
    ShopMenu.handleInput=function(input)
      if ShopMenu.open and ShopMenu.mode=="root" and input then
        local row=(ShopMenu.ROOT or {})[ShopMenu.cursor or 1]
        if row and row.id==ROOT_ID and input:wasPressed("a") then openCatalogue(); return end
      end
      return previousHandleInput(input)
    end
    ShopMenu.__allTmShopGen3InputPatched=MOD_ID
  end

  -- Native root frame grows with extra menu entries. Modern UI can still cover it.
  if ownsRoot and not ShopMenu.__allTmShopGen3DrawPatched then
    local previousDraw=ShopMenu.draw
    ShopMenu.draw=function()
      if not (ShopMenu.open and ShopMenu.mode=="root") then return previousDraw() end
      local rows=ShopMenu.ROOT or {}; local contentH=math.max(6,#rows*2)
      Window.stdFrame(Window.template(2,1,17,contentH))
      for i,row in ipairs(rows) do
        local yPx=10+(i-1)*16
        if i==ShopMenu.cursor then Window.cursorPx(20,yPx) end
        Window.printPx((row and (row.label or row.id)) or "?",28,yPx)
      end
      Window.dialogueFrame()
      if ShopMenu._status then
        local lines={}; for lineText in tostring(ShopMenu._status):gmatch("[^\r\n]+") do lines[#lines+1]=lineText end
        if #lines>0 then Window.print(lines[1],2,15,{clipTiles=26}) end
        if #lines>1 then Window.print(lines[2],2,17,{clipTiles=26}) end
      end
    end
    ShopMenu.__allTmShopGen3DrawPatched=MOD_ID
  end

  mod.exports=mod.exports or {}
  mod.exports.version=VERSION
  mod.exports.generation=3
  mod.exports.supportedGames={"firered"}
  mod.exports.machineInfo=machineInfo
  mod.exports.listMachines=function() return copyList(discoverMachines()) end
  mod.exports.listTMs=function() return copyList(discoverTMs()) end
  mod.exports.listHMs=function() return copyList(discoverHMs()) end
  mod.exports.normalStock=normalStock
  mod.exports.machineCount=NUM_MACHINES
  mod.exports.tmCount=NUM_TMS
  mod.exports.hmCount=NUM_HMS
  mod.exports.FreeTMShop=FreeTMShop
  mod.exports.CatalogueLayer=CatalogueLayer
  mod.exports.openCatalogue=openCatalogue

  mod.log:info("Gen3 free TM/HM shop v1.1.4 installed: modern details + type icons + filters")
end
