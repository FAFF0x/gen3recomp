# v1.1.4 static contract

- Manifest id: `all_tm_shop_gen3`
- Version: `1.1.4`
- Game target: `firered` only
- 50 TMs + 8 HMs
- Unique stack id: `all_tm_shop_gen3_catalogue`
- Game3 dot-syntax CatalogueLayer adapter
- render.hud specialized catalogue renderer
- Filters: machine / type / category
- Type badges + vector type icons
- Move details: type/category/power/accuracy/PP/description/effect/chance
- Normal Mart stock keeps non-machine items
- Equivalent root entries suppress duplicates
