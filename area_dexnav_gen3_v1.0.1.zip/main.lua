-- Area DexNav Gen 3 / FireRed
-- Press SELECT in the overworld to immediately encounter an uncaught species
-- from the current map's real FireRed LAND/WATER encounter table.
--
-- This is intentionally the simple Area DexNav behavior from the Gen 2 mod,
-- not the full ORAS-style Gen3 DexNav. It uses the Game3 runtime and public
-- encounter registry, with guarded access to FireRed internals for player
-- surf state, Pokedex checks and field UI messages.

return function(mod)
  if mod.generation and mod.generation ~= 3 then return end

  local MOD_ID = "area_dexnav_gen3"
  local LAND_WEIGHTS = { 20, 20, 10, 10, 10, 10, 5, 5, 4, 4, 1, 1 }
  local WATER_WEIGHTS = { 60, 30, 5, 4, 1 }

  local cache = {}
  local function tryRequire(name)
    if cache[name] ~= nil then return cache[name] or nil end
    local ok, value = pcall(require, name)
    cache[name] = ok and value or false
    return ok and value or nil
  end

  local function Runtime() return tryRequire("src.core.game3.runtime") end
  local function Player() return tryRequire("src.core.game3.player") end
  local function Pokemon() return tryRequire("src.core.game3.pokemon") end
  local function Dex() return tryRequire("src.core.game3.dex") end
  local function Hud() return tryRequire("src.ui.game3.hud") end
  local function Field() return tryRequire("src.core.game3.field") end
  local function Battle() return tryRequire("src.core.game3.battle") or tryRequire("src.core.game3.battle.init") end
  local function Rng() return tryRequire("src.core.game3.rng") end

  local function session()
    local rt = Runtime()
    if rt and rt.getSession then
      local ok, s = pcall(rt.getSession)
      if ok then return s end
    end
    return nil
  end

  local function speciesId(ref)
    if type(ref) == "number" then return ref end
    if type(ref) ~= "string" then return nil end
    local n = tonumber(ref)
    if n then return n end
    local p = Pokemon()
    if p and p.speciesFromName then
      local ok, id = pcall(p.speciesFromName, ref)
      if ok then return tonumber(id) end
    end
    return nil
  end

  local function currentMapId()
    local world = mod.world
    if world and world.current then
      local ok, current = pcall(world.current, world)
      if ok and type(current) == "table" then return current.mapId end
    end
    local map = tryRequire("src.core.game3.map")
    return map and map.current or nil
  end

  local function encounterRecord(mapId)
    local registry = mod.content and mod.content.encounters
    if not (registry and registry.get and mapId) then return nil end
    local ok, row = pcall(registry.get, registry, mapId)
    if ok and type(row) == "table" then return row end
    return nil
  end

  local function currentTerrain()
    local p = Player()
    return (p and p.surfing) and "water" or "land"
  end

  local function isCaught(s, species)
    if not (s and s.dex and species) then return false end
    local d = Dex()
    if d and d.isCaught then
      local ok, caught = pcall(d.isCaught, s.dex, species)
      if ok then return caught == true end
    end
    local side = s.dex.caught or s.dex.owned
    return type(side) == "table" and side[species] == true or false
  end

  local function areaFor(record, terrain)
    if type(record) ~= "table" then return nil end
    if terrain == "water" then return record.water end
    return record.land or record.grass
  end

  local function slotsFor(area)
    if type(area) ~= "table" then return nil end
    return area.slots or area.mons or (#area > 0 and area) or nil
  end

  local function randomZero(maxExclusive, rng)
    maxExclusive = math.floor(tonumber(maxExclusive) or 0)
    if maxExclusive <= 0 then return 0 end
    if rng then
      local ok, value = pcall(rng, maxExclusive)
      if ok and type(value) == "number" then
        value = math.floor(value)
        if value < 0 then value = 0 end
        if value >= maxExclusive then value = maxExclusive - 1 end
        return value
      end
    end
    local r = Rng()
    if r and r.Random then
      local ok, value = pcall(r.Random)
      if ok and type(value) == "number" then return value % maxExclusive end
    end
    return math.random(0, maxExclusive - 1)
  end

  local function randomLevel(slot, rng)
    local lo = tonumber(slot and (slot.minLevel or slot.min or slot.level)) or 1
    local hi = tonumber(slot and (slot.maxLevel or slot.max or slot.level)) or lo
    lo, hi = math.floor(lo), math.floor(hi)
    if lo < 1 then lo = 1 end
    if hi < lo then hi = lo end
    if hi > 100 then hi = 100 end
    return lo + randomZero(hi - lo + 1, rng)
  end

  local function candidates(_game, terrainOverride)
    local s = session()
    local mapId = currentMapId()
    local terrain = terrainOverride or currentTerrain()
    local record = encounterRecord(mapId)
    local area = areaFor(record, terrain)
    local slots = slotsFor(area)
    local rate = tonumber(area and area.rate) or 0

    if not mapId or not area or not slots or rate <= 0 then
      return {}, terrain, mapId, "no_encounters"
    end

    local weights = terrain == "water" and WATER_WEIGHTS or LAND_WEIGHTS
    local rows = {}
    local hadValid = false

    for i, weight in ipairs(weights) do
      local slot = slots[i]
      if type(slot) == "table" then
        local sp = speciesId(slot.species or slot[1])
        local lo = tonumber(slot.minLevel or slot.min or slot.level)
        local hi = tonumber(slot.maxLevel or slot.max or slot.level or lo)
        if sp and lo and hi and weight > 0 then
          hadValid = true
          if not isCaught(s, sp) then
            rows[#rows + 1] = {
              species = sp,
              minLevel = math.max(1, math.floor(lo)),
              maxLevel = math.max(1, math.floor(hi)),
              weight = weight,
              slot = i,
              terrain = terrain,
            }
          end
        end
      end
    end

    if #rows == 0 then
      return rows, terrain, mapId, hadValid and "complete" or "no_encounters"
    end
    return rows, terrain, mapId, nil
  end

  local function pickTarget(game, rng, terrainOverride)
    local rows, terrain, mapId, reason = candidates(game, terrainOverride)
    if #rows == 0 then return nil, reason, terrain, mapId end

    local total = 0
    for _, row in ipairs(rows) do total = total + row.weight end
    if total <= 0 then return nil, "no_encounters", terrain, mapId end

    local roll = randomZero(total, rng) + 1
    local chosen = rows[#rows]
    for _, row in ipairs(rows) do
      roll = roll - row.weight
      if roll <= 0 then chosen = row break end
    end

    return {
      species = chosen.species,
      level = randomLevel(chosen, rng),
      source = chosen.terrain,
      slot = chosen.slot,
    }, nil, terrain, mapId
  end

  local function hasUsableParty(s)
    for _, mon in ipairs(s and s.party or {}) do
      if not mon.isEgg and (tonumber(mon.hp) or 0) > 0 then return true end
    end
    return false
  end

  local function say(game, text)
    local hud = Hud()
    if hud and hud.openMessage and game then
      local ok = pcall(hud.openMessage, game, text)
      if ok then return end
    end
    if game and type(game.say) == "function" then pcall(game.say, game, text) end
  end

  local function fieldReady(game)
    if not game or game.phase ~= "field" then return false end
    if not session() then return false end
    local battle = Battle()
    if battle and battle.isActive and battle.isActive() then return false end
    local field = Field()
    if field and field.locked then return false end
    local hud = Hud()
    if hud and hud.busy then
      local ok, busy = pcall(hud.busy)
      if ok and busy then return false end
    end
    return currentMapId() ~= nil
  end

  local function activate(game)
    if not fieldReady(game) then return false end
    local s = session()
    if not hasUsableParty(s) then
      say(game, "Your party cannot\nbattle.")
      return true
    end

    local target, reason = pickTarget(game)
    if not target then
      if reason == "complete" then
        say(game, "All POKéMON in\nthis area have\nbeen caught!")
      else
        say(game, "No wild POKéMON\nfound here.")
      end
      return true
    end

    local world = mod.world
    if not (world and world.startWildBattle) then
      mod.log:warn("FireRed wild-battle API unavailable")
      return true
    end

    local ok, result, err = pcall(world.startWildBattle, world, target.species, target.level)
    if not ok or not result then
      mod.log:warn("Area DexNav battle could not start on %s: %s",
        tostring(currentMapId()), tostring(ok and err or result))
      return true
    end
    return true
  end

  -- Keep SELECT handling on the same Game3 input seam used by the known-good
  -- Gen3 DexNav. Starting a battle/message makes the normal registered-item
  -- SELECT path see the field as busy later in the same fixed update.
  mod.hooks:wrap("input.step", function(next, game, dt)
    local result = next(game, dt)
    local input = game and game.input
    if input and input.wasPressed and input:wasPressed("select") then
      local ok, err = pcall(activate, game)
      if not ok then mod.log:error("Area DexNav SELECT failed: %s", tostring(err)) end
    end
    return result
  end)

  mod.exports.candidates = candidates
  mod.exports.pickTarget = pickTarget
  mod.exports.activate = activate
  mod.exports.version = "1.0.1"
  mod.exports.generation = 3
  mod.exports.supportedGames = { "firered" }

  mod.log:info("Area DexNav Gen 3 loaded")
end
