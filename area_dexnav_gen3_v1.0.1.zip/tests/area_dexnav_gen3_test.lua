local script = (arg and arg[0]) or "tests/area_dexnav_gen3_test.lua"
local root = script:match("^(.*)[/\\]") or "tests"
local mainPath = root .. "/../main.lua"

local state = {
  session = {
    party = { { species = 1, hp = 20 } },
    dex = { seen = {}, caught = { [19] = true }, owned = {} },
  },
  surfing = false,
}

package.preload["src.core.game3.runtime"] = function()
  return { getSession = function() return state.session end }
end
package.preload["src.core.game3.player"] = function()
  return setmetatable({}, { __index = function(_, k)
    if k == "surfing" then return state.surfing end
  end })
end
package.preload["src.core.game3.pokemon"] = function()
  local byName = { PIDGEY=16, RATTATA=19, TENTACOOL=72, MAGIKARP=129 }
  return {
    speciesFromName = function(n) return byName[n] end,
  }
end
package.preload["src.core.game3.dex"] = function()
  return {
    isCaught = function(dex, species)
      return (dex.caught and dex.caught[species]) == true
        or (dex.owned and dex.owned[species]) == true
    end,
  }
end
package.preload["src.ui.game3.hud"] = function()
  return {
    busy = function() return false end,
    openMessage = function(game, text) game.said = text end,
  }
end
package.preload["src.core.game3.field"] = function() return { locked = false } end
package.preload["src.core.game3.battle"] = function() return { isActive = function() return false end } end
package.preload["src.core.game3.rng"] = function() return { Random = function() return 0 end } end

local encounters = {
  FR_ROUTE_1 = {
    land = { rate = 20, slots = {
      { species="PIDGEY", minLevel=2, maxLevel=3 },
      { species="PIDGEY", minLevel=2, maxLevel=4 },
      { species="RATTATA", minLevel=2, maxLevel=3 },
      { species="RATTATA", minLevel=2, maxLevel=4 },
      { species="PIDGEY", minLevel=3, maxLevel=5 },
      { species="RATTATA", minLevel=3, maxLevel=5 },
      { species="PIDGEY", minLevel=4, maxLevel=5 },
      { species="RATTATA", minLevel=4, maxLevel=5 },
      { species="PIDGEY", minLevel=5, maxLevel=5 },
      { species="RATTATA", minLevel=5, maxLevel=5 },
      { species="PIDGEY", minLevel=5, maxLevel=5 },
      { species="RATTATA", minLevel=5, maxLevel=5 },
    }},
    water = { rate = 10, slots = {
      { species="TENTACOOL", minLevel=10, maxLevel=15 },
      { species="TENTACOOL", minLevel=15, maxLevel=20 },
      { species="MAGIKARP", minLevel=20, maxLevel=20 },
      { species="TENTACOOL", minLevel=25, maxLevel=25 },
      { species="MAGIKARP", minLevel=30, maxLevel=30 },
    }},
  },
}

local inputPressed = false
local hook
local started
local mod = {
  id = "area_dexnav_gen3",
  generation = 3,
  exports = {},
  content = {
    encounters = {
      get = function(_, id) return encounters[id] end,
    },
  },
  world = {
    current = function() return { mapId = "FR_ROUTE_1" } end,
    startWildBattle = function(_, species, level)
      started = { species = species, level = level }
      return true
    end,
  },
  hooks = {
    wrap = function(_, name, fn)
      if name == "input.step" then hook = fn end
    end,
  },
  log = {
    info = function() end,
    warn = function() end,
    error = function(_, msg) error(msg) end,
  },
}

local init = assert(loadfile(mainPath))()
init(mod)
assert(type(hook) == "function", "input.step hook installed")

local rows, terrain = mod.exports.candidates()
assert(terrain == "land", "land selected when not surfing")
assert(#rows == 6, "caught Rattata slots removed, six Pidgey slots remain")
for _, r in ipairs(rows) do assert(r.species == 16, "only uncaught Pidgey survives") end
local target = mod.exports.pickTarget(nil, function() return 0 end)
assert(target.species == 16 and target.level == 2, "weighted target and min level")

state.surfing = true
state.session.dex.caught[72] = true
local waterRows, waterTerrain = mod.exports.candidates()
assert(waterTerrain == "water", "surf selects water")
assert(#waterRows == 2, "caught Tentacool slots removed")
for _, r in ipairs(waterRows) do assert(r.species == 129, "only uncaught Magikarp remains") end

state.surfing = false
local game = {
  phase = "field",
  input = {
    wasPressed = function(_, key) return key == "select" and inputPressed end,
  },
}
inputPressed = true
hook(function() end, game, 1/60)
assert(started and started.species == 16, "SELECT starts a FireRed wild battle")

state.session.dex.caught[16] = true
started = nil
game.said = nil
hook(function() end, game, 1/60)
assert(started == nil and game.said and game.said:find("caught", 1, true), "complete area message")

print("area_dexnav_gen3_test: ok")
