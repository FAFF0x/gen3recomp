-- Item Shortcut - Gen 3 / FireRed for Gen1Recomp
-- Five persistent Bag shortcuts, one FAST item, and remappable raw controls.
-- FireRed-only port of the Gen 2 Pokemon MOD package.

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local MOD_ID = "pokemonmod_gen3_item_shortcut"
  local VERSION = "1.0.4"
  local SLOT_COUNT = 5
  local SAVE_SLOTS = "slots"
  local SAVE_FAST = "fast_slot"
  local SAVE_BINDINGS = "bindings"
  local STACK_ID = "item_shortcut_gen3"
  local OWNER_KEY = "__pokemonmod_gen3_item_shortcut_owner_v104"

  local EQUIVALENT_IDS = {
    "item_shortcut_gen3",
    "item_shortcut",
    "pokemonmod_item_shortcut",
  }

  local DEFAULT_BINDINGS = {
    menuKeyboard = "i",
    menuGamepad = "y",
    fastKeyboard = "k",
    fastGamepad = "x",
  }

  local KEY_LABELS = {
    space = "SPACE", ["return"] = "ENTER", kpenter = "KP ENTER",
    tab = "TAB", backspace = "BACKSPACE", delete = "DELETE",
    insert = "INSERT", home = "HOME", ["end"] = "END",
    pageup = "PAGE UP", pagedown = "PAGE DOWN",
    lshift = "L SHIFT", rshift = "R SHIFT",
    lctrl = "L CTRL", rctrl = "R CTRL",
    lalt = "L ALT", ralt = "R ALT", escape = "ESC",
  }
  local PAD_LABELS = {
    a = "A", b = "B", x = "X", y = "Y",
    back = "BACK", guide = "GUIDE", start = "START",
    leftstick = "L3", rightstick = "R3",
    leftshoulder = "L1", rightshoulder = "R1",
    triggerleft = "L2", triggerright = "R2",
    lefttrigger = "L2", righttrigger = "R2",
    dpup = "D-UP", dpdown = "D-DOWN", dpleft = "D-LEFT", dpright = "D-RIGHT",
  }

  local function req(name)
    local ok, value = pcall(require, name)
    if ok then return value end
    return nil
  end

  local Stack = req("src.ui.game3.stack")
  local Window = req("src.ui.game3.window")
  local Font = req("src.ui.game3.frlg_font")
  local Bag = req("src.core.game3.bag")
  local ItemsData = req("src.core.game3.items_data")
  local ItemUse = req("src.core.game3.item_use")
  local Runtime = req("src.core.game3.runtime")
  local BagChrome = req("src.ui.game3.bag_chrome")

  if not (Stack and Window and Font and Bag and ItemsData and ItemUse) then
    mod.log:warn("%s: FireRed UI/item modules are unavailable", MOD_ID)
    return
  end

  local function copyTable(t)
    local out = {}
    if type(t) == "table" then
      for k, v in pairs(t) do out[k] = v end
    end
    return out
  end

  local function normalizeItem(id)
    if id == nil then return nil end
    if ItemsData.toNumericId then
      local n = ItemsData.toNumericId(id)
      if n then return n end
    end
    return id
  end

  local function itemName(id)
    if id == nil then return "EMPTY" end
    local ok, name = pcall(ItemsData.displayName, id)
    if ok and name and name ~= "" then return tostring(name) end
    return tostring(id)
  end

  local function itemDescription(id)
    if id == nil then return "No item assigned." end
    if ItemsData.description then
      local ok, text = pcall(ItemsData.description, id)
      if ok and text and text ~= "" then return tostring(text) end
    end
    return "FireRed BAG item."
  end

  local function getBindings()
    local b = mod.save:get(SAVE_BINDINGS)
    if type(b) ~= "table" then b = {} end
    local changed = false
    for k, v in pairs(DEFAULT_BINDINGS) do
      if type(b[k]) ~= "string" or b[k] == "" then
        b[k] = v
        changed = true
      end
    end
    if changed then mod.save:set(SAVE_BINDINGS, b) end
    return b
  end

  local function saveBindings(b)
    mod.save:set(SAVE_BINDINGS, copyTable(b))
  end

  local function resetBindings()
    saveBindings(DEFAULT_BINDINGS)
  end

  local function bindingLabel(kind, value)
    value = tostring(value or "")
    if kind == "gamepad" then return PAD_LABELS[value] or value:upper() end
    return KEY_LABELS[value] or value:upper()
  end

  local function getSlots()
    local raw = mod.save:get(SAVE_SLOTS)
    local slots = {}
    if type(raw) == "table" then
      for i = 1, SLOT_COUNT do
        if raw[i] ~= nil and raw[i] ~= "" then slots[i] = normalizeItem(raw[i]) end
      end
    end
    mod.save:set(SAVE_SLOTS, slots)
    return slots
  end

  local function saveSlots(slots)
    local out = {}
    for i = 1, SLOT_COUNT do if slots[i] ~= nil then out[i] = slots[i] end end
    mod.save:set(SAVE_SLOTS, out)
  end

  local function fastSlot(slots)
    local n = math.floor(tonumber(mod.save:get(SAVE_FAST)) or 0)
    if n >= 1 and n <= SLOT_COUNT and slots[n] ~= nil then return n end
    if n ~= 0 then mod.save:set(SAVE_FAST, 0) end
    return nil
  end

  local function setFast(slot, slots)
    slot = math.floor(tonumber(slot) or 0)
    if slot == 0 then mod.save:set(SAVE_FAST, 0); return true end
    if slot < 1 or slot > SLOT_COUNT or not slots[slot] then return false end
    mod.save:set(SAVE_FAST, slot)
    return true
  end

  local function assignSlot(slot, id)
    slot = math.floor(tonumber(slot) or 0)
    if slot < 1 or slot > SLOT_COUNT then return false end
    local slots = getSlots()
    local normalized = normalizeItem(id)
    local oldFast = fastSlot(slots)
    local previous
    if normalized ~= nil then
      for i = 1, SLOT_COUNT do
        if normalizeItem(slots[i]) == normalized then
          previous = i
          slots[i] = nil
        end
      end
      slots[slot] = normalized
    else
      slots[slot] = nil
    end
    saveSlots(slots)
    if oldFast == slot and normalized == nil then
      setFast(0, slots)
    elseif oldFast and previous == oldFast and previous ~= slot then
      setFast(slot, slots)
    end
    return true
  end

  local function sessionFor(game)
    return (game and game.session) or (Runtime and Runtime.getSession and Runtime.getSession())
  end

  local function itemCount(game, id)
    local s = sessionFor(game)
    if not (s and s.bag and id ~= nil) then return 0 end
    local ok, n = pcall(Bag.get, s.bag, id)
    return ok and math.max(0, math.floor(tonumber(n) or 0)) or 0
  end

  local function showMessage(game, text)
    local Hud = req("src.ui.game3.hud")
    if Hud and Hud.openMessage then
      Hud.openMessage(game, tostring(text or ""))
      return true
    end
    local Message = req("src.ui.game3.message")
    if Message and Message.show then
      Message.show(tostring(text or ""))
      return true
    end
    return false
  end

  local function inBattle()
    local Battle = package.loaded["src.core.game3.battle"] or req("src.core.game3.battle")
    return Battle and Battle.isActive and Battle.isActive() or false
  end

  local function fieldUsable(game)
    local s = sessionFor(game)
    if not (game and s and s.bag) then return false end
    if game.phase and game.phase ~= "field" then return false end
    if inBattle() then return false end
    local Field = package.loaded["src.core.game3.field"] or req("src.core.game3.field")
    if Field and Field.locked then return false end
    if Stack.busy and Stack.busy() then return false end
    local Message = package.loaded["src.ui.game3.message"]
    if Message and Message.isOpen and Message.isOpen() then return false end
    return true
  end

  local UI = {
    open = false,
    game = nil,
    mode = "main",
    cursor = 1,
    scroll = 0,
    selectedSlot = nil,
    sourceItem = nil,
    sourceBag = false,
    capture = nil,
    status = nil,
  }

  local function se(id)
    local Audio = package.loaded["src.core.game3.audio"] or req("src.core.game3.audio")
    if Audio and Audio.playSe then pcall(Audio.playSe, id) end
  end

  local function clamp(v, lo, hi)
    if v < lo then return lo end
    if v > hi then return hi end
    return v
  end

  local function allBagItems(game)
    local s = sessionFor(game)
    local out = {}
    if not (s and s.bag) then return out end
    for _, pocket in ipairs(ItemsData.BAG_POCKET_ORDER or {"ITEMS","KEY_ITEMS","POKE_BALLS","TM_CASE","BERRY_POUCH"}) do
      local rows = Bag.listPocket(s.bag, pocket) or {}
      for _, row in ipairs(rows) do
        local qty = math.floor(tonumber(row.qty) or Bag.get(s.bag, row.id) or 0)
        if qty > 0 then
          out[#out + 1] = {
            id = normalizeItem(row.id),
            name = row.name or itemName(row.id),
            qty = qty,
            pocket = pocket,
            description = row.description or itemDescription(row.id),
          }
        end
      end
    end
    return out
  end

  local function mainRows(game)
    local slots = getSlots()
    local fs = fastSlot(slots)
    local rows = {}
    for i = 1, SLOT_COUNT do
      local id = slots[i]
      local qty = id and itemCount(game, id) or 0
      local label = id and itemName(id) or "EMPTY"
      local right
      if fs == i then right = "FAST"
      elseif id and qty > 1 then right = "x" .. tostring(qty)
      elseif id and qty <= 0 then right = "MISSING" end
      rows[#rows + 1] = { kind = "slot", slot = i, id = id, label = label, right = right }
    end
    rows[#rows + 1] = { kind = "controls", label = "CONTROL MAPPING", right = "SET" }
    return rows
  end

  local function actionRows(game)
    local slots = getSlots()
    local slot = UI.selectedSlot or 1
    local id = slots[slot]
    if not id then
      return {
        { action = "assign", label = "ASSIGN ITEM" },
        { action = "back", label = "BACK" },
      }
    end
    local fs = fastSlot(slots)
    return {
      { action = "use", label = "USE" },
      { action = "assign", label = "CHANGE ITEM" },
      { action = fs == slot and "unset_fast" or "set_fast", label = fs == slot and "UNSET FAST" or "SET FAST" },
      { action = "clear", label = "CLEAR" },
      { action = "back", label = "BACK" },
    }
  end

  local function controlRows()
    local b = getBindings()
    return {
      { key = "menuKeyboard", kind = "keyboard", label = "MENU KEYBOARD", right = bindingLabel("keyboard", b.menuKeyboard) },
      { key = "menuGamepad", kind = "gamepad", label = "MENU GAMEPAD", right = bindingLabel("gamepad", b.menuGamepad) },
      { key = "fastKeyboard", kind = "keyboard", label = "FAST KEYBOARD", right = bindingLabel("keyboard", b.fastKeyboard) },
      { key = "fastGamepad", kind = "gamepad", label = "FAST GAMEPAD", right = bindingLabel("gamepad", b.fastGamepad) },
      { key = "reset", label = "RESET DEFAULTS", right = "RESET" },
      { key = "back", label = "BACK" },
    }
  end

  function UI:isOpen()
    return self.open and Stack.has(STACK_ID)
  end

  function UI:close()
    if Stack.has(STACK_ID) then Stack.pop(STACK_ID) end
    self.open = false
    self.mode = "main"
    self.cursor = 1
    self.scroll = 0
    self.selectedSlot = nil
    self.sourceItem = nil
    self.sourceBag = false
    self.capture = nil
    self.status = nil
  end

  function UI:show(game)
    self.game = game
    self.open = true
    self.mode = "main"
    self.cursor = 1
    self.scroll = 0
    self.selectedSlot = nil
    self.sourceItem = nil
    self.sourceBag = false
    self.capture = nil
    self.status = nil
    Stack.push(STACK_ID, self, { hideBelow = true })
  end

  function UI:showAssignFromBag(game, id)
    self.game = game
    self.open = true
    self.mode = "assign_from_bag"
    self.cursor = 1
    self.scroll = 0
    self.selectedSlot = nil
    self.sourceItem = normalizeItem(id)
    self.sourceBag = true
    self.capture = nil
    self.status = nil
    Stack.push(STACK_ID, self, { hideBelow = false, drawUnder = true })
  end

  function UI:openItemPicker(slot)
    self.mode = "items"
    self.selectedSlot = slot
    self.cursor = 1
    self.scroll = 0
    self.status = nil
  end

  local function selectedBagRow()
    local BagMenu = package.loaded["src.ui.game3.bag_menu"]
    if not (BagMenu and BagMenu.isOpen and BagMenu.isOpen()) or BagMenu._battle then return nil end
    if BagMenu.mode ~= "list" and BagMenu.mode ~= "action" then return nil end
    local rows = BagMenu.list and BagMenu.list() or nil
    return rows and rows[BagMenu.cursor] or nil
  end

  local function useItem(game, id)
    local s = sessionFor(game)
    if not (s and s.bag and id) then return false end
    if Bag.get(s.bag, id) <= 0 then
      showMessage(game, "That item is no longer\nin the BAG.")
      return false
    end

    if ItemUse.needsPartyTarget and ItemUse.needsPartyTarget(id) then
      local party = s.party or {}
      if #party < 1 then
        showMessage(game, "There is no POKéMON.")
        return false
      end
      local PartyMenu = req("src.ui.game3.party_menu")
      if not (PartyMenu and PartyMenu.show) then return false end
      PartyMenu.show(party, s.move_overlay or s.moveOverlay, {
        session = s,
        bag = s.bag,
        item = id,
        mode = "use",
      })
      return true
    end

    local ok, kind, text = ItemUse.useField(s, s.bag, id, nil)
    if kind == "vs_seeker" then
      if ok then
        local VsSeeker = req("src.core.game3.vs_seeker")
        if VsSeeker and VsSeeker.use then VsSeeker.use(s, game) end
      elseif text then
        showMessage(game, text)
      end
      return ok and true or false
    end
    if not ok and text then showMessage(game, text) end
    return ok and true or false
  end

  local function visibleRange(total, cursor, maxRows)
    maxRows = maxRows or 7
    local scroll = UI.scroll or 0
    if cursor <= scroll then scroll = cursor - 1 end
    if cursor > scroll + maxRows then scroll = cursor - maxRows end
    scroll = clamp(scroll, 0, math.max(0, total - maxRows))
    UI.scroll = scroll
    return scroll + 1, math.min(total, scroll + maxRows)
  end

  -- Modern UI presenter ----------------------------------------------------
  -- gen3_modern_ui intentionally only paints the stock FireRed stack ids.
  -- Item Shortcut owns a custom stack id, so we paint its presentation here
  -- in render.hud/window space while the native Game3 layer continues to own
  -- input and state underneath.  Palette/layout mirrors Modern UI Gen3.
  local MODERN = {
    bg = { 0.075, 0.285, 0.565, 0.995 },
    surface = { 0.975, 0.990, 1.000, 1 },
    raised = { 1.000, 0.965, 0.745, 1 },
    selected = { 1.000, 0.820, 0.250, 1 },
    accent = { 0.900, 0.175, 0.175, 1 },
    secondary = { 1.000, 0.790, 0.030, 1 },
    text = { 0.055, 0.180, 0.315, 1 },
    muted = { 0.285, 0.405, 0.510, 1 },
    divider = { 0.510, 0.720, 0.900, 1 },
    header = { 0.090, 0.330, 0.650, 1 },
    headerText = { 1.000, 1.000, 1.000, 1 },
    footer = { 0.045, 0.145, 0.270, 1 },
    footerText = { 0.960, 0.985, 1.000, 1 },
    ok = { 0.180, 0.690, 0.305, 1 },
    warn = { 0.920, 0.480, 0.160, 1 },
  }

  local modernFonts = {}
  local function modernFont(size)
    size = math.max(12, math.floor((tonumber(size) or 12) + 0.5))
    local key = tostring(size)
    if modernFonts[key] then return modernFonts[key] end
    local g = love and love.graphics
    local f = g and g.getFont and g.getFont() or nil
    if g and g.newFont then
      local ok, value = pcall(g.newFont, size)
      if ok and value then f = value end
    end
    if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    modernFonts[key] = f
    return f
  end

  local function mcolor(c, a)
    a = a or 1
    love.graphics.setColor(c[1], c[2], c[3], (c[4] or 1) * a)
  end

  local function mrect(mode, x, y, w, h, r)
    r = math.max(0, tonumber(r) or 0)
    love.graphics.rectangle(mode, x, y, w, h, r, r)
  end

  local function mtext(value, x, y, size, color, align, width)
    local f = modernFont(size)
    if f and love.graphics.setFont then love.graphics.setFont(f) end
    mcolor(color or MODERN.text)
    value = tostring(value or "")
    if width and love.graphics.printf then
      love.graphics.printf(value, x, y, width, align or "left")
    else
      love.graphics.print(value, x, y)
    end
  end

  local function modernLayout(viewport)
    local x = tonumber(viewport and viewport.gameX) or 0
    local y = tonumber(viewport and viewport.gameY) or 0
    local w = tonumber(viewport and viewport.gameWidth) or (love.graphics.getWidth and love.graphics.getWidth()) or 720
    local h = tonumber(viewport and viewport.gameHeight) or (love.graphics.getHeight and love.graphics.getHeight()) or 480
    local s = math.max(0.64, math.min(w / 720, h / 480))
    local pad = math.max(9, 13 * s)
    local headerH = math.max(42, 49 * s)
    local footerH = math.max(27, 30 * s)
    return {
      x=x,y=y,w=w,h=h,s=s,pad=pad,gap=math.max(6,9*s),
      title=math.max(20,24*s),body=math.max(15,17*s),small=math.max(13,14*s),tiny=math.max(12,12*s),
      row=math.max(34,39*s),headerH=headerH,footerH=footerH,
      contentY=y+headerH,contentH=h-headerH-footerH,
    }
  end

  local function modernBackdrop(L, title, subtitle)
    local t = MODERN
    love.graphics.setScissor(L.x, L.y, L.w, L.h)
    mcolor(t.bg); love.graphics.rectangle("fill", L.x, L.y, L.w, L.h)
    mcolor(t.header); love.graphics.rectangle("fill", L.x, L.y, L.w, L.headerH)
    mcolor(t.accent); love.graphics.rectangle("fill", L.x, L.y, L.w, math.max(3,4*L.s))
    mcolor(t.secondary); love.graphics.rectangle("fill", L.x, L.contentY-math.max(2,3*L.s), L.w, math.max(2,3*L.s))
    mtext(title or "ITEM SHORTCUT", L.x+L.pad, L.y+math.max(7,L.pad*0.55), L.title, t.headerText)
    if subtitle and subtitle ~= "" then
      mtext(subtitle, L.x+L.w*0.54, L.y+math.max(10,L.pad*0.72), L.small, t.secondary, "right", L.w*0.46-L.pad)
    end
  end

  local function modernFooter(L, value)
    local y = L.y + L.h - L.footerH
    mcolor(MODERN.footer); love.graphics.rectangle("fill", L.x, y, L.w, L.footerH)
    mcolor(MODERN.secondary); love.graphics.rectangle("fill", L.x, y, L.w, math.max(2,3*L.s))
    mtext(value or "", L.x+L.pad, y+math.max(6,L.footerH*0.29), L.tiny, MODERN.footerText, "left", L.w-L.pad*2)
  end

  local function modernPanel(x, y, w, h, selected)
    local t = MODERN
    mcolor(selected and t.raised or t.surface)
    mrect("fill", x, y, w, h, math.min(9,h*0.14))
    mcolor(selected and t.accent or t.divider, selected and 0.82 or 0.48)
    love.graphics.setLineWidth(1)
    mrect("line", x, y, w, h, math.min(9,h*0.14))
  end

  local function modernSelection(x, y, w, h)
    mcolor(MODERN.selected, 0.98); mrect("fill", x, y, w, h, math.min(8,h*0.22))
    mcolor(MODERN.accent); love.graphics.rectangle("fill", x, y, math.max(3,w*0.008), h)
  end

  local function pill(value, x, y, w, h, fill, fg)
    mcolor(fill or MODERN.header); mrect("fill", x, y, w, h, h/2)
    local f = modernFont(math.max(12,h*0.48))
    local fh = f and f.getHeight and f:getHeight() or math.max(12,h*0.48)
    mtext(value, x, y + math.max(1,(h-fh)/2), math.max(12,h*0.48), fg or MODERN.headerText, "center", w)
  end

  local function itemPocket(id)
    if not id then return "NO ITEM" end
    if ItemsData.info then
      local ok, info = pcall(ItemsData.info, id)
      if ok and type(info) == "table" and info.pocket then
        return tostring(info.pocket):gsub("_", " ")
      end
    end
    if ItemsData.pocketOf then
      local ok, p = pcall(ItemsData.pocketOf, id)
      if ok and p then return tostring(p):gsub("_", " ") end
    end
    return "BAG ITEM"
  end

  local function modernItemIcon(id, x, y, size)
    if not (id and BagChrome and BagChrome.drawItemIcon) then return false end
    local ok, result = pcall(BagChrome.drawItemIcon, id, x, y, size / 24)
    return ok and result ~= false
  end

  local function drawModernItemDetail(L, x, y, w, h, id, qty, extra)
    modernPanel(x,y,w,h,false)
    local icon = math.min(w*0.42,h*0.34,90*L.s)
    local ix = x+(w-icon)/2
    local iy = y+L.pad
    mcolor(MODERN.divider,0.18); love.graphics.circle("fill",ix+icon/2,iy+icon/2,icon*0.58)
    modernItemIcon(id,ix,iy,icon)
    mtext(id and itemName(id) or "EMPTY SLOT", x+L.pad, iy+icon+L.gap, L.body, MODERN.text, "center", w-L.pad*2)
    if id then
      pill("x"..tostring(qty or 0), x+w*0.31, iy+icon+L.gap+L.body*1.55, w*0.38, math.max(21,23*L.s), MODERN.header)
      mtext(itemPocket(id), x+L.pad, iy+icon+L.gap+L.body*3.05, L.tiny, MODERN.accent, "center", w-L.pad*2)
      mtext(itemDescription(id), x+L.pad, iy+icon+L.gap+L.body*4.35, L.small, MODERN.muted, "left", w-L.pad*2)
    else
      mtext(extra or "Choose a slot, then assign an item from your BAG.", x+L.pad, iy+icon+L.gap+L.body*2.0, L.small, MODERN.muted, "left", w-L.pad*2)
    end
  end

  local function modernRows(L, rows, cursor, x, y, w, h, maxRows, opts)
    opts = opts or {}
    maxRows = maxRows or #rows
    local first,last = visibleRange(#rows,cursor,maxRows)
    local count = math.max(1,last-first+1)
    local rowH = math.min(L.row, math.max(28,(h-L.gap*(count-1))/count))
    for index=first,last do
      local row=rows[index]
      local yy=y+(index-first)*(rowH+L.gap)
      modernPanel(x,yy,w,rowH,false)
      if index==cursor then modernSelection(x+1,yy+1,w-2,rowH-2) end
      local lx=x+L.pad
      if opts.numbered and row.slot then
        local bw=math.max(27,31*L.s)
        pill(tostring(row.slot),lx,yy+(rowH-bw)/2,bw,bw,index==cursor and MODERN.accent or MODERN.header)
        lx=lx+bw+L.gap
      end
      mtext(row.label or "",lx,yy+math.max(5,rowH*0.22),L.small,index==cursor and MODERN.text or MODERN.text,"left",w-(lx-x)-L.pad-75*L.s)
      if row.right then
        local rw=math.max(56,68*L.s)
        pill(tostring(row.right),x+w-rw-L.pad,yy+(rowH-math.max(21,23*L.s))/2,rw,math.max(21,23*L.s),
          tostring(row.right)=="FAST" and MODERN.accent or MODERN.header)
      end
    end
  end

  local function drawModernMain(L)
    modernBackdrop(L,"ITEM SHORTCUT","FIRE RED • 5 SLOTS")
    local rows=mainRows(UI.game)
    local gap=L.gap
    local x=L.x+L.pad; local y=L.contentY+L.pad
    local h=L.contentH-L.pad*2
    local leftW=L.w*0.60-L.pad-gap/2
    local rightX=x+leftW+gap
    local rightW=L.x+L.w-L.pad-rightX
    modernPanel(x,y,leftW,h,false)
    modernRows(L,rows,UI.cursor,x+L.gap,y+L.gap,leftW-L.gap*2,h-L.gap*2,6,{numbered=true})
    local sel=rows[UI.cursor]
    if sel and sel.kind=="slot" then
      local qty=sel.id and itemCount(UI.game,sel.id) or 0
      drawModernItemDetail(L,rightX,y,rightW,h,sel.id,qty)
      if sel.id and fastSlot(getSlots())==sel.slot then
        pill("FAST",rightX+rightW-L.pad-math.max(62,70*L.s),y+L.pad,math.max(62,70*L.s),math.max(22,24*L.s),MODERN.accent)
      end
    else
      modernPanel(rightX,y,rightW,h,false)
      mtext("CONTROL MAPPING",rightX+L.pad,y+L.pad,L.body,MODERN.text)
      local b=getBindings()
      local yy=y+L.pad+L.body*2.2
      local lines={
        {"MENU KEY",bindingLabel("keyboard",b.menuKeyboard)},
        {"MENU PAD",bindingLabel("gamepad",b.menuGamepad)},
        {"FAST KEY",bindingLabel("keyboard",b.fastKeyboard)},
        {"FAST PAD",bindingLabel("gamepad",b.fastGamepad)},
      }
      for _,r in ipairs(lines) do
        mtext(r[1],rightX+L.pad,yy,L.tiny,MODERN.muted)
        mtext(r[2],rightX+rightW*0.47,yy,L.small,MODERN.accent,"right",rightW*0.45-L.pad)
        yy=yy+L.body*1.65
      end
    end
    local b=getBindings()
    modernFooter(L,"A SELECT   B CLOSE   "..bindingLabel("keyboard",b.menuKeyboard).." MENU   "..bindingLabel("keyboard",b.fastKeyboard).." FAST")
  end

  local function drawModernActions(L)
    local slots=getSlots(); local slot=UI.selectedSlot or 1; local id=slots[slot]
    modernBackdrop(L,"SHORTCUT SLOT "..tostring(slot),id and itemName(id) or "EMPTY")
    local x=L.x+L.pad; local y=L.contentY+L.pad; local h=L.contentH-L.pad*2; local gap=L.gap
    local detailW=L.w*0.42-L.pad-gap/2
    drawModernItemDetail(L,x,y,detailW,h,id,id and itemCount(UI.game,id) or 0)
    local rx=x+detailW+gap; local rw=L.x+L.w-L.pad-rx
    modernPanel(rx,y,rw,h,false)
    modernRows(L,actionRows(UI.game),UI.cursor,rx+L.gap,y+L.gap,rw-L.gap*2,h-L.gap*2,6)
    modernFooter(L,"A CONFIRM   B BACK")
  end

  local function drawModernItems(L)
    local rows=allBagItems(UI.game)
    modernBackdrop(L,"ASSIGN ITEM","SLOT "..tostring(UI.selectedSlot or 1))
    local x=L.x+L.pad; local y=L.contentY+L.pad; local h=L.contentH-L.pad*2; local gap=L.gap
    local listW=L.w*0.59-L.pad-gap/2
    modernPanel(x,y,listW,h,false)
    if #rows==0 then
      mtext("THE BAG IS EMPTY",x+L.pad,y+L.pad,L.body,MODERN.muted)
    else
      local display={}
      for i,r in ipairs(rows) do display[i]={label=r.name,right="x"..tostring(r.qty)} end
      modernRows(L,display,UI.cursor,x+L.gap,y+L.gap,listW-L.gap*2,h-L.gap*2,7)
    end
    local rx=x+listW+gap; local rw=L.x+L.w-L.pad-rx; local r=rows[UI.cursor]
    drawModernItemDetail(L,rx,y,rw,h,r and r.id,r and (r.qty or itemCount(UI.game,r.id)) or 0)
    modernFooter(L,"↑ ↓ BROWSE   ← → PAGE   A ASSIGN   B BACK")
  end

  local function drawModernControls(L)
    modernBackdrop(L,"CONTROL MAPPING","ITEM SHORTCUT")
    local x=L.x+L.pad; local y=L.contentY+L.pad; local h=L.contentH-L.pad*2
    local rows=controlRows()
    modernPanel(x,y,L.w-L.pad*2,h,false)
    modernRows(L,rows,UI.cursor,x+L.gap,y+L.gap,L.w-L.pad*2-L.gap*2,h-L.gap*2,6)
    modernFooter(L,"A CHANGE   B BACK")
  end

  local function drawModernAssignFromBag(L)
    local slots=getSlots(); local rows={}
    for i=1,SLOT_COUNT do
      rows[i]={slot=i,label=slots[i] and itemName(slots[i]) or "EMPTY",right=slots[i] and normalizeItem(slots[i])==normalizeItem(UI.sourceItem) and "SET" or nil}
    end
    modernBackdrop(L,"ASSIGN FROM BAG",itemName(UI.sourceItem))
    local x=L.x+L.pad; local y=L.contentY+L.pad; local h=L.contentH-L.pad*2; local gap=L.gap
    local lw=L.w*0.60-L.pad-gap/2
    modernPanel(x,y,lw,h,false)
    modernRows(L,rows,UI.cursor,x+L.gap,y+L.gap,lw-L.gap*2,h-L.gap*2,5,{numbered=true})
    local rx=x+lw+gap; local rw=L.x+L.w-L.pad-rx
    drawModernItemDetail(L,rx,y,rw,h,UI.sourceItem,itemCount(UI.game,UI.sourceItem))
    modernFooter(L,"A ASSIGN TO SLOT   B CANCEL")
  end

  local function drawModernCapture(L)
    modernBackdrop(L,"CONTROL MAPPING","LISTENING")
    local w=math.min(L.w-L.pad*4,520*L.s); local h=math.min(L.contentH*0.62,210*L.s)
    local x=L.x+(L.w-w)/2; local y=L.contentY+(L.contentH-h)/2
    modernPanel(x,y,w,h,true)
    mtext("PRESS A NEW CONTROL",x+L.pad,y+L.pad,L.title,MODERN.text,"center",w-L.pad*2)
    local cap=UI.capture
    local line=cap and cap.kind=="keyboard" and "Press any keyboard key" or "Press any controller button"
    mtext(line,x+L.pad,y+h*0.46,L.body,MODERN.muted,"center",w-L.pad*2)
    if cap and cap.kind=="keyboard" then mtext("ESC cancels",x+L.pad,y+h*0.68,L.small,MODERN.accent,"center",w-L.pad*2) end
    modernFooter(L,"WAITING FOR INPUT")
  end

  local function drawModernOverlay(game,viewport)
    if not UI.open or not (love and love.graphics and viewport) then return end
    local top=Stack.top and Stack.top() or nil
    if not (top and top.id==STACK_ID) then return end
    local L=modernLayout(viewport)
    love.graphics.push("all")
    local ok,err=pcall(function()
      if love.graphics.origin then love.graphics.origin() end
      if UI.mode=="main" then drawModernMain(L)
      elseif UI.mode=="actions" then drawModernActions(L)
      elseif UI.mode=="items" then drawModernItems(L)
      elseif UI.mode=="controls" then drawModernControls(L)
      elseif UI.mode=="assign_from_bag" then drawModernAssignFromBag(L)
      elseif UI.mode=="capture" then drawModernCapture(L) end
    end)
    love.graphics.setScissor()
    love.graphics.pop()
    if not ok and mod.log and mod.log.warn then mod.log:warn("%s modern draw failed: %s",MOD_ID,tostring(err)) end
  end

  local function drawPanel(x, y, w, h, title)
    love.graphics.setColor(24/255, 52/255, 88/255, 1)
    love.graphics.rectangle("fill", x, y, w, h)
    love.graphics.setColor(235/255, 244/255, 1, 1)
    love.graphics.rectangle("fill", x + 2, y + 2, w - 4, h - 4)
    if title then
      love.graphics.setColor(34/255, 91/255, 160/255, 1)
      love.graphics.rectangle("fill", x + 2, y + 2, w - 4, 18)
      Font.draw(title, x + 7, y + 4, { small = true, colors = Font.COLOR.WHITE })
    end
    love.graphics.setColor(1,1,1,1)
  end

  local function drawRows(rows, x, y, w, cursor, maxRows)
    local first, last = visibleRange(#rows, cursor, maxRows)
    for index = first, last do
      local row = rows[index]
      local yy = y + (index - first) * 16
      if index == cursor then
        love.graphics.setColor(206/255, 226/255, 252/255, 1)
        love.graphics.rectangle("fill", x, yy - 1, w, 15)
        Window.cursorPx(x + 1, yy)
      end
      Font.draw(tostring(row.label or ""), x + 12, yy, { small = true, colors = Font.COLOR.NORMAL, maxWidth = w - 45 })
      if row.right then
        local right = tostring(row.right)
        local tw = Font.measure(right, { small = true })
        Font.draw(right, x + w - tw - 4, yy, { small = true, colors = Font.COLOR.BLUE })
      end
    end
  end

  local function drawMain(game)
    local rows = mainRows(game)
    drawPanel(5, 5, 230, 150, "ITEM SHORTCUT - FIRE RED")
    drawRows(rows, 13, 31, 214, UI.cursor, 6)
    local selected = rows[UI.cursor]
    local bottom = selected and selected.id and itemDescription(selected.id) or
      (selected and selected.kind == "controls" and "Remap shortcut and FAST controls." or "Choose a slot to assign a BAG item.")
    Font.draw(bottom, 13, 130, { small = true, colors = Font.COLOR.DARK_GRAY, maxWidth = 214, linePitch = 12 })
  end

  local function drawActions(game)
    local slots = getSlots()
    local id = slots[UI.selectedSlot or 1]
    local rows = actionRows(game)
    drawPanel(18, 10, 204, 140, "SLOT " .. tostring(UI.selectedSlot or 1) .. " - " .. itemName(id))
    drawRows(rows, 30, 40, 180, UI.cursor, 6)
    local qty = id and itemCount(game, id) or 0
    Font.draw(id and ("In BAG: x" .. tostring(qty)) or "No item assigned.", 30, 125,
      { small = true, colors = Font.COLOR.DARK_GRAY })
  end

  local function drawItems(game)
    local rows = allBagItems(game)
    drawPanel(4, 4, 232, 152, "ASSIGN ITEM TO SLOT " .. tostring(UI.selectedSlot or 1))
    if #rows == 0 then
      Font.draw("The BAG is empty.", 18, 45, { colors = Font.COLOR.NORMAL })
      return
    end
    local display = {}
    for i, r in ipairs(rows) do
      display[i] = {
        label = r.name,
        right = "x" .. tostring(r.qty),
      }
    end
    drawRows(display, 12, 28, 216, UI.cursor, 7)
    local r = rows[UI.cursor]
    if r then
      Font.draw((r.pocket or ""):gsub("_", " "), 12, 139, { small = true, colors = Font.COLOR.BLUE })
      Font.draw(r.description or "", 78, 139, { small = true, colors = Font.COLOR.DARK_GRAY, maxWidth = 150 })
    end
  end

  local function drawControls()
    local rows = controlRows()
    drawPanel(12, 8, 216, 144, "CONTROL MAPPING")
    drawRows(rows, 22, 35, 196, UI.cursor, 6)
    Font.draw("A: CHANGE   B: BACK", 22, 133, { small = true, colors = Font.COLOR.DARK_GRAY })
  end

  local function drawAssignFromBag(game)
    local slots = getSlots()
    local rows = {}
    for i = 1, SLOT_COUNT do
      rows[i] = {
        label = tostring(i) .. ". " .. (slots[i] and itemName(slots[i]) or "EMPTY"),
        right = slots[i] and normalizeItem(slots[i]) == normalizeItem(UI.sourceItem) and "SET" or nil,
      }
    end
    drawPanel(20, 16, 200, 128, "ASSIGN " .. itemName(UI.sourceItem))
    drawRows(rows, 30, 46, 180, UI.cursor, 5)
    Font.draw("Choose shortcut slot 1-5.", 30, 127, { small = true, colors = Font.COLOR.DARK_GRAY })
  end

  local function drawCapture()
    drawPanel(25, 35, 190, 90, "PRESS A NEW CONTROL")
    local cap = UI.capture
    local line = cap and cap.kind == "keyboard" and "Press a keyboard key." or "Press a controller button."
    Font.draw(line, 42, 68, { colors = Font.COLOR.NORMAL, maxWidth = 160 })
    Font.draw(cap and cap.kind == "keyboard" and "ESC cancels." or "", 42, 96,
      { small = true, colors = Font.COLOR.DARK_GRAY })
  end

  -- FireRed's game3 Stack invokes layer callbacks as plain functions:
  --   layer.mod.draw()
  --   layer.mod.handleInput(input)
  -- Do NOT define these two callbacks with ':' (implicit self), otherwise the
  -- layer becomes modal but draw silently errors and input is swallowed.
  function UI.draw()
    if not UI.open then return end
    love.graphics.push("all")
    love.graphics.origin()
    love.graphics.setScissor()
    love.graphics.setColor(12/255, 24/255, 42/255, 0.94)
    love.graphics.rectangle("fill", 0, 0, 240, 160)
    if UI.mode == "main" then drawMain(UI.game)
    elseif UI.mode == "actions" then drawActions(UI.game)
    elseif UI.mode == "items" then drawItems(UI.game)
    elseif UI.mode == "controls" then drawControls()
    elseif UI.mode == "assign_from_bag" then drawAssignFromBag(UI.game)
    elseif UI.mode == "capture" then drawCapture() end
    love.graphics.setColor(1,1,1,1)
    love.graphics.pop()
  end

  function UI.handleInput(input)
    if not UI.open or not input then return end
    if UI.mode == "capture" then return end

    local function moveCursor(total, delta)
      if total < 1 then return end
      UI.cursor = ((UI.cursor - 1 + delta) % total) + 1
      se(5)
    end

    if UI.mode == "main" then
      local rows = mainRows(UI.game)
      if input:wasPressed("up") then moveCursor(#rows, -1)
      elseif input:wasPressed("down") then moveCursor(#rows, 1)
      elseif input:wasPressed("b") then se(9); UI:close()
      elseif input:wasPressed("a") then
        se(5)
        local row = rows[UI.cursor]
        if row.kind == "slot" then
          UI.selectedSlot = row.slot
          UI.mode = "actions"
          UI.cursor = 1
          UI.scroll = 0
        else
          UI.mode = "controls"
          UI.cursor = 1
          UI.scroll = 0
        end
      end
      return
    end

    if UI.mode == "actions" then
      local rows = actionRows(UI.game)
      if input:wasPressed("up") then moveCursor(#rows, -1)
      elseif input:wasPressed("down") then moveCursor(#rows, 1)
      elseif input:wasPressed("b") then UI.mode = "main"; UI.cursor = UI.selectedSlot or 1; UI.scroll = 0; se(9)
      elseif input:wasPressed("a") then
        se(5)
        local row = rows[UI.cursor]
        local slots = getSlots()
        local id = slots[UI.selectedSlot or 1]
        if row.action == "use" and id then
          UI:close()
          useItem(UI.game, id)
        elseif row.action == "assign" then
          UI:openItemPicker(UI.selectedSlot or 1)
        elseif row.action == "set_fast" then
          setFast(UI.selectedSlot, slots)
          UI.mode = "main"; UI.cursor = UI.selectedSlot; UI.scroll = 0
        elseif row.action == "unset_fast" then
          setFast(0, slots)
          UI.mode = "main"; UI.cursor = UI.selectedSlot; UI.scroll = 0
        elseif row.action == "clear" then
          assignSlot(UI.selectedSlot, nil)
          UI.mode = "main"; UI.cursor = UI.selectedSlot; UI.scroll = 0
        else
          UI.mode = "main"; UI.cursor = UI.selectedSlot or 1; UI.scroll = 0
        end
      end
      return
    end

    if UI.mode == "items" then
      local rows = allBagItems(UI.game)
      if input:wasPressed("up") then moveCursor(#rows, -1)
      elseif input:wasPressed("down") then moveCursor(#rows, 1)
      elseif input:wasPressed("left") then UI.cursor = clamp(UI.cursor - 7, 1, math.max(1,#rows)); se(5)
      elseif input:wasPressed("right") then UI.cursor = clamp(UI.cursor + 7, 1, math.max(1,#rows)); se(5)
      elseif input:wasPressed("b") then UI.mode = "actions"; UI.cursor = 1; UI.scroll = 0; se(9)
      elseif input:wasPressed("a") and rows[UI.cursor] then
        local picked = rows[UI.cursor]
        assignSlot(UI.selectedSlot or 1, picked.id)
        UI.mode = "main"
        UI.cursor = UI.selectedSlot or 1
        UI.scroll = 0
        se(5)
      end
      return
    end

    if UI.mode == "controls" then
      local rows = controlRows()
      if input:wasPressed("up") then moveCursor(#rows, -1)
      elseif input:wasPressed("down") then moveCursor(#rows, 1)
      elseif input:wasPressed("b") then UI.mode = "main"; UI.cursor = 6; UI.scroll = 0; se(9)
      elseif input:wasPressed("a") then
        local row = rows[UI.cursor]
        if row.key == "reset" then
          resetBindings(); se(5)
        elseif row.key == "back" then
          UI.mode = "main"; UI.cursor = 6; UI.scroll = 0; se(9)
        else
          UI.capture = { key = row.key, kind = row.kind }
          UI.mode = "capture"
          se(5)
        end
      end
      return
    end

    if UI.mode == "assign_from_bag" then
      if input:wasPressed("up") then moveCursor(SLOT_COUNT, -1)
      elseif input:wasPressed("down") then moveCursor(SLOT_COUNT, 1)
      elseif input:wasPressed("b") then UI:close(); se(9)
      elseif input:wasPressed("a") then
        local slot = UI.cursor
        local id = UI.sourceItem
        assignSlot(slot, id)
        UI:close()
        local BagMenu = package.loaded["src.ui.game3.bag_menu"]
        if BagMenu and BagMenu.isOpen and BagMenu.isOpen() then
          BagMenu.mode = "message"
          BagMenu.messageText = string.format("Assigned %s to\nshortcut %d.", itemName(id), slot)
        end
        se(5)
      end
    end
  end

  local function bagAssignment(game)
    local row = selectedBagRow()
    if not row or not row.id then return false end
    UI:showAssignFromBag(game, row.id)
    return true
  end

  local function handleMenuShortcut(game)
    if UI:isOpen() then UI:close(); return true end
    local BagMenu = package.loaded["src.ui.game3.bag_menu"]
    if BagMenu and BagMenu.isOpen and BagMenu.isOpen() and not BagMenu._battle then
      return bagAssignment(game)
    end
    if not fieldUsable(game) then return false end
    UI:show(game)
    se(5)
    return true
  end

  local function handleFastShortcut(game)
    if UI:isOpen() then return false end
    if not fieldUsable(game) then return false end
    local slots = getSlots()
    local fs = fastSlot(slots)
    if not fs then
      showMessage(game, "No FAST item is set.\nSet one in Item Shortcut.")
      return true
    end
    useItem(game, slots[fs])
    return true
  end

  local pendingAction = nil

  local function queueShortcut(kind, game)
    pendingAction = { kind = kind, game = game }
    return true
  end

  local function runPending(game)
    local p = pendingAction
    if not p then return false end
    pendingAction = nil
    local g = p.game or game
    if p.kind == "menu" then
      return handleMenuShortcut(g)
    elseif p.kind == "fast" then
      return handleFastShortcut(g)
    end
    return false
  end

  local function finishCapture(value)
    local cap = UI.capture
    if not cap then return false end
    local b = getBindings()
    b[cap.key] = value
    saveBindings(b)
    UI.capture = nil
    UI.mode = "controls"
    UI.cursor = (cap.key == "menuKeyboard" and 1)
      or (cap.key == "menuGamepad" and 2)
      or (cap.key == "fastKeyboard" and 3) or 4
    UI.scroll = 0
    se(5)
    return true
  end

  local deferredTo
  if type(mod.find) == "function" then
    for _, id in ipairs(EQUIVALENT_IDS) do
      local ok, other = pcall(mod.find, id)
      if ok and other then deferredTo = other.id or id; break end
    end
  end

  local owner = rawget(_G, OWNER_KEY)
  if owner and owner ~= MOD_ID then deferredTo = deferredTo or tostring(owner) end

  if not deferredTo then
    rawset(_G, OWNER_KEY, MOD_ID)
    getBindings()
    getSlots()

    mod.hooks:wrap("input.key", function(nextFn, game, ev)
      if UI.capture and ev and ev.phase == "pressed" then
        if UI.capture.kind == "keyboard" then
          if ev.key == "escape" then
            UI.capture = nil
            UI.mode = "controls"
          else
            finishCapture(ev.key)
          end
        end
        return true
      end
      if not ev or ev.phase ~= "pressed" then return nextFn(game, ev) end
      local b = getBindings()
      local menuMatch = ev.key == b.menuKeyboard
      local fastMatch = ev.key == b.fastKeyboard
      if not menuMatch and not fastMatch then return nextFn(game, ev) end
      if menuMatch and UI:isOpen() then UI:close(); return true end
      if menuMatch then return queueShortcut("menu", game) end
      if fastMatch then return queueShortcut("fast", game) end
      return nextFn(game, ev)
    end)

    mod.hooks:wrap("input.gamepad", function(nextFn, game, ev)
      if UI.capture then
        if UI.capture.kind == "gamepad" and ev then
          if ev.phase == "pressed" and ev.button then
            finishCapture(ev.button)
            return true
          elseif ev.phase == "axis" and ev.axis and math.abs(tonumber(ev.value) or 0) > 0.6
              and (ev.axis == "triggerleft" or ev.axis == "triggerright"
                or ev.axis == "lefttrigger" or ev.axis == "righttrigger") then
            finishCapture(ev.axis)
            return true
          end
        end
        return true
      end
      if not ev or ev.phase ~= "pressed" or not ev.button then return nextFn(game, ev) end
      local b = getBindings()
      local menuMatch = ev.button == b.menuGamepad
      local fastMatch = ev.button == b.fastGamepad
      if not menuMatch and not fastMatch then return nextFn(game, ev) end
      if menuMatch and UI:isOpen() then UI:close(); return true end
      if menuMatch then return queueShortcut("menu", game) end
      if fastMatch then return queueShortcut("fast", game) end
      return nextFn(game, ev)
    end)

    mod.hooks:wrap("input.step", function(nextFn, game, dt)
      if pendingAction then
        local ok, err = pcall(runPending, game)
        if not ok then
          pendingAction = nil
          mod.log:warn("%s pending shortcut failed: %s", MOD_ID, tostring(err))
        end
      end
      return nextFn(game, dt)
    end)

    -- Window-space presenter matching Gen3 Modern UI.  This runs after the
    -- native 240x160 frame, so it also works when gen3_modern_ui is active.
    mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
      local result = nextFn(game, viewport)
      drawModernOverlay(game, viewport)
      return result
    end)

    -- Always expose a safe FireRed route in the Start menu. This is also a
    -- fallback for controllers/platforms that do not report a raw Y button.
    mod.hooks:wrap("ui.start_menu.items", function(nextFn, game, items)
      local out = nextFn(game, items)
      if type(out) ~= "table" then return out end
      for _, row in ipairs(out) do
        if row and (row.id == STACK_ID or row.label == "ITEM SHORTCUT") then
          return out
        end
      end
      local entry = {
        id = STACK_ID,
        label = "ITEM SHORTCUT",
        onSelect = function(g, _session)
          if UI:isOpen() then return end
          UI:show(g or game)
          se(5)
        end,
      }
      local at = #out + 1
      for i, row in ipairs(out) do
        local label = row and tostring(row.label or ""):upper() or ""
        if label == "SAVE" or label == "OPTION" or label == "OPTIONS" then
          at = i
          break
        end
      end
      table.insert(out, at, entry)
      return out
    end)

    mod.log:info("Item Shortcut Gen 3 installed [%s] v%s", MOD_ID, VERSION)
  else
    mod.log:warn("Item Shortcut Gen 3 runtime deferred to active equivalent mod '%s'", tostring(deferredTo))
  end

  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  mod.exports.version = VERSION
  mod.exports.open = function(game)
    if deferredTo or not fieldUsable(game) then return false end
    UI:show(game)
    return true
  end
  mod.exports.getSlots = function() return getSlots() end
  mod.exports.assign = function(slot, id) return assignSlot(slot, id) end
  mod.exports.clear = function(slot) return assignSlot(slot, nil) end
  mod.exports.getFastSlot = function() return fastSlot(getSlots()) end
  mod.exports.setFastSlot = function(slot) return setFast(slot, getSlots()) end
  mod.exports.getBindings = function() return getBindings() end
  mod.exports.resetBindings = function() resetBindings(); return true end
end
