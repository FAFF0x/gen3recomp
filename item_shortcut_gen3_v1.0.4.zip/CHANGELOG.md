# Changelog

## 1.0.4
- Added a high-resolution window-space presenter for the custom `item_shortcut_gen3` stack id.
- Matched Gen3 Modern UI's default Kanto palette: blue chrome, white surfaces, yellow selection, red accent and dark navy text.
- Main screen now uses a two-panel layout: five shortcut slots on the left and live selected-item details on the right.
- Added native FireRed item icons (when available), BAG quantity, pocket name, item description and a visible FAST badge.
- Restyled action selection, BAG item picker, control mapping, direct BAG assignment and input-capture screens.
- Kept the v1.0.3 FireRed stack/input contract unchanged.
- Added a `render.hud` presentation hook; underlying native UI remains only as a safe fallback.

## 1.0.3
- Fixed the invisible modal menu on FireRed: Game3 stack callbacks are now plain `draw()` / `handleInput(input)` functions, matching the actual runtime contract.
- Fixed the symptom where opening Item Shortcut froze field input while rendering nothing.
- Verified the custom stack id is intentionally ignored by `gen3_modern_ui`'s presenter list, so Modern UI no longer needs to own this screen; the native Game3 stack renders Item Shortcut correctly beneath the window-space overlay chain.
- Updated regression tests so `draw()` is called with zero arguments, exactly as `src/core/game3/gfx.lua` does.
- Keeps v1.0.2 deferred hotkey opening and the `ITEM SHORTCUT` Start-menu fallback.

## 1.0.2
- Deferred raw I/Y and K/X actions to the next `input.step` tick.
- Added `ITEM SHORTCUT` to the FireRed Start menu as a guaranteed fallback route.

## 1.0.1
- Initial FireRed-only port from the Gen2 package.
