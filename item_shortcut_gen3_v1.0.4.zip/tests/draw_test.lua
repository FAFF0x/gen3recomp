local root=assert(os.getenv('ITEM_SHORTCUT_ROOT'))
local drawCalls=0
local fakeFont={setFilter=function()end,getHeight=function()return 14 end}
_G.love={graphics={
 push=function(...)end,pop=function(...)end,origin=function()end,setScissor=function(...)end,
 setColor=function(...)end,rectangle=function(...)drawCalls=drawCalls+1 end,circle=function(...)drawCalls=drawCalls+1 end,
 setLineWidth=function(...)end,setFont=function(...)end,print=function(...)drawCalls=drawCalls+1 end,printf=function(...)drawCalls=drawCalls+1 end,
 newFont=function(...)return fakeFont end,getFont=function()return fakeFont end,getWidth=function()return 960 end,getHeight=function()return 640 end,
}}
local stack={layers={}}
function stack.push(id,m,opts) stack.layers[#stack.layers+1]={id=id,mod=m,opts=opts} end
function stack.pop(id) for i=#stack.layers,1,-1 do if stack.layers[i].id==id then table.remove(stack.layers,i); return true end end end
function stack.has(id) for _,v in ipairs(stack.layers) do if v.id==id then return true end end return false end
function stack.busy() return #stack.layers>0 end
function stack.top() return stack.layers[#stack.layers] end
package.preload['src.ui.game3.stack']=function() return stack end
package.preload['src.ui.game3.window']=function() return {cursorPx=function()end} end
local F={COLOR={WHITE={},NORMAL={},BLUE={},DARK_GRAY={}},draw=function(...)end,measure=function(s,o)return #tostring(s)*6 end}
package.preload['src.ui.game3.frlg_font']=function() return F end
package.preload['src.ui.game3.bag_chrome']=function() return {drawItemIcon=function(...) drawCalls=drawCalls+1 return true end} end
local bag={}; function bag.get(b,id)return (b.items and b.items[id]) or 0 end; function bag.listPocket(b,p)return {{id=13,qty=3,name='POTION',description='Heal'}} end
package.preload['src.core.game3.bag']=function()return bag end
local items={BAG_POCKET_ORDER={'ITEMS','KEY_ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH'},toNumericId=tonumber,displayName=function(id)return 'ITEM'..id end,description=function(id)return 'DESC' end,info=function(id)return {pocket='ITEMS'} end}
package.preload['src.core.game3.items_data']=function()return items end
package.preload['src.core.game3.item_use']=function()return {needsPartyTarget=function()return false end,useField=function()return true,'repel','ok'end}end
package.preload['src.core.game3.runtime']=function()return {} end
package.preload['src.core.game3.field']=function()return {locked=false}end
package.preload['src.core.game3.battle']=function()return {isActive=function()return false end}end
package.preload['src.core.game3.audio']=function()return {playSe=function()end}end
local saved,hooks={},{}
local mod={generation=3,save={get=function(_,k)return saved[k] end,set=function(_,k,v)saved[k]=v end},hooks={wrap=function(_,n,f)hooks[n]=f end},log={warn=function(...)print('WARN',...)end,info=function(...)print('INFO',...)end},exports={},find=function()return nil end}
assert(loadfile(root..'/main.lua'))()(mod)
local game={phase='field',session={bag={items={[13]=3}},party={}}}
assert(mod.exports.assign(1,13))
assert(mod.exports.open(game)==true)
assert(#stack.layers==1)
local ok,err=pcall(stack.layers[1].mod.draw)
assert(ok,err)
local base=function() return 'ok' end
local result=hooks['render.hud'](base,game,{gameX=0,gameY=0,gameWidth=960,gameHeight=640})
assert(result=='ok','render chain return changed')
assert(drawCalls>10,'modern overlay did not draw')
local input={wasPressed=function(_,k) return k=='b' end}
local okInput,errInput=pcall(stack.layers[1].mod.handleInput,input)
assert(okInput,errInput)
assert(#stack.layers==0,'B did not close custom stack layer')
print('draw-modern-ok',drawCalls)
