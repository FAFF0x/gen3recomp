-- EXP Share Modes Gen 3 / FireRed
-- Native Game3 port of EXP Share Modes.
--
-- FireRed's public exp.gain hook changes the amount for an already-selected
-- recipient, but it cannot add bench Pokemon to the recipient set. To preserve
-- the three modes faithfully, this mod replaces Experience.awardFoe while
-- keeping the engine's Experience.apply result contract, exp.gain hook,
-- battle.exp_gained events, level-up flow, EXP-bar animation data and bonuses.

local MOD_ID = "pokemonmod_gen3_exp_share_modes"
local VALID_MODE = { off = true, classic = true, modern = true }
local EQUIVALENT_MOD_IDS = {
  "exp_share_modes",
  "exp_share_modes_gen2",
  "exp_share_modes_gen3",
  "pokemonmod_gen2_exp_share_modes",
}

local function modeOf(mod)
  -- The in-game FireRed Options row is authoritative. Fall back to the
  -- Mod Manager option for existing installs that already chose a mode.
  local fallback = mod.options:get("mode") or "classic"
  local mode = mod.save and mod.save:get("mode", fallback) or fallback
  mode = tostring(mode)
  return VALID_MODE[mode] and mode or "classic"
end

local MODE_ORDER = { "off", "classic", "modern" }
local MODE_LABEL = {
  off = "OFF",
  classic = "CLASSIC",
  modern = "MODERN",
}

local function setMode(mod, mode)
  mode = tostring(mode or "classic")
  if not VALID_MODE[mode] then mode = "classic" end
  if mod.save and mod.save.set then mod.save:set("mode", mode) end
  return mode
end

local function cycleMode(mod, dir)
  local cur = modeOf(mod)
  local idx = 2
  for i, v in ipairs(MODE_ORDER) do
    if v == cur then idx = i break end
  end
  dir = (tonumber(dir) or 1) < 0 and -1 or 1
  idx = ((idx - 1 + dir) % #MODE_ORDER) + 1
  return setMode(mod, MODE_ORDER[idx])
end

local function eligible(mon)
  if type(mon) ~= "table" then return false end
  if mon.isEgg or mon.egg then return false end
  if (tonumber(mon.species or mon.speciesId) or 0) == 0 then return false end
  return (tonumber(mon.hp) or 0) > 0
end

local function contains(set, index)
  return set[index] == true
end

local function participantSet(st, foeBattler, opts)
  local set = {}
  if type(opts and opts.partyIndices) == "table" then
    for _, pi in ipairs(opts.partyIndices) do
      pi = tonumber(pi)
      if pi then set[pi] = true end
    end
  elseif type(foeBattler and foeBattler.participants) == "table" then
    for pi, on in pairs(foeBattler.participants) do
      if on then
        pi = tonumber(pi)
        if pi then set[pi] = true end
      end
    end
  end

  -- Single-battle compatibility fallback: the active party slot participated.
  if next(set) == nil then
    local pi = st and st.player and tonumber(st.player.partyIndex)
    if pi then set[pi] = true end
  end
  return set
end

local function indicesMatching(party, predicate)
  local out = {}
  for pi = 1, 6 do
    local mon = party and party[pi]
    if eligible(mon) and predicate(pi, mon) then
      out[#out + 1] = pi
    end
  end
  return out
end

local function groupPlan(mode, party, participants)
  local livingParticipants = indicesMatching(party, function(pi)
    return contains(participants, pi)
  end)

  if mode == "off" then
    return {
      { indices = livingParticipants, poolNumerator = 1, poolDenominator = 1, kind = "participants" },
    }
  end

  if mode == "classic" then
    return {
      { indices = indicesMatching(party, function() return true end), poolNumerator = 1, poolDenominator = 1, kind = "party" },
    }
  end

  return {
    { indices = livingParticipants, poolNumerator = 1, poolDenominator = 1, kind = "participants" },
    { indices = indicesMatching(party, function(pi) return not contains(participants, pi) end), poolNumerator = 1, poolDenominator = 2, kind = "bench" },
  }
end

local function baseShare(calculated, group)
  local count = #(group.indices or {})
  if count < 1 then return 0 end
  local n = tonumber(group.poolNumerator) or 1
  local d = math.max(1, tonumber(group.poolDenominator) or 1)
  local pool = math.floor((tonumber(calculated) or 0) * n / d)
  local amount = math.floor(pool / count)
  if amount < 1 then amount = 1 end
  return amount
end

local function boostedAmount(base, per, isTrainer)
  local amount = math.max(0, math.floor(tonumber(base) or 0))
  if amount <= 0 then return 0 end
  if per and per.luckyEgg then amount = math.floor(amount * 150 / 100) end
  if isTrainer then amount = math.floor(amount * 150 / 100) end
  if per and per.traded then amount = math.floor(amount * 150 / 100) end
  return math.max(1, amount)
end

local function findBattler(st, pi)
  local absent = (st and st.absent) or {}
  local b0 = st and st.player
  local b2 = st and st.double and st.battlers and st.battlers[2] or nil
  if b0 and tonumber(b0.partyIndex) == pi and not absent[0] then return b0, 0 end
  if b2 and tonumber(b2.partyIndex) == pi and not absent[2] then return b2, 2 end
  if st and st.double then
    if b2 and tonumber(b2.partyIndex) == pi and not absent[2] then return b2, 2 end
    if not absent[0] then return nil, 0 end
    return nil, 2
  end
  return nil, 0
end


local function installOptionsMenuRow(mod)
  local okRows, Rows = pcall(require, "src.ui.game3.option_rows")
  if not okRows or type(Rows) ~= "table" or type(Rows.build) ~= "function" then
    mod.log:warn("FireRed option rows unavailable; EXP mode remains configurable from Mod Manager")
    return false
  end

  -- Add our row to FireRed's existing BATTLE OPTIONS page, preserving any
  -- other mod that has already wrapped Rows.build.
  local rowId = "pokemonmod_exp_share_mode"
  local group
  for _, g in ipairs(Rows.GROUPS or {}) do
    if g.id == "group.battle" then group = g break end
  end
  if group then
    local found = false
    for _, id in ipairs(group.members or {}) do
      if id == rowId then found = true break end
    end
    if not found then
      group.members = group.members or {}
      group.members[#group.members + 1] = rowId
    end
  end

  Rows._pokemonmodExpShareOwners = Rows._pokemonmodExpShareOwners or {}
  if Rows._pokemonmodExpShareOwners[MOD_ID] then return true end

  local previousBuild = Rows.build
  Rows.build = function(ctx)
    local rows = previousBuild(ctx) or {}
    for _, row in ipairs(rows) do
      if row.id == rowId or row.label == "EXP SHARE MODE" then
        return rows
      end
    end
    rows[#rows + 1] = {
      id = rowId,
      label = "EXP SHARE MODE",
      value = function()
        return MODE_LABEL[modeOf(mod)] or "CLASSIC"
      end,
      step = function(_, dir)
        cycleMode(mod, dir)
        return true
      end,
    }
    return rows
  end
  Rows._pokemonmodExpShareOwners[MOD_ID] = true
  return true
end

local function installAwardOverride(mod, Experience, ModRuntime)
  local nativeAwardFoe = Experience._pokemonmod_exp_share_modes_original or Experience.awardFoe
  Experience._pokemonmod_exp_share_modes_original = nativeAwardFoe
  Experience._pokemonmod_exp_share_modes_owner = MOD_ID

  Experience.awardFoe = function(st, foeBattler, opts)
    opts = opts or {}
    if not st or not foeBattler or type(st.playerParty) ~= "table" then
      return nativeAwardFoe(st, foeBattler, opts)
    end

    local foeMon = foeBattler.mon
    local foeSpecies = foeBattler.species or (foeMon and (foeMon.species or foeMon.speciesId))
    local foeLevel = tonumber((foeMon and foeMon.level) or foeBattler.level) or 1
    if not foeSpecies then return nativeAwardFoe(st, foeBattler, opts) end

    local isTrainer = opts.trainer
    if isTrainer == nil then isTrainer = not st.wild end

    local participants = participantSet(st, foeBattler, opts)
    local mode = modeOf(mod)
    local groups = groupPlan(mode, st.playerParty, participants)
    local calculated = math.floor(Experience.expYield(foeSpecies) * math.max(1, foeLevel) / 7)
    local out = {}
    local awarded = {}

    for _, group in ipairs(groups) do
      local share = baseShare(calculated, group)
      for _, pi in ipairs(group.indices or {}) do
        local mon = st.playerParty[pi]
        if mon and not awarded[pi] and (tonumber(mon.level) or 1) < (Experience.MAX_LEVEL or 100) then
          awarded[pi] = true
          local per = opts.getOpts and opts.getOpts(mon, pi)
            or (Experience.recipientOpts and Experience.recipientOpts(st, mon))
            or {}
          local function vanilla_amount()
            return boostedAmount(share, per, isTrainer)
          end

          local amount
          if ModRuntime.wantsHook and ModRuntime.wantsHook("exp.gain") then
            local okG3, G3 = pcall(require, "src.mods.Gen3Compat")
            local defeatedDef = okG3 and G3 and G3.speciesView and G3.speciesView(foeSpecies) or foeSpecies
            amount = ModRuntime.call("exp.gain", vanilla_amount, {
              defeatedDef = defeatedDef,
              level = foeLevel,
              isTrainer = isTrainer,
              participants = #(group.indices or {}),
              traded = per.traded and true or false,
              luckyEgg = per.luckyEgg and true or false,
              expShare = false,
              mon = mon,
              index = pi,
              battle = st,
              loser = foeBattler,
              shareMode = mode,
              shareGroup = group.kind,
            })
            amount = math.max(0, math.floor(tonumber(amount) or 0))
          else
            amount = vanilla_amount()
          end

          local result = Experience.apply(mon, amount)
          local battler, battlerId = findBattler(st, pi)
          if battler then
            battler.mon = mon
            battler.fainted = (tonumber(mon.hp) or 0) <= 0
          end

          if ModRuntime.wants and ModRuntime.wants("battle.exp_gained") then
            ModRuntime.emit("battle.exp_gained", {
              battle = st,
              mon = mon,
              gained = result.gained,
              levels = result.levels,
              index = pi,
              battler = battler,
              battlerId = battlerId,
            })
          end

          out[#out + 1] = {
            mon = mon,
            partyIndex = pi,
            battler = battler,
            expGetterBattlerId = battlerId,
            amount = amount,
            boosted = per.traded and true or false,
            result = result,
          }
        end
      end
    end

    return out
  end

  return nativeAwardFoe
end

return function(mod)
  mod.options:define({
    {
      key = "mode",
      label = "EXP SHARE MODE",
      type = "choice",
      default = "classic",
      choices = {
        { "OFF", "off" },
        { "CLASSIC EVEN SPLIT", "classic" },
        { "MODERN PROGRESSIVE", "modern" },
      },
    },
  })

  local deferredTo
  if mod.find then
    for _, otherId in ipairs(EQUIVALENT_MOD_IDS) do
      local other = mod.find(otherId)
      if other then
        deferredTo = other.id or otherId
        break
      end
    end
  end

  local Experience = require("src.core.game3.battle.experience")
  local ModRuntime = require("src.mods.Runtime")

  local optionsMenuInstalled = installOptionsMenuRow(mod)

  if not deferredTo and Experience._pokemonmod_exp_share_modes_owner
      and Experience._pokemonmod_exp_share_modes_owner ~= MOD_ID then
    deferredTo = Experience._pokemonmod_exp_share_modes_owner
  end

  if not deferredTo then
    installAwardOverride(mod, Experience, ModRuntime)
  end

  mod.exports.mode = function() return modeOf(mod) end
  mod.exports.setMode = function(mode) return setMode(mod, mode) end
  mod.exports.cycleMode = function(dir) return cycleMode(mod, dir) end
  mod.exports.optionsMenuInstalled = optionsMenuInstalled
  mod.exports.eligible = eligible
  mod.exports.participantSet = participantSet
  mod.exports.groupPlan = groupPlan
  mod.exports.baseShare = baseShare
  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo

  if deferredTo then
    mod.log:warn("EXP distribution deferred to active equivalent mod '%s'", deferredTo)
  else
    mod.log:info("EXP Share Modes - Gen 3 loaded [" .. MOD_ID .. "] (default: Classic Even Split; START > OPTION > BATTLE OPTIONS)")
  end
end
