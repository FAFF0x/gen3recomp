# Changelog

## 1.0.2
- Added an in-game FireRed selector at START → OPTION → BATTLE OPTIONS.
- Added EXP SHARE MODE row with OFF / CLASSIC / MODERN values.
- Mode changes persist through the mod save store and apply immediately.
- Kept Mod Manager option as fallback for existing configurations.
- Preserved the v1.0.1 Game3 EXP distribution implementation.

# Changelog

## 1.0.1

- Ported EXP Share Modes from Gen2 to the native FireRed/Game3 battle experience pipeline.
- FireRed-only manifest and isolated Gen3 mod identity.
- Preserved Off, Classic Even Split and Modern Progressive modes.
- Preserved trainer, traded Pokémon and Lucky Egg bonuses.
- Preserved the Game3 `exp.gain` hook and `battle.exp_gained` events.
- Held EXP. SHARE no longer adds a second distribution rule while the mod is active.
- Added coexistence guard for equivalent EXP Share Modes packages.
