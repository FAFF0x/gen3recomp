package.path = './?.lua;' .. package.path

local saved = {}
local rowsModule = {
  GROUPS = {
    { id = 'group.battle', label = 'BATTLE OPTIONS', members = { 'battleScene', 'battleStyle' } },
  },
}
function rowsModule.build(ctx)
  return {
    { id='battleScene', label='BATTLE SCENE' },
    { id='battleStyle', label='BATTLE STYLE' },
  }
end
package.loaded['src.ui.game3.option_rows'] = rowsModule

local exp = {
  MAX_LEVEL = 100,
  awardFoe = function() return {} end,
  expYield = function() return 100 end,
  recipientOpts = function() return {} end,
  apply = function(mon, amount) return { gained=amount, levels={} } end,
}
package.loaded['src.core.game3.battle.experience'] = exp
package.loaded['src.mods.Runtime'] = {
  wantsHook = function() return false end,
  wants = function() return false end,
}

local mod = {
  options = {
    define = function() end,
    get = function(_, key) if key == 'mode' then return 'classic' end end,
  },
  save = {
    get = function(_, key, fallback) local v=saved[key]; if v==nil then return fallback end; return v end,
    set = function(_, key, value) saved[key]=value end,
  },
  exports = {},
  find = function() return nil end,
  log = { warn=function() end, info=function() end },
}

local install = assert(loadfile('main.lua'))()
install(mod)
assert(mod.exports.optionsMenuInstalled == true, 'options row installer')
local rows = rowsModule.build({})
local found
for _, r in ipairs(rows) do if r.id == 'pokemonmod_exp_share_mode' then found=r end end
assert(found, 'EXP SHARE MODE row exists')
assert(found.value() == 'CLASSIC', 'default value CLASSIC')
assert(found.step({}, 1) == true, 'step returns true')
assert(found.value() == 'MODERN', 'right cycles to MODERN')
assert(saved.mode == 'modern', 'mode persisted')
found.step({}, 1)
assert(found.value() == 'OFF', 'wrap MODERN -> OFF')
found.step({}, -1)
assert(found.value() == 'MODERN', 'left cycles OFF -> MODERN')

local battleGroup = rowsModule.GROUPS[1]
local n=0
for _, id in ipairs(battleGroup.members) do if id == 'pokemonmod_exp_share_mode' then n=n+1 end end
assert(n == 1, 'battle group contains one EXP row id')
print('PASS options menu integration')
