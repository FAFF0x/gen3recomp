local source = debug.getinfo(1, "S").source:sub(2)
local root = source:match("^(.*)tests/") or ""
root = root:gsub("/$", "")

local optionValue = "classic"
local emitted = {}

local Experience = {
  MAX_LEVEL = 100,
  expYield = function() return 100 end,
  recipientOpts = function(_, mon)
    return { luckyEgg = mon.luckyEgg == true, traded = mon.traded == true }
  end,
  apply = function(mon, amount)
    mon.exp = (mon.exp or 0) + amount
    return { gained = amount, levels = {} }
  end,
  awardFoe = function() error("native award should be replaced") end,
}

local Runtime = {
  wantsHook = function(name) return name == "exp.gain" end,
  call = function(name, nextFn, ctx)
    assert(name == "exp.gain")
    assert(ctx.expShare == false)
    return nextFn()
  end,
  wants = function(name) return name == "battle.exp_gained" end,
  emit = function(name, payload)
    emitted[#emitted + 1] = { name = name, payload = payload }
  end,
}

package.preload["src.core.game3.battle.experience"] = function() return Experience end
package.preload["src.mods.Runtime"] = function() return Runtime end
package.preload["src.mods.Gen3Compat"] = function()
  return { speciesView = function(sp) return { speciesId = sp } end }
end

local mod = {
  options = {
    define = function() end,
    get = function(_, key) assert(key == "mode"); return optionValue end,
  },
  exports = {},
  log = { info = function() end, warn = function() end },
  find = function() return nil end,
}

assert(loadfile(root .. "/main.lua"))()(mod)
assert(mod.exports.active == true)
assert(Experience._pokemonmod_exp_share_modes_owner == "pokemonmod_gen3_exp_share_modes")

local function mon(hp, extra)
  local m = { hp = hp, level = 10, species = 1, exp = 0 }
  for k, v in pairs(extra or {}) do m[k] = v end
  return m
end

local function fixture()
  local party = {
    mon(20),
    mon(30),
    mon(0),
    mon(25),
    mon(20, { isEgg = true }),
    mon(20, { level = 100 }),
  }
  local st = {
    wild = true,
    playerParty = party,
    player = { partyIndex = 1, mon = party[1] },
    battlers = {},
    absent = {},
  }
  local foe = { species = 16, level = 14, mon = { species = 16, level = 14 }, participants = { [1] = true, [3] = true } }
  return st, foe
end

local function byIndex(out)
  local b = {}
  for _, row in ipairs(out) do b[row.partyIndex] = row.amount end
  return b
end

-- calculated = floor(100 * 14 / 7) = 200
optionValue = "off"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 200, "off participant gets full pool")
  assert(by[2] == nil and by[3] == nil and by[4] == nil, "off excludes bench/fainted")
end

optionValue = "classic"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 50 and by[2] == 50 and by[4] == 50, "classic uses all four conscious non-Egg slots in the divisor")
  assert(by[5] == nil and by[6] == nil, "egg and lv100 excluded")
end

optionValue = "modern"
do
  local st, foe = fixture()
  local by = byIndex(Experience.awardFoe(st, foe, {}))
  assert(by[1] == 200, "modern participant gets 100% participant pool")
  assert(by[2] == 33 and by[4] == 33, "modern bench splits 50% pool across three conscious bench slots")
end

-- FireRed recipient bonuses remain per-recipient.
optionValue = "classic"
do
  local st, foe = fixture()
  st.wild = false
  st.playerParty[1].luckyEgg = true
  st.playerParty[1].traded = true
  local by = byIndex(Experience.awardFoe(st, foe, { trainer = true }))
  -- 50 * 1.5 Lucky Egg -> 75; trainer -> 112; traded -> 168
  assert(by[1] == 168, "Lucky Egg + trainer + traded bonuses preserved")
end

assert(#emitted > 0, "battle.exp_gained events emitted")
print("exp_share_modes_gen3_test: ok")
