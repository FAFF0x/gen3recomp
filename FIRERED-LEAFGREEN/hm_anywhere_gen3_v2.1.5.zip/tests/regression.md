# v2.1.5 regression checklist

- Manifest targets `firered` and `leafgreen`.
- No executable references to Gen2 modules.
- HM entry appears only when a supported HM is owned.
- TM entry appears only when TM28 is owned.
- Contextual OFF restores normal learned-move requirement.
- Contextual ON lets native `FieldMoves.partyMoveUser` fall back to machine ownership only after the vanilla lookup fails.
- Duplicate patch sentinel prevents two HM Anywhere implementations from stacking the same replacement.
- Custom menu follows the Game3 static stack contract: `handleInput(input)`, `update()`, `draw()`.
- B returns to START; successful field move exits menus before calling `Field.executeFieldMove`.

- A newly earned badge is accepted when represented in `session.flags`, `session.badges` (table or bitmask), `save.flags`, `save.player.badges`, or the active script store.
- CUT and ROCK SMASH menu paths recognize live EventObjects using `def.graphicsId`.
- FLY menu eligibility reads `mapDef.mapType` (with `type` fallback for older builds).
- Contextual CUT/SURF/STRENGTH/ROCK SMASH/WATERFALL use the same robust badge fallback after the vanilla badge check fails.
