# Changelog

## 1.0.1
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Replaced the FireRed-only runtime export with explicit FRLG `supportedGames` metadata.
- Kept the shared Game3 `help_system` suppression logic unchanged.
- Preserved L/R input for boxes, menus and other mods.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.0

- Initial FireRed-only release.
- Globally disables the modal HELP screen opened by L/R.
- Preserves L/R input for native menus and other mods.
- Re-applies the disable state after FireRed resets the Help subsystem.
- Closes an already-open HELP screen if the mod becomes active while HELP is visible.
