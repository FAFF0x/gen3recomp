# Changelog

## 1.4.0
- Fixed vanilla battle dialogue leaking through the modern battle HUD.
- Added a modern battle dialogue panel that follows the native Game3 `Message` typewriter/waiting state.
- Added modern YES/NO and multi-choice battle decision panels, including the opponent-switch prompt.
- Added a modern level-up stat-growth card for both stat-gain and new-total pages.
- Added a fullscreen modern battle move-learning / move-forget interface driven by the native `SummaryMenu` `select_move` cursor.
- Battle move-learning prompts, HM warnings, level-up messages and post-action text now remain visually consistent with Modern Battle UI.
- Kept native FRLG input, battle sequencing, EXP calculations, switching, move replacement and callbacks untouched.
- Fixed the internal version constant so it now matches the manifest/export version.

## 1.3.1
- Added LeafGreen support alongside FireRed.
- Updated manifest and mod-card compatibility targets to `firered` + `leafgreen`.
- Added explicit runtime `supportedGames` and `frlgRuntime` metadata.
- Retained the legacy `fireRedRuntime` export for compatibility with existing integrations.
- Kept the shared Game3 battle adapter, HUD, move information, EXP and Pokédex logic unchanged.
- Preserved the existing mod id `modern_battle_ui_gen3_firered` so this version upgrades the current mod instead of creating a duplicate.

## 1.3.0
- Added a concise description for the currently highlighted move in the normal move grid.
- Growl and other stat moves now explain the actual stat change instead of only showing STATUS.
- Added a full MOVE INFO overlay toggled with SELECT.
- Full info shows type, category, power, accuracy, PP, priority, target, current matchup, secondary chance and a detailed effect explanation.
- D-pad remains available while MOVE INFO is open so the player can inspect all four moves.
- A, B and START are suppressed while the info overlay is open to prevent accidental battle actions.
- Move explanations are generated from FireRed's live effect metadata, including stat changes, status effects, recoil, draining, multi-hit, weather, screens, priority and special move behaviors.
- No battle calculations or move definitions are modified.

## 1.2.0
- Added effectiveness badges to every move card so matchup information is visible before selecting a move.
- Added distinct SUPER, NORMAL, RESIST and IMMUNE states, including ×4/×2/×1/×1/2/×1/4/×0 multipliers.
- Status moves now show STATUS rather than a damage-effectiveness badge.
- Added a live EXP progress bar directly below the active Pokémon name.
- EXP rendering follows the native animated battle ratio when available and falls back to the Gen 3 experience growth curve.
- Added Pokédex caught-state information to the opponent card using the active FireRed session's `session.dex` and `Dex.isCaught`.
- Added CAUGHT / NOT CAUGHT Poké Ball badges without changing capture logic.
- Hidden ghost encounters do not reveal Pokédex ownership before the species is revealed.
- Battle logic and the v1.1.1 visual language remain unchanged.

## 1.1.1
- Reworked the battle presentation around the visual language of Modern UI Gen3 v1.0.19.
- Replaced the dark low-contrast palette with Kanto blue, white, Poké Ball red and Pokémon yellow.
- Fixed blurry/illegible text by drawing typography directly in final window space instead of rasterizing 5–8 px fonts and scaling them up.
- Generated fonts now use a 12 px minimum and linear filtering, matching Modern UI's readability strategy.
- Increased contrast and hierarchy for Pokémon names, levels, HP values, command labels, move labels and move details.
- Selected command/move cards now use a yellow raised surface plus a red selection rail.
- HP bars now use the same green / amber / red thresholds as Modern UI Gen3.
- Battle logic, FireRed runtime adapter, input ownership and native animations remain unchanged from v1.1.0.

## 1.1.0
- Rebuilt the port against FireRed's actual `src.core.game3.battle` runtime.
- Target changed to the real FireRed game id.
- Replaced command/move chrome and singles health boxes through `render.hud` while preserving native battle logic.
