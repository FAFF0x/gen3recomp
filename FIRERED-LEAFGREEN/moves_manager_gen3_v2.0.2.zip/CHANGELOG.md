# Changelog

## 2.0.2 - FireRed + LeafGreen
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Replaced the FireRed-only runtime export with FRLG `game` and `supportedGames` metadata.
- Kept the shared Game3 Party, Pokemon, move data, HM protection, move restore and reorder logic unchanged.
- Preserved the existing `moves_manager_gen3` id so this version upgrades the current mod instead of creating a duplicate.

## 2.0.1 - Gen 3 / FireRed port

- Ported the mod from Gen2 to FireRed's native game3 runtime.
- Changed internal ID to `moves_manager_gen3` and target to `firered` only.
- Replaced direct Gen2 move-table edits with `Pokemon.replaceMove`, `Pokemon.teachMove` and `Pokemon.swapMoves`.
- Added FireRed HM protection.
- Rebuilt remembered-move reconstruction around Gen3 learnsets and evolution data.
- Added native game3 stack UI and a high-resolution Modern UI-compatible presenter.
- Added Party menu **MOVES** integration without declaring conflicts against other mods.
