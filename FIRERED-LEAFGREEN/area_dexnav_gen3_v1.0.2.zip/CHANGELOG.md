# Changelog

## 1.0.2

- Added LeafGreen support alongside FireRed.
- Updated both manifest `games` and runtime `supportedGames` metadata.
- Kept the shared Game3 encounter-registry, Pokédex, surf-state and wild-battle logic unchanged.
- Preserved the same mod id so this updates the existing Gen3 mod instead of creating a duplicate.

## 1.0.1

- Ported Area DexNav from Gen2 to the real FireRed/Game3 runtime.
- Target is exclusively `firered`.
- Uses Game3 encounter registry, Pokédex, surf state and wild-battle API.
- Preserves native FireRed land/water slot weights and per-slot level ranges.
- Uses a separate `area_dexnav_gen3` manifest id so it does not collide with the Gen2 package on import.
