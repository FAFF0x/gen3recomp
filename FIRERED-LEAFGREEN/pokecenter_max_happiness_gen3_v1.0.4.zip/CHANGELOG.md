# Changelog

## 1.0.4
- Added LeafGreen support alongside FireRed.
- Updated manifest and mod-card compatibility targets to `firered` + `leafgreen`.
- Added explicit FRLG runtime metadata through `game` and `supportedGames` exports.
- Kept the shared Game3 `special HealPlayerParty` hook unchanged.
- Confirmed the Pokemon Center map check is already prefix-agnostic because it matches the shared `POKEMON_CENTER_1F` suffix, so it works with both FR and LG map ids.
- Preserved the existing `pokecenter_max_happiness_gen3` id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.3
- Ported the mod from Gen 2 to FireRed / Gen 3 only.
- Changed target to `games: ["firered"]`.
- Changed mod id to `pokecenter_max_happiness_gen3` to avoid collisions with the Gen2 build.
- Replaced the Gen2 `World:healParty()` patch with FireRed's real `special HealPlayerParty` script path.
- Uses the composable `script.command` hook instead of globally replacing `Party.healAll`.
- Sets both Gen3 friendship aliases (`friendship` and `happiness`) to 255.
- Applies only inside Pokemon Center 1F maps.
- Eggs remain excluded.
- Other Game3 healing paths stay vanilla.
