# Changelog

## 1.2.0
- Fixed load-order conflict with Modern Bag Gen 3.
- Raised mod priority from 25 to 900 so Stable Menu Navigation installs after Modern UI and Modern Bag.
- The mod now wraps the final Bag input handler, preventing Modern Bag's own Fast/Very Fast logic-frame repeat from bypassing the limiter.
- Bag held scrolling is intentionally slow: 60-frame (~1.00 s) initial delay, then 18-frame (~0.30 s) repeats.
- Help uses a 45-frame (~0.75 s) initial delay and 18-frame (~0.30 s) repeats.
- Directional edge de-duplication remains active at high GAME SPEED.
- Bag action/custom/quantity/confirmation menus remain one-step-per-press.
- Added runtime diagnostics for Modern Bag detection and final Bag input-gate ownership.
- FireRed + LeafGreen compatibility preserved.

## 1.1.0
- Fixed the real cause of excessively fast Bag navigation at high GAME SPEED.
- Raw directional `wasPressed` edges are no longer forwarded directly to Bag/Help.
- A physical direction is now emitted exactly once even when several fixed updates observe the same input frame.
- Bag held navigation is substantially slower: 45-frame (~0.75 s) initial delay, then 12-frame (~0.20 s) repeats.
- Help held navigation now uses a 36-frame (~0.60 s) initial delay and 12-frame (~0.20 s) repeats.
- Bag submenus such as action, quantity and confirmation remain one-step-per-press and do not auto-repeat.
- FireRed + LeafGreen compatibility preserved.

## 1.0.4
- Slowed held menu navigation to make it easier to control.
- Repeat interval increased from 5 frames (~0.083 s) to 8 frames (~0.133 s), reducing repeated movement from about 12 to 7.5 steps per second.
- Bag keeps its 40-frame (~0.667 s) initial hold delay.
- Help initial hold delay increased from 20 frames (~0.333 s) to 30 frames (~0.500 s).
- First physical directional presses remain immediate.
- Real-time gating remains independent from GAME SPEED.
- FireRed + LeafGreen compatibility preserved.

## 1.0.3
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Replaced the FireRed-only runtime export with FRLG `game` and `supportedGames` metadata.
- Updated the shared-owner fast path so it also reports FireRed + LeafGreen compatibility.
- Kept the Game3 Bag/Help real-time repeat logic unchanged.
- Preserved the existing mod id so this version upgrades the current mod instead of creating a duplicate.

## 1.0.2

- FireRed-only Gen 3 port.
- Reimplemented stable held navigation against the native FireRed Bag and Help systems.
- Bag cadence preserved at 40-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Help cadence preserved at 20-frame initial delay / 5-frame repeat, measured in wall-clock time.
- Edge presses remain immediate.
- Other FireRed menus remain edge-only and are not modified.
- Added generation-specific duplicate-patch guard.
- Added unique Gen 3 mod ID and FireRed-only manifest target.
- Does not patch the shared legacy `MenuRepeat` helper.
