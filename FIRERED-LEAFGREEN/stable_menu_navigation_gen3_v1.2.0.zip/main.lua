-- Stable Menu Navigation - Gen 3 / FireRed + LeafGreen
-- v1.2.0
--
-- FRLG's Bag and Help screens implement GBA-style held-direction repeat
-- with logic-frame counters. GAME SPEED can execute multiple fixed updates per
-- rendered frame, which makes those counters advance faster than real time.
--
-- This mod uses a deliberately very slow, de-duplicated wall-clock cadence:
--   Bag:  60 frames initial delay, then every 18 frames
--   Help: 45 frames initial delay, then every 18 frames
-- at 60 Hz. It is intentionally loaded after Modern Bag so Modern Bag's
-- own logic-frame repeat cannot bypass this final input gate.

local VERSION = "1.2.0"
local MOD_ID = "pokemonmod_gen3_stable_menu_navigation"
local PATCH_KEY = "__pokemonmod_gen3_stable_menu_navigation_v2"
local LOGIC_HZ = 60
local DIRS = { "up", "down", "left", "right" }

local BAG_DELAY_FRAMES = 60
local HELP_DELAY_FRAMES = 45
local REPEAT_RATE_FRAMES = 18

local function wallTime()
  if love and love.timer and type(love.timer.getTime) == "function" then
    local ok, value = pcall(love.timer.getTime)
    if ok and type(value) == "number" then return value end
  end
  if os and type(os.clock) == "function" then return os.clock() end
  return 0
end

local function sec(frames)
  return math.max(0, tonumber(frames) or 0) / LOGIC_HZ
end

local function clearState(state)
  state.dir = nil
  state.nextAt = nil
end

local function pressed(input, key)
  return input and type(input.wasPressed) == "function" and input:wasPressed(key) == true
end

local function down(input, key)
  return input and type(input.isDown) == "function" and input:isDown(key) == true
end

local function firstPressedDir(input)
  for _, key in ipairs(DIRS) do
    if pressed(input, key) then return key end
  end
  return nil
end

local function firstHeldDir(input)
  for _, key in ipairs(DIRS) do
    if down(input, key) then return key end
  end
  return nil
end

-- Emit a directional event exactly once for the physical press, then optionally
-- repeat it on a slow wall-clock cadence while the same direction remains held.
--
-- Important: with high GAME SPEED, input:wasPressed(key) can remain true across
-- several fixed updates belonging to the same rendered frame. We therefore do
-- NOT forward raw directional wasPressed values to Bag/Help. The state.dir latch
-- consumes that edge once and only rearms after release or a direction change.
local function realtimeDirection(state, input, delayFrames, rateFrames, allowRepeat)
  local now = wallTime()
  local edge = firstPressedDir(input)
  local held = firstHeldDir(input)
  local dir = held or edge

  if not dir then
    clearState(state)
    return nil
  end

  -- New physical direction: immediate single step.
  if state.dir ~= dir then
    state.dir = dir
    state.nextAt = now + sec(delayFrames)
    state.lastAt = now
    return dir
  end

  -- Same physical press seen again in another fixed update: swallow it.
  -- Only a real-time held-repeat deadline may generate another movement.
  if not allowRepeat or not held then
    return nil
  end

  if type(state.nextAt) ~= "number" then
    state.nextAt = now + sec(delayFrames)
    return nil
  end

  if now >= state.nextAt then
    state.nextAt = now + math.max(0.001, sec(rateFrames))
    state.lastAt = now
    return held
  end

  return nil
end

local function isDir(key)
  return key == "up" or key == "down" or key == "left" or key == "right"
end

local function makeBagInputProxy(input, synthetic)
  return setmetatable({
    wasPressed = function(_, key)
      -- Never forward raw directional edges: a single real press can otherwise
      -- be observed by several fixed updates at high GAME SPEED.
      if isDir(key) then return synthetic == key end
      return pressed(input, key)
    end,
    isDown = function(_, key)
      -- Disable BagMenu's private logic-frame up/down repeat counter. Our
      -- wall-clock gate is the sole owner of directional navigation timing.
      if key == "up" or key == "down" then return false end
      return down(input, key)
    end,
  }, { __index = input })
end

local function makeHelpInputProxy(input, synthetic)
  return setmetatable({
    wasPressed = function(_, key)
      if isDir(key) then return synthetic == key end
      return pressed(input, key)
    end,
  }, { __index = input })
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local okBag, BagMenu = pcall(require, "src.ui.game3.bag_menu")
  local okHelp, Help = pcall(require, "src.ui.game3.help_system")

  if not okBag or type(BagMenu) ~= "table" or type(BagMenu.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation could not access FRLG BagMenu")
    mod.exports.active = false
    mod.exports.reason = "FRLG BagMenu unavailable"
    return
  end
  if not okHelp or type(Help) ~= "table" or type(Help.update) ~= "function"
      or type(Help.handleInput) ~= "function" then
    mod.log:error("Stable Menu Navigation could not access FRLG Help system")
    mod.exports.active = false
    mod.exports.reason = "FRLG Help system unavailable"
    return
  end

  local installed = rawget(_G, PATCH_KEY)
  if type(installed) == "table" and installed.active == true then
    -- An equivalent Gen 3 copy already owns the real-time gates. Do not layer
    -- another timing wrapper on top of it.
    mod.exports.active = true
    mod.exports.shared = true
    mod.exports.mode = "frlg_realtime_repeat"
    mod.exports.version = VERSION
    mod.exports.generation = 3
    mod.exports.game = "frlg"
    mod.exports.supportedGames = { "firered", "leafgreen" }
    mod.exports.legacyMode = "firered_realtime_repeat"
    return
  end

  local bagState = {}
  local helpState = {}

  local modernBagDispatch = rawget(BagMenu, "__pokemonmodModernBagGen3DispatchV1")
  local modernBagDetected = type(modernBagDispatch) == "table"

  local baseBagHandleInput = BagMenu.handleInput
  local baseBagShow = BagMenu.show
  local baseHelpUpdate = Help.update
  local baseHelpShow = Help.show

  if type(baseBagShow) == "function" then
    BagMenu.show = function(...)
      clearState(bagState)
      return baseBagShow(...)
    end
  end

  BagMenu.handleInput = function(input)
    -- Gate ALL Bag directional edges so fast fixed updates cannot duplicate a
    -- single physical press. Only the normal item list receives held repeats;
    -- action/quantity/confirm modes stay one-step-per-press.
    local synthetic = realtimeDirection(
      bagState,
      input,
      BAG_DELAY_FRAMES,
      REPEAT_RATE_FRAMES,
      BagMenu.mode == "list"
    )

    return baseBagHandleInput(makeBagInputProxy(input, synthetic))
  end

  if type(baseHelpShow) == "function" then
    Help.show = function(...)
      clearState(helpState)
      return baseHelpShow(...)
    end
  end

  Help.update = function(game)
    -- Closed Help keeps its exact native open/eligibility behavior (L/R,
    -- button mode, fades, context checks). Only the already-open navigation
    -- repeat is replaced.
    if not Help.open then
      clearState(helpState)
      return baseHelpUpdate(game)
    end

    local input = game and game.input
    if not input then return true end
    local synthetic = realtimeDirection(
      helpState, input, HELP_DELAY_FRAMES, REPEAT_RATE_FRAMES, true
    )
    Help.handleInput(makeHelpInputProxy(input, synthetic))
    return true
  end

  rawset(_G, PATCH_KEY, {
    active = true,
    owner = MOD_ID,
    version = VERSION,
    bag = BagMenu,
    help = Help,
    bagHandleInput = BagMenu.handleInput,
    helpUpdate = Help.update,
  })

  mod.exports.active = true
  mod.exports.shared = false
  mod.exports.mode = "frlg_realtime_repeat"
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "frlg"
  mod.exports.supportedGames = { "firered", "leafgreen" }
  mod.exports.legacyMode = "firered_realtime_repeat"
  mod.exports.logicHz = LOGIC_HZ
  mod.exports.bagInitialDelayFrames = BAG_DELAY_FRAMES
  mod.exports.helpInitialDelayFrames = HELP_DELAY_FRAMES
  mod.exports.repeatRateFrames = REPEAT_RATE_FRAMES
  mod.exports.deduplicatesDirectionalEdges = true
  mod.exports.bagRepeatOnlyInList = true
  mod.exports.finalBagInputGate = true
  mod.exports.modernBagDetected = modernBagDetected
  mod.exports.requiredLoadPriority = 900
  mod.exports.bagInitialDelaySeconds = sec(BAG_DELAY_FRAMES)
  mod.exports.helpInitialDelaySeconds = sec(HELP_DELAY_FRAMES)
  mod.exports.repeatRateSeconds = sec(REPEAT_RATE_FRAMES)
  mod.exports.targets = { bag = true, help = true }

  mod.log:info(
    "Stable Menu Navigation Gen 3 enabled: FINAL slow FRLG input gate (after Modern Bag)"
  )
end
