# FRLG real-time repeat regression checklist

## Bag

- initial Up/Down press moves immediately;
- first held repeat occurs about 40/60 = 0.667 s later;
- subsequent held repeats occur about 8/60 = 0.1333 s apart;
- result is independent of GAME SPEED;
- multiple fixed updates at the same wall-clock timestamp do not produce multiple cursor moves;
- action/toss/submenu modes remain edge-only.

## Help

- initial direction press moves immediately;
- first held repeat occurs about 30/60 = 0.500 s later;
- subsequent held repeats occur about 8/60 = 0.1333 s apart;
- L/R open/close behavior and Help eligibility rules remain native.

## Scope

- no Gen1/Gen2 shared MenuRepeat patch;
- no overworld movement changes;
- no battle-input changes;
- FireRed + LeafGreen manifest targets.


## v1.1.0 edge de-duplication

### Bag
- A single physical UP/DOWN press moves exactly one row even if `handleInput` is called multiple times with `wasPressed=true`.
- Holding UP/DOWN does not move again until roughly 45/60 = 0.75 s.
- Subsequent held repeats are roughly 12/60 = 0.20 s apart.
- LEFT/RIGHT pocket switching receives one event per physical press.
- Action / toss / quantity / confirmation modes do not auto-repeat directional input.

### Help
- A single physical directional press is emitted once across repeated fixed updates.
- First held repeat occurs roughly 36/60 = 0.60 s later.
- Subsequent held repeats are roughly 12/60 = 0.20 s apart.


## v1.2.0 Modern Bag load-order regression

With Modern Bag Gen 3 installed:

- Stable Menu Navigation manifest priority is 900, greater than Modern Bag's 520.
- `BagMenu.handleInput` is wrapped after Modern Bag's dispatcher.
- One UP/DOWN tap moves one row only.
- Holding UP/DOWN produces no second row movement for about 1.00 second.
- Continued holding advances about one row every 0.30 second.
- Modern Bag's `hold_scroll_speed = fast` or `very_fast` cannot speed up this final gate.
- Modern Bag filters/tools/action menus remain one movement per physical press.
