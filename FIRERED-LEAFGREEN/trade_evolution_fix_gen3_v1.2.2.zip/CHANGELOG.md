# Changelog

## 1.2.2
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Added explicit FRLG runtime metadata with `game = "frlg"` and `supportedGames`.
- Kept the same twelve Gen 3 trade-evolution conversions, held-item checks and post-evolution item consumption logic.
- Preserved the existing `pokemonmod_gen3_trade_evolution_fix` id so this version upgrades the current mod instead of creating a duplicate.

## 1.2.1

- Ported Trade Evolution Fix exclusively to FireRed / Gen 3.
- Uses FireRed `EVO_TRADE`, `EVO_TRADE_ITEM`, and `EVO_LEVEL` evolution data.
- Keeps the original solo levels from the Gen2 mod for the ten shared trade evolutions.
- Adds FireRed's two additional trade evolutions: Clamperl → Huntail and Clamperl → Gorebyss, both at level 40 while holding their original Deep Sea item.
- Correctly separates the Gen3 level parameter from the held-item requirement.
- Consumes required held items only after a successful evolution.
- Preserves Slowpoke → Slowbro when King's Rock is not held.
- Avoids duplicate paths when another mod already provides a level evolution.
- FireRed-only manifest and unique Gen3 mod id.
