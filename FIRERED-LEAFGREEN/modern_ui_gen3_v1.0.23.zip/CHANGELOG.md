# Changelog

## 1.0.23
- Fixed the compact Electric-type badge color in Party cards.
- Added the `ELECTR` alias to the type-color palette so the shortened label uses the same yellow color as `ELECTRIC`.
- FireRed + LeafGreen compatibility and the existing `gen3_modern_ui` id are preserved.

## 1.0.22
- Fixed type/status badge labels that could wrap or overflow their pill backgrounds in compact layouts.
- Party-screen type pills now compute widths from the rendered label text instead of a rough character estimate.
- Pill text now auto-fits to the available width and remains on a single line when space is tight.
- Status pills reuse the same text-fitting logic for more consistent alignment.
- FireRed + LeafGreen compatibility and the existing `gen3_modern_ui` id are preserved.

## 1.0.21
- Added a global Modern UI presenter for `src.ui.game3.message`.
- NPC dialogue, signs and ordinary script messages no longer rely on the vanilla FRLG textbox presentation.
- Added a global Modern UI presenter for `src.ui.game3.choice`.
- YES/NO prompts and generic multichoice script menus now use Modern UI cards and selection highlighting.
- Native Message/Choice input, typing, paging, callbacks and script result logic remain untouched.
- Global dialogue works even when no supported Game3 Stack menu is open.
- Battle-frame text is intentionally left to Modern Battle UI to avoid overlay conflicts.
- FireRed + LeafGreen support and the existing `gen3_modern_ui` id are preserved.

## 1.0.20
- Added LeafGreen support alongside FireRed.
- Updated `manifest.json` and `mod.card` targets to `firered` + `leafgreen`.
- Replaced the FireRed-only runtime identity with FRLG metadata and explicit `supportedGames`.
- Kept the shared `src.ui.game3.*` / `src.core.game3.*` presenters and native menu ownership unchanged.
- Preserved the existing `gen3_modern_ui` mod id so this version upgrades the installed mod instead of creating a duplicate.

## 1.0.19
- Added icon-led Start Menu navigation with Pokédex, Pokémon, Bag, Trainer, Save, Options and Exit symbols.
- Added generic icon fallback for extra Start Menu entries injected by other mods.
- Added type-aware Party card accents and type badges using FireRed species data.
- Added visible status pills and yellow mid-HP state in Party cards.
- Added Bag pocket tabs and a larger, clearer item detail panel.
- Added icon-led Bag and Party action menus.
- Added subtle screen fade-in and selection pulse, with a UI ANIMATIONS toggle.
- Redesigned Trainer Card with Kanto identity panel, Poké Ball motif and eight badge slots.
- Preserved native FireRed ownership of menu logic, state transitions and callbacks.

## 1.0.18
- Reworked the default theme around recognizable Pokémon colors: Kanto blue, Poké Ball red, logo yellow and white menu cards.
- Added dedicated header/footer colors and stronger selection contrast.
- Removed the narrow Plain Pixel font from the overlay renderer.
- Switched to the readable built-in LÖVE font with smooth filtering.
- Increased minimum font sizes for body, small and hint text.
- Preserved the v1.0.17 layout, menu behavior and FireRed Game3 integration.

## 1.0.17
- Major visual and usability redesign.
- Compact FireRed-oriented layout and palette.
- Plain Pixel font support with fallback.
- Reworked Start, Bag and Party layouts.
- Fixed hidden Party CANCEL cursor.
- Fixed hidden Box special targets.
- Added visible Bag party-target selection.
- Added PC storage submenu presentation.
- Native fallback for PC transfer screens not safely represented by the overlay.

## 1.0.16
- First functional FireRed Game3 port using `src.ui.game3.*` and `render.hud`.
