-- DV EV Editor Gen 3 v2.0.2 for Pokemon Recomp / FireRed
-- Native Game3 port of dv_ev_editor_gen2. Gen 3 uses six IVs and six EVs.

return function(mod)
  local MOD_ID = "dv_ev_editor_gen3"
  local VERSION = "2.0.2"
  local EDITOR_LAYER = "dv_ev_editor_gen3"
  local ACTION_LABEL = "IV/EV"

  local Pokemon = require("src.core.game3.pokemon")
  local PartyMenu = require("src.ui.game3.party_menu")
  local Stack = require("src.ui.game3.stack")
  local Window = require("src.ui.game3.window")
  local FrlgFont = require("src.ui.game3.frlg_font")

  local IV_MAX = 31
  local EV_MAX = 255

  local STATS = {
    { key = "hp",  label = "HP",      stat = "maxHp" },
    { key = "atk", label = "ATTACK",  stat = "attack" },
    { key = "def", label = "DEFENSE", stat = "defense" },
    { key = "spa", label = "SP. ATK", stat = "spAtk" },
    { key = "spd", label = "SP. DEF", stat = "spDef" },
    { key = "spe", label = "SPEED",   stat = "speed" },
  }

  local ALIASES = {
    hp = { "hp" },
    atk = { "atk", "attack" },
    def = { "def", "defense" },
    spa = { "spa", "spAtk", "specialAttack" },
    spd = { "spd", "spDef", "specialDefense" },
    spe = { "spe", "speed" },
  }

  local function clampInteger(value, minimum, maximum)
    value = math.floor(tonumber(value) or minimum)
    if value < minimum then return minimum end
    if value > maximum then return maximum end
    return value
  end

  local function aliasValue(t, key, fallback)
    if type(t) ~= "table" then return fallback end
    for _, k in ipairs(ALIASES[key] or { key }) do
      if t[k] ~= nil then return t[k] end
    end
    return fallback
  end

  local function ensureMon(mon)
    if type(mon) ~= "table" then return false end
    mon.ivs = mon.ivs or {}
    mon.evs = mon.evs or {}
    for _, row in ipairs(STATS) do
      mon.ivs[row.key] = clampInteger(aliasValue(mon.ivs, row.key, 0), 0, IV_MAX)
      mon.evs[row.key] = clampInteger(aliasValue(mon.evs, row.key, 0), 0, EV_MAX)
    end
    return true
  end

  local function monName(mon)
    if not mon then return "POKEMON" end
    if Pokemon.displayMonName then
      local ok, name = pcall(Pokemon.displayMonName, mon)
      if ok and name and name ~= "" then return tostring(name) end
    end
    local species = tonumber(mon.species or mon.speciesId)
    if species and Pokemon.name then
      local ok, name = pcall(Pokemon.name, species)
      if ok and name and name ~= "" then return tostring(name) end
    end
    return tostring(mon.nickname or mon.name or "POKEMON")
  end

  local function actualStat(mon, key)
    return math.floor(tonumber(mon and mon[key]) or 0)
  end

  local function effectiveEv(raw)
    return math.floor(clampInteger(raw, 0, EV_MAX) / 4)
  end

  local function totalEv(mon)
    local total = 0
    if type(mon) == "table" and type(mon.evs) == "table" then
      for _, row in ipairs(STATS) do
        total = total + clampInteger(mon.evs[row.key], 0, EV_MAX)
      end
    end
    return total
  end

  local function recalculate(mon)
    if not ensureMon(mon) then return false end
    local oldMax = math.max(1, tonumber(mon.maxHp or mon.maxhp) or 1)
    local oldHp = clampInteger(mon.hp, 0, oldMax)
    local missing = math.max(0, oldMax - oldHp)

    Pokemon.applyStats(mon)

    local newMax = math.max(1, tonumber(mon.maxHp or mon.maxhp) or oldMax)
    if oldHp <= 0 then
      mon.hp = 0
    else
      mon.hp = math.max(1, math.min(newMax, newMax - missing))
    end
    return true
  end

  local function maximizeIvEv(mon)
    if not ensureMon(mon) then return false end
    for _, row in ipairs(STATS) do
      mon.ivs[row.key] = IV_MAX
      mon.evs[row.key] = EV_MAX
    end
    return recalculate(mon)
  end

  local Editor = {
    open = false,
    mon = nil,
    page = 1,
    row = 1,
    editing = false,
    editValue = 0,
    editDigit = 1,
    editWidth = 2,
    editMax = IV_MAX,
    notice = nil,
    _partyReturnMode = "action",
    _partyActionCursor = 1,
  }

  local function se(id)
    pcall(function() require("src.core.game3.audio").playSe(id) end)
  end

  function Editor.isOpen()
    return Editor.open == true
  end

  function Editor.rowCount()
    return #STATS
  end

  function Editor.selectedRow()
    return STATS[Editor.row]
  end

  function Editor.setPage(page)
    if page < 1 then page = 2 elseif page > 2 then page = 1 end
    Editor.page = page
    Editor.editing = false
  end

  function Editor.startEdit()
    local row = Editor.selectedRow()
    if not row or not Editor.mon then return end
    if Editor.page == 1 then
      Editor.editValue = clampInteger(Editor.mon.ivs[row.key], 0, IV_MAX)
      Editor.editWidth = 2
      Editor.editMax = IV_MAX
    else
      Editor.editValue = clampInteger(Editor.mon.evs[row.key], 0, EV_MAX)
      Editor.editWidth = 3
      Editor.editMax = EV_MAX
    end
    Editor.editDigit = 1
    Editor.editing = true
    se(5)
  end

  function Editor.changeDigit(delta)
    local place = 10 ^ (Editor.editWidth - Editor.editDigit)
    Editor.editValue = clampInteger(Editor.editValue + delta * place, 0, Editor.editMax)
  end

  function Editor.applyEdit()
    local row = Editor.selectedRow()
    if not row or not Editor.mon then return end
    if Editor.page == 1 then
      Editor.mon.ivs[row.key] = clampInteger(Editor.editValue, 0, IV_MAX)
    else
      Editor.mon.evs[row.key] = clampInteger(Editor.editValue, 0, EV_MAX)
    end
    recalculate(Editor.mon)
    Editor.editing = false
    Editor.notice = "VALUES UPDATED"
    se(5)
  end

  function Editor.maxAll()
    if maximizeIvEv(Editor.mon) then
      Editor.editing = false
      Editor.notice = "MAX IVs + EVs"
      se(5)
    end
  end

  function Editor.show(mon)
    if not ensureMon(mon) then return false end
    recalculate(mon)
    Editor.mon = mon
    Editor.page = 1
    Editor.row = 1
    Editor.editing = false
    Editor.notice = nil
    Editor.open = true

    Editor._partyReturnMode = PartyMenu.mode or "action"
    Editor._partyActionCursor = PartyMenu.actionCursor or 1
    -- Hide Party OAM while the editor owns the top layer.
    PartyMenu.mode = "summary"
    if PartyMenu.reloadSprites then pcall(PartyMenu.reloadSprites) end

    Stack.push(EDITOR_LAYER, Editor, { hideBelow = true })
    return true
  end

  function Editor.close()
    Editor.open = false
    Stack.pop(EDITOR_LAYER)
    PartyMenu.mode = Editor._partyReturnMode or "action"
    PartyMenu.actionCursor = Editor._partyActionCursor or PartyMenu.actionCursor or 1
    if PartyMenu.reloadSprites then pcall(PartyMenu.reloadSprites) end
    Editor.mon = nil
    Editor.editing = false
    Editor.notice = nil
    se(9)
  end

  function Editor.handleInput(input)
    if not Editor.open or not input then return end

    if input:wasPressed("start") then
      Editor.maxAll()
      return
    end

    if Editor.editing then
      if input:wasPressed("left") then
        Editor.editDigit = Editor.editDigit > 1 and Editor.editDigit - 1 or Editor.editWidth
        se(5)
      elseif input:wasPressed("right") then
        Editor.editDigit = Editor.editDigit < Editor.editWidth and Editor.editDigit + 1 or 1
        se(5)
      elseif input:wasPressed("up") then
        Editor.changeDigit(1)
        se(5)
      elseif input:wasPressed("down") then
        Editor.changeDigit(-1)
        se(5)
      elseif input:wasPressed("a") then
        Editor.applyEdit()
      elseif input:wasPressed("b") then
        Editor.editing = false
        Editor.notice = nil
        se(9)
      end
      return
    end

    if input:wasPressed("up") then
      Editor.row = Editor.row > 1 and Editor.row - 1 or #STATS
      Editor.notice = nil
      se(5)
    elseif input:wasPressed("down") then
      Editor.row = Editor.row < #STATS and Editor.row + 1 or 1
      Editor.notice = nil
      se(5)
    elseif input:wasPressed("left") then
      Editor.setPage(Editor.page - 1)
      Editor.notice = nil
      se(5)
    elseif input:wasPressed("right") or input:wasPressed("select") then
      Editor.setPage(Editor.page + 1)
      Editor.notice = nil
      se(5)
    elseif input:wasPressed("a") then
      Editor.startEdit()
    elseif input:wasPressed("b") then
      Editor.close()
    end
  end

  local function normalColor()
    return FrlgFont.COLOR.NORMAL
  end

  local function grayColor()
    return FrlgFont.COLOR.DARK_GRAY or FrlgFont.COLOR.NORMAL
  end

  local function drawNativeValue(value, x, y, selected)
    local colors = selected and (FrlgFont.COLOR.BLUE or normalColor()) or normalColor()
    FrlgFont.draw(tostring(value), x, y, { colors = colors })
  end

  function Editor.draw()
    if not Editor.open or not Editor.mon then return end
    local G = love and love.graphics
    if G then
      G.setColor(0.08, 0.20, 0.38, 1)
      G.rectangle("fill", 0, 0, 240, 160)
      G.setColor(1, 1, 1, 1)
    end

    Window.stdFrame(Window.template(1, 1, 28, 18))
    local pageName = Editor.page == 1 and "IVs" or "EVs"
    FrlgFont.draw("IV/EV EDITOR", 14, 10, { colors = normalColor() })
    FrlgFont.draw(pageName .. "  " .. monName(Editor.mon) .. "  Lv" .. tostring(Editor.mon.level or 1),
      14, 24, { colors = normalColor(), maxWidth = 210 })

    if Editor.page == 1 then
      FrlgFont.draw("STAT", 28, 40, { colors = grayColor() })
      FrlgFont.draw("IV", 108, 40, { colors = grayColor() })
      FrlgFont.draw("FINAL", 168, 40, { colors = grayColor() })
    else
      FrlgFont.draw("STAT", 22, 40, { colors = grayColor() })
      FrlgFont.draw("EV", 92, 40, { colors = grayColor() })
      FrlgFont.draw("EFF", 132, 40, { colors = grayColor() })
      FrlgFont.draw("FINAL", 178, 40, { colors = grayColor() })
    end

    for i, row in ipairs(STATS) do
      local y = 54 + (i - 1) * 14
      local selected = (Editor.row == i)
      if selected then Window.cursorPx(13, y) end
      FrlgFont.draw(row.label, 24, y, { colors = normalColor(), maxWidth = 64 })
      if Editor.page == 1 then
        local v = Editor.mon.ivs[row.key] or 0
        if selected and Editor.editing then v = Editor.editValue end
        drawNativeValue(string.format("%02d", v), 110, y, selected)
        FrlgFont.draw(tostring(actualStat(Editor.mon, row.stat)), 180, y, { colors = normalColor() })
      else
        local v = Editor.mon.evs[row.key] or 0
        if selected and Editor.editing then v = Editor.editValue end
        drawNativeValue(string.format("%03d", v), 88, y, selected)
        FrlgFont.draw(string.format("%02d", effectiveEv(v)), 135, y, { colors = normalColor() })
        FrlgFont.draw(tostring(actualStat(Editor.mon, row.stat)), 190, y, { colors = normalColor() })
      end
    end

    if Editor.page == 2 then
      local total = totalEv(Editor.mon)
      FrlgFont.draw("TOTAL EV " .. tostring(total) .. " / 510", 14, 139,
        { colors = total > 510 and (FrlgFont.COLOR.RED or normalColor()) or grayColor() })
    end

    local footer
    if Editor.notice then
      footer = Editor.notice
    elseif Editor.editing then
      footer = "L/R DIGIT  U/D VALUE  A OK  B CANCEL"
    else
      footer = "L/R PAGE  A EDIT  B BACK  START MAX"
    end
    FrlgFont.draw(footer, 14, 148, { colors = normalColor(), maxWidth = 215, small = true })
  end

  -- High-resolution overlay. It sits above the native 240x160 fallback and
  -- remains compatible with Gen3 Modern UI because it only draws for our layer.
  local fonts = {}
  local function uiFont(size)
    if not (love and love.graphics and love.graphics.newFont) then return nil end
    size = math.max(10, math.floor(size))
    if not fonts[size] then
      local ok, f = pcall(love.graphics.newFont, size)
      if ok then fonts[size] = f end
    end
    return fonts[size]
  end

  local function setColor(c)
    love.graphics.setColor(c[1], c[2], c[3], c[4] or 1)
  end

  local function roundRect(mode, x, y, w, h, r)
    love.graphics.rectangle(mode, x, y, w, h, r, r)
  end

  local function drawModern(viewport)
    if not Editor.open or not Editor.mon or not viewport or not love or not love.graphics then return end
    local top = Stack.top()
    if not (top and top.id == EDITOR_LAYER) then return end

    local G = love.graphics
    local x = viewport.gameX or 0
    local y = viewport.gameY or 0
    local w = viewport.gameWidth or viewport.width or 960
    local h = viewport.gameHeight or viewport.height or 640
    if w < 320 or h < 200 then return end

    local s = math.max(0.75, math.min(w / 720, h / 480))
    local pad = 18 * s
    local headerH = 64 * s
    local footerH = 44 * s
    local bodyY = y + pad + headerH
    local bodyH = h - pad * 2 - headerH - footerH
    local rowGap = 7 * s
    local rowH = (bodyH - rowGap * 5) / 6

    setColor({0.035, 0.09, 0.18, 0.97})
    roundRect("fill", x, y, w, h, 12 * s)

    setColor({0.12, 0.32, 0.66, 1})
    roundRect("fill", x + pad, y + pad, w - pad * 2, headerH - 8 * s, 12 * s)
    setColor({0.95, 0.20, 0.20, 1})
    roundRect("fill", x + pad, y + pad, 8 * s, headerH - 8 * s, 4 * s)

    local titleFont = uiFont(22 * s)
    local bodyFont = uiFont(16 * s)
    local smallFont = uiFont(13 * s)
    if titleFont then G.setFont(titleFont) end
    setColor({1,1,1,1})
    G.print("IV / EV EDITOR", x + pad + 22 * s, y + pad + 9 * s)
    if smallFont then G.setFont(smallFont) end
    setColor({0.84,0.90,1,1})
    G.print(monName(Editor.mon) .. "   Lv." .. tostring(Editor.mon.level or 1),
      x + pad + 22 * s, y + pad + 37 * s)

    local tabW = 72 * s
    local tabX = x + w - pad - tabW * 2 - 8 * s
    local tabY = y + pad + 10 * s
    local tabs = { "IVs", "EVs" }
    for i = 1, 2 do
      setColor(i == Editor.page and {1.0,0.82,0.16,1} or {0.16,0.25,0.38,1})
      roundRect("fill", tabX + (i - 1) * (tabW + 8 * s), tabY, tabW, 30 * s, 8 * s)
      if smallFont then G.setFont(smallFont) end
      setColor(i == Editor.page and {0.08,0.10,0.15,1} or {1,1,1,1})
      G.printf(tabs[i], tabX + (i - 1) * (tabW + 8 * s), tabY + 7 * s, tabW, "center")
    end

    for i, row in ipairs(STATS) do
      local ry = bodyY + (i - 1) * (rowH + rowGap)
      local selected = Editor.row == i
      setColor(selected and {0.12,0.31,0.57,0.98} or {0.075,0.13,0.22,0.98})
      roundRect("fill", x + pad, ry, w - pad * 2, rowH, 10 * s)
      if selected then
        setColor({1.0,0.82,0.16,1})
        roundRect("fill", x + pad, ry, 6 * s, rowH, 3 * s)
      end

      if bodyFont then G.setFont(bodyFont) end
      setColor({1,1,1,1})
      G.print(row.label, x + pad + 18 * s, ry + rowH * 0.27)

      local rawX = x + w * 0.43
      local finalX = x + w * 0.77
      if Editor.page == 1 then
        local v = Editor.mon.ivs[row.key] or 0
        if selected and Editor.editing then v = Editor.editValue end
        setColor({0.65,0.78,1.0,1})
        G.print("IV", rawX, ry + 7 * s)
        setColor({1,1,1,1})
        G.print(string.format("%02d / 31", v), rawX, ry + rowH * 0.45)
      else
        local v = Editor.mon.evs[row.key] or 0
        if selected and Editor.editing then v = Editor.editValue end
        setColor({0.65,0.78,1.0,1})
        G.print("EV", rawX, ry + 5 * s)
        setColor({1,1,1,1})
        G.print(string.format("%03d / 255", v), rawX, ry + rowH * 0.40)
        if smallFont then G.setFont(smallFont) end
        setColor({0.75,0.80,0.86,1})
        G.print("Effective " .. tostring(effectiveEv(v)) .. "/63", rawX, ry + rowH * 0.70)
      end

      if bodyFont then G.setFont(bodyFont) end
      setColor({0.65,0.78,1.0,1})
      G.print("STAT", finalX, ry + 7 * s)
      setColor({1,1,1,1})
      G.print(tostring(actualStat(Editor.mon, row.stat)), finalX, ry + rowH * 0.45)
    end

    local fy = y + h - pad - footerH + 8 * s
    if smallFont then G.setFont(smallFont) end
    if Editor.page == 2 then
      local tev = totalEv(Editor.mon)
      setColor(tev > 510 and {1.0,0.40,0.34,1} or {0.78,0.86,0.96,1})
      G.print("TOTAL EV: " .. tostring(tev) .. " / 510", x + pad, fy)
    end
    setColor({0.90,0.94,1,1})
    local hint = Editor.editing
      and "LEFT/RIGHT digit   UP/DOWN value   A confirm   B cancel   START max all"
      or "LEFT/RIGHT page   UP/DOWN stat   A edit   B back   START max all"
    G.printf(hint, x + pad, fy + 19 * s, w - pad * 2, "center")

    if Editor.notice then
      local nw = 190 * s
      local nh = 38 * s
      setColor({1.0,0.82,0.16,0.98})
      roundRect("fill", x + (w - nw) / 2, y + h - pad - footerH - nh - 10 * s, nw, nh, 10 * s)
      if bodyFont then G.setFont(bodyFont) end
      setColor({0.08,0.10,0.15,1})
      G.printf(Editor.notice, x + (w - nw) / 2, y + h - pad - footerH - nh + 1 * s, nw, "center")
    end
    G.setColor(1,1,1,1)
  end

  local function hasAction(actions)
    for _, label in ipairs(actions or {}) do
      if label == ACTION_LABEL or label == "DV/EV" then return true end
    end
    return false
  end

  local function insertEditorAction()
    if PartyMenu._battle then return end
    local mon = PartyMenu._party and PartyMenu._party[PartyMenu.cursor]
    if not mon or mon.isEgg or mon.egg then return end
    local actions = PartyMenu.ACTIONS
    if type(actions) ~= "table" or hasAction(actions) then return end
    local at = #actions + 1
    for i, label in ipairs(actions) do
      if label == "SUMMARY" then at = i + 1 break end
    end
    table.insert(actions, at, ACTION_LABEL)
  end

  local patchKey = "_dvEvEditorGen3Patch"
  if not PartyMenu[patchKey] then
    local previousHandleInput = PartyMenu.handleInput
    PartyMenu[patchKey] = {
      owner = MOD_ID,
      version = VERSION,
      previous = previousHandleInput,
    }

    PartyMenu.handleInput = function(input)
      -- If another screen/state rebuilt the action list, re-insert our row.
      if PartyMenu.mode == "action" and not PartyMenu._battle then
        insertEditorAction()
        local selected = PartyMenu.ACTIONS and PartyMenu.ACTIONS[PartyMenu.actionCursor]
        if selected == ACTION_LABEL and input and input.wasPressed and input:wasPressed("a") then
          local mon = PartyMenu._party and PartyMenu._party[PartyMenu.cursor]
          if mon and not mon.isEgg and not mon.egg then
            se(5)
            Editor.show(mon)
            return
          end
        end
      end

      local before = PartyMenu.mode
      previousHandleInput(input)
      if before == "list" and PartyMenu.mode == "action" and not PartyMenu._battle then
        insertEditorAction()
      end
    end
  end

  if mod.hooks and mod.hooks.wrap then
    mod.hooks:wrap("render.hud", function(nextFn, game, viewport)
      local result = nextFn(game, viewport)
      if Editor.open then
        pcall(drawModern, viewport)
      end
      return result
    end, 0)
  end

  mod.exports = mod.exports or {}
  mod.exports.IV_MAX = IV_MAX
  mod.exports.EV_MAX = EV_MAX
  mod.exports.effectiveEv = effectiveEv
  mod.exports.totalEv = totalEv
  mod.exports.recalculate = recalculate
  mod.exports.maximizeIvEv = maximizeIvEv
  mod.exports.Editor = Editor
  mod.exports.actionLabel = ACTION_LABEL

  if mod.log and mod.log.info then
    mod.log:info("DV EV Editor Gen 3 v%s loaded - IV/EV party action, START = MAX ALL", VERSION)
  end
end
