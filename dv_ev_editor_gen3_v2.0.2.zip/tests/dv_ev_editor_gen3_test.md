# DV EV Editor Gen 3 v2.0.2 smoke-test checklist

- Manifest ID is `dv_ev_editor_gen3`.
- Manifest target is exactly `firered`.
- No executable `src.*.gen2` references exist.
- Party action injection occurs only outside battle and skips Eggs.
- `IV/EV` is inserted after `SUMMARY` and deduplicated.
- IV values clamp to 0..31.
- EV values clamp to 0..255.
- START max sets all six IVs to 31 and all six EVs to 255.
- Stat recalculation calls Game3 `Pokemon.applyStats` and preserves missing HP/fainted state.
- Editor stack layer is `dv_ev_editor_gen3` and returns to the Party action menu on B.
