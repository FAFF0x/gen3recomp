# Changelog

## 2.0.2

- Native FireRed/Game3 port of the Gen2 v2.0.1 editor.
- Replaces Gen2 DVs with six Gen3 IVs (`0–31`).
- Replaces Gen2 Stat EXP with six Gen3 EV bytes (`0–255`).
- Adds separate HP / Attack / Defense / Sp. Atk / Sp. Def / Speed rows.
- Shows effective EV contribution (`floor(EV/4)`, `0–63`) and total EV count.
- Adds `IV/EV` after `SUMMARY` in the normal FireRed party action menu.
- Excludes battle party menus and Eggs.
- Uses `Pokemon.applyStats` for immediate Gen3 stat recalculation.
- Preserves missing HP and fainted state when stats are recalculated.
- START now sets all IVs to 31 and all raw EV bytes to 255.
- Adds a high-resolution editor overlay compatible with Gen3 Modern UI while retaining a native Game3 fallback.
- Uses a Gen3-only mod ID and namespace to avoid collision with `dv_ev_editor_gen2`.
