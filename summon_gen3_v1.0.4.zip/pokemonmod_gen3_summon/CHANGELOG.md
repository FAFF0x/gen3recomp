# Changelog

## 1.0.4
- Added LeafGreen support alongside FireRed.
- Updated manifest targets to `firered` and `leafgreen`.
- Replaced the FireRed-only runtime export with FRLG `game` and `supportedGames` metadata.
- Kept the shared Game3 Pokemon, Start Menu, Stack and WorldAPI wild-battle flow unchanged.
- Preserved the existing `pokemonmod_gen3_summon` id so this version upgrades the current mod instead of creating a duplicate.

## v1.0.3
- fixed pixelated/unreadable text introduced by v1.0.2;
- SUMMON is now presented in high-resolution window space through `render.hud`;
- layout mirrors the default Gen3 Modern UI palette and spacing;
- native 240x160 layer remains only as the input/state fallback;
- added optional dependency metadata for `gen3_modern_ui`.

## v1.0.2
- first Modern UI-styled visual pass (240x160; superseded by v1.0.3).

## v1.0.1
- first FireRed / Gen3 release.
