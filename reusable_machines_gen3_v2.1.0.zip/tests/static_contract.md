# Static contract

- manifest.games contains ["firered", "leafgreen"]
- no `src.*.gen2` executable references
- TM consumption is suppressed only while PartyMenu teaches the matching TM or during direct ItemUse.useTm
- HM forget bypass is scoped to active LearnMove.begin flows
- no custom UI replaces TM Case, Party Menu, Summary, or LearnMove


## v2.1.0 extended species
- Gen 1-3 species keep native FRLG `Pokemon.canLearnTmIndex` behavior
- Gen 4+ species fall back to the embedded National Dex 58-machine compatibility table
- actual ItemUse preflight and Party compatibility preview use the same patched Pokemon API
- National Dex fallback currently covers #001-#1025
- no blanket "all Pokemon can learn all TMs" bypass
