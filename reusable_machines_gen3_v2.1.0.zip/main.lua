-- Reusable Machines - Gen 3 / FireRed + LeafGreen
-- v2.1.0
--
-- 1) TM01-TM50 are not consumed after a successful teach.
-- 2) HM moves may be replaced during the normal Game3 learn-move flow.
-- 3) The native FRLG TM Case / Party / Summary UI remains engine-owned.
--
-- Coexistence: patches are stored on the actual Game3 modules so a second
-- equivalent build does not wrap the same functions twice.

local ItemsData = require("src.core.game3.items_data")
local Bag = require("src.core.game3.bag")
local Pokemon = require("src.core.game3.pokemon")
local ItemUse = require("src.core.game3.item_use")
local PartyMenu = require("src.ui.game3.party_menu")
local LearnMove = require("src.core.game3.battle.learn_move")
local Stack = require("src.ui.game3.stack")
local FrlgFont = require("src.ui.game3.frlg_font")

local DISPATCH_KEY = "__reusableMachinesGen3DispatchV1"
local unpack_ = table.unpack or unpack

-- Extended machine compatibility for National Dex species beyond the original
-- FRLG roster. Each dex number owns 16 hex chars: lo32 + hi26 bits for the
-- native TM01-TM50/HM01-HM08 order. Gen 1-3 continue to use the ROM bitfield.
local EXTENDED_TMHM_MAX_DEX = 1025
local EXTENDED_TMHM_PACKED = [[
843d872000e41e09843d873000e41e09863dc73000e41e09cc51063300a61ee5cc51063300a61ee5ce71463300ae5ef5cc53326503b01e41cc53326503b01e41ce53727503b01e4100000000000000000000000000000000b43f46200040be8100000000000000000000000000000000c435462000c43e898413062000087e818413062000087e818413462000087e81add33e2000843e0aadd37e3000a43e0a8413062000087e808413462000087e808e57062000213f488e57462000213f48cdd3822900f03e03cddbc22900f03e03ce59062100a43ed0ce59462100a43ed08dd3362400a43e8b8dd3362400a43e8befd37e3500b43fff8dd3362400a43e0b8dd3362400a43e0befd37e3500b43f7ffdfbb62d00e1be27fdfbf62d00e1be278c59063000021e25ac79463800021e25fdbbbe2d0061be37fdbbfe2d0061be37a4170e2000097f88a4174e2000097f888435072000441e098435072000441e09843d472000441e09cc35872000c43e89cc35c72000c43e89943506200040be09943546200040be898e11062000843ed88e11462000843ed8add30e2400453f82add34e3400453f82dc53ba6d03f0be80dc53fa6d03f0be80cfd30ea100a23ec0cfd34ea100a23ec08c59063000a23ea58c79463000a23ea59c13326503103e00de13326503b03e00de137ae503b03e40b45b8e290041bf03bc5b8e290041bf03bc5bce290041bf03ce1386a100a03e64ce1386a100a03e64ce13c6a100a03e648435072000443e098435072000443e098435472000443e09841f326403143e09841f726403143e09ce11062100a01e74ce11062100a01e74ce11463100a01e748471062000221e258471462000221e25be5bb66c03709e25fe5bf66d03f09ea58593862000400e138593c62000400e1384510620000c7e818413062000087e8184134e2000087f81845b326403303e00845b726403303e00ad970e2000203f7eed974e2100a03f7e8413326403101e018413f26403101f01b5970e200001bf08b5970e200001bf08f5974e2100a1bf088e510e3000a01f50f41b8e290041bf01f41bce290041bf01cc13326402b43e40cc13726402b43e4085938a2000402f038593ca2000402f03943587200060be099635c7280060be09ce51362100a03ef4ce51762100a03ef4c6130ea100a03e40c6130ea100a03e40eff3762500b43e76a5930e2000403f2ea5934e2000403f2e8fd3363000a03e76cfd3763100b43e76f7fbf66d00e1be778435472000c43e0beffb767500b43ef68413326403101e008413726403101e008413326403101e008413726403101e009593b26403501e019593f26403509e01f5bbce290041bf83c41bc62000847e80f413fa6d0040bf01d5d3caa100e03e03d4514e3100a23e24ce1346a100a43e40aff3762400b03e76000000000000000087d37e7403b01f3597fb727403b01e030000000000000000ac53063800001e01ac53767c03b01e01add3c63800e01e03ac53463800a21e25b5f3762000402e838413326403903e518413726403903e518c17326401903ed1cc17726403943ed186534e3200a87ff5ffb3762500b01e778413f67400884e918593c67000c84e93843b4630008a4eb585dbf66401101e2785dbf66401101e27c7dbf67703bc5ef7f7fbfeed02e18ff7ffffffff03ffffff847d872000441e01847d872000e41e01867dc72000e41e018c51063000061ea4cc51063100a61ea4ee71463900a61ee4cc53326703143ec0cc53327703b43ec0ce53727703b43ec0edf3362500143e06edf3762500b43e06b41306280048fe81b41346280048fe81cc3d862100403e81cc3dc62100e03e819c35062000403e089c35462000403e08a4174e2000097f888593326403501e028593726403501e0285d3822000501e03bc7b862c00401e27bc3b862400401e27b43b862400c01e27f43bc62500c85ea7b43786280040fe81b437c6280048fe818ddb862000401e03cddb863100e01e03cddbc63100e01e03843d472000441e08cc53b26503b01e00cc53f26503b01e00ce114e2900a03f50de13726503b03e008437872000403e818435872000403e818437c72000403e81edf30e2500a53e82843f872000441e08843fc72000441e08b435062000407e808e5b326403d01e58ce5b726503f03e58bc53c63800449e01bc53ce380045bf01b4134e2800097f80fe5bf66d03f09e65b5934e280041bf8200000200000000000008000000000000b7d3c62800e0be038e37862000a01e518e37c62000a01e51aff3762c00a03e76ce530e2000a47fd88e514e3000a41f50efb30eb500a23f2feff34eb500a23f6fa4133a6403101e0ac41bc62000a47e908e19062000e01e58ce1347a100a43ec0ec533e6d00b53f81ce130eb100a43fc0ce134eb100a43fc08611862000821e758631c62000a21e758e13b27000a01e518e13f27000a01e51be1bb66c00b01e519413772403103e249413772403103e2cc413726500087e808613736403101ec084114e3000cc7fd0a4730e3000833f2ca4734e3000a33f2c8413726403101e008e53063000a03e508e53463000a03e50b5f3762000402e82bff3c6380040be030000000000000000c61306a000a03e00ce1306a000a03e90b413b26c0040be01d5938a2100c03e02d451062100823e24e7f3762500b01e52f7fbf66d00e1be76add3c63800e40e13ac73463800e60e35ac53767c03940e11ce534e2000801f50ce534e2000801fd0cfd37e3700b41ff6b7dff67c03f8ce93b7bfc63800ea4eb7b43fc62c00448e93cc7d072100e43ec0cc7d072100e43ec0ce7d473300e43ec08c11062000a61ee4cc1106a100a63ee4ce3146b100a63ee48c53327403b01e40ce53327503b01e40ce5372f503b01e40ac530e3000813f00ac534e3000a13f00add3362400943e02add3763400b43e0200000000000000000000000000000000b43d462000403e800000000000000000b435c62000403e888437376400503e00c437376403f03e00c437776503f03e00ac37072000c01e00ec37472000e43f40ec374f2000e43fc08413062000087e808413462000087e808413326401187e828413726401187e82b49b8e280041bf03b49bce280041bf03b49bce280041bf03a437362401503e00a437762401503e80843f072000411e08cc7f47a100e51ec8e5b336a500a43ee6efb33eb500a43ee6efb37eb500a43ee6ac35062000440e90ac35462000443e90ac35462000442e90a433363400001e26e6333e3400a21f66e6337e3400b21f66ce130ea100b03e40ce134ea100b03e408453b26401101e0087910e2000a01f52adfb362c00401e02adfb762c00e01e02fc17cead00c5bfc3e4335e2100a01f7c8e53063400a41ed28e53063400a41ed2cff37e3700b41ef6f4138ea900e0bec1f413cea900e0bec185d3823000603e0685d3c23000623e0685d3822000409e0285d3822000401e02e5b78e2500403e82e5b7862500403e82a437072000441e08a437172400a13e0ae637572400a13e0a84133a6403103f0086137a7403b03f408613327403b01e408613727403b01e408e13063000a21e748e33463000a21e748671462000a21e7cb4538e280041bf03fc53ce290041bf03fc1b062d00e1be428e35462000a01e508e35462200a85ed08e75462200a85ef4cc37072100443e10ec374f2100643e10843b162000087e80867b563200887ea4edf77e3500b03ee6ce574e2000a13e0cb61bf26800408e51b63bc62800428e758613366403101e508613766403b01e50cc133a6401b43ec8cc137a6403b43ec8be3b962800408e51be3bd62800e08e518435072000401e588e35472000e01e58cc11062400841ed0ce51462400a41ed08453b26403101e00845bf26403101e00a5b3366400403e36edf3362500e5bee6b5930e280041bf02b5934e280041bf02b4133e280041bf00f6137e2900e1bf40863f473000ec5e80b41b8e2800419f03a5d37e6c00e53ff60008000000000000a41bb26400401e00a61bfa6400401f008653326403b01e408653327403b01e408653727403b01e408413326403101e008413726403111e40b41b726403101e00861b726c03901e50841b326403101e00c413063200a41ee4c413063200a41ee4c653463200ac5ee40000000000000000f613c62100e40ed9f613c62100e40ed9cf99462100a00e52c79b726100a00e42c79b462100a00ed2b7bbd63e035c5e93b7bbd63e035c5e93c79b727c03b00e42cff946b300a60ef6c7f376b603ba0ef6b59bc62c00408e93f5bbde2d00e58fc3847d873000e41e01847d873000e41e01867dc73000e41e51cc510ea100a63fe4cc510ea100a63fe4ce714eb900a63fe4cc13326403141ec0cc13326403b41ec0ce13727403b45ec08413062000087e808413062000087e808413462000087e80add33e2000843e02add37e2503b43e020000000000000000c4174e2000e41e8085d3863000603e0285d3863000603e0285d3c63000603e02a437072000441e08a437472000441e088fd3363000a03e76cfd3763300b43e768fd33e3000a01f768fd37e3000a01f770001020000000000bc3f47200040be00b43f46200040be80000000000000000084134e2000443e888dd3c62000443e82cc533af503b03e40cc537af503b03f40843d072000401e00843d472000401e008413326403101e508e13726403f01e58edf34e2500a53e82b5930628004cbe82b5934628004cbe82acf3162500841e02adf3762500a41e02b5934e280041bf82b4134e2800097f80add30e2400453f82add34e3400453f82b41b8e2800419f03ac530e3000853f2cac534e3000a53f2cb63b862800408e51b63bc62800e08e51ce11062800003e50f5bb8e290041bf03b43b866400401e2684130e2000087f80b4134e2c0041bf428e53063200a41ef48e53063200a41ef4ce53463200b41ef4ffb3362500b01e76ce5306b100a01ec0fe5346bd00a01ec08e51063400a01e508e51463400a01e50ec530e2000e43fc8ee534e3000e43fc8ee130ea100a13fc8ee134ea100a53fc88435472000443e08841b326403503e00841b726403503e008613326403101e80a47fb36400401e00e67ff36500e01e40ec537e6d00b53f818593c62000400e13eff3762500b43e76cfd3763100b43e76c635472000e43ecbdfd3caa100e03f47d6f14e3100a23f64f43bc62500c85ea7b435462000407e80ac77473800e01e80ac53767c00a01e00ce534e2000a47fd88e13f27000a01e51b5f3762000402e82f69bcea900e5bfc387914e2000a01f52f6137e2900e1bf40b59bfa6400411f03a593862000412e03b5ffc62c00408e13b5dbf62c00408e13b5dbce2c00408f37c7db76b200e60ef6c79b76f703b40ef68e314e3000a21f74c79b462100a00ec2b7db463a00ac4e82b5bbd62800409e01841b326403100e00b41bf26c03508e01f5937e2900e52fca943d472000400e00f7fffffe03fe0efff5b9ce2000c28e24843d8f2800441f81843d8f2800441f81843dcf2800e41f818c310e3000a21e64cc310eb100a21e64ce314eb100a21e648c133a6403943e80cc133a6403943e80cc137a6403b43e80ac93062000041e00ad93c62000e41e04ac93063000801ec0ac93063000b01ec0ad93463000b01ec0a4530e2000043f80a4534e2000843f808c310e2000c43f40cc314e2000c43f408c310e2000863f64cc314e2000863f648c133a6003943f40cc137a6003943f40b41b822800409f41b41bc22800409f4184130e2000085e8084130e2000085e8084134e2000085e808593862000401e008593ce3000c21e008611022000a01e508611022000a01e508631422000a01e50b41f8a280048ff81b41fca280048ff81ce11062000a41ed8ce11462000a41ed8bdfbf62800509e25cc130ea100a03e40cc130ea100a03e40ce134ea100a03e408413026000101e088413026000901e08ce13426002b01e48ce130ea000a01e40ce130ea000a01e40843f862800441e00843f862800441e00843fc72800445e818431062000801e088431062000801e088e71462000a41e48843d0e2000401e00b43dce2000403e00843d072000441e00843dc72000441e0084137a6403141e00ce510a3000043f58ce510a3300a43fd8ce514ab300a43fd8cc310e3000a23e64de314eb000a23f64843f072000001e808e31022000a41ed08e31422000a41ed0cc530eb300a03f48cc534eb300a03f48b43bd2280048fe81b41b02280040be00b41b42280040be008e53322003b01e508e53722003b01e508e510a3200845fd08e514a32008c5fd08417062000003e0894b7462000003e08ac130e3800043f88fc134e3800843f8c8cdb072800003e008ddbc72800003e00b49b8a280040bf41b49b8a280040bf41f49bca280040bf41b51b862800409e41b51b862800409e41b51bc62900e09e418413126402185e808413526402185e808413ba6000001e008413ba6000001e008413fa6000001e00ac3f872000401e00ac3fc72000c41e0085f38a2000441e808417022000041e8084174a2000841e808437072000401e088437472000401e08b41f3a6003501e08b41f7a6003501e08b41bf26c03109e008597822000443e008597c22000443e0084b5072000c01e0085b5472000e41e908491422000800e108491422000800e108591422000800e1000000000000000008597822000401e00c597c6b300e41e44b49b82280040fe41b49bc2280040fe41b4390e2800423e24b4390e2800423e24b4394e2800423e24cc530e3200b41ec0cc530e3200b41ec0ce534e3200b41ec08c133a6500b43ec0ce137af502b43ec08433f26400001e018417022000001e088417422000001e188f93022000501e58cc130ea900a01ec1cc134ea900a01ec18e534e3200b41fccfe1b162100e02e51febb562100e82e51cc130a2000843fd0cc134a2000843fd086130e2000b41ec0841306a000ac5ec0841346a000ac5ec0a4130e20008c7fc0a4134e20008c7fd08c370e2000863ee48c11022000a41ed084130e3000a03f0084130e3000a03f0086534e3000b87f65943d862800021e24943fc628000a1ea4c41b4e3800a40e91c6194a3800a40ed1c43dcf3800e40e81d4534ea000a83f98d5d34ea000a83f08b43bc63200ae4e65f59bc63300ec4e41de534ea800a81e58b41bf67200ac4ec1c41b4e7c00b40e81f59bc62900e08e0095b5f22000480e85cc370fb100e41ec9cc370fb100e41ec9ce374fb300e41ec9943b86280006be24943b86280006be24b43bc6280006be258c133a2403b43ec08c133a2403b43ec0cc137a2403b43ec0ce5102a000b43f58ce5142a000b43f5884130e20000a7e8084130e20000a7ea484334ea0000a7ea400000000000000000001000000000000943fc62800403e808c330e3000a23e248c334e3000a23e24943f862800401e00943f862800409e00943fc62800409e00cc3707b000b01e00ce3747b000b01e80cc130eb000b41fc8ce134eb200b43fc88c13063000d01e00b4db862800449f01bcdbc62800449f01c413022000841e81c413022000841e81e413462000841e819493862800409f019593c62800409f01949b862800503e04959bc62800503e0494938e280044bf859493ce280044bf85ce1b3a2000b43fd8ce1b7aa202b43fd8a4d3026403103e08a5d3426403103e088453322403143e08a453722403143e088dd3822000541e508df3c62000541e50ce51063200a01ed0ce51463200a01ed084dbf27800c01e5197dbf27800c01e51bc5bc63800449e01cc134ea100ac7fc08dd3c62000443e80941bc66800408e5184d3062400001e0885d3362400001e0887d3766700b01e2c941bc62800043f11bc3f062000a4be01be3f462800a4be01b43d872000c0be2cb43dc72000c0be2c841b326000f01e40861b727000f01e40f4710e22000c7f80f4714e26000c7f849593c67800440e01b4134e22000c6f80ce59462000a00e10941bc66800408e51f49bce290040af51ce334e3400a60e7c843f872000005a80843f872000005a80e43fcfa100005ac084110eb000021b2484110eb000021b24c6114eb100023ba48453326403101a008453326403101a00b453f26c03101a01c411072000087a80c411072000087a80c4114720000a7a808e130e2000003b508e134e3100003b508c93822000001a008d93822000001a008db3c22000081a00ce1306a100003a40ce1376e100003a40841b0e2800085a90941986280000ba819439c6280000ba818c510a3000001a50cc510eb000001a508653126003101a00841b326400101a08841bf26400101a088611063000001a508611463000001a508417322401101a00841f722403101a01843d072000001a00c43f472000001a80843d862000001a08843fc62000001a0884510e2200023b2c84514e2200023b2cc6110ab000001ac0c6114ab200001ac0843d872000001a01843d872000001a01843dcf2000001a01843dcf2800003a00f79bce2800009a01e6534ea100003ac084130a6001101a00c4137ae003101ac8b617062000009a58b617462000009a58800b8860000018018413467200000a90a493567200104a949639c22800001a51c61346a80000324086714eb200021a6485d1422000003a01b59fcea000003a00941bfaac01101b81a7bbf63a00185a24e637462000103a80c6590ab300001ad0c6590eb300001ad0c65b4eb300001ad4859bca3800086b81b599ce280000ab01443dcfb800000b41a41bfa2803100b010000000000000000000000000000000097f9c63800000a65b5bbf63800080a819599822000000a59c6110aa000000a40c4117a2000000b0085b3c62800000a018635422000080a24c415022800000880c651422200002a6cd631c62800002ad1f4b1d60800008a01e41142a800002a400451022000000a0884d1422200082aac0619822000008a51b431ce2800022b24c5d14aa800000a800081002000000a0043a1502000000a4000250d0000003a0000250d0000003a0042254d8100003a0000010c0000021a2400010c8000021a2420014c8000021a24000b800403101a01000b800403101a01200bf80403101a010841010000003a000a43450000003a000001080000083a8000010c0000083a800003cc8000087a8100000000000000003029800800009a01302dc00800009a010801080000003a003801480000003a000025850000001a000025c50000001a000001000000001a000001400000001a000003000403101a000a43700403101a500981000000001a000981408000001a000801000000001a510801040000021a750a21440000021a7500000000000010000025450000081a80022fc50000001a010a01000000001a500a01400000001a500003700402187a804003000403101a004003700403101a000001000000001a0041834c2000003a080001040000001a000021440000021a244001088003001a004801488003101a003005000800008a003005c00800008a01100d800800009a01100d800800009a01300dc00800009a010001880000003a010001880000003a014001c88100003a0169c37c8000103a0069c34c0000003a003a0ff44800101a514001040000005a0071abfc480000ba01320b48080000ba500001000000001a00102dc00800001a004003448000000a400183400000101a000001000000001a00000df04800001a010209440000001a500003704403101a013001000800009a004181090000003a004a01000000001a504a01480000001a5003c34c0200000a6401c3784000100a400203400003100a400003704003100a4041a1c01200001a410001000000001a002181840002107a2521a1c40202187a254841400000000a00486bc41000000a112023c42000080a2d4801008100001a804801089100001ac048654d9100002ac00183c00000000a010201c00200000a010001785000000a003001480800000a00102dc50800008a013ba3c4180000aa014001c40000002ad04a034c9100002ac02003700401100a0068034ca900002ac82003782001100a0810034c0800080a080025090000000a000025090000000a80602549000000aa800801041000020a240801041000020a242a21441000020a240003000000100a800003000400100a804003488400100a800803050000002a000803450000002a000007050000002a0040070d0000002ac00003040000002a0040030c0000002a800983040000002a000983040100002a004983448100002a4008030d0400002a8008034d0400002a800803041000000a000803441000000a000025050000000a000025050000000a000025c50000000a0100014c0000082a800a03040000000a100a03440000000a104a03440100000a50000104000002022430218c0800020a2560018c8200020a2501838004000008010183c024000008010181000000080a800181400000080a8008030c1000002a0008034c1000002a0008030c2000002a0808030c2000002a082025010000002a002025410000002a0000278920000008090027c920000008094803440000002a500025050000002a100025450000022a340801000000002a483803c4080000aa59100384080000aa113003c4080000aa91000180000000aa41400180000000aa41400180000000aa410803300400100a100803700400100a1000034c00000822d00003300401100a000003788501100a0000030c200000221800034c2000022a1800834c0200022a800a01400000000a500003842000000a590023c42000000a592803041000002a102803441000002a100001488400082a800203700400000a000203700400000a0010037004011008000203400401100a000003480400100a006b834c8100022a400a03402401100a583383c4180000aa012ba3742800002a744803480000002ad04a014c9000000a501983f49c00000a7500254d0000002a0021814c08000008004207448000000a900381c40000000a110301400000000a500003780400002a004381400100000a4000034c1000080a641021c42000020a244b837c0200000a740803300200000a004803300200000a804a03700200000a8020018000000028013181c001000028110027cd0000000a014003680000000a800a014c0000000a501001cc0000020a254a014c1200080aa47081c8080000888148214c9300020a2401a1c80a00020a010003441601100a044025480800000a800025450000000a0120250008000008012025400800000801480148b100002a483001c82800002a082001c82800082a8840270d0000000a5043a1c01200000a410227450000000a010201441200020a2403a14c1800000a005201480000000ad05001400800000a0003a3543c00100a042001002000000808
]]

local function extendedTmhmPair(nationalDex)
  nationalDex = math.floor(tonumber(nationalDex) or 0)
  if nationalDex < 1 or nationalDex > EXTENDED_TMHM_MAX_DEX then return nil, nil end
  local pos = (nationalDex - 1) * 16 + 1
  local lo = tonumber(EXTENDED_TMHM_PACKED:sub(pos, pos + 7), 16)
  local hi = tonumber(EXTENDED_TMHM_PACKED:sub(pos + 8, pos + 15), 16)
  return lo, hi
end

local function extendedCanLearnTmIndex(species, tmIndex)
  species = tonumber(species)
  tmIndex = tonumber(tmIndex)
  if not species or not tmIndex or tmIndex < 0 or tmIndex > 57 then return false end

  local national = nil
  if Pokemon.national then
    local ok, value = pcall(Pokemon.national, species)
    if ok then national = tonumber(value) end
  end

  -- Expansion packs commonly keep the internal index equal to National Dex.
  -- Use that only when no explicit national mapping is available.
  if not national and species >= 387 and species <= EXTENDED_TMHM_MAX_DEX then
    national = species
  end

  -- Original Kanto/Johto/Hoenn species keep exact FRLG ROM compatibility.
  if not national or national <= 386 then return false end

  local lo, hi = extendedTmhmPair(national)
  if not lo then return false end
  if tmIndex < 32 then
    return math.floor(lo / (2 ^ tmIndex)) % 2 == 1
  end
  return math.floor(hi / (2 ^ (tmIndex - 32))) % 2 == 1
end

local function pack(...)
  return { n = select("#", ...), ... }
end

local function sameItem(a, b)
  local na = ItemsData.toNumericId(a) or tonumber(a)
  local nb = ItemsData.toNumericId(b) or tonumber(b)
  if na and nb then return na == nb end
  return tostring(a) == tostring(b)
end

local function isMachine(id)
  return ItemsData.isTm(id) == true
end

local function isHM(id)
  return ItemsData.isHm(id) == true
end

local function isTM(id)
  return isMachine(id) and not isHM(id)
end

local function machineLabel(itemId, fallback)
  if not isMachine(itemId) then return fallback end
  local num = ItemsData.tmNumber(itemId)
  local prefix = isHM(itemId) and "HM" or "TM"
  local moveId = Pokemon.moveFromTmItem(itemId)
  local moveName = moveId and Pokemon.moveName(moveId) or nil
  local machine = num and string.format("%s%02d", prefix, num)
    or ItemsData.displayName(itemId)
    or fallback
    or tostring(itemId)
  if moveName and moveName ~= "" then
    return tostring(machine) .. " " .. tostring(moveName)
  end
  return tostring(machine)
end

local function compatibility(mon, itemId)
  if not mon then return "empty", "EMPTY" end
  if mon.isEgg then return "egg", "EGG" end
  local moveId = Pokemon.moveFromTmItem(itemId)
  if not moveId then return "invalid", "NOT ABLE" end
  if Pokemon.knowsMove(mon, moveId) then return "learned", "LEARNED" end
  local species = tonumber(mon.species or mon.speciesId)
  if species and Pokemon.canLearnTmItem(species, itemId) then
    return "able", "CAN LEARN"
  end
  return "unable", "NOT ABLE"
end

local compatFonts = {}
local function compatFont(size)
  size = math.max(10, math.floor((tonumber(size) or 11) + 0.5))
  if compatFonts[size] then return compatFonts[size] end
  if not (love and love.graphics and love.graphics.newFont) then return nil end
  local ok, f = pcall(love.graphics.newFont, size)
  if ok and f then
    if f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    compatFonts[size] = f
    return f
  end
  return nil
end

local COMPAT_COLORS = {
  able = { 0.12, 0.66, 0.34, 0.96 },
  learned = { 0.16, 0.48, 0.86, 0.96 },
  unable = { 0.78, 0.22, 0.22, 0.96 },
  egg = { 0.42, 0.44, 0.48, 0.94 },
  invalid = { 0.42, 0.44, 0.48, 0.94 },
}

local function roundRect(mode, x, y, w, h, r)
  if love.graphics.rectangle then
    love.graphics.rectangle(mode, x, y, w, h, r or 4, r or 4)
  end
end

-- Drawn after Modern UI (hook priority 200). The PartyMenu remains the owner
-- of input/state; this is presentation-only and therefore composes with it.
local function drawCompatibilityOverlay(viewport)
  if not (love and love.graphics) then return end
  local top = Stack.top and Stack.top() or nil
  if not (top and top.id == "party") then return end
  if not (PartyMenu.isOpen and PartyMenu.isOpen()) then return end
  if PartyMenu.mode ~= "use" or not isMachine(PartyMenu._item) then return end

  local itemId = PartyMenu._item
  local party = PartyMenu._party or {}
  local x = tonumber(viewport and viewport.gameX) or 0
  local y = tonumber(viewport and viewport.gameY) or 0
  local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
  local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
  if w <= 0 or h <= 0 then return end

  -- Mirror Modern UI's default Party geometry. At native 240x160 this still
  -- degrades into a compact readable overlay instead of touching save data.
  local s = math.max(0.64, math.min(w / 720, h / 480))
  local pad = math.max(9, 13 * s)
  local gap = math.max(6, 9 * s)
  local headerH = math.max(42, 49 * s)
  local footerH = math.max(27, 30 * s)
  local contentY = y + headerH
  local contentH = h - headerH - footerH
  local gx = x + pad
  local gy = contentY + gap
  local gw = w - pad * 2
  local gh = contentH - gap * 2
  local cellW = (gw - gap) / 2
  local cellH = (gh - gap * 2) / 3

  love.graphics.push("all")
  love.graphics.setScissor(x, y, w, h)

  -- Current machine indicator in the header.
  local title = machineLabel(itemId, ItemsData.displayName(itemId))
  local titleFont = compatFont(math.max(10, 12 * s))
  if titleFont then love.graphics.setFont(titleFont) end
  local tw = titleFont and titleFont:getWidth(title) or (#title * 7)
  local th = math.max(18, 22 * s)
  local tx = x + w * 0.50 - tw * 0.5 - 9 * s
  local ty = y + math.max(8, (headerH - th) * 0.5)
  love.graphics.setColor(0.06, 0.10, 0.16, 0.88)
  roundRect("fill", tx, ty, tw + 18 * s, th, th * 0.45)
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.print(title, tx + 9 * s, ty + math.max(2, 3 * s))

  for i = 1, 6 do
    local mon = party[i]
    if mon then
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local cx = gx + col * (cellW + gap)
      local cy = gy + row * (cellH + gap)
      local kind, label = compatibility(mon, itemId)
      local c = COMPAT_COLORS[kind] or COMPAT_COLORS.unable
      local f = compatFont(math.max(10, 11 * s))
      if f then love.graphics.setFont(f) end
      local textW = f and f:getWidth(label) or (#label * 6)
      local badgeH = math.max(18, 20 * s)
      local badgeW = math.max(textW + 16 * s, 58 * s)
      local bx = cx + cellW - badgeW - 8 * s
      local by = cy + cellH - math.max(35 * s, badgeH + 11 * s)
      love.graphics.setColor(c[1], c[2], c[3], c[4])
      roundRect("fill", bx, by, badgeW, badgeH, badgeH * 0.45)
      if i == (PartyMenu.cursor or 1) then
        love.graphics.setColor(1, 1, 1, 0.92)
        love.graphics.setLineWidth(math.max(1, 1.5 * s))
        roundRect("line", bx - 1, by - 1, badgeW + 2, badgeH + 2, badgeH * 0.45)
      end
      love.graphics.setColor(1, 1, 1, 1)
      local py = by + math.max(1, (badgeH - (f and f:getHeight() or 11)) * 0.5)
      love.graphics.printf(label, bx, py, badgeW, "center")
    end
  end

  love.graphics.setScissor()
  love.graphics.pop()
end

local function nativeCompatibilityLabel(kind)
  if kind == "able" then return "ABLE" end
  if kind == "learned" then return "LEARNED" end
  if kind == "egg" then return "EGG" end
  return "NOT ABLE"
end

local NATIVE_BADGE_POS = {
  [1] = { x = 12, y = 67, w = 70 },
  [2] = { x = 174, y = 13, w = 61 },
  [3] = { x = 174, y = 37, w = 61 },
  [4] = { x = 174, y = 61, w = 61 },
  [5] = { x = 174, y = 85, w = 61 },
  [6] = { x = 174, y = 109, w = 61 },
}

local function drawNativeCompatibility()
  if not (PartyMenu.isOpen and PartyMenu.isOpen()) then return end
  if PartyMenu.mode ~= "use" or not isMachine(PartyMenu._item) then return end
  for i = 1, 6 do
    local mon = PartyMenu._party and PartyMenu._party[i]
    local pos = NATIVE_BADGE_POS[i]
    if mon and pos then
      local kind = compatibility(mon, PartyMenu._item)
      local label = nativeCompatibilityLabel(kind)
      pcall(FrlgFont.draw, label, pos.x, pos.y, { maxWidth = pos.w, small = true, colors = FrlgFont.COLOR.WHITE })
    end
  end
end

return function(mod)
  local dispatch = rawget(Bag, DISPATCH_KEY)
  if not dispatch then
    dispatch = {
      owners = {},
      hmForgetDepth = 0,
      directTmDepth = 0,
      directTmItem = nil,
      extendedCompatPatched = false,
    }
    rawset(Bag, DISPATCH_KEY, dispatch)
  end
  dispatch.owners[mod.id or "reusable_machines_gen3"] = true

  -- Gen 4+ species are not present in FireRed/LeafGreen's original TM/HM
  -- bitfield. Keep the original result when it is true; otherwise consult the
  -- extended National Dex compatibility table. Patching canLearnTmIndex makes
  -- the actual ItemUse preflight and the Party compatibility preview agree.
  if not dispatch.extendedCompatPatched then
    dispatch.extendedCompatPatched = true
    dispatch.baseCanLearnTmIndex = Pokemon.canLearnTmIndex
    Pokemon.canLearnTmIndex = function(species, tmIndex)
      if dispatch.baseCanLearnTmIndex(species, tmIndex) then return true end
      return extendedCanLearnTmIndex(species, tmIndex)
    end
  end

  local function modernUiActive()
    if not (mod.find and type(mod.find) == "function") then return false end
    local ok, handle = pcall(mod.find, mod, "gen3_modern_ui")
    if not ok or not handle then return false end
    local exp = handle.exports
    if exp and type(exp.isActive) == "function" then
      local okA, active = pcall(exp.isActive)
      if okA then return active == true end
    end
    return true
  end

  if not dispatch.partyCompatibilityDrawPatched then
    dispatch.partyCompatibilityDrawPatched = true
    dispatch.basePartyDraw = PartyMenu.draw
    PartyMenu.draw = function(...)
      local result = pack(dispatch.basePartyDraw(...))
      if not modernUiActive() then drawNativeCompatibility() end
      return unpack_(result, 1, result.n)
    end
  end

  -- -----------------------------------------------------------------------
  -- Reusable TM consumption
  --
  -- FRLG removes a TM only after teaching succeeds. In the normal UI that
  -- removal happens while PartyMenu is still open with PartyMenu._item set to
  -- the machine being taught. Suppress exactly that matching removal. Selling
  -- and tossing happen outside this context and therefore remain untouched.
  if not dispatch.bagRemovePatched then
    dispatch.bagRemovePatched = true
    dispatch.baseBagRemove = Bag.remove
    Bag.remove = function(bag, id, qty, ...)
      if isTM(id) then
        local partyOwnsTeach = PartyMenu
          and PartyMenu.isOpen and PartyMenu.isOpen()
          and PartyMenu._item ~= nil
          and sameItem(PartyMenu._item, id)
        local directTeach = dispatch.directTmDepth > 0
          and dispatch.directTmItem ~= nil
          and sameItem(dispatch.directTmItem, id)
        if partyOwnsTeach or directTeach then
          -- Match Bag.remove's successful return without changing inventory.
          return true
        end
      end
      return dispatch.baseBagRemove(bag, id, qty, ...)
    end
  end

  -- Non-UI callers can still use ItemUse.useTm directly. Mark only the
  -- duration of that call so its synchronous successful TM consume is skipped.
  if not dispatch.itemUseTmPatched then
    dispatch.itemUseTmPatched = true
    dispatch.baseUseTm = ItemUse.useTm
    ItemUse.useTm = function(session, bag, id, partySlot, ...)
      if not isTM(id) then
        return dispatch.baseUseTm(session, bag, id, partySlot, ...)
      end
      dispatch.directTmDepth = dispatch.directTmDepth + 1
      local prev = dispatch.directTmItem
      dispatch.directTmItem = id
      local result = pack(pcall(dispatch.baseUseTm, session, bag, id, partySlot, ...))
      dispatch.directTmItem = prev
      dispatch.directTmDepth = math.max(0, dispatch.directTmDepth - 1)
      if not result[1] then error(result[2], 0) end
      return unpack_(result, 2, result.n)
    end
  end

  -- -----------------------------------------------------------------------
  -- Forgettable HM during the normal move-learning flow only.
  --
  -- Game3 protects HMs in Pokemon.replaceMove, LearnMove and SummaryMenu via
  -- Pokemon.isHmMove(). Keep the protection everywhere else, but report false
  -- while LearnMove.begin owns an active learn/replace flow. This mirrors the
  -- Gen2 mod's scope: move learning can replace an HM; unrelated screens do
  -- not gain a global HM-delete bypass.
  if not dispatch.hmMovePatched then
    dispatch.hmMovePatched = true
    dispatch.baseIsHmMove = Pokemon.isHmMove
    Pokemon.isHmMove = function(moveId)
      if dispatch.hmForgetDepth > 0 then return false end
      return dispatch.baseIsHmMove(moveId)
    end
  end

  if not dispatch.learnMovePatched then
    dispatch.learnMovePatched = true
    dispatch.baseLearnBegin = LearnMove.begin
    LearnMove.begin = function(opts, ...)
      opts = opts or {}
      local wrapped = {}
      for k, v in pairs(opts) do wrapped[k] = v end
      local baseDone = opts.onDone
      local finished = false
      local function release(...)
        if not finished then
          finished = true
          dispatch.hmForgetDepth = math.max(0, dispatch.hmForgetDepth - 1)
        end
        if baseDone then return baseDone(...) end
      end
      wrapped.onDone = release
      dispatch.hmForgetDepth = dispatch.hmForgetDepth + 1
      local result = pack(pcall(dispatch.baseLearnBegin, wrapped, ...))
      if not result[1] then
        release(false)
        error(result[2], 0)
      end
      -- begin() may complete synchronously and call wrapped.onDone itself.
      return unpack_(result, 2, result.n)
    end
  end

  -- Compatibility preview for TM/HM target selection. Higher hook priority
  -- makes this paint after Modern UI's render.hud presenter.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    if modernUiActive() then drawCompatibilityOverlay(viewport) end
    return result
  end, 200)

  mod.exports.isMachine = isMachine
  mod.exports.isTM = isTM
  mod.exports.isHM = isHM
  mod.exports.machineLabel = machineLabel
  mod.exports.compatibility = compatibility
  mod.exports.extendedCanLearnTmIndex = extendedCanLearnTmIndex
  mod.exports.extendedTmhmMaxDex = EXTENDED_TMHM_MAX_DEX
  mod.exports.extendedCompatibility = true
  mod.exports.version = "2.1.0"
  mod.exports.game = "frlg"
  mod.exports.generation = 3
  mod.exports.supportedGames = { "firered", "leafgreen" }

  if mod.log and mod.log.info then
    mod.log:info("Reusable Machines Gen 3 v2.1.0 installed: reusable TM/HM + extended National Dex machine compatibility")
  end
end
