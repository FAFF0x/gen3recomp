# Changelog

## 1.0.1

- Ported Performance Monitor to FireRed / Generation 3 only.
- Changed manifest target to `games: ["firered"]` and mod id to `pokemonmod_gen3_performance_monitor`.
- Replaced Gen 2 overworld/stack lookups with FireRed `game3` Runtime, Map and Stack data.
- FireRed session/options are now used in diagnostic environment snapshots.
- Changed report identity to `pokemon-recomp-gen3-performance-report`.
- Namespaced instrumentation markers as Gen 3 markers.
- Removed logic that could unwrap another performance-monitor mod's runtime wrappers.
- Kept storage exports isolated under this mod's unique id.
- Preserved FPS, frame-time, renderer, memory, hook/event attribution, provenance callbacks, slow-frame analysis and 10-second diagnostics.
- Kept `conflicts` and `incompatible` empty.
