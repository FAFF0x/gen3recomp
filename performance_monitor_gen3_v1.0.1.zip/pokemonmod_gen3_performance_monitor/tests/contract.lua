-- Lightweight contract test for the FireRed / Gen 3 port.
local registeredHooks, registeredEvents = {}, {}

local function makeMod(generation)
  return {
    generation = generation,
    hooks = {
      wrap = function(_, name, cb, priority)
        registeredHooks[name] = { cb = cb, priority = priority }
        return function() end
      end,
    },
    events = {
      on = function(_, name, cb, priority)
        registeredEvents[name] = { cb = cb, priority = priority }
        return function() end
      end,
    },
    exports = {},
    log = {
      info = function() end,
      warn = function() end,
      error = function(_, msg) error(msg) end,
    },
  }
end

local chunk = assert(loadfile(arg[1]))
local install = assert(chunk())

-- Hard runtime generation guard.
registeredHooks, registeredEvents = {}, {}
install(makeMod(2))
assert(next(registeredHooks) == nil and next(registeredEvents) == nil,
  "Gen 3 monitor activated for a non-Gen3 mod context")

-- Gen 3 installs only the shared input/render seams plus game.ready.
registeredHooks, registeredEvents = {}, {}
local mod = makeMod(3)
install(mod)
assert(registeredHooks["input.step"], "input.step hook not registered")
assert(registeredHooks["render.hud"], "render.hud hook not registered")
assert(registeredEvents["game.ready"], "game.ready event not registered")
assert(type(mod.exports.getSnapshot) == "function", "snapshot export missing")
assert(type(mod.exports.getDiagnosticReport) == "function", "diagnostic export missing")
assert(type(mod.exports.exportDiagnosticReport) == "function", "report export missing")

-- Shared hook contracts must preserve downstream behavior.
local stepCalls = 0
local stepResult = registeredHooks["input.step"].cb(function(game, dt)
  stepCalls = stepCalls + 1
  return "step-ok", game, dt
end, { phase = "field" }, 1/60)
assert(stepCalls == 1 and stepResult == "step-ok", "input.step downstream contract broken")

local hudCalls = 0
local hudResult = registeredHooks["render.hud"].cb(function(game, viewport)
  hudCalls = hudCalls + 1
  return "hud-ok"
end, { phase = "field" }, { gameX = 0, gameY = 0 })
assert(hudCalls == 1 and hudResult == "hud-ok", "render.hud downstream contract broken")

-- A minimal FireRed game.ready event must be safe even when no other mods exist.
registeredEvents["game.ready"].cb({ game = { phase = "field", session = { map = "FR_PALLET_TOWN" } } })

print("performance-monitor-gen3-contract-ok")
