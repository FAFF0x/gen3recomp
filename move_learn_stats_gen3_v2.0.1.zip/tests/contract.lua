local root = os.getenv("MOD_ROOT") or "."

local SummaryMenu = {
  open = true,
  _mode = "select_move",
  _cursor = 1,
  _moveCursor = 2,
  _moveToLearn = 85,
  _hmNotice = false,
}
local mon = {
  moves = { 33, 45, 57, 15 },
  maxPp = { 35, 40, 18, 30 },
}
SummaryMenu._party = { mon }

local defs = {
  [33] = { name = "TACKLE", power = 40, accuracy = 100, pp = 35, type = 0 },
  [45] = { name = "GROWL", power = 0, accuracy = 100, pp = 40, type = 0 },
  [57] = { name = "SURF", power = 95, accuracy = 100, pp = 15, type = 11 },
  [15] = { name = "CUT", power = 50, accuracy = 95, pp = 30, type = 0 },
  [85] = { name = "THUNDERBOLT", power = 95, accuracy = 100, pp = 15, type = 13 },
}
local names = { [33]="TACKLE", [45]="GROWL", [57]="SURF", [15]="CUT", [85]="THUNDERBOLT" }

package.preload["src.core.game3.pokemon"] = function()
  return {
    moveIdAt = function(m, s) return m.moves[s] end,
    battleMove = function(id) return defs[tonumber(id)] end,
    moveName = function(id) return names[tonumber(id)] end,
    isHmMove = function(id) return tonumber(id) == 15 end,
  }
end
package.preload["src.ui.game3.summary_menu"] = function() return SummaryMenu end
package.preload["src.ui.game3.stack"] = function()
  return { top = function() return { id = "summary", mod = SummaryMenu } end }
end
package.preload["src.core.game3.summary_data"] = function()
  return { moveDescription = function(id) return "Description " .. tostring(id) end }
end

local hook
local mod = {
  exports = {},
  hooks = { wrap = function(_, name, fn, priority) hook = {name=name,fn=fn,priority=priority} end },
  find = function() return nil end,
  log = { warn=function() end, info=function() end },
}

assert(loadfile(root .. "/main.lua"))()(mod)
assert(mod.exports.version == "2.0.1")
assert(mod.exports.generation == 3 and mod.exports.game == "firered")
assert(mod.exports.active == true and mod.exports.deferredTo == nil)
assert(hook and hook.name == "render.hud" and hook.priority == 1200)

local ctx = assert(mod.exports.context())
assert(ctx.cursor == 2)
assert(ctx.selected.name == "GROWL" and ctx.selected.power == "---" and ctx.selected.pp == "40")
assert(ctx.learning.name == "THUNDERBOLT" and ctx.learning.power == "95")
assert(ctx.learning.type == "ELECTRIC" and ctx.learning.accuracy == "100")

SummaryMenu._moveCursor = 4
ctx = assert(mod.exports.context())
assert(ctx.selected.name == "CUT" and ctx.selected.hm == true)
SummaryMenu._moveCursor = 5
ctx = assert(mod.exports.context())
assert(ctx.cancel == true and ctx.selected == nil)

SummaryMenu._mode = nil
assert(mod.exports.context() == nil)

print("pokemonmod_gen3_move_learn_stats contract: ok")
