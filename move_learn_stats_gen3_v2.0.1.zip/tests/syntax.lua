local root = assert(os.getenv("MOD_ROOT"))
for _, name in ipairs({ "main.lua", "tests/contract.lua" }) do
  local chunk, err = loadfile(root .. "/" .. name)
  assert(chunk, err)
end
print("lua-syntax-ok")
