# Changelog

## 2.0.1 - FireRed / Gen 3 port

- Ported the mod from Gen2 to FireRed's native Game3 move-learning flow.
- Target is now exclusively `firered`.
- New isolated ID: `pokemonmod_gen3_move_learn_stats`.
- Removed all `Game2`, `ui.gen2` and `Gen2MoveDeleter` dependencies.
- Covers battle level-up, Rare Candy, TM/HM and evolution learning via `SummaryMenu` `select_move` mode.
- Adds SELECTED vs LEARNING comparison with type, power, accuracy and maximum PP.
- Adds HM warning and fifth-row cancel/keep-current-set handling.
- Adds window-space rendering compatible with `gen3_modern_ui`.
- Keeps duplicate-equivalent runtime defer protection without manifest conflicts.
