-- Move Learn Stats - Gen 3 (Pokemon MOD) v2.0.1
-- FireRed-only port of the Gen 2 mod.
--
-- FireRed funnels full-moveset learning (battle level-up, field level-up,
-- Rare Candy, TM/HM and evolution) through SummaryMenu's select_move mode.
-- This mod only observes that state and paints a comparison overlay. Native
-- FireRed remains authoritative for cursor/input, HM protection, cancellation,
-- move replacement, PP, messages, fanfares and item consumption.

local Pokemon = require("src.core.game3.pokemon")
local SummaryMenu = require("src.ui.game3.summary_menu")
local Stack = require("src.ui.game3.stack")
local SummaryData = require("src.core.game3.summary_data")

local MOD_ID = "pokemonmod_gen3_move_learn_stats"
local VERSION = "2.0.1"
local EQUIVALENT_MOD_IDS = { "move_learn_stats_gen3", "move_learn_stats" }

local TYPE_NAMES = {
  [0] = "NORMAL", [1] = "FIGHTING", [2] = "FLYING", [3] = "POISON",
  [4] = "GROUND", [5] = "ROCK", [6] = "BUG", [7] = "GHOST",
  [8] = "STEEL", [9] = "???", [10] = "FIRE", [11] = "WATER",
  [12] = "GRASS", [13] = "ELECTRIC", [14] = "PSYCHIC", [15] = "ICE",
  [16] = "DRAGON", [17] = "DARK",
}

local function moveIdAt(mon, slot)
  if not mon or not slot then return nil end
  if Pokemon and type(Pokemon.moveIdAt) == "function" then
    local ok, id = pcall(Pokemon.moveIdAt, mon, slot)
    if ok then return id end
  end
  local entry = mon.moves and mon.moves[slot]
  if type(entry) == "table" then
    return tonumber(entry.id or entry.move or entry.moveId or entry.num or entry[1])
  end
  return tonumber(entry)
end

local function typeName(v)
  if type(v) == "string" and v ~= "" then return string.upper(v) end
  return TYPE_NAMES[tonumber(v)] or tostring(v or "---")
end

local function maxPpFor(mon, slot, def)
  local entry = mon and mon.moves and slot and mon.moves[slot]
  if type(entry) == "table" and tonumber(entry.maxPp) then
    return math.max(0, math.floor(tonumber(entry.maxPp)))
  end
  if mon and type(mon.maxPp) == "table" and slot and tonumber(mon.maxPp[slot]) then
    return math.max(0, math.floor(tonumber(mon.maxPp[slot])))
  end
  return math.max(0, math.floor(tonumber(def and def.pp) or 0))
end

local function moveStats(moveId, mon, slot)
  moveId = tonumber(moveId)
  if not moveId or moveId <= 0 then return nil end
  local def = Pokemon.battleMove(moveId) or {}
  local name = Pokemon.moveName(moveId)
  if not name or name == "" or tostring(name):match("^MOVE ") then
    name = def.name or ("MOVE " .. tostring(moveId))
  end
  local power = tonumber(def.power) or 0
  local acc = tonumber(def.accuracy) or 0
  local desc = ""
  if SummaryData and type(SummaryData.moveDescription) == "function" then
    local ok, text = pcall(SummaryData.moveDescription, moveId, name)
    if ok and text then desc = tostring(text):gsub("\n", " ") end
  end
  local isHm = false
  if Pokemon and type(Pokemon.isHmMove) == "function" then
    local ok, v = pcall(Pokemon.isHmMove, moveId)
    isHm = ok and v == true
  end
  return {
    id = moveId,
    name = tostring(name or "---"),
    power = power > 0 and tostring(math.floor(power)) or "---",
    accuracy = acc > 0 and tostring(math.floor(acc)) or "---",
    pp = tostring(maxPpFor(mon, slot, def)),
    type = typeName(def.type or def.kind),
    description = desc,
    hm = isHm,
  }
end

local function context()
  if not (SummaryMenu and SummaryMenu.open and SummaryMenu._mode == "select_move") then return nil end
  local top = Stack and Stack.top and Stack.top() or nil
  if top and top.id and top.id ~= "summary" then return nil end
  local party = SummaryMenu._party or {}
  local mon = party[SummaryMenu._cursor or 1]
  local learnId = tonumber(SummaryMenu._moveToLearn)
  if not (mon and learnId and learnId > 0) then return nil end
  local cursor = math.max(1, math.min(5, math.floor(tonumber(SummaryMenu._moveCursor) or 1)))
  local selectedId = cursor <= 4 and moveIdAt(mon, cursor) or nil
  return {
    mon = mon,
    cursor = cursor,
    selected = selectedId and moveStats(selectedId, mon, cursor) or nil,
    learning = moveStats(learnId, nil, nil),
    learningId = learnId,
    cancel = cursor == 5,
    hmNotice = SummaryMenu._hmNotice == true,
  }
end

local fontCache = {}
local function font(size)
  size = math.max(10, math.floor(size + 0.5))
  if not fontCache[size] and love and love.graphics and love.graphics.newFont then
    local ok, f = pcall(love.graphics.newFont, size)
    if ok then
      if f and f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
      fontCache[size] = f
    end
  end
  return fontCache[size]
end

local function setColor(c, a)
  love.graphics.setColor(c[1], c[2], c[3], a or c[4] or 1)
end

local C = {
  navy = { 19/255, 41/255, 75/255, 1 },
  blue = { 49/255, 100/255, 190/255, 1 },
  pale = { 238/255, 245/255, 1, 1 },
  white = { 1, 1, 1, 1 },
  text = { 24/255, 36/255, 58/255, 1 },
  muted = { 92/255, 107/255, 132/255, 1 },
  yellow = { 1, 213/255, 58/255, 1 },
  red = { 224/255, 70/255, 70/255, 1 },
  green = { 47/255, 156/255, 96/255, 1 },
}

local function roundRect(mode, x, y, w, h, r)
  love.graphics.rectangle(mode, x, y, w, h, r, r)
end

local function text(str, x, y, size, color, align, width)
  local f = font(size)
  if f then love.graphics.setFont(f) end
  setColor(color or C.text)
  if width then
    love.graphics.printf(tostring(str or ""), x, y, width, align or "left")
  else
    love.graphics.print(tostring(str or ""), x, y)
  end
end

local function statLine(label, value, x, y, w, fs)
  text(label, x, y, fs, C.muted)
  text(value, x, y, fs, C.text, "right", w)
end

local function moveCard(stats, x, y, w, h, title, scale, selected)
  setColor(C.white, 0.97)
  roundRect("fill", x, y, w, h, 8 * scale)
  if selected then
    setColor(C.yellow, 0.96)
    love.graphics.setLineWidth(math.max(2, 3 * scale))
  else
    setColor(C.blue, 0.45)
    love.graphics.setLineWidth(math.max(1, 2 * scale))
  end
  roundRect("line", x, y, w, h, 8 * scale)

  local pad = 11 * scale
  text(title, x + pad, y + pad, 12 * scale, C.muted)
  if not stats then
    text("KEEP CURRENT MOVESET", x + pad, y + 31 * scale, 17 * scale, C.text)
    text("Selecting the fifth row cancels learning.", x + pad, y + 58 * scale,
      12 * scale, C.muted, "left", w - pad * 2)
    return
  end
  text(stats.name, x + pad, y + 28 * scale, 18 * scale, C.navy)
  local badgeW = math.min(w * 0.36, 96 * scale)
  setColor(C.pale)
  roundRect("fill", x + w - badgeW - pad, y + 27 * scale, badgeW, 25 * scale, 6 * scale)
  text(stats.type, x + w - badgeW - pad, y + 32 * scale, 11 * scale, C.blue, "center", badgeW)

  local sy = y + 64 * scale
  local sw = w - pad * 2
  statLine("POWER", stats.power, x + pad, sy, sw, 12 * scale)
  statLine("ACCURACY", stats.accuracy, x + pad, sy + 20 * scale, sw, 12 * scale)
  statLine("MAX PP", stats.pp, x + pad, sy + 40 * scale, sw, 12 * scale)
  if stats.hm then
    text("HM • CANNOT BE FORGOTTEN", x + pad, sy + 62 * scale, 11 * scale, C.red)
  elseif stats.description ~= "" then
    text(stats.description, x + pad, sy + 62 * scale, 11 * scale, C.muted, "left", sw)
  end
end

local function drawOverlay(viewport)
  local ctx = context()
  if not ctx or not (love and love.graphics) then return end
  local G = love.graphics
  local vx = tonumber(viewport and viewport.gameX) or 0
  local vy = tonumber(viewport and viewport.gameY) or 0
  local vw = tonumber(viewport and viewport.gameWidth) or G.getWidth()
  local vh = tonumber(viewport and viewport.gameHeight) or G.getHeight()
  if vw < 1 or vh < 1 then return end
  local s = math.max(0.72, math.min(vw / 960, vh / 640))
  local margin = math.max(10, 14 * s)
  local panelW = math.min(vw * 0.44, 430 * s)
  local panelH = math.min(vh - margin * 2, 372 * s)
  local x = vx + margin
  local y = vy + math.max(margin, (vh - panelH) / 2)

  setColor(C.navy, 0.94)
  roundRect("fill", x, y, panelW, panelH, 12 * s)
  setColor(C.yellow, 1)
  G.rectangle("fill", x, y, panelW, math.max(4, 5 * s))
  text("MOVE COMPARISON", x + 15 * s, y + 15 * s, 18 * s, C.white)
  text("Choose the move to replace", x + 15 * s, y + 42 * s, 12 * s, {0.78,0.84,0.94,1})

  local cardX = x + 12 * s
  local cardW = panelW - 24 * s
  local cardH = 129 * s
  moveCard(ctx.cancel and nil or ctx.selected, cardX, y + 69 * s, cardW, cardH,
    ctx.cancel and "SELECTED" or "SELECTED", s, true)
  moveCard(ctx.learning, cardX, y + 207 * s, cardW, cardH, "LEARNING", s, false)

  local footerY = y + panelH - 27 * s
  local warn = ctx.hmNotice or (ctx.selected and ctx.selected.hm)
  if warn then
    text("HM moves cannot be forgotten", x + 14 * s, footerY, 11 * s, C.red)
  else
    text("A REPLACE   •   B CANCEL", x + 14 * s, footerY, 11 * s, C.white)
  end
end

return function(mod)
  local deferredTo
  if type(mod.find) == "function" then
    for _, id in ipairs(EQUIVALENT_MOD_IDS) do
      local ok, handle = pcall(mod.find, id)
      if ok and type(handle) == "table" then
        deferredTo = id
        break
      end
    end
  end

  mod.exports = mod.exports or {}
  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "firered"
  mod.exports.active = deferredTo == nil
  mod.exports.deferredTo = deferredTo
  mod.exports.moveStats = moveStats
  mod.exports.context = context

  if deferredTo then
    if mod.log and type(mod.log.info) == "function" then
      mod.log:info("Move Learn Stats Gen3 deferred to active equivalent mod: %s", tostring(deferredTo))
    end
    return
  end

  if mod.hooks and type(mod.hooks.wrap) == "function" then
    -- High priority means this wrapper is outside ordinary UI overhauls; because
    -- it calls next() first, our comparison is painted last and remains visible
    -- above gen3_modern_ui without replacing its Summary presentation.
    mod.hooks:wrap("render.hud", function(next, game, viewport)
      local result = next(game, viewport)
      if context() then
        local ok, err = pcall(drawOverlay, viewport)
        if not ok and mod.log and type(mod.log.warn) == "function" then
          mod.log:warn("Move Learn Stats Gen3 overlay failed: %s", tostring(err))
        end
      end
      return result
    end, 1200)
  end

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info("[%s] v%s installed for FireRed Summary select_move", MOD_ID, VERSION)
  end
end
