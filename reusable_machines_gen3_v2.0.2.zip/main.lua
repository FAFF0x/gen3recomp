-- Reusable Machines - Gen 3 / FireRed
-- v2.0.2
--
-- 1) TM01-TM50 are not consumed after a successful teach.
-- 2) HM moves may be replaced during the normal Game3 learn-move flow.
-- 3) The native FireRed TM Case / Party / Summary UI remains engine-owned.
--
-- Coexistence: patches are stored on the actual Game3 modules so a second
-- equivalent build does not wrap the same functions twice.

local ItemsData = require("src.core.game3.items_data")
local Bag = require("src.core.game3.bag")
local Pokemon = require("src.core.game3.pokemon")
local ItemUse = require("src.core.game3.item_use")
local PartyMenu = require("src.ui.game3.party_menu")
local LearnMove = require("src.core.game3.battle.learn_move")
local Stack = require("src.ui.game3.stack")
local FrlgFont = require("src.ui.game3.frlg_font")

local DISPATCH_KEY = "__reusableMachinesGen3DispatchV1"
local unpack_ = table.unpack or unpack

local function pack(...)
  return { n = select("#", ...), ... }
end

local function sameItem(a, b)
  local na = ItemsData.toNumericId(a) or tonumber(a)
  local nb = ItemsData.toNumericId(b) or tonumber(b)
  if na and nb then return na == nb end
  return tostring(a) == tostring(b)
end

local function isMachine(id)
  return ItemsData.isTm(id) == true
end

local function isHM(id)
  return ItemsData.isHm(id) == true
end

local function isTM(id)
  return isMachine(id) and not isHM(id)
end

local function machineLabel(itemId, fallback)
  if not isMachine(itemId) then return fallback end
  local num = ItemsData.tmNumber(itemId)
  local prefix = isHM(itemId) and "HM" or "TM"
  local moveId = Pokemon.moveFromTmItem(itemId)
  local moveName = moveId and Pokemon.moveName(moveId) or nil
  local machine = num and string.format("%s%02d", prefix, num)
    or ItemsData.displayName(itemId)
    or fallback
    or tostring(itemId)
  if moveName and moveName ~= "" then
    return tostring(machine) .. " " .. tostring(moveName)
  end
  return tostring(machine)
end

local function compatibility(mon, itemId)
  if not mon then return "empty", "EMPTY" end
  if mon.isEgg then return "egg", "EGG" end
  local moveId = Pokemon.moveFromTmItem(itemId)
  if not moveId then return "invalid", "NOT ABLE" end
  if Pokemon.knowsMove(mon, moveId) then return "learned", "LEARNED" end
  local species = tonumber(mon.species or mon.speciesId)
  if species and Pokemon.canLearnTmItem(species, itemId) then
    return "able", "CAN LEARN"
  end
  return "unable", "NOT ABLE"
end

local compatFonts = {}
local function compatFont(size)
  size = math.max(10, math.floor((tonumber(size) or 11) + 0.5))
  if compatFonts[size] then return compatFonts[size] end
  if not (love and love.graphics and love.graphics.newFont) then return nil end
  local ok, f = pcall(love.graphics.newFont, size)
  if ok and f then
    if f.setFilter then pcall(f.setFilter, f, "linear", "linear") end
    compatFonts[size] = f
    return f
  end
  return nil
end

local COMPAT_COLORS = {
  able = { 0.12, 0.66, 0.34, 0.96 },
  learned = { 0.16, 0.48, 0.86, 0.96 },
  unable = { 0.78, 0.22, 0.22, 0.96 },
  egg = { 0.42, 0.44, 0.48, 0.94 },
  invalid = { 0.42, 0.44, 0.48, 0.94 },
}

local function roundRect(mode, x, y, w, h, r)
  if love.graphics.rectangle then
    love.graphics.rectangle(mode, x, y, w, h, r or 4, r or 4)
  end
end

-- Drawn after Modern UI (hook priority 200). The PartyMenu remains the owner
-- of input/state; this is presentation-only and therefore composes with it.
local function drawCompatibilityOverlay(viewport)
  if not (love and love.graphics) then return end
  local top = Stack.top and Stack.top() or nil
  if not (top and top.id == "party") then return end
  if not (PartyMenu.isOpen and PartyMenu.isOpen()) then return end
  if PartyMenu.mode ~= "use" or not isMachine(PartyMenu._item) then return end

  local itemId = PartyMenu._item
  local party = PartyMenu._party or {}
  local x = tonumber(viewport and viewport.gameX) or 0
  local y = tonumber(viewport and viewport.gameY) or 0
  local w = tonumber(viewport and viewport.gameWidth) or love.graphics.getWidth()
  local h = tonumber(viewport and viewport.gameHeight) or love.graphics.getHeight()
  if w <= 0 or h <= 0 then return end

  -- Mirror Modern UI's default Party geometry. At native 240x160 this still
  -- degrades into a compact readable overlay instead of touching save data.
  local s = math.max(0.64, math.min(w / 720, h / 480))
  local pad = math.max(9, 13 * s)
  local gap = math.max(6, 9 * s)
  local headerH = math.max(42, 49 * s)
  local footerH = math.max(27, 30 * s)
  local contentY = y + headerH
  local contentH = h - headerH - footerH
  local gx = x + pad
  local gy = contentY + gap
  local gw = w - pad * 2
  local gh = contentH - gap * 2
  local cellW = (gw - gap) / 2
  local cellH = (gh - gap * 2) / 3

  love.graphics.push("all")
  love.graphics.setScissor(x, y, w, h)

  -- Current machine indicator in the header.
  local title = machineLabel(itemId, ItemsData.displayName(itemId))
  local titleFont = compatFont(math.max(10, 12 * s))
  if titleFont then love.graphics.setFont(titleFont) end
  local tw = titleFont and titleFont:getWidth(title) or (#title * 7)
  local th = math.max(18, 22 * s)
  local tx = x + w * 0.50 - tw * 0.5 - 9 * s
  local ty = y + math.max(8, (headerH - th) * 0.5)
  love.graphics.setColor(0.06, 0.10, 0.16, 0.88)
  roundRect("fill", tx, ty, tw + 18 * s, th, th * 0.45)
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.print(title, tx + 9 * s, ty + math.max(2, 3 * s))

  for i = 1, 6 do
    local mon = party[i]
    if mon then
      local col = (i - 1) % 2
      local row = math.floor((i - 1) / 2)
      local cx = gx + col * (cellW + gap)
      local cy = gy + row * (cellH + gap)
      local kind, label = compatibility(mon, itemId)
      local c = COMPAT_COLORS[kind] or COMPAT_COLORS.unable
      local f = compatFont(math.max(10, 11 * s))
      if f then love.graphics.setFont(f) end
      local textW = f and f:getWidth(label) or (#label * 6)
      local badgeH = math.max(18, 20 * s)
      local badgeW = math.max(textW + 16 * s, 58 * s)
      local bx = cx + cellW - badgeW - 8 * s
      local by = cy + cellH - math.max(35 * s, badgeH + 11 * s)
      love.graphics.setColor(c[1], c[2], c[3], c[4])
      roundRect("fill", bx, by, badgeW, badgeH, badgeH * 0.45)
      if i == (PartyMenu.cursor or 1) then
        love.graphics.setColor(1, 1, 1, 0.92)
        love.graphics.setLineWidth(math.max(1, 1.5 * s))
        roundRect("line", bx - 1, by - 1, badgeW + 2, badgeH + 2, badgeH * 0.45)
      end
      love.graphics.setColor(1, 1, 1, 1)
      local py = by + math.max(1, (badgeH - (f and f:getHeight() or 11)) * 0.5)
      love.graphics.printf(label, bx, py, badgeW, "center")
    end
  end

  love.graphics.setScissor()
  love.graphics.pop()
end

local function nativeCompatibilityLabel(kind)
  if kind == "able" then return "ABLE" end
  if kind == "learned" then return "LEARNED" end
  if kind == "egg" then return "EGG" end
  return "NOT ABLE"
end

local NATIVE_BADGE_POS = {
  [1] = { x = 12, y = 67, w = 70 },
  [2] = { x = 174, y = 13, w = 61 },
  [3] = { x = 174, y = 37, w = 61 },
  [4] = { x = 174, y = 61, w = 61 },
  [5] = { x = 174, y = 85, w = 61 },
  [6] = { x = 174, y = 109, w = 61 },
}

local function drawNativeCompatibility()
  if not (PartyMenu.isOpen and PartyMenu.isOpen()) then return end
  if PartyMenu.mode ~= "use" or not isMachine(PartyMenu._item) then return end
  for i = 1, 6 do
    local mon = PartyMenu._party and PartyMenu._party[i]
    local pos = NATIVE_BADGE_POS[i]
    if mon and pos then
      local kind = compatibility(mon, PartyMenu._item)
      local label = nativeCompatibilityLabel(kind)
      pcall(FrlgFont.draw, label, pos.x, pos.y, { maxWidth = pos.w, small = true, colors = FrlgFont.COLOR.WHITE })
    end
  end
end

return function(mod)
  local dispatch = rawget(Bag, DISPATCH_KEY)
  if not dispatch then
    dispatch = {
      owners = {},
      hmForgetDepth = 0,
      directTmDepth = 0,
      directTmItem = nil,
    }
    rawset(Bag, DISPATCH_KEY, dispatch)
  end
  dispatch.owners[mod.id or "reusable_machines_gen3"] = true

  local function modernUiActive()
    if not (mod.find and type(mod.find) == "function") then return false end
    local ok, handle = pcall(mod.find, mod, "gen3_modern_ui")
    if not ok or not handle then return false end
    local exp = handle.exports
    if exp and type(exp.isActive) == "function" then
      local okA, active = pcall(exp.isActive)
      if okA then return active == true end
    end
    return true
  end

  if not dispatch.partyCompatibilityDrawPatched then
    dispatch.partyCompatibilityDrawPatched = true
    dispatch.basePartyDraw = PartyMenu.draw
    PartyMenu.draw = function(...)
      local result = pack(dispatch.basePartyDraw(...))
      if not modernUiActive() then drawNativeCompatibility() end
      return unpack_(result, 1, result.n)
    end
  end

  -- -----------------------------------------------------------------------
  -- Reusable TM consumption
  --
  -- FireRed removes a TM only after teaching succeeds. In the normal UI that
  -- removal happens while PartyMenu is still open with PartyMenu._item set to
  -- the machine being taught. Suppress exactly that matching removal. Selling
  -- and tossing happen outside this context and therefore remain untouched.
  if not dispatch.bagRemovePatched then
    dispatch.bagRemovePatched = true
    dispatch.baseBagRemove = Bag.remove
    Bag.remove = function(bag, id, qty, ...)
      if isTM(id) then
        local partyOwnsTeach = PartyMenu
          and PartyMenu.isOpen and PartyMenu.isOpen()
          and PartyMenu._item ~= nil
          and sameItem(PartyMenu._item, id)
        local directTeach = dispatch.directTmDepth > 0
          and dispatch.directTmItem ~= nil
          and sameItem(dispatch.directTmItem, id)
        if partyOwnsTeach or directTeach then
          -- Match Bag.remove's successful return without changing inventory.
          return true
        end
      end
      return dispatch.baseBagRemove(bag, id, qty, ...)
    end
  end

  -- Non-UI callers can still use ItemUse.useTm directly. Mark only the
  -- duration of that call so its synchronous successful TM consume is skipped.
  if not dispatch.itemUseTmPatched then
    dispatch.itemUseTmPatched = true
    dispatch.baseUseTm = ItemUse.useTm
    ItemUse.useTm = function(session, bag, id, partySlot, ...)
      if not isTM(id) then
        return dispatch.baseUseTm(session, bag, id, partySlot, ...)
      end
      dispatch.directTmDepth = dispatch.directTmDepth + 1
      local prev = dispatch.directTmItem
      dispatch.directTmItem = id
      local result = pack(pcall(dispatch.baseUseTm, session, bag, id, partySlot, ...))
      dispatch.directTmItem = prev
      dispatch.directTmDepth = math.max(0, dispatch.directTmDepth - 1)
      if not result[1] then error(result[2], 0) end
      return unpack_(result, 2, result.n)
    end
  end

  -- -----------------------------------------------------------------------
  -- Forgettable HM during the normal move-learning flow only.
  --
  -- Game3 protects HMs in Pokemon.replaceMove, LearnMove and SummaryMenu via
  -- Pokemon.isHmMove(). Keep the protection everywhere else, but report false
  -- while LearnMove.begin owns an active learn/replace flow. This mirrors the
  -- Gen2 mod's scope: move learning can replace an HM; unrelated screens do
  -- not gain a global HM-delete bypass.
  if not dispatch.hmMovePatched then
    dispatch.hmMovePatched = true
    dispatch.baseIsHmMove = Pokemon.isHmMove
    Pokemon.isHmMove = function(moveId)
      if dispatch.hmForgetDepth > 0 then return false end
      return dispatch.baseIsHmMove(moveId)
    end
  end

  if not dispatch.learnMovePatched then
    dispatch.learnMovePatched = true
    dispatch.baseLearnBegin = LearnMove.begin
    LearnMove.begin = function(opts, ...)
      opts = opts or {}
      local wrapped = {}
      for k, v in pairs(opts) do wrapped[k] = v end
      local baseDone = opts.onDone
      local finished = false
      local function release(...)
        if not finished then
          finished = true
          dispatch.hmForgetDepth = math.max(0, dispatch.hmForgetDepth - 1)
        end
        if baseDone then return baseDone(...) end
      end
      wrapped.onDone = release
      dispatch.hmForgetDepth = dispatch.hmForgetDepth + 1
      local result = pack(pcall(dispatch.baseLearnBegin, wrapped, ...))
      if not result[1] then
        release(false)
        error(result[2], 0)
      end
      -- begin() may complete synchronously and call wrapped.onDone itself.
      return unpack_(result, 2, result.n)
    end
  end

  -- Compatibility preview for TM/HM target selection. Higher hook priority
  -- makes this paint after Modern UI's render.hud presenter.
  mod.hooks:wrap("render.hud", function(next, game, viewport)
    local result = next(game, viewport)
    if modernUiActive() then drawCompatibilityOverlay(viewport) end
    return result
  end, 200)

  mod.exports.isMachine = isMachine
  mod.exports.isTM = isTM
  mod.exports.isHM = isHM
  mod.exports.machineLabel = machineLabel
  mod.exports.compatibility = compatibility
  mod.exports.version = "2.0.2"
  mod.exports.generation = 3
  mod.exports.supportedGames = { "firered" }

  if mod.log and mod.log.info then
    mod.log:info("Reusable Machines Gen 3 installed: reusable TM teaching, HM replacement, and TM/HM compatibility preview")
  end
end
