# Changelog

## 2.0.2
- Added immediate TM/HM compatibility preview on the Party target screen.
- Every Pokémon now shows CAN LEARN, LEARNED, NOT ABLE, or EGG before selection.
- Added the selected machine + move name to the Party header overlay.
- Overlay is presentation-only and drawn after Modern UI, preserving native input/state.
- Kept reusable TM and forgettable-HM behavior from v2.0.1 unchanged.


## 2.0.1

- Port nativo a FireRed / Game3.
- Target esclusivo `firered`.
- TM01-TM50 riutilizzabili dopo insegnamento riuscito.
- Vendita/toss delle TM non alterati.
- HM sostituibili durante il normale flusso LearnMove senza disabilitare globalmente la protezione HM.
- Compatibilità con UI Game3/Modern UI mantenendo i menu engine-owned.
- ID/namespace separato `reusable_machines_gen3` e guardie anti-doppia patch.
