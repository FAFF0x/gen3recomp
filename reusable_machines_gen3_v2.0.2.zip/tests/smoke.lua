package.path = '/mnt/data/reusable_machines_v202_work/?.lua;' .. package.path

local bagRemoveCalls = 0
local Bag = {}
function Bag.remove(bag,id,qty) bagRemoveCalls=bagRemoveCalls+1; bag[id]=(bag[id] or 0)-(qty or 1); return true end

local ItemsData = {}
function ItemsData.toNumericId(x) return tonumber(x) end
function ItemsData.isTm(id) local n=tonumber(id); return n and n>=289 and n<=346 or false end
function ItemsData.isHm(id) local n=tonumber(id); return n and n>=339 and n<=346 or false end
function ItemsData.tmNumber(id) local n=tonumber(id); if not n then return nil end; if n>=339 then return n-338 end; return n-288 end
function ItemsData.displayName(id) return tostring(id) end

local Pokemon = {}
function Pokemon.moveFromTmItem(id) return tonumber(id)==289 and 5 or tonumber(id)==339 and 15 or nil end
function Pokemon.moveName(id) return id==5 and 'MEGA PUNCH' or id==15 and 'CUT' or 'MOVE' end
function Pokemon.knowsMove(mon,id) for _,m in ipairs(mon.moves or {}) do if m==id then return true end end return false end
function Pokemon.canLearnTmItem(species,id) return tonumber(species)==1 and tonumber(id)==289 end
function Pokemon.isHmMove(id) return tonumber(id)==15 end

local ItemUse = {}
function ItemUse.useTm(session,bag,id,slot) Bag.remove(bag,id,1); return true,'tm','ok' end
local PartyMenu = {open=false,mode='list',_party={},draw=function() return 'drawn' end}
function PartyMenu.isOpen() return PartyMenu.open end
local LearnMove = {}
function LearnMove.begin(opts) if opts.onDone then opts.onDone(true) end end
local Stack = {top=function() return {id='party'} end}
local FrlgFont = {COLOR={WHITE={}},draw=function() end}

package.preload['src.core.game3.items_data']=function() return ItemsData end
package.preload['src.core.game3.bag']=function() return Bag end
package.preload['src.core.game3.pokemon']=function() return Pokemon end
package.preload['src.core.game3.item_use']=function() return ItemUse end
package.preload['src.ui.game3.party_menu']=function() return PartyMenu end
package.preload['src.core.game3.battle.learn_move']=function() return LearnMove end
package.preload['src.ui.game3.stack']=function() return Stack end
package.preload['src.ui.game3.frlg_font']=function() return FrlgFont end

local hooks = {}
local mod = {
  id='reusable_machines_gen3', exports={},
  hooks={wrap=function(self,name,cb,priority) hooks[name]={cb=cb,priority=priority} end},
  find=function(self,id) if id=='gen3_modern_ui' then return {exports={isActive=function() return true end}} end end,
  log={info=function() end}
}
local entry = assert(loadfile('/mnt/data/reusable_machines_v202_work/main.lua'))()
entry(mod)
assert(mod.exports.version=='2.0.2')
assert(mod.exports.generation==3)
assert(mod.exports.compatibility({species=1,moves={}},289)=='able')
local k,l=mod.exports.compatibility({species=1,moves={}},289); assert(k=='able' and l=='CAN LEARN')
k,l=mod.exports.compatibility({species=1,moves={5}},289); assert(k=='learned' and l=='LEARNED')
k,l=mod.exports.compatibility({species=2,moves={}},289); assert(k=='unable' and l=='NOT ABLE')
k,l=mod.exports.compatibility({species=1,moves={},isEgg=true},289); assert(k=='egg' and l=='EGG')
assert(hooks['render.hud'] and hooks['render.hud'].priority==200)
-- TM teaching remains reusable when PartyMenu owns the item.
local bag={[289]=1}; PartyMenu.open=true; PartyMenu.mode='use'; PartyMenu._item=289
Bag.remove(bag,289,1); assert(bag[289]==1 and bagRemoveCalls==0)
-- Outside teaching context it is removable.
PartyMenu.open=false; Bag.remove(bag,289,1); assert(bag[289]==0 and bagRemoveCalls==1)
print('reusable_machines_gen3_v2.0.2 smoke: ok')
