# Static contract

- manifest.games is exactly ["firered"]
- no `src.*.gen2` executable references
- TM consumption is suppressed only while PartyMenu teaches the matching TM or during direct ItemUse.useTm
- HM forget bypass is scoped to active LearnMove.begin flows
- no custom UI replaces TM Case, Party Menu, Summary, or LearnMove
