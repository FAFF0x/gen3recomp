-- Lightweight contract test for the Gen 3 port.
local calls = {}
local mon = { species = 25, level = 20, nickname = nil, personality = 1234 }

local PartyMenu = {
  _party = { mon }, cursor = 1, mode = "list", _battle = false,
  actionCursor = 1, ACTIONS = {},
}
function PartyMenu.handleInput(input)
  if PartyMenu.mode == "list" and input:wasPressed("a") then
    PartyMenu.ACTIONS = { "SUMMARY", "SWITCH", "ITEM", "CANCEL" }
    PartyMenu.mode = "action"
    PartyMenu.actionCursor = 1
  end
end
function PartyMenu.reloadSprites() end

local namingOpts
local namingOpen = false
local Naming = {
  monTitle = function(n) return n .. "'s nickname?" end,
  open = function(opts) namingOpts = opts; namingOpen = true end,
  isOpen = function() return namingOpen end,
}
local Pokemon = {
  speciesOf = function(m) return m.species end,
  name = function(id) return id == 25 and "PIKACHU" or "POKEMON" end,
}

package.loaded["src.ui.game3.party_menu"] = PartyMenu
package.loaded["src.ui.game3.naming"] = Naming
package.loaded["src.core.game3.pokemon"] = Pokemon
package.loaded["src.core.game3.audio"] = { playSe = function() end }

local mod = {
  generation = 3,
  log = { info = function() end, warn = function() end, error = function(_, msg) error(msg) end },
  exports = {},
}

local entry = assert(loadfile(arg[1]))
entry()(mod)

local function input(key)
  return { wasPressed = function(_, k) return k == key end }
end

PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "action", "party action popup did not open")
assert(table.concat(PartyMenu.ACTIONS, ",") == "SUMMARY,RENAME,SWITCH,ITEM,CANCEL",
  "RENAME not inserted after SUMMARY")

PartyMenu.actionCursor = 2
PartyMenu.handleInput(input("a"))
assert(namingOpts and namingOpts.template == "NICKNAME", "native Gen 3 naming screen not opened")
assert(namingOpts.maxLen == 10, "nickname length must be 10")
assert(namingOpts.species == 25 and namingOpts.seed == "PIKACHU", "naming context mismatch")

-- While Naming is open, HUD may fall through to PartyMenu. The wrapper must
-- swallow every such dispatch so cursor/mode cannot move under the keyboard.
PartyMenu.mode = "action"
PartyMenu.actionCursor = 4
PartyMenu.handleInput(input("down"))
assert(PartyMenu.actionCursor == 4 and PartyMenu.mode == "action",
  "PartyMenu received leaked input while Naming was open")

namingOpen = false
namingOpts.onDone("SPARKY")
-- Confirm A can reach PartyMenu later in the same frame; swallow it once.
PartyMenu.mode = "list"
PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "list", "confirm A leaked through after Naming closed")
-- Next frame input resumes normally.
PartyMenu.handleInput(input("a"))
assert(PartyMenu.mode == "action", "PartyMenu did not resume after one swallowed edge")
assert(mon.nickname == "SPARKY", "nickname was not stored")

-- Species name means clear nickname.
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "RENAME", "SWITCH", "ITEM", "CANCEL" }
PartyMenu.actionCursor = 2
PartyMenu.handleInput(input("a"))
namingOpen = false
namingOpts.onDone("PIKACHU")
assert(mon.nickname == nil, "species name should clear nickname")
-- swallow the post-confirm PartyMenu edge before continuing the contract
PartyMenu.handleInput(input("none"))

-- No duplicate row.
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "NICKNAME", "SWITCH", "ITEM", "CANCEL" }
PartyMenu.actionCursor = 1
PartyMenu.handleInput(input("none"))
local n = 0
for _, a in ipairs(PartyMenu.ACTIONS) do if a == "RENAME" or a == "NICKNAME" then n = n + 1 end end
assert(n == 1, "duplicate rename action inserted")

-- Egg and battle menus must remain unchanged.
mon.isEgg = true
PartyMenu.mode = "action"
PartyMenu.ACTIONS = { "SUMMARY", "CANCEL" }
PartyMenu.handleInput(input("none"))
assert(#PartyMenu.ACTIONS == 2, "RENAME inserted for egg")
mon.isEgg = false
PartyMenu._battle = true
PartyMenu.ACTIONS = { "SUMMARY", "CANCEL" }
PartyMenu.handleInput(input("none"))
assert(#PartyMenu.ACTIONS == 2, "RENAME inserted in battle")

print("nickname-changer-gen3-contract-ok")
