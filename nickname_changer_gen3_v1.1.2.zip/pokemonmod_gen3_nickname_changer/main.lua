-- Nickname Changer - Gen 3 v1.1.2
-- FireRed-only port of FAFF0x's Nickname Changer.
--
-- FireRed does not currently expose its native PartyMenu action list through
-- ui.party.submenu, so this port decorates the live Gen 3 PartyMenu itself.
-- The patch is deliberately narrow: it only inserts/handles RENAME and leaves
-- every stock field-move, SUMMARY, SWITCH, ITEM and CANCEL action untouched.

local VERSION = "1.1.2"
local MOD_ID = "pokemonmod_gen3_nickname_changer"
local LABEL = "RENAME"
local SENTINEL = "__pokemonmod_gen3_nickname_changer_v112"

-- The native FireRed Naming screen is pumped by game3 Runtime/Battle instead
-- of exposing Stack.handleInput.  When it is opened on top of PartyMenu, HUD
-- can otherwise fall through and feed the same key press to PartyMenu below.
-- Keep an explicit modal ownership flag and swallow the one PartyMenu input
-- edge immediately after Naming closes.
local renameActive = false
local swallowPartyInputOnce = false

local function upper(value)
  return tostring(value or ""):upper()
end

local function isRenameLabel(value)
  local s = upper(value)
  return s == "RENAME" or s == "NICKNAME"
    or s:find("RENAME", 1, true) ~= nil
    or s:find("NICKNAME", 1, true) ~= nil
end

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local okParty, PartyMenu = pcall(require, "src.ui.game3.party_menu")
  local okNaming, Naming = pcall(require, "src.ui.game3.naming")
  local okPokemon, Pokemon = pcall(require, "src.core.game3.pokemon")

  if not okParty or type(PartyMenu) ~= "table"
      or not okNaming or type(Naming) ~= "table"
      or not okPokemon or type(Pokemon) ~= "table" then
    mod.log:error("FireRed nickname runtime is unavailable")
    return
  end

  local function speciesName(mon)
    if not mon then return "POKEMON" end
    local species = Pokemon.speciesOf and Pokemon.speciesOf(mon)
      or tonumber(mon.species or mon.speciesId)
    local name = species and Pokemon.name and Pokemon.name(species)
    return (name and tostring(name)) or "POKEMON"
  end

  local function currentMon()
    local party = PartyMenu._party
    local idx = tonumber(PartyMenu.cursor) or 1
    return type(party) == "table" and party[idx] or nil
  end

  local function hasRename(actions)
    if type(actions) ~= "table" then return false end
    for _, action in ipairs(actions) do
      if isRenameLabel(action) then return true end
    end
    return false
  end

  local function canRename()
    local mon = currentMon()
    if not mon or mon.isEgg then return false end
    if PartyMenu._battle then return false end
    return true
  end

  -- FireRed dynamically rebuilds ACTIONS whenever A is pressed on a party
  -- Pokémon. Insert RENAME into that finished list rather than replacing it.
  local function ensureRenameAction()
    if PartyMenu.mode ~= "action" or not canRename() then return false end
    local actions = PartyMenu.ACTIONS
    if type(actions) ~= "table" then return false end
    if hasRename(actions) then return true end

    local insertAt = nil
    for i, action in ipairs(actions) do
      if upper(action) == "SUMMARY" then
        insertAt = i + 1
        break
      end
    end
    if not insertAt then
      for i, action in ipairs(actions) do
        if upper(action) == "CANCEL" then
          insertAt = i
          break
        end
      end
    end
    table.insert(actions, insertAt or (#actions + 1), LABEL)
    return true
  end

  local function openNamingScreen(mon)
    if not mon or mon.isEgg then return false end

    local species = Pokemon.speciesOf and Pokemon.speciesOf(mon)
      or tonumber(mon.species or mon.speciesId)
    local speciesLabel = speciesName(mon)
    local oldNickname = mon.nickname
    local seed = (type(oldNickname) == "string" and oldNickname ~= "")
      and oldNickname or speciesLabel

    PartyMenu.mode = "list"
    PartyMenu.actionCursor = 1
    renameActive = true
    swallowPartyInputOnce = false

    Naming.open({
      template = "NICKNAME",
      maxLen = 10,
      species = species,
      personality = mon.personality,
      seed = seed,
      title = Naming.monTitle and Naming.monTitle(speciesLabel)
        or (speciesLabel .. "'s nickname?"),
      onDone = function(name)
        -- Naming.close() invokes this callback during the same logic frame as
        -- the confirm A press.  Mark the modal as finished now, but swallow
        -- exactly one PartyMenu dispatch so that confirm press cannot also
        -- reopen/activate the menu underneath.
        renameActive = false
        swallowPartyInputOnce = true

        -- nil / empty means cancel: keep the current nickname unchanged.
        if type(name) == "string" and name ~= "" then
          -- Entering the species name restores the normal non-nicknamed state,
          -- matching FireRed's catch flow instead of freezing the species name
          -- across future evolutions.
          if upper(name) == upper(speciesLabel) then
            mon.nickname = nil
          else
            mon.nickname = name
          end
          mod.log:info("Renamed %s to %s", tostring(speciesLabel), tostring(name))
        end
        PartyMenu.mode = "list"
        PartyMenu.actionCursor = 1
        if PartyMenu.reloadSprites then pcall(PartyMenu.reloadSprites) end
      end,
    })
    return true
  end

  if not PartyMenu[SENTINEL] then
    if type(PartyMenu.handleInput) ~= "function" then
      mod.log:error("FireRed PartyMenu input API changed; RENAME cannot be installed")
      return
    end

    local previousHandleInput = PartyMenu.handleInput

    PartyMenu.handleInput = function(input)
      -- Naming is a modal Stack layer, but FireRed's HUD falls through to
      -- PartyMenu because Naming intentionally has no handleInput method.
      -- Runtime/Battle already delivers input to Naming.update(), so the
      -- underlying PartyMenu must stay completely inert while our rename is
      -- active.
      if renameActive and Naming.isOpen and Naming.isOpen() then
        return
      end

      -- Consume the confirm edge once after Naming closes. Without this, the
      -- same A that selects OK is seen by PartyMenu later in the same frame.
      if swallowPartyInputOnce then
        swallowPartyInputOnce = false
        return
      end

      -- Keep the injected row present while the action popup is alive. This
      -- also makes Modern UI pick it up because its presenter reads ACTIONS.
      if PartyMenu.mode == "action" then
        ensureRenameAction()
        local actions = PartyMenu.ACTIONS or {}
        local selected = actions[tonumber(PartyMenu.actionCursor) or 1]
        if isRenameLabel(selected) and input and input.wasPressed
            and input:wasPressed("a") and canRename() then
          pcall(function() require("src.core.game3.audio").playSe(5) end)
          openNamingScreen(currentMon())
          return
        end
      end

      local result = previousHandleInput(input)

      -- The stock handler builds ACTIONS on the same A press that changes
      -- list -> action, so decorate it after vanilla has completed that frame.
      if PartyMenu.mode == "action" then
        ensureRenameAction()
      end
      return result
    end

    PartyMenu[SENTINEL] = true
  end

  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.game = "firered"
  mod.exports.rename = function(mon)
    return openNamingScreen(mon)
  end
  mod.exports.isInstalled = function()
    return PartyMenu[SENTINEL] == true
  end
  mod.exports.isRenaming = function()
    return renameActive and Naming.isOpen and Naming.isOpen() or false
  end
end
