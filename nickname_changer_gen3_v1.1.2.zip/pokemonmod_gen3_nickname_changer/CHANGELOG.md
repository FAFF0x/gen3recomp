# Changelog

## 1.1.2

- Fixed FireRed input leaking through the native Naming screen into the PartyMenu underneath.
- D-pad/A/B input during rename no longer moves or activates the hidden party action menu.
- Consumes the confirm input once after Naming closes so the final A press cannot immediately reopen/trigger PartyMenu.
- Keeps Modern UI compatibility and the existing RENAME flow unchanged.

## 1.1.1

- Ported Nickname Changer exclusively to FireRed / Gen 3.
- Replaced all Gen 2 PartyMenu and naming-screen dependencies with the native FireRed `game3` modules.
- Added RENAME after SUMMARY in the FireRed party action popup.
- Kept contextual field moves and all stock party actions intact.
- Added duplicate RENAME/NICKNAME detection for compatibility with equivalent mods.
- RENAME is disabled in battle and for Eggs.
- Uses FireRed's native 10-character naming screen.
- Entering the species name clears the custom nickname instead of pinning that name across evolution.
- Added compatibility with `gen3_modern_ui` through the shared live PartyMenu action list.
- Uses a generation-specific manifest id so it does not collide with the Gen 2 package.
