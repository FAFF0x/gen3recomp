# Changelog

## 1.0.0

- Initial FireRed-only release.
- Globally disables the modal HELP screen opened by L/R.
- Preserves L/R input for native menus and other mods.
- Re-applies the disable state after FireRed resets the Help subsystem.
- Closes an already-open HELP screen if the mod becomes active while HELP is visible.
