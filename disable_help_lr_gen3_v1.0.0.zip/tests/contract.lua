local wrappers = {}
local events = {}
local logs = {}

local Help = {
  enabled = true,
  open = true,
  closes = 0,
}
function Help.close()
  Help.closes = Help.closes + 1
  Help.open = false
end

package.loaded["src.ui.game3.help_system"] = Help

local mod = {
  generation = 3,
  hooks = {
    wrap = function(_, name, fn) wrappers[name] = fn end,
  },
  events = {
    on = function(_, name, fn) events[name] = fn end,
  },
  exports = {},
  log = {
    info = function(_, fmt, ...)
      logs[#logs + 1] = string.format(fmt, ...)
    end,
  },
}

local entry = assert(loadfile("main.lua"))()
entry(mod)

assert(Help.enabled == false, "HELP must be disabled immediately")
assert(Help.open == false, "already-open HELP must be closed")
assert(Help.closes == 1, "HELP close should run once on load")
assert(type(wrappers["core.update"]) == "function", "core.update wrapper missing")
assert(type(events["game.ready"]) == "function", "game.ready guard missing")
assert(mod.exports.fireRedOnly == true, "FireRed export missing")
assert(mod.exports.shouldersPreserved == true, "L/R preservation export missing")
assert(mod.exports.isHelpDisabled() == true, "status export should report disabled")

-- Simulate FireRed Help.reset() happening during vanilla update.
Help.enabled = true
local nextSawDisabled = false
local result = wrappers["core.update"](function(game, dt)
  nextSawDisabled = (Help.enabled == false)
  Help.enabled = true
  return "ok"
end, {}, 1/60)

assert(nextSawDisabled, "HELP must already be disabled before vanilla update")
assert(result == "ok", "wrapper must preserve core.update return")
assert(Help.enabled == false, "HELP must be re-disabled after a reset in the frame")

-- Simulate a later game.ready transition.
Help.enabled = true
events["game.ready"]({})
assert(Help.enabled == false, "game.ready must re-disable HELP")

print("contract-ok")
