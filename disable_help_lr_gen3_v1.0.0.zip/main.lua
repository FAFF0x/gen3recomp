-- Disable L/R Help Gen 3 for Pokemon Recomp / FireRed
-- v1.0.0
--
-- Disables only FireRed's modal L/R HELP trigger. The L/R input itself is
-- untouched, so shoulder buttons remain available to the game and other mods.

local VERSION = "1.0.0"
local MOD_ID = "disable_help_lr_gen3"
local HELP_MODULE = "src.ui.game3.help_system"

return function(mod)
  if (mod.generation or 3) ~= 3 then return end

  local cachedHelp = nil

  local function helpModule()
    if type(cachedHelp) == "table" then return cachedHelp end
    local loaded = package.loaded[HELP_MODULE]
    if type(loaded) == "table" then
      cachedHelp = loaded
      return cachedHelp
    end
    local ok, value = pcall(require, HELP_MODULE)
    if ok and type(value) == "table" then
      cachedHelp = value
      return cachedHelp
    end
    return nil
  end

  local function disableHelp(closeOpenScreen)
    local Help = helpModule()
    if not Help then return false end

    -- help_system.lua checks this flag before reacting to L/R.
    Help.enabled = false

    -- If the mod is enabled while HELP is already on screen, dismiss it once.
    if closeOpenScreen and Help.open and type(Help.close) == "function" then
      pcall(Help.close)
      Help.enabled = false
    end
    return true
  end

  -- Disable immediately on mod load.
  disableHelp(true)

  -- Re-apply on every frame BEFORE FireRed runs Help.update(). This is the
  -- important part: Help.reset() deliberately restores enabled=true when the
  -- game/session is reset, so a one-time assignment would not stay permanent.
  mod.hooks:wrap("core.update", function(nextFn, game, dt)
    disableHelp(true)
    local result = nextFn(game, dt)
    -- A title/session transition may call Help.reset() during the frame.
    -- Re-assert after vanilla update so the next frame also starts disabled.
    disableHelp(true)
    return result
  end)

  -- game.ready is an extra guard for new/load-game transitions. It does not
  -- consume any input and therefore cannot interfere with L/R functionality.
  if mod.events and type(mod.events.on) == "function" then
    mod.events:on("game.ready", function()
      disableHelp(true)
    end)
  end

  mod.exports.version = VERSION
  mod.exports.generation = 3
  mod.exports.fireRedOnly = true
  mod.exports.disablesHelpTrigger = true
  mod.exports.shouldersPreserved = true
  mod.exports.isHelpDisabled = function()
    local Help = helpModule()
    return Help ~= nil and Help.enabled == false
  end

  if mod.log and type(mod.log.info) == "function" then
    mod.log:info("%s v%s installed: FireRed L/R HELP trigger disabled", MOD_ID, VERSION)
  end
end
