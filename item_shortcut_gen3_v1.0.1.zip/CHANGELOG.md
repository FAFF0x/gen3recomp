# Changelog

## 1.0.1

- Ported Item Shortcut from Gen 2 to the FireRed Gen 3 runtime.
- Changed the game target from `gen2` to `firered` only.
- Added a unique Gen3 manifest/save identity to avoid import/save conflicts with Gen2 and legacy Item Shortcut packages.
- Replaced Gen2 Pack/World/Game2 item dispatch with FireRed `Bag`, `ItemUse`, Party Menu and VS Seeker paths.
- Replaced direct Game method patches with FireRed raw input hooks (`input.key`, `input.gamepad`).
- Added a native Gen3 shortcut screen with five slots, use/change/FAST/clear actions and control remapping.
- Added direct assignment from the FireRed BAG by pressing the shortcut-menu binding on the highlighted item.
