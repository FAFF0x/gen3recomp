local root = assert(os.getenv('ITEM_SHORTCUT_ROOT'))

local stack = { layers = {} }
function stack.push(id, mod, opts) stack.layers[#stack.layers+1] = {id=id,mod=mod,opts=opts} end
function stack.pop(id)
  for i=#stack.layers,1,-1 do if not id or stack.layers[i].id==id then table.remove(stack.layers,i); return true end end
  return false
end
function stack.has(id) for _,v in ipairs(stack.layers) do if v.id==id then return true end end return false end
function stack.busy() return #stack.layers > 0 end
package.preload['src.ui.game3.stack'] = function() return stack end
package.preload['src.ui.game3.window'] = function() return {cursorPx=function() end} end
package.preload['src.ui.game3.frlg_font'] = function()
  return {COLOR={WHITE={},NORMAL={},BLUE={},DARK_GRAY={}},draw=function() end,measure=function(s) return #tostring(s)*6 end}
end
local bag = {}
function bag.get(b,id) return (b.items and b.items[id]) or 0 end
function bag.listPocket(b,pocket)
  local out={}
  for id,qty in pairs(b.items or {}) do out[#out+1]={id=id,qty=qty,name='ITEM'..tostring(id),description='DESC'} end
  return out
end
package.preload['src.core.game3.bag'] = function() return bag end
local items = {
  BAG_POCKET_ORDER={'ITEMS','KEY_ITEMS','POKE_BALLS','TM_CASE','BERRY_POUCH'},
  toNumericId=function(id) return tonumber(id) end,
  displayName=function(id) return 'ITEM'..tostring(id) end,
  description=function(id) return 'DESC'..tostring(id) end,
}
package.preload['src.core.game3.items_data'] = function() return items end
package.preload['src.core.game3.item_use'] = function()
  return {needsPartyTarget=function(id) return false end,useField=function() return true,'repel','ok' end}
end
package.preload['src.core.game3.runtime'] = function() return {getSession=function() return nil end} end
package.preload['src.core.game3.field'] = function() return {locked=false} end
package.preload['src.core.game3.battle'] = function() return {isActive=function() return false end} end
package.preload['src.core.game3.audio'] = function() return {playSe=function() end} end
package.preload['src.ui.game3.hud'] = function() return {openMessage=function() end} end

local saved = {}
local hooks = {}
local mod = {
  generation=3,
  save={get=function(_,k) return saved[k] end,set=function(_,k,v) saved[k]=v end},
  hooks={wrap=function(_,name,fn) hooks[name]=fn end},
  log={warn=function() end,info=function() end},
  exports={},
  find=function() return nil end,
}
local init = assert(loadfile(root..'/main.lua'))()
init(mod)
assert(type(hooks['input.key'])=='function','input.key missing')
assert(type(hooks['input.gamepad'])=='function','input.gamepad missing')
assert(mod.exports.active==true,'mod not active')
assert(mod.exports.version=='1.0.1','version mismatch')
assert(mod.exports.assign(1,13),'assign failed')
assert(mod.exports.assign(2,360),'assign second failed')
local slots=mod.exports.getSlots()
assert(slots[1]==13 and slots[2]==360,'slot persistence failed')
assert(mod.exports.setFastSlot(2),'FAST set failed')
assert(mod.exports.getFastSlot()==2,'FAST mismatch')
local game={phase='field',session={bag={items={[13]=3,[360]=1}},party={}}}
assert(mod.exports.open(game)==true,'open failed')
assert(stack.has('item_shortcut_gen3'),'UI not pushed')
print('contract-ok')
